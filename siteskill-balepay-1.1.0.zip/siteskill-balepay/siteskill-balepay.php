<?php
/**
 * Plugin Name: درگاه بله پی اسکیل
 * Description: درگاه کامل ووکامرس برای پرداخت مستقیم بله و کارت به کارت، اتصال امن مشتری، دریافت رسید و مدیریت تراکنش‌ها.
 * Version: 1.1.0
 * Author: SiteSkill.ir
 * Author URI: https://siteskill.ir
 * License: GPL-2.0-or-later
 * Text Domain: siteskill-balepay
 * Requires PHP: 7.4
 * Requires at least: 6.0
 * WC requires at least: 7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'EBP_VERSION', '1.1.0' );
define( 'EBP_FILE', __FILE__ );
define( 'EBP_PATH', plugin_dir_path( __FILE__ ) );
define( 'EBP_URL', plugin_dir_url( __FILE__ ) );

/**
 * Is this site licensed for Bale Pay Skill?
 *
 * Reads cached licence state only (no network call), so it is safe to call
 * inside any hook. Never call it while files are still loading — the licence
 * object is created during boot(), so only hooks that fire at or after
 * plugins_loaded may rely on it.
 */
function ebp_licensed() {
	return isset( $GLOBALS['ebp_license'] ) && $GLOBALS['ebp_license']->is_valid();
}

require_once EBP_PATH . 'includes/class-ebp-crypto.php';
require_once EBP_PATH . 'includes/class-ebp-settings.php';
require_once EBP_PATH . 'includes/class-ebp-db.php';
require_once EBP_PATH . 'includes/class-ebp-bale-api.php';
require_once EBP_PATH . 'includes/class-ebp-linking.php';
require_once EBP_PATH . 'includes/class-ebp-webhook.php';
require_once EBP_PATH . 'includes/class-ebp-admin.php';
require_once EBP_PATH . 'includes/class-ebp-receipts.php';
require_once EBP_PATH . 'includes/class-ebp-lifecycle.php';
require_once EBP_PATH . 'includes/class-ebp-notifier.php';

final class EBP_Plugin {
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		register_activation_hook( EBP_FILE, array( 'EBP_DB', 'activate' ) );
		register_deactivation_hook( EBP_FILE, array( 'EBP_Lifecycle', 'deactivate' ) );
		add_action( 'before_woocommerce_init', array( $this, 'declare_compatibility' ) );
		add_action( 'plugins_loaded', array( $this, 'boot' ), 20 );
	}

	public function declare_compatibility() {
		if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', EBP_FILE, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', EBP_FILE, true );
		}
	}

	public function boot() {
		if ( EBP_VERSION !== get_option( 'ebp_db_version' ) ) {
			EBP_DB::activate();
		}

		// The admin surface always loads so the licence screen and the
		// "enter your licence" prompt stay reachable even when locked.
		new EBP_Admin();

		// The licence client is created AFTER the plugin's own menu so its
		// «لایسنس» page is registered second and lands beneath the Bale Pay
		// menu instead of above the plugin's own screens.
		require_once EBP_PATH . 'includes/class-ssk-license.php';
		$GLOBALS['ebp_license'] = new SSK_License(
			array(
				'slug'    => 'siteskill-balepay',
				'name'    => 'درگاه بله پی اسکیل',
				'file'    => EBP_FILE,
				'version' => EBP_VERSION,
				'parent'  => EBP_Admin::PAGE,
			)
		);

		// Full lock. Without a valid licence nothing operational is registered:
		// no gateways, no webhook, no receipt handling, no front-end hooks. The
		// rest of the store keeps working — the Bale Pay methods simply are not
		// offered — and no request ever fatals or white-screens over a missing
		// licence. The moment a valid key is entered the next request boots the
		// plugin in full.
		if ( ! ebp_licensed() ) {
			return;
		}

		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Payment_Gateway' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_notice' ) );
			return;
		}

		require_once EBP_PATH . 'includes/class-wc-gateway-ebp.php';
		require_once EBP_PATH . 'includes/class-wc-gateway-ebp-card.php';
		add_filter( 'woocommerce_payment_gateways', array( $this, 'register_gateway' ) );

		new EBP_Linking();
		new EBP_Webhook();
		new EBP_Receipts();
		new EBP_Lifecycle();

		add_action( 'woocommerce_blocks_payment_method_type_registration', array( $this, 'register_blocks' ) );
	}

	public function register_gateway( $gateways ) {
		$gateways[] = 'WC_Gateway_SiteSkill_BalePay';
		$gateways[] = 'WC_Gateway_EBP_Card';
		return $gateways;
	}

	public function register_blocks( $registry ) {
		if ( ! class_exists( '\\Automattic\\WooCommerce\\Blocks\\Payments\\Integrations\\AbstractPaymentMethodType' ) ) {
			return;
		}
		require_once EBP_PATH . 'includes/class-ebp-blocks.php';
		$registry->register( new EBP_Blocks() );
		$registry->register( new EBP_Card_Blocks() );
	}

	public function woocommerce_notice() {
		if ( current_user_can( 'activate_plugins' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'درگاه بله پی اسکیل برای اجرا به ووکامرس نیاز دارد.', 'siteskill-balepay' ) . '</p></div>';
		}
	}
}

EBP_Plugin::instance();
