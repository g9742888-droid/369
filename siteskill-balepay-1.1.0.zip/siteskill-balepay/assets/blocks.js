( function () {
	'use strict';

	const registry = window.wc && window.wc.wcBlocksRegistry;
	const settingsApi = window.wc && window.wc.wcSettings;
	const element = window.wp && window.wp.element;
	const htmlEntities = window.wp && window.wp.htmlEntities;
	if ( ! registry || ! settingsApi || ! element ) {
		return;
	}

	const data = settingsApi.getSetting( 'siteskill_balepay_data', {} );
	const decode = htmlEntities ? htmlEntities.decodeEntities : ( value ) => value;
	const el = element.createElement;

	const Content = () => {
		const children = [ el( 'p', { key: 'desc' }, decode( data.description || '' ) ) ];
		if ( ! data.loggedIn ) {
			children.push( el( 'p', { key: 'login', className: 'woocommerce-error' }, 'برای پرداخت با بله‌پی ابتدا وارد حساب کاربری شوید.' ) );
		} else if ( data.linked ) {
			children.push( el( 'p', { key: 'linked' }, 'حساب بله متصل است؛ فاکتور پس از ثبت سفارش در چت شما ارسال می‌شود.' ) );
		} else {
			children.push(
				el( 'a', { key: 'connect', href: data.connectUrl, target: '_blank', rel: 'noopener noreferrer' }, 'اتصال به ربات بله' ),
				el( 'p', { key: 'code' }, 'کد اتصال: ' + ( data.connectCode || '' ) )
			);
		}
		return el( 'div', { className: 'ebp-block-content' }, children );
	};

	registry.registerPaymentMethod( {
		name: 'siteskill_balepay',
		label: decode( data.title || 'بله پی اسکیل' ),
		ariaLabel: decode( data.title || 'بله پی اسکیل' ),
		content: el( Content ),
		edit: el( Content ),
		canMakePayment: () => true,
		supports: { features: data.supports || [ 'products' ] },
	} );

	const cardData = settingsApi.getSetting( 'siteskill_balepay_card_data', {} );
	const CardContent = () => el( 'div', { className: 'ebp-block-content' }, [
		el( 'p', { key: 'desc' }, decode( cardData.description || '' ) ),
		el( 'p', { key: 'help' }, decode( cardData.instructions || 'پس از ثبت سفارش، اطلاعات کارت مقصد و فرم ارسال رسید نمایش داده می‌شود.' ) ),
	] );
	registry.registerPaymentMethod( {
		name: 'siteskill_balepay_card',
		label: decode( cardData.title || 'کارت به کارت' ),
		ariaLabel: decode( cardData.title || 'کارت به کارت' ),
		content: el( CardContent ),
		edit: el( CardContent ),
		canMakePayment: () => Number( cardData.cardCount || 0 ) > 0,
		supports: { features: cardData.supports || [ 'products' ] },
	} );
}() );
