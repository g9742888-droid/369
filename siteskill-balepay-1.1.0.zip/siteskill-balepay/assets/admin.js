( function () {
	'use strict';
	const form = document.getElementById( 'ebp-card-form' );
	const title = document.getElementById( 'ebp-card-form-title' );
	const cancel = document.querySelector( '.ebp-cancel-edit' );
	const setField = ( name, value ) => {
		if ( ! form ) return;
		const input = form.elements.namedItem( name );
		if ( ! input ) return;
		if ( input.type === 'checkbox' ) input.checked = Boolean( Number( value ) );
		else input.value = value || '';
	};
	document.querySelectorAll( '.ebp-edit-card' ).forEach( ( button ) => {
		button.addEventListener( 'click', () => {
			if ( ! form ) return;
			let card;
			try { card = JSON.parse( button.dataset.card || '{}' ); } catch ( error ) { return; }
			[ 'id', 'label', 'bank_name', 'card_number', 'account_holder', 'iban', 'sort_order', 'is_active' ].forEach( ( key ) => setField( key === 'id' ? 'card_id' : key, card[ key ] ) );
			if ( title ) title.textContent = 'ویرایش کارت مقصد';
			if ( cancel ) cancel.hidden = false;
			form.scrollIntoView( { behavior: window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ? 'auto' : 'smooth', block: 'center' } );
		} );
	} );
	if ( cancel && form ) cancel.addEventListener( 'click', () => {
		form.reset(); setField( 'card_id', '' ); setField( 'is_active', 1 ); cancel.hidden = true;
		if ( title ) title.textContent = 'افزودن کارت مقصد';
	} );
	document.querySelectorAll( '.ebp-confirm-delete' ).forEach( ( link ) => link.addEventListener( 'click', ( event ) => {
		if ( ! window.confirm( 'این کارت غیرفعال شود؟ تراکنش‌های قبلی حفظ می‌شوند.' ) ) event.preventDefault();
	} ) );
	document.querySelectorAll( '.ebp-confirm-reject' ).forEach( ( button ) => button.addEventListener( 'click', ( event ) => {
		if ( ! window.confirm( 'رسید رد و سفارش لغو شود؟' ) ) event.preventDefault();
	} ) );
	document.querySelectorAll( '.ebp-form' ).forEach( ( managedForm ) => managedForm.addEventListener( 'submit', () => {
		const submit = managedForm.querySelector( 'button[type="submit"]' );
		if ( submit ) { submit.disabled = true; submit.textContent = 'در حال ذخیره…'; }
	} ) );
}() );
