<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Gateway_SiteSkill_BalePay extends WC_Payment_Gateway {
	public function __construct() {
		$this->id                 = 'siteskill_balepay';
		$this->has_fields         = true;
		$this->method_title       = 'درگاه بله پی اسکیل';
		$this->method_description = 'ارسال فاکتور پرداخت به چت بلهٔ مشتری و تأیید خودکار سفارش با webhook.';
		$this->supports           = array( 'products' );
		$this->enabled            = EBP_Settings::get( 'enabled', 'yes' );
		$this->title              = EBP_Settings::get( 'title', 'بله پی اسکیل' );
		$this->description        = EBP_Settings::get( 'description', '' );

		$this->form_fields = array(
			'info' => array(
				'title'       => 'تنظیمات',
				'type'        => 'title',
				'description' => 'تنظیمات توکن‌ها و webhook از منوی «ووکامرس ← بله‌پی» انجام می‌شود.',
			),
		);

		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		add_action( 'wp_ajax_ebp_payment_status', array( __CLASS__, 'ajax_payment_status' ) );
		add_action( 'wp_ajax_nopriv_ebp_payment_status', array( __CLASS__, 'ajax_payment_status' ) );
	}

	public function is_available() {
		if ( ! parent::is_available() || ! EBP_Settings::is_configured() ) {
			return false;
		}
		return in_array( get_woocommerce_currency(), array( 'IRR', 'IRT', 'TOMAN' ), true );
	}

	public function payment_fields() {
		wp_enqueue_style( 'ebp-frontend', EBP_URL . 'assets/frontend.css', array(), EBP_VERSION );
		if ( $this->description ) {
			echo wp_kses_post( wpautop( $this->description ) );
		}
		echo EBP_Linking::styles(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo EBP_Linking::render_for_user( get_current_user_id() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function validate_fields() {
		if ( ! is_user_logged_in() ) {
			wc_add_notice( 'برای پرداخت با بله‌پی ابتدا وارد حساب کاربری شوید.', 'error' );
			return false;
		}
		if ( ! EBP_DB::linked_user( get_current_user_id() ) ) {
			wc_add_notice( 'ابتدا حساب خود را به ربات بله متصل کنید و سپس پرداخت را دوباره انجام دهید.', 'error' );
			return false;
		}
		return true;
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wc_add_notice( 'سفارش پیدا نشد.', 'error' );
			return array( 'result' => 'failure' );
		}

		$user_id = get_current_user_id();
		if ( ! $user_id || ( $order->get_customer_id() && (int) $order->get_customer_id() !== (int) $user_id ) ) {
			wc_add_notice( 'حساب کاربری سفارش معتبر نیست.', 'error' );
			return array( 'result' => 'failure' );
		}

		$linked = EBP_DB::linked_user( $user_id );
		if ( ! $linked ) {
			wc_add_notice( 'حساب بله به این حساب کاربری متصل نیست.', 'error' );
			return array( 'result' => 'failure' );
		}

		$existing = EBP_DB::payment_for_order( $order_id );
		if ( $existing && 'sent' === $existing->status && strtotime( $existing->expires_at . ' UTC' ) >= time() ) {
			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_order_received_url(),
			);
		}

		$amount_rial = self::amount_to_rial( $order->get_total(), $order->get_currency() );
		if ( is_wp_error( $amount_rial ) ) {
			wc_add_notice( $amount_rial->get_error_message(), 'error' );
			return array( 'result' => 'failure' );
		}

		$ttl = absint( EBP_Settings::get( 'deadline_minutes', 30 ) ) * MINUTE_IN_SECONDS;
		$payment = EBP_DB::create_payment(
			array(
				'order_id'    => $order_id,
				'wp_user_id'  => $user_id,
				'chat_id'     => $linked->chat_id,
				'amount_rial' => $amount_rial,
				'ttl'         => $ttl,
			)
		);
		if ( ! $payment ) {
			wc_add_notice( 'ایجاد درخواست پرداخت ناموفق بود.', 'error' );
			return array( 'result' => 'failure' );
		}

		$title = sprintf( 'سفارش %s', $order->get_order_number() );
		$description = sprintf(
			'پرداخت سفارش %s از %s — مهلت پرداخت %d دقیقه',
			$order->get_order_number(),
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			absint( EBP_Settings::get( 'deadline_minutes', 30 ) )
		);

		$result = ( new EBP_Bale_API() )->send_invoice(
			$linked->chat_id,
			$title,
			$description,
			$payment->public_id,
			$amount_rial
		);
		if ( is_wp_error( $result ) ) {
			EBP_DB::set_payment_status( $payment->id, 'failed' );
			EBP_DB::log( 'error', 'wallet_invoice_failed', $result->get_error_message(), array( 'order_id' => $order_id, 'payment_id' => $payment->id ) );
			wc_add_notice( 'ارسال فاکتور به بله ناموفق بود: ' . $result->get_error_message(), 'error' );
			return array( 'result' => 'failure' );
		}

		EBP_DB::set_payment_status( $payment->id, 'sent' );
		EBP_DB::log( 'info', 'wallet_invoice_sent', 'فاکتور پرداخت به بله ارسال شد.', array( 'order_id' => $order_id, 'payment_id' => $payment->id ) );
		$order->update_status( 'pending', 'فاکتور بله‌پی به چت متصل‌شده ارسال شد و سفارش در انتظار پرداخت است.' );
		$order->update_meta_data( '_ebp_payment_public_id', $payment->public_id );
		$order->update_meta_data( '_ebp_payment_expires_at', $payment->expires_at );
		$order->save();

		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}

		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_order_received_url(),
		);
	}

	public static function amount_to_rial( $amount, $currency ) {
		$amount = (float) wc_format_decimal( $amount );
		if ( 'IRR' === $currency ) {
			return (int) round( $amount );
		}
		if ( in_array( $currency, array( 'IRT', 'TOMAN' ), true ) ) {
			return (int) round( $amount * 10 );
		}
		return new WP_Error( 'ebp_currency', 'بله‌پی فقط سفارش‌های ریالی یا تومانی را پشتیبانی می‌کند.' );
	}

	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $this->id !== $order->get_payment_method() ) {
			return;
		}

		$payment = EBP_DB::payment_for_order( $order_id );
		wp_enqueue_style( 'ebp-frontend', EBP_URL . 'assets/frontend.css', array(), EBP_VERSION );
		echo EBP_Linking::styles(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $order->is_paid() || ( $payment && 'paid' === $payment->status ) ) {
			echo '<div class="ebp-box ebp-success"><strong>پرداخت بله‌پی با موفقیت تأیید شد.</strong></div>';
			return;
		}

		$bot_link = 'https://ble.ir/' . rawurlencode( EBP_Settings::get( 'bot_username', '' ) );
		echo '<div class="ebp-box"><strong>فاکتور پرداخت برای شما در بله ارسال شد.</strong><p>بله را باز کنید و پرداخت را تکمیل کنید؛ نتیجه به‌صورت خودکار روی سفارش اعمال می‌شود.</p>';
		echo '<p><a class="button alt" target="_blank" rel="noopener" href="' . esc_url( $bot_link ) . '">بازکردن چت بله</a> <button type="button" class="button" id="ebp-check-status">بررسی وضعیت</button></p><span id="ebp-status-result"></span></div>';

		$data = array(
			'url'      => admin_url( 'admin-ajax.php' ),
			'orderId'  => $order->get_id(),
			'orderKey' => $order->get_order_key(),
		);
		echo '<script>(function(){const d=' . wp_json_encode( $data ) . ';const b=document.getElementById("ebp-check-status"),r=document.getElementById("ebp-status-result");async function check(){b.disabled=true;r.textContent="در حال بررسی…";const f=new URLSearchParams({action:"ebp_payment_status",order_id:d.orderId,order_key:d.orderKey});try{const x=await fetch(d.url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:f});const j=await x.json();if(j.success&&j.data.paid){location.reload();return}r.textContent=j.success?"پرداخت هنوز تأیید نشده است.":"بررسی وضعیت ناموفق بود."}catch(e){r.textContent="خطا در ارتباط با سایت."}b.disabled=false}b.addEventListener("click",check);setTimeout(check,8000)})();</script>';
	}

	public static function ajax_payment_status() {
		if ( ! ebp_licensed() ) {
			wp_send_json_error( array( 'message' => 'برای استفاده از این افزونه باید کد لایسنس را وارد کنید.' ), 403 );
		}
		$order_id  = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$order_key = isset( $_POST['order_key'] ) ? wc_clean( wp_unslash( $_POST['order_key'] ) ) : '';
		$order = wc_get_order( $order_id );
		if ( ! $order || ! hash_equals( (string) $order->get_order_key(), (string) $order_key ) ) {
			wp_send_json_error( array( 'message' => 'سفارش معتبر نیست.' ), 403 );
		}
		if ( $order->get_customer_id() && is_user_logged_in() && (int) $order->get_customer_id() !== get_current_user_id() ) {
			wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست.' ), 403 );
		}
		wp_send_json_success( array( 'paid' => $order->is_paid(), 'status' => $order->get_status() ) );
	}
}
