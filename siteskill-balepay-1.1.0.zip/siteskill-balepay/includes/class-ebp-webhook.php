<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Webhook {
	const REST_NS = 'siteskill-balepay/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	public function routes() {
		register_rest_route(
			self::REST_NS,
			'/webhook/(?P<secret>[A-Fa-f0-9]{64})',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'receive' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	public static function url() {
		return rest_url( self::REST_NS . '/webhook/' . rawurlencode( EBP_Settings::webhook_secret() ) );
	}

	public function receive( WP_REST_Request $request ) {
		$provided = (string) $request->get_param( 'secret' );
		$expected = EBP_Settings::webhook_secret();
		if ( ! hash_equals( $expected, $provided ) ) {
			return new WP_REST_Response( array( 'ok' => false ), 403 );
		}

		$update = $request->get_json_params();
		if ( ! is_array( $update ) ) {
			return new WP_REST_Response( array( 'ok' => false ), 400 );
		}

		if ( isset( $update['pre_checkout_query'] ) && is_array( $update['pre_checkout_query'] ) ) {
			$this->pre_checkout( $update['pre_checkout_query'] );
		} elseif ( isset( $update['message']['successful_payment'] ) ) {
			$this->successful_payment( $update['message'] );
		} elseif ( isset( $update['message'] ) && is_array( $update['message'] ) ) {
			$this->message( $update['message'] );
		}

		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	private function message( array $message ) {
		$text = trim( (string) ( $message['text'] ?? '' ) );
		if ( ! preg_match( '/^\/start(?:\s+([A-Za-z0-9]+))?$/', $text, $matches ) ) {
			return;
		}

		$chat_id = (string) ( $message['chat']['id'] ?? '' );
		$from_id = (string) ( $message['from']['id'] ?? '' );
		if ( '' === $chat_id || '' === $from_id || $chat_id !== $from_id ) {
			return;
		}

		$api = new EBP_Bale_API();
		$code = strtoupper( (string) ( $matches[1] ?? '' ) );
		if ( '' === $code ) {
			$api->send_message( $chat_id, 'برای اتصال حساب، از صفحه «حساب کاربری ← اتصال بله‌پی» در فروشگاه وارد شوید.' );
			return;
		}

		$link = EBP_DB::consume_link_code( $code );
		if ( ! $link ) {
			$api->send_message( $chat_id, 'کد اتصال نامعتبر یا منقضی شده است. از فروشگاه یک کد جدید بگیرید.' );
			return;
		}

		EBP_DB::link_user(
			$link->wp_user_id,
			$chat_id,
			$from_id,
			array(
				'username'   => $message['from']['username'] ?? '',
				'first_name' => $message['from']['first_name'] ?? '',
			)
		);
		$api->send_message( $chat_id, 'حساب شما با موفقیت به فروشگاه متصل شد ✅ اکنون به صفحه پرداخت برگردید.' );
	}

	private function pre_checkout( array $query ) {
		$payload = (string) ( $query['invoice_payload'] ?? '' );
		$payment = EBP_DB::payment_by_public_id( $payload );
		$check = $this->validate_payment(
			$payment,
			(string) ( $query['from']['id'] ?? '' ),
			(string) ( $query['currency'] ?? '' ),
			isset( $query['total_amount'] ) ? (int) $query['total_amount'] : -1,
			false
		);

		$api = new EBP_Bale_API();
		if ( is_wp_error( $check ) ) {
			$api->answer_pre_checkout( (string) ( $query['id'] ?? '' ), false, $check->get_error_message() );
			return;
		}
		$api->answer_pre_checkout( (string) ( $query['id'] ?? '' ), true );
	}

	private function successful_payment( array $message ) {
		$success = (array) $message['successful_payment'];
		$payment = EBP_DB::payment_by_public_id( (string) ( $success['invoice_payload'] ?? '' ) );
		$charge_id = sanitize_text_field(
			(string) ( $success['telegram_payment_charge_id'] ?? $success['provider_payment_charge_id'] ?? '' )
		);

		if ( $payment && 'paid' === $payment->status ) {
			if ( '' !== $charge_id && hash_equals( (string) $payment->charge_id, $charge_id ) ) {
				return;
			}
			$order = wc_get_order( $payment->order_id );
			if ( $order ) {
				$order->add_order_note( 'هشدار بله‌پی: رویداد پرداخت تکراری با شناسه‌ای متفاوت دریافت شد و نادیده گرفته شد.' );
			}
			return;
		}

		$check = $this->validate_payment(
			$payment,
			(string) ( $message['from']['id'] ?? $message['chat']['id'] ?? '' ),
			(string) ( $success['currency'] ?? '' ),
			isset( $success['total_amount'] ) ? (int) $success['total_amount'] : -1,
			true
		);
		if ( is_wp_error( $check ) ) {
			if ( $payment ) {
				EBP_DB::set_payment_status( $payment->id, 'pending_review' );
				$order = wc_get_order( $payment->order_id );
				if ( $order ) {
					$note = 'رویداد پرداخت بله‌پی دریافت شد اما اعتبارسنجی ناموفق بود: ' . $check->get_error_message();
					if ( '' !== $charge_id ) {
						$note .= ' شناسه تراکنش گزارش‌شده: ' . $charge_id;
					}
					$order->update_status( 'on-hold', $note );
				}
			}
			return;
		}

		if ( '' === $charge_id ) {
			EBP_DB::set_payment_status( $payment->id, 'pending_review' );
			return;
		}

		if ( ! EBP_DB::mark_paid( $payment->id, $charge_id ) ) {
			EBP_DB::set_payment_status( $payment->id, 'pending_review' );
			return;
		}

		$order = wc_get_order( $payment->order_id );
		if ( ! $order ) {
			return;
		}
		$order->payment_complete( $charge_id );
		EBP_DB::log( 'info', 'wallet_payment_completed', 'پرداخت مستقیم بله تأیید شد.', array( 'order_id' => $order->get_id(), 'payment_id' => $payment->id ) );
		$order->add_order_note( 'پرداخت بله‌پی تأیید شد. شناسه تراکنش: ' . $charge_id );
	}

	private function validate_payment( $payment, $bale_user_id, $currency, $amount, $allow_expired ) {
		if ( ! $payment ) {
			return new WP_Error( 'ebp_unknown_payment', 'درخواست پرداخت معتبر نیست.' );
		}
		if ( 'sent' !== $payment->status ) {
			return new WP_Error( 'ebp_invalid_state', 'این درخواست پرداخت قابل استفاده نیست.' );
		}
		if ( ! $allow_expired && strtotime( $payment->expires_at . ' UTC' ) < time() ) {
			EBP_DB::set_payment_status( $payment->id, 'expired' );
			return new WP_Error( 'ebp_expired', 'مهلت پرداخت پایان یافته است.' );
		}
		if ( $allow_expired && strtotime( $payment->expires_at . ' UTC' ) < time() ) {
			return new WP_Error( 'ebp_late_payment', 'پرداخت پس از پایان مهلت دریافت شده و نیازمند بررسی مدیر است.' );
		}
		if ( ! hash_equals( (string) $payment->chat_id, (string) $bale_user_id ) ) {
			return new WP_Error( 'ebp_wrong_user', 'این فاکتور متعلق به حساب بلهٔ دیگری است.' );
		}
		if ( 'IRR' !== strtoupper( $currency ) || (int) $payment->amount_rial !== (int) $amount ) {
			return new WP_Error( 'ebp_amount_mismatch', 'مبلغ یا واحد پول فاکتور با سفارش مطابقت ندارد.' );
		}

		$order = wc_get_order( $payment->order_id );
		if ( ! $order || 'siteskill_balepay' !== $order->get_payment_method() ) {
			return new WP_Error( 'ebp_order_mismatch', 'سفارش مرتبط با این فاکتور معتبر نیست.' );
		}
		if ( (int) $order->get_customer_id() !== (int) $payment->wp_user_id ) {
			return new WP_Error( 'ebp_customer_mismatch', 'مالک سفارش با فاکتور مطابقت ندارد.' );
		}
		return true;
	}
}
