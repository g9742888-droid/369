<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Receipts {
	public function __construct() {
		add_action( 'admin_post_ebp_upload_receipt', array( $this, 'upload' ) );
		add_action( 'admin_post_nopriv_ebp_upload_receipt', array( $this, 'upload' ) );
	}

	public function upload() {
		if ( ! ebp_licensed() ) {
			wp_die( esc_html__( 'برای استفاده از این افزونه باید کد لایسنس را وارد کنید.', 'siteskill-balepay' ), '', array( 'response' => 403 ) );
		}
		$order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
		$order_key = isset( $_POST['order_key'] ) ? wc_clean( wp_unslash( $_POST['order_key'] ) ) : '';
		$order = wc_get_order( $order_id );
		$redirect = $order ? $order->get_checkout_order_received_url() : wc_get_checkout_url();
		if ( ! $order || ! hash_equals( (string) $order->get_order_key(), (string) $order_key ) ) {
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'ebp_receipt_' . $order_id ) ) {
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}
		$payment = EBP_DB::payment_for_order( $order_id );
		if ( ! $payment || 'card' !== $payment->method || ! in_array( $payment->status, array( 'awaiting_receipt', 'rejected' ), true ) ) {
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}
		if ( empty( $_FILES['receipt']['tmp_name'] ) || UPLOAD_ERR_OK !== (int) $_FILES['receipt']['error'] ) {
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}
		$max_bytes = absint( EBP_Settings::get( 'receipt_max_mb', 5 ) ) * MB_IN_BYTES;
		if ( (int) $_FILES['receipt']['size'] > $max_bytes ) {
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}
		$allowed = array(
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'webp'         => 'image/webp',
			'pdf'          => 'application/pdf',
		);
		$checked = wp_check_filetype_and_ext( $_FILES['receipt']['tmp_name'], sanitize_file_name( $_FILES['receipt']['name'] ), $allowed );
		if ( empty( $checked['type'] ) || ! in_array( $checked['type'], array_values( $allowed ), true ) ) {
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$attachment_id = media_handle_upload( 'receipt', 0, null, array( 'post_title' => sprintf( 'رسید سفارش %d', $order_id ), 'post_status' => 'inherit' ) );
		if ( is_wp_error( $attachment_id ) ) {
			EBP_DB::log( 'error', 'receipt_upload_failed', $attachment_id->get_error_message(), array( 'order_id' => $order_id ) );
			wp_safe_redirect( add_query_arg( 'ebp_receipt', 'error', $redirect ) );
			exit;
		}
		$url = wp_get_attachment_url( $attachment_id );
		EBP_DB::save_receipt( $payment->id, $attachment_id, $url );
		$order->update_status( 'on-hold', 'رسید کارت به کارت دریافت شد و در انتظار بررسی مدیر است.' );
		$order->add_order_note( 'رسید کارت به کارت ثبت شد: ' . esc_url_raw( $url ) );
		EBP_Notifier::customer( $order, 'message_receipt_received' );
		EBP_Notifier::managers( $order );
		EBP_DB::log( 'info', 'receipt_uploaded', 'رسید کارت به کارت ثبت شد.', array( 'order_id' => $order_id, 'payment_id' => $payment->id ) );
		wp_safe_redirect( add_query_arg( 'ebp_receipt', 'uploaded', $redirect ) );
		exit;
	}
}
