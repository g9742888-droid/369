<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Notifier {
	public static function render( $template, WC_Order $order, $note = '' ) {
		return strtr(
			(string) $template,
			array(
				'{order_id}' => (string) $order->get_order_number(),
				'{total}'    => wp_strip_all_tags( $order->get_formatted_order_total() ),
				'{customer}' => $order->get_formatted_billing_full_name(),
				'{note}'     => (string) $note,
			)
		);
	}

	public static function customer( WC_Order $order, $template_key, $note = '' ) {
		$user_id = (int) $order->get_customer_id();
		$linked = $user_id ? EBP_DB::linked_user( $user_id ) : null;
		if ( ! $linked || ! EBP_Settings::secret( 'bot_token' ) ) {
			return false;
		}
		$text = self::render( EBP_Settings::get( $template_key, '' ), $order, $note );
		$result = ( new EBP_Bale_API() )->send_message( $linked->chat_id, $text );
		return ! is_wp_error( $result );
	}

	public static function managers( WC_Order $order ) {
		if ( ! EBP_Settings::secret( 'bot_token' ) ) {
			return false;
		}
		$text = self::render( EBP_Settings::get( 'message_admin_receipt', '' ), $order );
		$text .= "\n" . admin_url( 'admin.php?page=siteskill-balepay&ebp_tab=transactions' );
		$api = new EBP_Bale_API();
		$sent = false;
		foreach ( EBP_DB::list_linked_users( 500 ) as $linked ) {
			$user = get_userdata( $linked->wp_user_id );
			if ( $user && user_can( $user, 'manage_woocommerce' ) ) {
				$result = $api->send_message( $linked->chat_id, $text );
				$sent = $sent || ! is_wp_error( $result );
			}
		}
		return $sent;
	}
}
