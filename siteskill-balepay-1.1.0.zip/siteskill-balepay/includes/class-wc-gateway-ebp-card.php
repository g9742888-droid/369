<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WC_Gateway_EBP_Card extends WC_Payment_Gateway {
	public function __construct() {
		$this->id                 = 'siteskill_balepay_card';
		$this->has_fields         = true;
		$this->method_title       = 'کارت به کارت بله پی اسکیل';
		$this->method_description = 'نمایش کارت مقصد، دریافت رسید و تأیید یا رد سفارش توسط مدیر.';
		$this->supports           = array( 'products' );
		$this->enabled            = EBP_Settings::get( 'card_enabled', 'yes' );
		$this->title              = EBP_Settings::get( 'card_title', 'کارت به کارت' );
		$this->description        = EBP_Settings::get( 'card_description', '' );

		$this->form_fields = array(
			'info' => array(
				'title'       => 'تنظیمات',
				'type'        => 'title',
				'description' => 'کارت‌های مقصد و تنظیمات این روش از منوی «بله پی اسکیل» مدیریت می‌شوند.',
			),
		);

		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
		add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
	}

	public function is_available() {
		if ( ! parent::is_available() || ! EBP_Settings::card_is_configured() ) {
			return false;
		}
		return in_array( get_woocommerce_currency(), array( 'IRR', 'IRT', 'TOMAN' ), true );
	}

	private function enqueue_assets() {
		wp_enqueue_style( 'ebp-frontend', EBP_URL . 'assets/frontend.css', array(), EBP_VERSION );
	}

	public function payment_fields() {
		$this->enqueue_assets();
		if ( $this->description ) {
			echo wp_kses_post( wpautop( $this->description ) );
		}
		$cards = EBP_DB::list_cards( true );
		if ( empty( $cards ) ) {
			echo '<div class="ebp-alert ebp-alert-warning">در حال حاضر کارت فعالی برای پرداخت ثبت نشده است.</div>';
			return;
		}
		echo '<fieldset class="ebp-card-choice"><legend class="screen-reader-text">انتخاب کارت مقصد</legend>';
		foreach ( $cards as $index => $card ) {
			$number = self::format_card_number( $card->card_number );
			echo '<label class="ebp-bank-card-option">';
			echo '<input type="radio" name="ebp_card_id" value="' . esc_attr( $card->id ) . '" ' . checked( 0, $index, false ) . '>';
			echo '<span class="ebp-bank-card-content"><span class="ebp-bank-card-top"><strong>' . esc_html( $card->label ) . '</strong><span>' . esc_html( $card->bank_name ) . '</span></span>';
			echo '<b class="ebp-card-number" dir="ltr">' . esc_html( $number ) . '</b>';
			echo '<span class="ebp-card-holder">به نام ' . esc_html( $card->account_holder ) . '</span>';
			if ( $card->iban ) {
				echo '<small dir="ltr">IR' . esc_html( preg_replace( '/^IR/i', '', $card->iban ) ) . '</small>';
			}
			echo '</span></label>';
		}
		echo '</fieldset>';
	}

	public function validate_fields() {
		$card_id = isset( $_POST['ebp_card_id'] ) ? absint( wp_unslash( $_POST['ebp_card_id'] ) ) : 0;
		if ( ! $card_id ) {
			$cards = EBP_DB::list_cards( true );
			$card_id = $cards ? (int) $cards[0]->id : 0;
		}
		if ( ! $card_id || ! EBP_DB::get_card( $card_id, true ) ) {
			wc_add_notice( 'یک کارت مقصد معتبر انتخاب کنید.', 'error' );
			return false;
		}
		return true;
	}

	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wc_add_notice( 'سفارش پیدا نشد.', 'error' );
			return array( 'result' => 'failure' );
		}
		$card_id = isset( $_POST['ebp_card_id'] ) ? absint( wp_unslash( $_POST['ebp_card_id'] ) ) : 0;
		$cards = EBP_DB::list_cards( true );
		if ( ! $card_id && $cards ) {
			$card_id = (int) $cards[0]->id;
		}
		$card = EBP_DB::get_card( $card_id, true );
		if ( ! $card ) {
			wc_add_notice( 'کارت مقصد معتبر نیست یا غیرفعال شده است.', 'error' );
			return array( 'result' => 'failure' );
		}

		$amount_rial = WC_Gateway_SiteSkill_BalePay::amount_to_rial( $order->get_total(), $order->get_currency() );
		if ( is_wp_error( $amount_rial ) ) {
			wc_add_notice( $amount_rial->get_error_message(), 'error' );
			return array( 'result' => 'failure' );
		}

		$existing = EBP_DB::payment_for_order( $order_id );
		if ( ! $existing || 'card' !== $existing->method || in_array( $existing->status, array( 'rejected', 'failed', 'expired' ), true ) ) {
			$user_id = (int) $order->get_customer_id();
			$linked = $user_id ? EBP_DB::linked_user( $user_id ) : null;
			$payment = EBP_DB::create_payment(
				array(
					'order_id'    => $order_id,
					'wp_user_id'  => $user_id,
					'chat_id'     => $linked ? $linked->chat_id : '',
					'method'      => 'card',
					'card_id'     => $card_id,
					'amount_rial' => $amount_rial,
					'ttl'         => absint( EBP_Settings::get( 'card_deadline_hours', 24 ) ) * HOUR_IN_SECONDS,
				)
			);
			if ( ! $payment ) {
				wc_add_notice( 'ثبت درخواست کارت به کارت ناموفق بود.', 'error' );
				return array( 'result' => 'failure' );
			}
			EBP_DB::set_payment_status( $payment->id, 'awaiting_receipt' );
		} else {
			$payment = $existing;
		}

		$order->update_status( 'on-hold', 'سفارش کارت به کارت ثبت شد و در انتظار واریز و ارسال رسید است.' );
		$order->update_meta_data( '_ebp_payment_public_id', $payment->public_id );
		$order->update_meta_data( '_ebp_card_id', $card_id );
		$order->save();
		EBP_DB::log( 'info', 'card_order_created', 'سفارش کارت به کارت ایجاد شد.', array( 'order_id' => $order_id, 'payment_id' => $payment->id ) );

		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}
		return array( 'result' => 'success', 'redirect' => $order->get_checkout_order_received_url() );
	}

	public function thankyou_page( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $this->id !== $order->get_payment_method() ) {
			return;
		}
		$this->enqueue_assets();
		$payment = EBP_DB::payment_for_order( $order_id );
		$card = $payment && $payment->card_id ? EBP_DB::get_card( $payment->card_id ) : null;
		if ( ! $payment || ! $card ) {
			echo '<div class="ebp-alert ebp-alert-error">اطلاعات پرداخت کارت به کارت در دسترس نیست.</div>';
			return;
		}

		if ( $order->is_paid() || 'approved' === $payment->status ) {
			echo '<div class="ebp-result-card is-success"><strong>پرداخت تأیید شد</strong><p>رسید شما بررسی و سفارش نهایی شده است.</p></div>';
			return;
		}
		echo '<section class="ebp-transfer-panel" dir="rtl">';
		echo '<div class="ebp-transfer-head"><span class="ebp-step">۱</span><div><h3>واریز به کارت مقصد</h3><p>' . esc_html( EBP_Settings::get( 'card_instructions', '' ) ) . '</p></div></div>';
		echo '<div class="ebp-bank-card"><span>' . esc_html( $card->bank_name ) . '</span><b dir="ltr">' . esc_html( self::format_card_number( $card->card_number ) ) . '</b><small>به نام ' . esc_html( $card->account_holder ) . '</small></div>';
		echo '<div class="ebp-amount-row"><span>مبلغ قابل واریز</span><strong>' . wp_kses_post( $order->get_formatted_order_total() ) . '</strong></div>';

		if ( 'pending_review' === $payment->status && $payment->receipt_url ) {
			echo '<div class="ebp-alert ebp-alert-success"><strong>رسید دریافت شد.</strong> پس از بررسی مدیر، نتیجه روی همین سفارش ثبت می‌شود.</div>';
		} elseif ( 'rejected' === $payment->status ) {
			echo '<div class="ebp-alert ebp-alert-error"><strong>رسید رد شده است.</strong> ' . esc_html( $payment->admin_note ) . '</div>';
		} else {
			$status = isset( $_GET['ebp_receipt'] ) ? sanitize_key( wp_unslash( $_GET['ebp_receipt'] ) ) : '';
			if ( 'error' === $status ) {
				echo '<div class="ebp-alert ebp-alert-error">آپلود رسید ناموفق بود. نوع و اندازه فایل را بررسی کنید.</div>';
			}
			echo '<div class="ebp-transfer-head ebp-upload-head"><span class="ebp-step">۲</span><div><h3>ارسال تصویر رسید</h3><p>فرمت‌های JPG، PNG، WebP یا PDF تا ' . esc_html( EBP_Settings::get( 'receipt_max_mb', 5 ) ) . ' مگابایت پذیرفته می‌شود.</p></div></div>';
			echo '<form class="ebp-receipt-form" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			echo '<input type="hidden" name="action" value="ebp_upload_receipt"><input type="hidden" name="order_id" value="' . esc_attr( $order_id ) . '"><input type="hidden" name="order_key" value="' . esc_attr( $order->get_order_key() ) . '">';
			wp_nonce_field( 'ebp_receipt_' . $order_id );
			echo '<label class="ebp-file-drop"><input required type="file" name="receipt" accept="image/jpeg,image/png,image/webp,application/pdf"><span>انتخاب فایل رسید</span><small>برای انتخاب فایل کلیک کنید</small></label>';
			echo '<button class="button alt ebp-submit-receipt" type="submit">ثبت رسید برای بررسی</button></form>';
		}
		echo '</section>';
	}

	public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		if ( $sent_to_admin || ! $order instanceof WC_Order || $this->id !== $order->get_payment_method() || $order->is_paid() ) {
			return;
		}
		$payment = EBP_DB::payment_for_order( $order->get_id() );
		$card = $payment && $payment->card_id ? EBP_DB::get_card( $payment->card_id ) : null;
		if ( ! $card ) {
			return;
		}
		$text = sprintf( 'کارت مقصد: %s — به نام %s. پس از واریز، رسید را در صفحه سفارش ارسال کنید.', self::format_card_number( $card->card_number ), $card->account_holder );
		echo $plain_text ? "\n" . esc_html( $text ) . "\n" : '<p>' . esc_html( $text ) . '</p>';
	}

	public static function format_card_number( $number ) {
		$digits = preg_replace( '/\D+/', '', (string) $number );
		return trim( chunk_split( $digits, 4, ' ' ) );
	}
}
