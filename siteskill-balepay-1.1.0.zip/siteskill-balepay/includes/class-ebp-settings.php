<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Settings {
	const OPTION = 'ebp_settings';
	private static $cache = null;

	public static function defaults() {
		return array(
			'enabled'                => 'yes',
			'title'                  => 'بله پی اسکیل',
			'description'            => 'پرداخت امن داخل پیام‌رسان بله',
			'card_enabled'           => 'yes',
			'card_title'             => 'کارت به کارت',
			'card_description'       => 'واریز به کارت بانکی و ارسال رسید برای بررسی',
			'card_instructions'      => 'مبلغ سفارش را به یکی از کارت‌های نمایش‌داده‌شده واریز و تصویر رسید را ثبت کنید.',
			'receipt_max_mb'         => 5,
			'bot_username'           => '',
			'bot_token'              => '',
			'provider_token'         => '',
			'webhook_secret'         => '',
			'deadline_minutes'       => 30,
			'card_deadline_hours'    => 24,
			'wallet_discount'        => 0,
			'card_discount'          => 0,
			'admin_accent'           => '#209b78',
			'message_receipt_received' => 'رسید سفارش #{order_id} دریافت شد و در انتظار بررسی است.',
			'message_receipt_approved' => 'پرداخت سفارش #{order_id} تأیید شد ✅',
			'message_receipt_rejected' => 'رسید سفارش #{order_id} تأیید نشد. {note}',
			'message_admin_receipt'    => 'رسید جدید برای سفارش #{order_id} ثبت شد. مبلغ: {total}',
			'delete_data_on_uninstall' => 'no',
		);
	}

	public static function all() {
		if ( null === self::$cache ) {
			self::$cache = wp_parse_args( get_option( self::OPTION, array() ), self::defaults() );
		}
		return self::$cache;
	}

	public static function get( $key, $default = null ) {
		$settings = self::all();
		return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
	}

	public static function secret( $key ) {
		return EBP_Crypto::decrypt( self::get( $key, '' ) );
	}

	public static function webhook_secret() {
		$secret = self::secret( 'webhook_secret' );
		if ( '' === $secret ) {
			$secret = bin2hex( random_bytes( 32 ) );
			self::save( array( 'webhook_secret' => $secret ), true );
		}
		return $secret;
	}

	public static function save( array $input, $partial = false ) {
		$current = self::all();
		$data = $current;

		if ( isset( $input['enabled'] ) || ! $partial ) {
			$data['enabled'] = ! empty( $input['enabled'] ) ? 'yes' : 'no';
		}
		if ( isset( $input['card_enabled'] ) || ! $partial ) {
			$data['card_enabled'] = ! empty( $input['card_enabled'] ) ? 'yes' : 'no';
		}
		if ( isset( $input['title'] ) ) {
			$data['title'] = sanitize_text_field( $input['title'] );
		}
		if ( isset( $input['description'] ) ) {
			$data['description'] = sanitize_textarea_field( $input['description'] );
		}
		foreach ( array( 'card_title', 'card_description', 'card_instructions' ) as $text_key ) {
			if ( isset( $input[ $text_key ] ) ) {
				$data[ $text_key ] = 'card_title' === $text_key
					? sanitize_text_field( $input[ $text_key ] )
					: sanitize_textarea_field( $input[ $text_key ] );
			}
		}
		foreach ( array( 'message_receipt_received', 'message_receipt_approved', 'message_receipt_rejected', 'message_admin_receipt' ) as $template_key ) {
			if ( isset( $input[ $template_key ] ) ) {
				$data[ $template_key ] = sanitize_textarea_field( $input[ $template_key ] );
			}
		}
		if ( isset( $input['bot_username'] ) ) {
			$data['bot_username'] = ltrim( preg_replace( '/[^A-Za-z0-9_]/', '', (string) $input['bot_username'] ), '@' );
		}
		if ( isset( $input['deadline_minutes'] ) ) {
			$data['deadline_minutes'] = max( 5, min( 1440, absint( $input['deadline_minutes'] ) ) );
		}
		if ( isset( $input['card_deadline_hours'] ) ) {
			$data['card_deadline_hours'] = max( 1, min( 168, absint( $input['card_deadline_hours'] ) ) );
		}
		if ( isset( $input['receipt_max_mb'] ) ) {
			$data['receipt_max_mb'] = max( 1, min( 10, absint( $input['receipt_max_mb'] ) ) );
		}
		foreach ( array( 'wallet_discount', 'card_discount' ) as $discount_key ) {
			if ( isset( $input[ $discount_key ] ) ) {
				$data[ $discount_key ] = max( 0, min( 50, (float) $input[ $discount_key ] ) );
			}
		}
		if ( isset( $input['admin_accent'] ) ) {
			$color = sanitize_hex_color( $input['admin_accent'] );
			$data['admin_accent'] = $color ? $color : '#209b78';
		}
		if ( isset( $input['delete_data_on_uninstall'] ) || ! $partial ) {
			$data['delete_data_on_uninstall'] = ! empty( $input['delete_data_on_uninstall'] ) ? 'yes' : 'no';
		}

		foreach ( array( 'bot_token', 'provider_token', 'webhook_secret' ) as $secret_key ) {
			if ( isset( $input[ $secret_key ] ) && '' !== trim( (string) $input[ $secret_key ] ) ) {
				$encrypted = EBP_Crypto::encrypt( sanitize_text_field( (string) $input[ $secret_key ] ) );
				if ( '' !== $encrypted ) {
					$data[ $secret_key ] = $encrypted;
				}
			}
		}

		update_option( self::OPTION, $data, false );
		self::$cache = null;
		return self::all();
	}

	public static function is_configured() {
		return 'yes' === self::get( 'enabled' )
			&& '' !== self::get( 'bot_username' )
			&& '' !== self::secret( 'bot_token' )
			&& '' !== self::secret( 'provider_token' );
	}

	public static function card_is_configured() {
		return 'yes' === self::get( 'card_enabled', 'yes' ) && EBP_DB::count_active_cards() > 0;
	}
}
