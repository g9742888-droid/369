<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Linking {
	const ENDPOINT = 'bale-pay';

	public function __construct() {
		add_action( 'init', array( $this, 'register_endpoint' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'account_menu' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( $this, 'account_page' ) );
		add_shortcode( 'siteskill_balepay_connect', array( $this, 'shortcode' ) );
	}

	public function register_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
		if ( get_option( 'ebp_flush_rewrite' ) ) {
			delete_option( 'ebp_flush_rewrite' );
			flush_rewrite_rules( false );
		}
	}

	public function account_menu( $items ) {
		$logout = $items['customer-logout'] ?? null;
		unset( $items['customer-logout'] );
		$items[ self::ENDPOINT ] = 'اتصال بله‌پی';
		if ( null !== $logout ) {
			$items['customer-logout'] = $logout;
		}
		return $items;
	}

	public static function deep_link( $code ) {
		$username = EBP_Settings::get( 'bot_username', '' );
		if ( '' === $username ) {
			return '';
		}
		return 'https://ble.ir/' . rawurlencode( $username ) . '?start=' . rawurlencode( $code );
	}

	public static function render_for_user( $wp_user_id ) {
		if ( ! $wp_user_id ) {
			return '<div class="ebp-box ebp-warning">برای استفاده از بله‌پی ابتدا وارد حساب کاربری شوید.</div>';
		}

		$linked = EBP_DB::linked_user( $wp_user_id );
		if ( $linked ) {
			$name = $linked->first_name ? ' (' . esc_html( $linked->first_name ) . ')' : '';
			return '<div class="ebp-box ebp-success">حساب بلهٔ شما' . $name . ' متصل است. پس از ثبت سفارش، فاکتور در چت بله ارسال می‌شود.</div>';
		}

		if ( ! EBP_Settings::is_configured() ) {
			return '<div class="ebp-box ebp-warning">بله‌پی هنوز توسط مدیر فروشگاه پیکربندی نشده است.</div>';
		}

		$code = EBP_DB::create_link_code( $wp_user_id );
		$link = self::deep_link( $code );
		return '<div class="ebp-box"><p>یک‌بار حساب فروشگاه را به ربات بله متصل کنید.</p>'
			. '<p><a class="button alt" target="_blank" rel="noopener" href="' . esc_url( $link ) . '">اتصال به ربات بله</a></p>'
			. '<small>کد اتصال تا ۱۵ دقیقه معتبر است: <code>' . esc_html( $code ) . '</code></small></div>';
	}

	public function account_page() {
		echo self::styles(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::render_for_user( get_current_user_id() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function shortcode() {
		return self::styles() . self::render_for_user( get_current_user_id() );
	}

	public static function styles() {
		return '<style>.ebp-box{border:1px solid #d8dee8;border-radius:10px;padding:14px 16px;margin:10px 0;background:#fff}.ebp-success{border-color:#86d19a;background:#f2fff5}.ebp-warning{border-color:#efc46f;background:#fff9ec}.ebp-box code{direction:ltr;display:inline-block;letter-spacing:1px}</style>';
	}
}
