<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_DB {
	public static function table( $name ) {
		global $wpdb;
		$allowed = array( 'links', 'users', 'payments', 'cards', 'logs' );
		if ( ! in_array( $name, $allowed, true ) ) {
			return '';
		}
		return $wpdb->prefix . 'ebp_' . $name;
	}

	public static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();

		$sql = array(
			'CREATE TABLE ' . self::table( 'links' ) . " (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				wp_user_id bigint(20) unsigned NOT NULL,
				code varchar(40) NOT NULL,
				expires_at datetime NOT NULL,
				consumed_at datetime NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY code (code),
				KEY wp_user_id (wp_user_id)
			) {$charset};",
			'CREATE TABLE ' . self::table( 'users' ) . " (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				wp_user_id bigint(20) unsigned NOT NULL,
				chat_id varchar(80) NOT NULL,
				bale_user_id varchar(80) NOT NULL,
				username varchar(191) NULL,
				first_name varchar(191) NULL,
				linked_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY wp_user_id (wp_user_id),
				UNIQUE KEY chat_id (chat_id),
				KEY bale_user_id (bale_user_id)
			) {$charset};",
			'CREATE TABLE ' . self::table( 'payments' ) . " (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				public_id varchar(80) NOT NULL,
				order_id bigint(20) unsigned NOT NULL,
				wp_user_id bigint(20) unsigned NOT NULL,
				chat_id varchar(80) NOT NULL,
				method varchar(30) NOT NULL DEFAULT 'wallet',
				card_id bigint(20) unsigned NULL,
				amount_rial bigint(20) unsigned NOT NULL,
				currency varchar(10) NOT NULL DEFAULT 'IRR',
				status varchar(30) NOT NULL DEFAULT 'created',
				charge_id varchar(191) NULL,
				receipt_attachment_id bigint(20) unsigned NULL,
				receipt_url text NULL,
				admin_note text NULL,
				reviewed_by bigint(20) unsigned NULL,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				expires_at datetime NOT NULL,
				paid_at datetime NULL,
				decided_at datetime NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY public_id (public_id),
				UNIQUE KEY charge_id (charge_id),
				KEY order_id (order_id),
				KEY method_status (method,status),
				KEY status_expires (status,expires_at)
			) {$charset};",
			'CREATE TABLE ' . self::table( 'cards' ) . " (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				label varchar(191) NOT NULL,
				card_number varchar(32) NOT NULL,
				iban varchar(34) NULL,
				account_holder varchar(191) NOT NULL,
				bank_name varchar(100) NULL,
				is_active tinyint(1) NOT NULL DEFAULT 1,
				sort_order int(11) NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY active_sort (is_active,sort_order)
			) {$charset};",
			'CREATE TABLE ' . self::table( 'logs' ) . " (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				level varchar(20) NOT NULL DEFAULT 'info',
				event varchar(80) NOT NULL,
				message text NOT NULL,
				context longtext NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY level_created (level,created_at)
			) {$charset};",
		);

		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}

		update_option( 'ebp_db_version', EBP_VERSION, false );
		update_option( 'ebp_flush_rewrite', 1, false );
	}

	public static function create_link_code( $wp_user_id ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM ' . self::table( 'links' ) . ' WHERE wp_user_id = %d OR expires_at < %s',
				$wp_user_id,
				$now
			)
		);

		$code = strtoupper( bin2hex( random_bytes( 10 ) ) );
		$wpdb->insert(
			self::table( 'links' ),
			array(
				'wp_user_id' => absint( $wp_user_id ),
				'code'       => $code,
				'expires_at' => gmdate( 'Y-m-d H:i:s', time() + 15 * MINUTE_IN_SECONDS ),
			),
			array( '%d', '%s', '%s' )
		);
		return $code;
	}

	public static function consume_link_code( $code ) {
		global $wpdb;
		$table = self::table( 'links' );
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE code = %s AND consumed_at IS NULL AND expires_at >= %s LIMIT 1",
				$code,
				current_time( 'mysql', true )
			)
		);
		if ( ! $row ) {
			return null;
		}

		$changed = $wpdb->update(
			$table,
			array( 'consumed_at' => current_time( 'mysql', true ) ),
			array( 'id' => $row->id, 'consumed_at' => null ),
			array( '%s' ),
			array( '%d', '%s' )
		);
		return 1 === $changed ? $row : null;
	}

	public static function link_user( $wp_user_id, $chat_id, $bale_user_id, array $profile ) {
		global $wpdb;
		$table = self::table( 'users' );
		$now = current_time( 'mysql', true );

		$wpdb->delete( $table, array( 'chat_id' => (string) $chat_id ), array( '%s' ) );
		$existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE wp_user_id = %d", $wp_user_id ) );
		$data = array(
			'wp_user_id'  => absint( $wp_user_id ),
			'chat_id'     => (string) $chat_id,
			'bale_user_id' => (string) $bale_user_id,
			'username'    => sanitize_text_field( $profile['username'] ?? '' ),
			'first_name'  => sanitize_text_field( $profile['first_name'] ?? '' ),
			'linked_at'   => $now,
			'updated_at'  => $now,
		);

		if ( $existing_id ) {
			$wpdb->update( $table, $data, array( 'id' => $existing_id ) );
			return (int) $existing_id;
		}
		$wpdb->insert( $table, $data );
		return (int) $wpdb->insert_id;
	}

	public static function linked_user( $wp_user_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::table( 'users' ) . ' WHERE wp_user_id = %d LIMIT 1', $wp_user_id )
		);
	}

	public static function create_payment( array $data ) {
		global $wpdb;
		$public_id = 'ebp_' . bin2hex( random_bytes( 20 ) );
		$now = current_time( 'mysql', true );
		$inserted = $wpdb->insert(
			self::table( 'payments' ),
			array(
				'public_id'   => $public_id,
				'order_id'    => absint( $data['order_id'] ),
				'wp_user_id'  => absint( $data['wp_user_id'] ),
				'chat_id'     => (string) $data['chat_id'],
				'method'      => sanitize_key( $data['method'] ?? 'wallet' ),
				'card_id'     => ! empty( $data['card_id'] ) ? absint( $data['card_id'] ) : null,
				'amount_rial' => absint( $data['amount_rial'] ),
				'currency'    => 'IRR',
				'status'      => 'created',
				'created_at'  => $now,
				'updated_at'  => $now,
				'expires_at'  => gmdate( 'Y-m-d H:i:s', time() + absint( $data['ttl'] ) ),
			),
			array( '%s', '%d', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%s' )
		);
		return $inserted ? self::payment_by_public_id( $public_id ) : null;
	}

	public static function payment_by_public_id( $public_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::table( 'payments' ) . ' WHERE public_id = %s LIMIT 1', $public_id )
		);
	}

	public static function payment_for_order( $order_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'payments' ) . ' WHERE order_id = %d ORDER BY id DESC LIMIT 1',
				$order_id
			)
		);
	}

	public static function set_payment_status( $id, $status ) {
		global $wpdb;
		return false !== $wpdb->update(
			self::table( 'payments' ),
			array( 'status' => sanitize_key( $status ), 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function mark_paid( $id, $charge_id ) {
		global $wpdb;
		$table = self::table( 'payments' );
		$result = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = 'paid', charge_id = %s, paid_at = %s, updated_at = %s WHERE id = %d AND status IN ('created','sent')",
				$charge_id,
				current_time( 'mysql', true ),
				current_time( 'mysql', true ),
				$id
			)
		);
		return 1 === $result;
	}

	public static function list_cards( $active_only = false ) {
		global $wpdb;
		$sql = 'SELECT * FROM ' . self::table( 'cards' );
		if ( $active_only ) {
			$sql .= ' WHERE is_active = 1';
		}
		return $wpdb->get_results( $sql . ' ORDER BY sort_order ASC, id ASC' );
	}

	public static function get_card( $id, $active_only = false ) {
		global $wpdb;
		$sql = 'SELECT * FROM ' . self::table( 'cards' ) . ' WHERE id = %d';
		if ( $active_only ) {
			$sql .= ' AND is_active = 1';
		}
		return $wpdb->get_row( $wpdb->prepare( $sql . ' LIMIT 1', absint( $id ) ) );
	}

	public static function count_active_cards() {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table( 'cards' ) . ' WHERE is_active = 1' );
	}

	public static function save_card( array $data, $id = 0 ) {
		global $wpdb;
		$now = current_time( 'mysql', true );
		$card_number = preg_replace( '/\D+/', '', (string) ( $data['card_number'] ?? '' ) );
		$iban = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) ( $data['iban'] ?? '' ) ) );
		$row = array(
			'label'          => sanitize_text_field( $data['label'] ?? '' ),
			'card_number'    => $card_number,
			'iban'           => $iban,
			'account_holder' => sanitize_text_field( $data['account_holder'] ?? '' ),
			'bank_name'      => sanitize_text_field( $data['bank_name'] ?? '' ),
			'is_active'      => ! empty( $data['is_active'] ) ? 1 : 0,
			'sort_order'     => isset( $data['sort_order'] ) ? (int) $data['sort_order'] : 0,
			'updated_at'     => $now,
		);
		if ( $id ) {
			return false !== $wpdb->update( self::table( 'cards' ), $row, array( 'id' => absint( $id ) ) ) ? absint( $id ) : 0;
		}
		$row['created_at'] = $now;
		return $wpdb->insert( self::table( 'cards' ), $row ) ? (int) $wpdb->insert_id : 0;
	}

	public static function delete_card( $id ) {
		global $wpdb;
		return false !== $wpdb->update(
			self::table( 'cards' ),
			array( 'is_active' => 0, 'updated_at' => current_time( 'mysql', true ) ),
			array( 'id' => absint( $id ) ),
			array( '%d', '%s' ),
			array( '%d' )
		);
	}

	public static function save_receipt( $payment_id, $attachment_id, $url ) {
		global $wpdb;
		return false !== $wpdb->update(
			self::table( 'payments' ),
			array(
				'receipt_attachment_id' => absint( $attachment_id ),
				'receipt_url'           => esc_url_raw( $url ),
				'status'                => 'pending_review',
				'updated_at'            => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $payment_id ) ),
			array( '%d', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function decide_payment( $id, $status, $admin_id, $note = '' ) {
		global $wpdb;
		if ( ! in_array( $status, array( 'approved', 'rejected' ), true ) ) {
			return false;
		}
		return false !== $wpdb->update(
			self::table( 'payments' ),
			array(
				'status'      => $status,
				'admin_note'  => sanitize_textarea_field( $note ),
				'reviewed_by' => absint( $admin_id ),
				'decided_at'  => current_time( 'mysql', true ),
				'updated_at'  => current_time( 'mysql', true ),
			),
			array( 'id' => absint( $id ) ),
			array( '%s', '%s', '%d', '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function payment_by_id( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'payments' ) . ' WHERE id = %d LIMIT 1', absint( $id ) ) );
	}

	public static function list_payments( $limit = 100, $offset = 0 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT p.*, c.label AS card_label, c.card_number FROM ' . self::table( 'payments' ) . ' p LEFT JOIN ' . self::table( 'cards' ) . ' c ON c.id = p.card_id ORDER BY p.id DESC LIMIT %d OFFSET %d',
				max( 1, min( 500, absint( $limit ) ) ),
				absint( $offset )
			)
		);
	}

	public static function payment_counts() {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT status, COUNT(*) AS total, COALESCE(SUM(amount_rial),0) AS amount FROM ' . self::table( 'payments' ) . ' GROUP BY status', OBJECT_K );
		return is_array( $rows ) ? $rows : array();
	}

	public static function list_linked_users( $limit = 100 ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'users' ) . ' ORDER BY id DESC LIMIT %d', max( 1, min( 500, absint( $limit ) ) ) ) );
	}

	public static function log( $level, $event, $message, array $context = array() ) {
		global $wpdb;
		return (bool) $wpdb->insert(
			self::table( 'logs' ),
			array(
				'level'      => sanitize_key( $level ),
				'event'      => sanitize_key( $event ),
				'message'    => sanitize_text_field( $message ),
				'context'    => wp_json_encode( $context ),
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);
	}

	public static function list_logs( $limit = 100 ) {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'logs' ) . ' ORDER BY id DESC LIMIT %d', max( 1, min( 500, absint( $limit ) ) ) ) );
	}

	public static function expired_open_payments( $limit = 100 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM " . self::table( 'payments' ) . " WHERE expires_at < %s AND status IN ('created','sent','awaiting_receipt') ORDER BY id ASC LIMIT %d",
				current_time( 'mysql', true ),
				max( 1, min( 500, absint( $limit ) ) )
			)
		);
	}
}
