<?php
/**
 * SiteSkill licence client — drop this file into any plugin unchanged.
 *
 * Usage inside the plugin's main file:
 *
 *     require_once __DIR__ . '/class-ssk-license.php';
 *
 *     $ssk_license = new SSK_License( array(
 *         'slug'    => 'shuttle',          // must match the Extension slug on siteskill.ir
 *         'name'    => 'Shuttle',          // shown on the settings screen
 *         'file'    => __FILE__,           // the plugin's main file
 *         'version' => '2.1.3',
 *         'parent'  => 'shuttle',          // optional: the plugin's own menu slug
 *     ) );
 *
 *     if ( $ssk_license->is_valid() ) {
 *         // paid features here
 *     }
 *
 * Design notes that matter on a customer's live site:
 *
 *  - **The site never blocks on the network.** Verification happens on a daily
 *    WP-Cron event, not on page load. A visitor's request never waits on
 *    siteskill.ir.
 *
 *  - **Server unreachable ≠ invalid.** If siteskill.ir is down, or the host
 *    blocks outbound HTTP, or DNS fails, the last known-good answer keeps
 *    working for GRACE_DAYS. Treating a network error as "unlicensed" would
 *    switch off a paying customer's site because *our* server had a bad
 *    afternoon — the single worst failure mode a licence client can have.
 *
 *  - **Only an explicit refusal deactivates.** The server has to actually say
 *    the licence is invalid/revoked/expired before features go away.
 *
 * @package SiteSkill
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'SSK_License' ) ) :

	class SSK_License {

		/** Where licences live. */
		const API = 'https://siteskill.ir/api/license/';

		/** Where a customer buys a licence. */
		const SITE = 'https://siteskill.ir';

		/** Where free plugins hand out their own licences. */
		const FREE_PAGE = 'https://siteskill.ir/license';

		/** How long a cached "valid" answer is trusted before re-checking. */
		const CHECK_EVERY = DAY_IN_SECONDS;

		/** How long a licence keeps working while the server can't be reached. */
		const GRACE_DAYS = 14;

		/** @var array{slug:string,name:string,file:string,version:string} */
		private $config;

		/** @var string option name holding the key */
		private $opt_key;

		/** @var string option name holding the cached state */
		private $opt_state;

		public function __construct( array $config ) {
			$this->config = wp_parse_args(
				$config,
				array(
					'slug'    => '',
					'name'    => '',
					'file'    => '',
					'version' => '',
					// Menu slug to hang the licence screen under. Left empty it
					// lands in Settings, which is fine for one plugin and poor
					// for ten: the customer ends up with a row of "licence X"
					// entries under a menu that has nothing to do with them.
					'parent'  => '',
				)
			);

			$this->opt_key   = 'ssk_license_key_' . $this->config['slug'];
			$this->opt_state = 'ssk_license_state_' . $this->config['slug'];

			add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
			add_action( 'admin_init', array( $this, 'handle_form' ) );
			add_action( 'admin_notices', array( $this, 'admin_notice' ) );

			// Daily background re-check, so no visitor ever waits on our server.
			add_action( 'ssk_license_cron_' . $this->config['slug'], array( $this, 'refresh' ) );
			if ( ! wp_next_scheduled( 'ssk_license_cron_' . $this->config['slug'] ) ) {
				wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ssk_license_cron_' . $this->config['slug'] );
			}
		}

		/* ------------------------------------------------------------ state */

		public function get_key() {
			return trim( (string) get_option( $this->opt_key, '' ) );
		}

		private function get_state() {
			$state = get_option( $this->opt_state, array() );

			return wp_parse_args(
				is_array( $state ) ? $state : array(),
				array(
					'status'         => 'inactive',
					'message'        => '',
					'domain'         => '',
					'expires_at'     => null,
					'checked_at'     => 0,
					'last_good_at'   => 0,
					'latest_version' => '',
				)
			);
		}

		/**
		 * Is a newer version available on siteskill.ir?
		 *
		 * Compared with version_compare, not string equality, so 1.10.0 is
		 * correctly newer than 1.9.0 — the classic way this check goes wrong.
		 */
		public function update_available() {
			$state  = $this->get_state();
			$latest = trim( (string) $state['latest_version'] );
			$mine   = trim( (string) $this->config['version'] );

			if ( '' === $latest || '' === $mine ) {
				return false;
			}

			return version_compare( $latest, $mine, '>' );
		}

		public function latest_version() {
			$state = $this->get_state();

			return (string) $state['latest_version'];
		}

		private function save_state( array $patch ) {
			update_option( $this->opt_state, array_merge( $this->get_state(), $patch ), false );
		}

		/**
		 * The one method a plugin needs.
		 *
		 * Deliberately never makes an HTTP request: it reads cached state only,
		 * so calling it on every page load costs nothing.
		 */
		public function is_valid() {
			if ( '' === $this->get_key() ) {
				return false;
			}

			$state = $this->get_state();

			if ( 'active' === $state['status'] ) {
				// An expiry we already know about is honoured locally, so a
				// lapsed licence stops working even if the site is offline.
				if ( ! empty( $state['expires_at'] ) && strtotime( $state['expires_at'] ) < time() ) {
					return false;
				}

				return true;
			}

			// Unreachable server: keep the last good answer alive for a while.
			if ( 'unreachable' === $state['status'] && $state['last_good_at'] ) {
				return ( time() - (int) $state['last_good_at'] ) < ( self::GRACE_DAYS * DAY_IN_SECONDS );
			}

			return false;
		}

		public function status() {
			return $this->get_state();
		}

		/* -------------------------------------------------------- the network */

		/** The bare host of this site, matching how the server normalises it. */
		public function site_domain() {
			$host = wp_parse_url( home_url(), PHP_URL_HOST );
			$host = strtolower( (string) $host );

			return preg_replace( '/^www\./', '', $host );
		}

		private function post( $endpoint, array $body ) {
			$response = wp_remote_post(
				self::API . $endpoint,
				array(
					'timeout'   => 15,
					'sslverify' => true,
					'headers'   => array( 'Accept' => 'application/json' ),
					'body'      => $body,
				)
			);

			if ( is_wp_error( $response ) ) {
				return new WP_Error( 'ssk_unreachable', $response->get_error_message() );
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$data = json_decode( wp_remote_retrieve_body( $response ), true );

			// 429/5xx are *our* problem, not the customer's licence.
			if ( $code >= 500 || 429 === $code ) {
				return new WP_Error( 'ssk_unreachable', 'server busy' );
			}

			if ( ! is_array( $data ) || ! isset( $data['status'] ) ) {
				return new WP_Error( 'ssk_unreachable', 'unexpected response' );
			}

			return $data;
		}

		public function activate( $key ) {
			$key = strtoupper( trim( $key ) );

			$data = $this->post(
				'activate',
				array(
					'key'    => $key,
					'domain' => $this->site_domain(),
					'slug'   => $this->config['slug'],
				)
			);

			if ( is_wp_error( $data ) ) {
				// Nothing is saved: the customer should retry, not be told their
				// key is bad because the request never arrived.
				return $data;
			}

			if ( empty( $data['ok'] ) ) {
				$this->save_state(
					array(
						'status'     => $data['status'],
						'message'    => $data['message'],
						'checked_at' => time(),
					)
				);

				return new WP_Error( 'ssk_rejected', $data['message'] );
			}

			update_option( $this->opt_key, $key, false );
			$this->save_state(
				array(
					'status'         => 'active',
					'message'        => $data['message'],
					'domain'         => isset( $data['domain'] ) ? $data['domain'] : '',
					'expires_at'     => isset( $data['expires_at'] ) ? $data['expires_at'] : null,
					'latest_version' => isset( $data['latest_version'] ) ? $data['latest_version'] : '',
					'checked_at'     => time(),
					'last_good_at'   => time(),
				)
			);

			return true;
		}

		public function deactivate() {
			$key = $this->get_key();
			if ( '' === $key ) {
				return true;
			}

			$this->post(
				'deactivate',
				array(
					'key'    => $key,
					'domain' => $this->site_domain(),
				)
			);

			// Clear locally regardless: the customer asked to disconnect this
			// site, and a network error must not trap them here.
			delete_option( $this->opt_key );
			delete_option( $this->opt_state );

			return true;
		}

		/** The daily cron check. */
		public function refresh() {
			$key = $this->get_key();
			if ( '' === $key ) {
				return;
			}

			$data = $this->post(
				'validate',
				array(
					'key'    => $key,
					'domain' => $this->site_domain(),
				)
			);

			if ( is_wp_error( $data ) ) {
				$this->save_state(
					array(
						'status'     => 'unreachable',
						'message'    => 'ارتباط با سرور لایسنس برقرار نشد.',
						'checked_at' => time(),
					)
				);

				return;
			}

			if ( empty( $data['ok'] ) ) {
				$this->save_state(
					array(
						'status'     => $data['status'],
						'message'    => $data['message'],
						'checked_at' => time(),
					)
				);

				return;
			}

			$this->save_state(
				array(
					'status'         => 'active',
					'message'        => $data['message'],
					'domain'         => isset( $data['domain'] ) ? $data['domain'] : '',
					'expires_at'     => isset( $data['expires_at'] ) ? $data['expires_at'] : null,
					'latest_version' => isset( $data['latest_version'] ) ? $data['latest_version'] : '',
					'checked_at'     => time(),
					'last_good_at'   => time(),
				)
			);
		}

		/* ------------------------------------------------------------- admin */

		public function add_settings_page() {
			$parent = $this->config['parent'] ? $this->config['parent'] : 'options-general.php';

			// Under the plugin's own menu the word "licence" is enough; under
			// Settings it has to say which plugin it belongs to.
			$label = $this->config['parent'] ? 'لایسنس' : 'لایسنس ' . $this->config['name'];

			add_submenu_page(
				$parent,
				'لایسنس ' . $this->config['name'],
				$label,
				'manage_options',
				'ssk-license-' . $this->config['slug'],
				array( $this, 'render_settings_page' )
			);
		}

		public function handle_form() {
			if ( ! isset( $_POST['ssk_license_action'] ) || ! current_user_can( 'manage_options' ) ) {
				return;
			}

			/*
			 * Every SiteSkill plugin ships this same class, and each one hooks
			 * handle_form() on admin_init. They all used the default nonce field
			 * (_wpnonce), so submitting ONE plugin's licence form ran EVERY
			 * plugin's handler — and the others' check_admin_referer() failed
			 * its nonce and killed the page with "the link you followed has
			 * expired". Giving each plugin its own nonce field, and bailing
			 * out when it is absent, means an instance only ever handles its
			 * own form and quietly ignores the rest.
			 */
			$nonce_field = 'ssk_license_nonce_' . $this->config['slug'];

			if ( ! isset( $_POST[ $nonce_field ] ) ) {
				return; // this POST belongs to another SiteSkill plugin
			}

			check_admin_referer( 'ssk_license_' . $this->config['slug'], $nonce_field );

			$action = sanitize_text_field( wp_unslash( $_POST['ssk_license_action'] ) );

			if ( 'activate' === $action ) {
				$key    = isset( $_POST['ssk_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['ssk_license_key'] ) ) : '';
				$result = $this->activate( $key );

				set_transient(
					'ssk_license_flash_' . $this->config['slug'],
					is_wp_error( $result )
						? array( 'type' => 'error', 'text' => $result->get_error_message() )
						: array( 'type' => 'success', 'text' => 'لایسنس با موفقیت فعال شد.' ),
					30
				);
			}

			if ( 'deactivate' === $action ) {
				$this->deactivate();
				set_transient(
					'ssk_license_flash_' . $this->config['slug'],
					array( 'type' => 'success', 'text' => 'لایسنس از این سایت جدا شد.' ),
					30
				);
			}

			if ( 'refresh' === $action ) {
				$this->refresh();

				if ( $this->update_available() ) {
					$text = sprintf(
						'بررسی شد. نسخه‌ی %s منتشر شده است (نسخه‌ی فعلی شما: %s).',
						$this->latest_version(),
						$this->config['version']
					);
					$type = 'info';
				} else {
					$state = $this->get_state();
					// "Unreachable" is not a failure the customer should act on —
					// the licence keeps working — but silently claiming everything
					// is fine would hide a real problem, so say which it was.
					$type = ( 'active' === $state['status'] ) ? 'success' : 'error';
					$text = ( 'active' === $state['status'] )
						? 'بررسی شد. لایسنس معتبر است و نسخه‌ی شما به‌روز است.'
						: ( 'unreachable' === $state['status']
							? 'ارتباط با سایت‌اسکیل برقرار نشد. افزونه طبق مهلت تعریف‌شده به کار خود ادامه می‌دهد.'
							: (string) $state['message'] );
				}

				set_transient(
					'ssk_license_flash_' . $this->config['slug'],
					array( 'type' => $type, 'text' => $text ),
					30
				);
			}

			wp_safe_redirect( $this->settings_url() );
			exit;
		}

		/**
		 * Where this plugin's licence screen actually lives.
		 *
		 * It moves with `parent`, and WordPress hosts a submenu on a different
		 * file depending on what the parent is: a menu slug puts children on
		 * admin.php, while a parent that is itself a file (options-general.php,
		 * edit.php?post_type=…) hosts them on that file. Guessing wrong lands
		 * the customer on "Sorry, you are not allowed to access this page"
		 * immediately after saving a perfectly good key.
		 */
		private function settings_url() {
			$page   = 'ssk-license-' . $this->config['slug'];
			$parent = $this->config['parent'];

			if ( ! $parent ) {
				return admin_url( 'options-general.php?page=' . $page );
			}

			if ( false !== strpos( $parent, '.php' ) ) {
				return admin_url( add_query_arg( 'page', $page, $parent ) );
			}

			return admin_url( 'admin.php?page=' . $page );
		}

		public function admin_notice() {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$state    = $this->get_state();
			$settings = $this->settings_url();

			// A new release is news, not a problem — say so separately and in a
			// friendlier colour than a licence failure.
			if ( $this->update_available() ) {
				printf(
					'<div class="notice notice-info is-dismissible"><p><strong>%s:</strong> %s <a href="%s" target="_blank" rel="noopener">%s</a></p></div>',
					esc_html( $this->config['name'] ),
					sprintf(
						/* translators: 1: new version, 2: installed version */
						esc_html__( 'نسخه‌ی %1$s منتشر شد (نسخه‌ی فعلی شما: %2$s).', 'ssk' ),
						esc_html( $this->latest_version() ),
						esc_html( $this->config['version'] )
					),
					esc_url( self::FREE_PAGE ),
					esc_html__( 'دریافت نسخه‌ی جدید', 'ssk' )
				);
			}

			// Only nag about a real refusal, never about a network blip.
			$bad = array( 'invalid', 'revoked', 'expired', 'domain_mismatch', 'wrong_plugin' );
			if ( '' === $this->get_key() || ! in_array( $state['status'], $bad, true ) ) {
				return;
			}

			printf(
				'<div class="notice notice-error"><p><strong>%s:</strong> %s <a href="%s">تنظیم لایسنس</a></p></div>',
				esc_html( $this->config['name'] ),
				esc_html( $state['message'] ),
				esc_url( $settings )
			);
		}

		public function render_settings_page() {
			$state = $this->get_state();
			$key   = $this->get_key();
			$flash = get_transient( 'ssk_license_flash_' . $this->config['slug'] );
			delete_transient( 'ssk_license_flash_' . $this->config['slug'] );

			?>
			<div class="wrap" dir="rtl">
				<h1>لایسنس <?php echo esc_html( $this->config['name'] ); ?></h1>

				<?php if ( $flash ) : ?>
					<div class="notice notice-<?php echo esc_attr( $flash['type'] ); ?>">
						<p><?php echo esc_html( $flash['text'] ); ?></p>
					</div>
				<?php endif; ?>

				<table class="form-table">
					<tr>
						<th>وضعیت</th>
						<td>
							<?php if ( $this->is_valid() ) : ?>
								<span style="color:#0a7c42;font-weight:700">فعال</span>
								<?php if ( ! empty( $state['expires_at'] ) ) : ?>
									— تا <?php echo esc_html( date_i18n( 'Y/m/d', strtotime( $state['expires_at'] ) ) ); ?>
								<?php else : ?>
									— دائمی
								<?php endif; ?>
							<?php else : ?>
								<span style="color:#b32d2e;font-weight:700">غیرفعال</span>
								<?php echo $state['message'] ? ' — ' . esc_html( $state['message'] ) : ''; ?>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th>دامنه‌ی این سایت</th>
						<td><code><?php echo esc_html( $this->site_domain() ); ?></code></td>
					</tr>
					<tr>
						<th>نسخه</th>
						<td>
							<?php echo esc_html( $this->config['version'] ); ?>
							<?php if ( $this->update_available() ) : ?>
								— <strong style="color:#b26200">نسخه‌ی <?php echo esc_html( $this->latest_version() ); ?> منتشر شده است</strong>
							<?php endif; ?>
						</td>
					</tr>
				</table>

				<?php
				/*
				 * Where to get a key. Shown on every plugin, licensed or not:
				 * this screen is exactly where someone looks when they have no
				 * key and no idea where one comes from.
				 */
				?>
				<div style="background:#f0f6fc;border:1px solid #c3d4e6;border-radius:8px;padding:14px 16px;max-width:640px;margin:18px 0">
					<p style="margin:0 0 8px">
						<strong>کد لایسنس ندارید؟</strong>
					</p>
					<p style="margin:0 0 6px">
						برای تهیه‌ی لایسنس به
						<a href="<?php echo esc_url( self::SITE ); ?>" target="_blank" rel="noopener">SiteSkill.ir</a>
						مراجعه کنید.
					</p>
					<p style="margin:0">
						افزونه‌های رایگان لایسنس خودشان را همین‌جا می‌دهند:
						<a href="<?php echo esc_url( self::FREE_PAGE ); ?>" target="_blank" rel="noopener">صفحه‌ی Extensions</a>
					</p>
				</div>

				<form method="post">
					<?php wp_nonce_field( 'ssk_license_' . $this->config['slug'], 'ssk_license_nonce_' . $this->config['slug'] ); ?>

					<?php if ( '' === $key ) : ?>
						<p>
							<input type="text" name="ssk_license_key" class="regular-text" dir="ltr"
								placeholder="SSK-XXXXX-XXXXX-XXXXX-XXXXX" required>
						</p>
						<input type="hidden" name="ssk_license_action" value="activate">
						<?php submit_button( 'فعال‌سازی' ); ?>
					<?php else : ?>
						<p><code dir="ltr"><?php echo esc_html( $key ); ?></code></p>
						<input type="hidden" name="ssk_license_action" value="deactivate">
						<?php submit_button( 'جدا کردن از این سایت', 'secondary' ); ?>
						<p class="description">
							برای انتقال به سایت دیگر، ابتدا اینجا جدا کنید یا از بخش «تغییر دامنه» در siteskill.ir استفاده کنید.
						</p>
					<?php endif; ?>
				</form>

				<?php if ( '' !== $key ) : ?>
					<?php
					/*
					 * The daily WP-Cron check is what keeps a visitor from ever
					 * waiting on our server, but it also means news of a new
					 * release can be up to a day late — and on a quiet site,
					 * where cron only fires when somebody visits, longer still.
					 * This button is the way to ask right now.
					 */
					?>
					<form method="post" style="margin-top:8px">
						<?php wp_nonce_field( 'ssk_license_' . $this->config['slug'], 'ssk_license_nonce_' . $this->config['slug'] ); ?>
						<input type="hidden" name="ssk_license_action" value="refresh">
						<?php submit_button( 'بررسی وضعیت و نسخه‌ی جدید', 'secondary', 'submit', false ); ?>
						<span class="description" style="margin-right:8px">
							<?php
							$checked = $state['checked_at'] ? human_time_diff( (int) $state['checked_at'] ) . ' پیش' : 'هنوز بررسی نشده';
							echo esc_html( 'آخرین بررسی: ' . $checked );
							?>
						</span>
					</form>
				<?php endif; ?>
			</div>
			<?php
		}
	}

endif;
