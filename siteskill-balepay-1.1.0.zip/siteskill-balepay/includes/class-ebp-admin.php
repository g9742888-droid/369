<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Admin {
	const PAGE = 'siteskill-balepay';

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_head', array( $this, 'menu_icon_style' ) );
		add_action( 'admin_post_ebp_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_ebp_register_webhook', array( $this, 'register_webhook' ) );
		add_action( 'admin_post_ebp_test_connection', array( $this, 'test_connection' ) );
		add_action( 'admin_post_ebp_save_card', array( $this, 'save_card' ) );
		add_action( 'admin_post_ebp_delete_card', array( $this, 'delete_card' ) );
		add_action( 'admin_post_ebp_decide_payment', array( $this, 'decide_payment' ) );
		add_action( 'admin_post_ebp_export_transactions', array( $this, 'export_transactions' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( EBP_FILE ), array( $this, 'action_links' ) );
	}

	public function menu() {
		add_menu_page( 'درگاه بله پی اسکیل', 'بله پی اسکیل', 'manage_woocommerce', self::PAGE, array( $this, 'page' ), EBP_URL . 'assets/icon.png', 56 );
	}

	/**
	 * Constrain the custom PNG menu icon.
	 *
	 * When a raster URL is handed to add_menu_page(), WordPress prints it in an
	 * unsized <img>, so a large logo renders at its natural size and overflows
	 * the menu. Dashicons sit in a 20px box, so we match that. The menu shows on
	 * every admin screen, hence admin_head rather than the plugin-page assets.
	 */
	public function menu_icon_style() {
		echo '<style>#adminmenu .toplevel_page_' . esc_attr( self::PAGE ) . ' .wp-menu-image img{width:20px;height:20px;padding:7px 0;box-sizing:content-box}</style>' . "\n";
	}

	public function assets( $hook ) {
		if ( 'toplevel_page_' . self::PAGE !== $hook ) {
			return;
		}
		wp_enqueue_style( 'ebp-admin', EBP_URL . 'assets/admin.css', array( 'dashicons' ), EBP_VERSION );
		wp_enqueue_script( 'ebp-admin', EBP_URL . 'assets/admin.js', array(), EBP_VERSION, true );
	}

	public function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( $this->url() ) . '">مدیریت درگاه</a>' );
		return $links;
	}

	private function authorize( $action ) {
		if ( ! ebp_licensed() ) {
			wp_die( esc_html__( 'برای استفاده از این افزونه باید کد لایسنس را وارد کنید.', 'siteskill-balepay' ), '', array( 'response' => 403 ) );
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'siteskill-balepay' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	private function url( $tab = 'dashboard', array $args = array() ) {
		return add_query_arg( array_merge( array( 'page' => self::PAGE, 'ebp_tab' => $tab ), $args ), admin_url( 'admin.php' ) );
	}

	private function redirect( $tab, $status ) {
		wp_safe_redirect( $this->url( $tab, array( 'ebp_status' => sanitize_key( $status ) ) ) );
		exit;
	}

	public function save_settings() {
		$this->authorize( 'ebp_save_settings' );
		$scope = isset( $_POST['scope'] ) ? sanitize_key( wp_unslash( $_POST['scope'] ) ) : 'gateways';
		$partial = in_array( $scope, array( 'appearance', 'templates' ), true );
		$input = array();
		if ( 'appearance' === $scope ) {
			$input['admin_accent'] = isset( $_POST['admin_accent'] ) ? wp_unslash( $_POST['admin_accent'] ) : '#209b78';
		} elseif ( 'templates' === $scope ) {
			foreach ( array( 'message_receipt_received', 'message_receipt_approved', 'message_receipt_rejected', 'message_admin_receipt' ) as $key ) {
				$input[ $key ] = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
			}
		} else {
			$keys = array( 'title', 'description', 'card_title', 'card_description', 'card_instructions', 'bot_username', 'bot_token', 'provider_token', 'deadline_minutes', 'card_deadline_hours', 'receipt_max_mb', 'wallet_discount', 'card_discount' );
			foreach ( $keys as $key ) {
				$input[ $key ] = isset( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
			}
			$input['enabled'] = isset( $_POST['enabled'] ) ? 'yes' : '';
			$input['card_enabled'] = isset( $_POST['card_enabled'] ) ? 'yes' : '';
		}
		EBP_Settings::save( $input, $partial );
		EBP_DB::log( 'info', 'settings_saved', 'تنظیمات افزونه به‌روزرسانی شد.', array( 'scope' => $scope ) );
		$this->redirect( $partial ? $scope : 'gateways', 'saved' );
	}

	public function register_webhook() {
		$this->authorize( 'ebp_register_webhook' );
		if ( ! EBP_Settings::is_configured() ) {
			$this->redirect( 'connections', 'incomplete' );
		}
		$result = ( new EBP_Bale_API() )->set_webhook( EBP_Webhook::url() );
		if ( is_wp_error( $result ) ) {
			EBP_DB::log( 'error', 'webhook_failed', $result->get_error_message() );
			$this->redirect( 'connections', 'webhook_error' );
		}
		EBP_DB::log( 'info', 'webhook_registered', 'وبهوک ربات بله ثبت شد.' );
		$this->redirect( 'connections', 'webhook_ok' );
	}

	public function test_connection() {
		$this->authorize( 'ebp_test_connection' );
		$result = ( new EBP_Bale_API() )->get_me();
		if ( is_wp_error( $result ) ) {
			EBP_DB::log( 'error', 'connection_test_failed', $result->get_error_message() );
			$this->redirect( 'connections', 'connection_error' );
		}
		EBP_DB::log( 'info', 'connection_test_ok', 'اتصال ربات بله با موفقیت آزمایش شد.' );
		$this->redirect( 'connections', 'connection_ok' );
	}

	public function save_card() {
		$this->authorize( 'ebp_save_card' );
		$card_number = isset( $_POST['card_number'] ) ? preg_replace( '/\D+/', '', wp_unslash( $_POST['card_number'] ) ) : '';
		$label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
		$holder = isset( $_POST['account_holder'] ) ? sanitize_text_field( wp_unslash( $_POST['account_holder'] ) ) : '';
		if ( '' === $label || '' === $holder || ! preg_match( '/^\d{16,19}$/', $card_number ) ) {
			$this->redirect( 'cards', 'card_invalid' );
		}
		$id = isset( $_POST['card_id'] ) ? absint( wp_unslash( $_POST['card_id'] ) ) : 0;
		$saved = EBP_DB::save_card(
			array(
				'label'          => $label,
				'card_number'    => $card_number,
				'iban'           => isset( $_POST['iban'] ) ? wp_unslash( $_POST['iban'] ) : '',
				'account_holder' => $holder,
				'bank_name'      => isset( $_POST['bank_name'] ) ? wp_unslash( $_POST['bank_name'] ) : '',
				'is_active'      => isset( $_POST['is_active'] ),
				'sort_order'     => isset( $_POST['sort_order'] ) ? (int) $_POST['sort_order'] : 0,
			),
			$id
		);
		EBP_DB::log( $saved ? 'info' : 'error', 'card_saved', $saved ? 'کارت بانکی ذخیره شد.' : 'ذخیره کارت بانکی ناموفق بود.', array( 'card_id' => $saved ) );
		$this->redirect( 'cards', $saved ? 'card_saved' : 'card_error' );
	}

	public function delete_card() {
		$id = isset( $_GET['card_id'] ) ? absint( wp_unslash( $_GET['card_id'] ) ) : 0;
		$this->authorize( 'ebp_delete_card_' . $id );
		EBP_DB::delete_card( $id );
		EBP_DB::log( 'warning', 'card_disabled', 'کارت بانکی غیرفعال شد.', array( 'card_id' => $id ) );
		$this->redirect( 'cards', 'card_deleted' );
	}

	public function decide_payment() {
		$payment_id = isset( $_POST['payment_id'] ) ? absint( wp_unslash( $_POST['payment_id'] ) ) : 0;
		$this->authorize( 'ebp_decide_payment_' . $payment_id );
		$action = isset( $_POST['decision'] ) ? sanitize_key( wp_unslash( $_POST['decision'] ) ) : '';
		$note = isset( $_POST['admin_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['admin_note'] ) ) : '';
		$payment = EBP_DB::payment_by_id( $payment_id );
		$order = $payment ? wc_get_order( $payment->order_id ) : null;
		if ( ! $payment || ! $order || 'card' !== $payment->method || ! in_array( $action, array( 'approve', 'reject' ), true ) ) {
			$this->redirect( 'transactions', 'decision_error' );
		}
		if ( 'approve' === $action ) {
			if ( ! $order->is_paid() ) {
				$order->payment_complete( 'card-' . $payment->id );
			}
			$order->add_order_note( 'رسید کارت به کارت توسط مدیر تأیید شد.' . ( $note ? ' یادداشت: ' . $note : '' ) );
			EBP_DB::decide_payment( $payment_id, 'approved', get_current_user_id(), $note );
			EBP_Notifier::customer( $order, 'message_receipt_approved', $note );
			$status = 'approved';
		} else {
			if ( $order->is_paid() ) {
				$this->redirect( 'transactions', 'paid_cannot_reject' );
			}
			$order->update_status( 'cancelled', 'رسید کارت به کارت توسط مدیر رد شد.' . ( $note ? ' یادداشت: ' . $note : '' ) );
			EBP_DB::decide_payment( $payment_id, 'rejected', get_current_user_id(), $note );
			EBP_Notifier::customer( $order, 'message_receipt_rejected', $note );
			$status = 'rejected';
		}
		EBP_DB::log( 'info', 'payment_decided', 'نتیجه بررسی تراکنش ثبت شد.', array( 'payment_id' => $payment_id, 'decision' => $status ) );
		$this->redirect( 'transactions', $status );
	}

	private function csv_safe( $value ) {
		$value = (string) $value;
		return '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ? "'" . $value : $value;
	}

	public function export_transactions() {
		$this->authorize( 'ebp_export_transactions' );
		$rows = EBP_DB::list_payments( 500, 0 );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=siteskill-balepay-transactions-' . gmdate( 'Y-m-d' ) . '.csv' );
		echo "\xEF\xBB\xBF";
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'شناسه', 'سفارش', 'روش', 'وضعیت', 'مبلغ ریال', 'کارت مقصد', 'تاریخ' ) );
		foreach ( $rows as $row ) {
			fputcsv( $out, array( $row->id, $row->order_id, $row->method, $row->status, $row->amount_rial, $this->csv_safe( $row->card_number ), $row->created_at ) );
		}
		fclose( $out );
		exit;
	}

	public function page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( ! ebp_licensed() ) {
			$this->render_locked();
			return;
		}
		$tabs = $this->tabs();
		$tab = isset( $_GET['ebp_tab'] ) ? sanitize_key( wp_unslash( $_GET['ebp_tab'] ) ) : 'dashboard';
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'dashboard';
		}
		$accent = EBP_Settings::get( 'admin_accent', '#209b78' );
		?>
		<div class="wrap ebp-admin-wrap" dir="rtl" style="--ebp-accent:<?php echo esc_attr( $accent ); ?>">
			<div class="ebp-admin-layout">
				<aside class="ebp-admin-sidebar" aria-label="ناوبری بله پی اسکیل">
					<div class="ebp-admin-brand"><span class="ebp-brand-mark"><?php echo $this->icon( 'payment' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><div><strong>بله پی اسکیل</strong><small>مدیریت پرداخت</small></div></div>
					<nav class="ebp-admin-nav">
						<?php foreach ( $tabs as $key => $item ) : ?>
							<a class="<?php echo $tab === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url( $this->url( $key ) ); ?>" aria-current="<?php echo $tab === $key ? 'page' : 'false'; ?>"><span class="ebp-nav-icon"><?php echo $this->icon( $item['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><span><?php echo esc_html( $item['label'] ); ?></span></a>
						<?php endforeach; ?>
					</nav>
					<div class="ebp-admin-version">نسخه <?php echo esc_html( EBP_VERSION ); ?></div>
				</aside>
				<main class="ebp-admin-main">
					<header class="ebp-page-head"><div><h1><?php echo esc_html( $tabs[ $tab ]['label'] ); ?></h1><p><?php echo esc_html( $tabs[ $tab ]['desc'] ); ?></p></div><a class="ebp-site-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">مشاهده سایت</a></header>
					<?php $this->notice(); ?>
					<?php $method = 'render_' . $tab; $this->{$method}(); ?>
				</main>
			</div>
		</div>
		<?php
	}

	private function render_locked() {
		$license_url = admin_url( 'admin.php?page=ssk-license-' . self::PAGE );
		$accent = EBP_Settings::get( 'admin_accent', '#209b78' );
		?>
		<div class="wrap ebp-admin-wrap" dir="rtl" style="--ebp-accent:<?php echo esc_attr( $accent ); ?>">
			<div class="ebp-panel" style="max-width:640px;margin-top:24px">
				<div class="ebp-panel-head"><div><h2>افزونه قفل است</h2><p>برای فعال‌سازی امکانات درگاه بله پی اسکیل، ابتدا کد لایسنس معتبر را وارد کنید.</p></div></div>
				<p>تا زمانی که لایسنس معتبر ثبت نشود، درگاه‌های پرداخت، وبهوک و بخش‌های مدیریتی این افزونه فعال نمی‌شوند. سایر بخش‌های فروشگاه شما بدون تغییر به کار خود ادامه می‌دهند.</p>
				<p><a class="ebp-btn is-primary" href="<?php echo esc_url( $license_url ); ?>">وارد کردن کد لایسنس</a></p>
			</div>
		</div>
		<?php
	}

	private function tabs() {
		return array(
			'dashboard'    => array( 'label' => 'داشبورد', 'desc' => 'تصویر کلی از وضعیت پرداخت‌های فروشگاه', 'icon' => 'dashboard' ),
			'transactions' => array( 'label' => 'تراکنش‌ها', 'desc' => 'بررسی پرداخت‌های بله و رسیدهای کارت به کارت', 'icon' => 'transactions' ),
			'gateways'     => array( 'label' => 'درگاه‌های پرداخت', 'desc' => 'فعال‌سازی و تنظیم روش‌های پرداخت', 'icon' => 'payment' ),
			'cards'        => array( 'label' => 'کارت‌های مقصد', 'desc' => 'مدیریت شماره کارت‌های کارت به کارت', 'icon' => 'cards' ),
			'templates'    => array( 'label' => 'قالب پیام‌ها', 'desc' => 'متن پیام‌های خودکار مشتری و مدیر', 'icon' => 'templates' ),
			'connections'  => array( 'label' => 'اتصال بله', 'desc' => 'تنظیم ربات، توکن‌ها و وبهوک امن', 'icon' => 'connections' ),
			'users'        => array( 'label' => 'کاربران متصل', 'desc' => 'حساب‌های سایت که به بله متصل شده‌اند', 'icon' => 'users' ),
			'reports'      => array( 'label' => 'گزارش‌ها', 'desc' => 'آمار پرداخت و دریافت خروجی تراکنش‌ها', 'icon' => 'reports' ),
			'logs'         => array( 'label' => 'رویدادها', 'desc' => 'رخدادهای فنی و مدیریتی اخیر', 'icon' => 'logs' ),
			'appearance'   => array( 'label' => 'ظاهر پنل', 'desc' => 'شخصی‌سازی رنگ اصلی پنل مدیریت', 'icon' => 'appearance' ),
		);
	}

	private function notice() {
		$status = isset( $_GET['ebp_status'] ) ? sanitize_key( wp_unslash( $_GET['ebp_status'] ) ) : '';
		$messages = array(
			'saved' => array( 'success', 'تنظیمات با موفقیت ذخیره شد.' ), 'webhook_ok' => array( 'success', 'وبهوک با موفقیت در بله ثبت شد.' ),
			'incomplete' => array( 'error', 'نام کاربری ربات و هر دو توکن را کامل کنید.' ), 'webhook_error' => array( 'error', 'ثبت وبهوک ناموفق بود.' ),
			'connection_ok' => array( 'success', 'ارتباط با ربات بله برقرار است.' ), 'connection_error' => array( 'error', 'ارتباط با ربات بله ناموفق بود.' ),
			'card_saved' => array( 'success', 'کارت بانکی ذخیره شد.' ), 'card_deleted' => array( 'success', 'کارت بانکی غیرفعال شد.' ),
			'card_invalid' => array( 'error', 'نام کارت، صاحب حساب و شماره کارت معتبر الزامی است.' ), 'card_error' => array( 'error', 'ذخیره کارت ناموفق بود.' ),
			'approved' => array( 'success', 'تراکنش تأیید و سفارش نهایی شد.' ), 'rejected' => array( 'success', 'تراکنش رد و سفارش لغو شد.' ),
			'decision_error' => array( 'error', 'ثبت تصمیم ناموفق بود.' ), 'paid_cannot_reject' => array( 'error', 'سفارش پرداخت‌شده را نمی‌توان رد کرد.' ),
		);
		if ( isset( $messages[ $status ] ) ) {
			echo '<div class="ebp-admin-notice is-' . esc_attr( $messages[ $status ][0] ) . '" role="status">' . esc_html( $messages[ $status ][1] ) . '</div>';
		}
	}

	private function render_dashboard() {
		$counts = EBP_DB::payment_counts();
		$payments = EBP_DB::list_payments( 6 );
		$total = array_sum( array_map( static function ( $row ) { return (int) $row->total; }, $counts ) );
		$paid = ( isset( $counts['paid'] ) ? (int) $counts['paid']->total : 0 ) + ( isset( $counts['approved'] ) ? (int) $counts['approved']->total : 0 );
		$pending = ( isset( $counts['pending_review'] ) ? (int) $counts['pending_review']->total : 0 ) + ( isset( $counts['awaiting_receipt'] ) ? (int) $counts['awaiting_receipt']->total : 0 );
		?>
		<div class="ebp-stat-grid"><?php $this->stat_card( 'کل تراکنش‌ها', number_format_i18n( $total ), 'transactions' ); ?><?php $this->stat_card( 'پرداخت موفق', number_format_i18n( $paid ), 'success' ); ?><?php $this->stat_card( 'نیازمند پیگیری', number_format_i18n( $pending ), 'pending' ); ?><?php $this->stat_card( 'کارت فعال', number_format_i18n( EBP_DB::count_active_cards() ), 'cards' ); ?></div>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>دسترسی سریع</h2><p>مهم‌ترین بخش‌های مدیریت پرداخت</p></div></div><div class="ebp-quick-grid"><a href="<?php echo esc_url( $this->url( 'transactions' ) ); ?>"><?php echo $this->icon( 'transactions' ); // phpcs:ignore ?><span><strong>بررسی تراکنش‌ها</strong><small>رسیدهای جدید و پرداخت‌های بله</small></span></a><a href="<?php echo esc_url( $this->url( 'cards' ) ); ?>"><?php echo $this->icon( 'cards' ); // phpcs:ignore ?><span><strong>مدیریت کارت‌ها</strong><small>افزودن یا غیرفعال‌کردن کارت مقصد</small></span></a><a href="<?php echo esc_url( $this->url( 'connections' ) ); ?>"><?php echo $this->icon( 'connections' ); // phpcs:ignore ?><span><strong>وضعیت اتصال</strong><small>توکن ربات و ثبت وبهوک</small></span></a></div></div>
		<?php $this->payments_table( $payments, false ); ?>
		<?php
	}

	private function render_transactions() {
		$this->payments_table( EBP_DB::list_payments( 200 ), true );
	}

	private function render_gateways() {
		$s = EBP_Settings::all();
		?>
		<form class="ebp-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_save_settings"><input type="hidden" name="scope" value="gateways"><?php wp_nonce_field( 'ebp_save_settings' ); ?>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>پرداخت مستقیم بله</h2><p>ارسال فاکتور پرداخت به گفت‌وگوی متصل مشتری</p></div><?php $this->toggle( 'enabled', 'فعال', 'yes' === $s['enabled'] ); ?></div><div class="ebp-field-grid"><div class="ebp-field"><label for="ebp-title">عنوان روش پرداخت</label><input id="ebp-title" name="title" value="<?php echo esc_attr( $s['title'] ); ?>"></div><div class="ebp-field"><label for="ebp-deadline">مهلت پرداخت (دقیقه)</label><input id="ebp-deadline" type="number" min="5" max="1440" name="deadline_minutes" value="<?php echo esc_attr( $s['deadline_minutes'] ); ?>"></div><div class="ebp-field"><label for="ebp-wallet-discount">تخفیف این روش (درصد)</label><input id="ebp-wallet-discount" type="number" min="0" max="50" step="0.1" name="wallet_discount" value="<?php echo esc_attr( $s['wallet_discount'] ); ?>"></div><div class="ebp-field is-wide"><label for="ebp-description">توضیح مشتری</label><textarea id="ebp-description" rows="3" name="description"><?php echo esc_textarea( $s['description'] ); ?></textarea></div></div></div>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>کارت به کارت</h2><p>نمایش کارت مقصد و دریافت رسید از مشتری</p></div><?php $this->toggle( 'card_enabled', 'فعال', 'yes' === $s['card_enabled'] ); ?></div><div class="ebp-field-grid"><div class="ebp-field"><label for="ebp-card-title">عنوان روش پرداخت</label><input id="ebp-card-title" name="card_title" value="<?php echo esc_attr( $s['card_title'] ); ?>"></div><div class="ebp-field"><label for="ebp-card-deadline">مهلت ارسال رسید (ساعت)</label><input id="ebp-card-deadline" type="number" min="1" max="168" name="card_deadline_hours" value="<?php echo esc_attr( $s['card_deadline_hours'] ); ?>"></div><div class="ebp-field"><label for="ebp-max-mb">حداکثر حجم رسید (MB)</label><input id="ebp-max-mb" type="number" min="1" max="10" name="receipt_max_mb" value="<?php echo esc_attr( $s['receipt_max_mb'] ); ?>"></div><div class="ebp-field"><label for="ebp-card-discount">تخفیف این روش (درصد)</label><input id="ebp-card-discount" type="number" min="0" max="50" step="0.1" name="card_discount" value="<?php echo esc_attr( $s['card_discount'] ); ?>"></div><div class="ebp-field is-wide"><label for="ebp-card-description">توضیح کوتاه</label><textarea id="ebp-card-description" rows="2" name="card_description"><?php echo esc_textarea( $s['card_description'] ); ?></textarea></div><div class="ebp-field is-wide"><label for="ebp-card-instructions">راهنمای واریز</label><textarea id="ebp-card-instructions" rows="3" name="card_instructions"><?php echo esc_textarea( $s['card_instructions'] ); ?></textarea></div></div></div>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>اتصال ربات</h2><p>توکن‌های موجود با مقدار خالی تغییر نمی‌کنند</p></div></div><?php $this->connection_fields( $s ); ?></div><div class="ebp-form-actions"><button class="ebp-btn is-primary" type="submit">ذخیره تنظیمات</button></div></form>
		<?php
	}

	private function render_cards() {
		$cards = EBP_DB::list_cards();
		?>
		<div class="ebp-card-list"><?php if ( ! $cards ) : ?><div class="ebp-empty">هنوز کارت مقصدی ثبت نشده است.</div><?php endif; ?><?php foreach ( $cards as $card ) : ?><article class="ebp-card-item <?php echo $card->is_active ? '' : 'is-disabled'; ?>"><div class="ebp-card-item-top"><span><?php echo esc_html( $card->bank_name ?: 'کارت بانکی' ); ?></span><span class="ebp-status <?php echo $card->is_active ? 'is-success' : 'is-muted'; ?>"><?php echo $card->is_active ? 'فعال' : 'غیرفعال'; ?></span></div><b dir="ltr"><?php echo esc_html( WC_Gateway_EBP_Card::format_card_number( $card->card_number ) ); ?></b><p><?php echo esc_html( $card->label ); ?> — <?php echo esc_html( $card->account_holder ); ?></p><div class="ebp-card-actions"><button type="button" class="ebp-btn is-small ebp-edit-card" data-card="<?php echo esc_attr( wp_json_encode( $card ) ); ?>">ویرایش</button><?php if ( $card->is_active ) : ?><a class="ebp-btn is-small is-danger ebp-confirm-delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ebp_delete_card&card_id=' . $card->id ), 'ebp_delete_card_' . $card->id ) ); ?>">غیرفعال‌کردن</a><?php endif; ?></div></article><?php endforeach; ?></div>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2 id="ebp-card-form-title">افزودن کارت مقصد</h2><p>شماره کارت فقط برای نمایش به خریدار استفاده می‌شود.</p></div></div><form class="ebp-form" id="ebp-card-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_save_card"><input type="hidden" name="card_id" value=""><?php wp_nonce_field( 'ebp_save_card' ); ?><div class="ebp-field-grid"><div class="ebp-field"><label for="ebp-card-label">عنوان کارت <span>*</span></label><input id="ebp-card-label" required name="label" placeholder="مثلاً کارت اصلی فروشگاه"></div><div class="ebp-field"><label for="ebp-bank-name">نام بانک</label><input id="ebp-bank-name" name="bank_name" placeholder="مثلاً ملت"></div><div class="ebp-field"><label for="ebp-card-number">شماره کارت <span>*</span></label><input id="ebp-card-number" required dir="ltr" inputmode="numeric" minlength="16" maxlength="23" name="card_number" placeholder="0000 0000 0000 0000"></div><div class="ebp-field"><label for="ebp-account-holder">صاحب حساب <span>*</span></label><input id="ebp-account-holder" required name="account_holder"></div><div class="ebp-field"><label for="ebp-iban">شماره شبا</label><input id="ebp-iban" dir="ltr" name="iban" placeholder="IR..."></div><div class="ebp-field"><label for="ebp-sort-order">ترتیب نمایش</label><input id="ebp-sort-order" type="number" name="sort_order" value="0"></div></div><div class="ebp-inline-actions"><?php $this->toggle( 'is_active', 'کارت فعال باشد', true ); ?><button class="ebp-btn is-primary" type="submit">ذخیره کارت</button><button class="ebp-btn ebp-cancel-edit" type="button" hidden>لغو ویرایش</button></div></form></div>
		<?php
	}

	private function render_connections() {
		$s = EBP_Settings::all();
		?>
		<div class="ebp-status-grid"><div class="ebp-connection-card"><span class="ebp-connection-dot <?php echo EBP_Settings::secret( 'bot_token' ) ? 'is-online' : ''; ?>"></span><div><strong>توکن ربات</strong><small><?php echo EBP_Settings::secret( 'bot_token' ) ? 'ثبت شده' : 'ثبت نشده'; ?></small></div></div><div class="ebp-connection-card"><span class="ebp-connection-dot <?php echo EBP_Settings::secret( 'provider_token' ) ? 'is-online' : ''; ?>"></span><div><strong>توکن پذیرنده</strong><small><?php echo EBP_Settings::secret( 'provider_token' ) ? 'ثبت شده' : 'ثبت نشده'; ?></small></div></div><div class="ebp-connection-card"><span class="ebp-connection-dot <?php echo EBP_Settings::is_configured() ? 'is-online' : ''; ?>"></span><div><strong>آمادگی درگاه</strong><small><?php echo EBP_Settings::is_configured() ? 'آماده ثبت وبهوک' : 'نیازمند تکمیل'; ?></small></div></div></div>
		<div class="ebp-panel"><form class="ebp-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_save_settings"><input type="hidden" name="scope" value="gateways"><?php wp_nonce_field( 'ebp_save_settings' ); ?><input type="hidden" name="enabled" value="<?php echo 'yes' === $s['enabled'] ? '1' : ''; ?>"><input type="hidden" name="card_enabled" value="<?php echo 'yes' === $s['card_enabled'] ? '1' : ''; ?>"><input type="hidden" name="title" value="<?php echo esc_attr( $s['title'] ); ?>"><input type="hidden" name="description" value="<?php echo esc_attr( $s['description'] ); ?>"><input type="hidden" name="card_title" value="<?php echo esc_attr( $s['card_title'] ); ?>"><input type="hidden" name="card_description" value="<?php echo esc_attr( $s['card_description'] ); ?>"><input type="hidden" name="card_instructions" value="<?php echo esc_attr( $s['card_instructions'] ); ?>"><input type="hidden" name="deadline_minutes" value="<?php echo esc_attr( $s['deadline_minutes'] ); ?>"><input type="hidden" name="card_deadline_hours" value="<?php echo esc_attr( $s['card_deadline_hours'] ); ?>"><input type="hidden" name="receipt_max_mb" value="<?php echo esc_attr( $s['receipt_max_mb'] ); ?>"><input type="hidden" name="wallet_discount" value="<?php echo esc_attr( $s['wallet_discount'] ); ?>"><input type="hidden" name="card_discount" value="<?php echo esc_attr( $s['card_discount'] ); ?>"><?php $this->connection_fields( $s ); ?><div class="ebp-form-actions"><button class="ebp-btn is-primary" type="submit">ذخیره اطلاعات اتصال</button></div></form></div>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>آزمایش اتصال و وبهوک</h2><p>ابتدا اتصال ربات را آزمایش و سپس وبهوک را ثبت کنید.</p></div></div><div class="ebp-inline-actions"><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_test_connection"><?php wp_nonce_field( 'ebp_test_connection' ); ?><button class="ebp-btn" type="submit">آزمایش اتصال ربات</button></form><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_register_webhook"><?php wp_nonce_field( 'ebp_register_webhook' ); ?><button class="ebp-btn is-primary" type="submit">ثبت وبهوک در بله</button></form></div></div>
		<?php
	}

	private function render_templates() {
		$s = EBP_Settings::all();
		$fields = array(
			'message_receipt_received' => array( 'رسید دریافت شد', 'برای مشتری بلافاصله بعد از آپلود رسید' ),
			'message_receipt_approved' => array( 'رسید تأیید شد', 'برای مشتری پس از تأیید مدیر' ),
			'message_receipt_rejected' => array( 'رسید رد شد', 'برای مشتری پس از رد مدیر' ),
			'message_admin_receipt' => array( 'رسید جدید برای مدیر', 'برای مدیران متصل‌شده به ربات' ),
		);
		?>
		<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>متغیرهای قابل استفاده</h2><p><code>{order_id}</code> شماره سفارش، <code>{total}</code> مبلغ، <code>{customer}</code> مشتری و <code>{note}</code> یادداشت مدیر</p></div></div><form class="ebp-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_save_settings"><input type="hidden" name="scope" value="templates"><?php wp_nonce_field( 'ebp_save_settings' ); ?><div class="ebp-field-grid"><?php foreach ( $fields as $key => $meta ) : ?><div class="ebp-field is-wide"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $meta[0] ); ?></label><textarea id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" rows="3"><?php echo esc_textarea( $s[ $key ] ); ?></textarea><small><?php echo esc_html( $meta[1] ); ?></small></div><?php endforeach; ?></div><div class="ebp-form-actions"><button class="ebp-btn is-primary" type="submit">ذخیره قالب‌ها</button></div></form></div>
		<?php
	}

	private function connection_fields( $s ) {
		?><div class="ebp-field-grid"><div class="ebp-field"><label for="ebp-username">نام کاربری ربات</label><input id="ebp-username" dir="ltr" name="bot_username" value="<?php echo esc_attr( $s['bot_username'] ); ?>" placeholder="SiteSkillBot"></div><div class="ebp-field"><label for="ebp-bot-token">Bot Token</label><input id="ebp-bot-token" dir="ltr" type="password" autocomplete="new-password" name="bot_token" placeholder="برای حفظ مقدار فعلی خالی بگذارید"></div><div class="ebp-field"><label for="ebp-provider-token">Provider Token</label><input id="ebp-provider-token" dir="ltr" type="password" autocomplete="new-password" name="provider_token" placeholder="برای حفظ مقدار فعلی خالی بگذارید"></div></div><?php
	}

	private function render_users() {
		$users = EBP_DB::list_linked_users( 200 );
		echo '<div class="ebp-panel"><div class="ebp-table-wrap"><table class="ebp-table"><thead><tr><th>کاربر سایت</th><th>نام بله</th><th>نام کاربری بله</th><th>تاریخ اتصال</th></tr></thead><tbody>';
		if ( ! $users ) { echo '<tr><td colspan="4" class="ebp-empty-cell">کاربری متصل نشده است.</td></tr>'; }
		foreach ( $users as $user ) {
			$wp_user = get_userdata( $user->wp_user_id );
			echo '<tr><td>' . esc_html( $wp_user ? $wp_user->display_name : '#' . $user->wp_user_id ) . '</td><td>' . esc_html( $user->first_name ) . '</td><td dir="ltr">' . esc_html( $user->username ? '@' . $user->username : '—' ) . '</td><td dir="ltr">' . esc_html( get_date_from_gmt( $user->linked_at, 'Y/m/d H:i' ) ) . '</td></tr>';
		}
		echo '</tbody></table></div></div>';
	}

	private function render_reports() {
		$counts = EBP_DB::payment_counts();
		?><div class="ebp-stat-grid"><?php foreach ( array( 'paid' => 'پرداخت مستقیم موفق', 'approved' => 'کارت به کارت تأییدشده', 'pending_review' => 'در انتظار بررسی', 'rejected' => 'ردشده' ) as $key => $label ) : $row = isset( $counts[ $key ] ) ? $counts[ $key ] : null; ?><?php $this->stat_card( $label, number_format_i18n( $row ? $row->total : 0 ), 'reports' ); ?><?php endforeach; ?></div><div class="ebp-panel"><div class="ebp-panel-head"><div><h2>خروجی تراکنش‌ها</h2><p>فایل CSV سازگار با اکسل، حداکثر ۵۰۰ تراکنش اخیر</p></div></div><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_export_transactions"><?php wp_nonce_field( 'ebp_export_transactions' ); ?><button class="ebp-btn is-primary" type="submit">دریافت فایل CSV</button></form></div><?php
	}

	private function render_logs() {
		$logs = EBP_DB::list_logs( 200 );
		echo '<div class="ebp-panel"><div class="ebp-table-wrap"><table class="ebp-table"><thead><tr><th>زمان</th><th>سطح</th><th>رویداد</th><th>پیام</th></tr></thead><tbody>';
		if ( ! $logs ) { echo '<tr><td colspan="4" class="ebp-empty-cell">رخدادی ثبت نشده است.</td></tr>'; }
		foreach ( $logs as $log ) {
			echo '<tr><td dir="ltr">' . esc_html( get_date_from_gmt( $log->created_at, 'Y/m/d H:i' ) ) . '</td><td><span class="ebp-status is-' . esc_attr( $log->level ) . '">' . esc_html( $log->level ) . '</span></td><td>' . esc_html( $log->event ) . '</td><td>' . esc_html( $log->message ) . '</td></tr>';
		}
		echo '</tbody></table></div></div>';
	}

	private function render_appearance() {
		?><div class="ebp-panel ebp-appearance-card"><div class="ebp-panel-head"><div><h2>رنگ اصلی پنل</h2><p>رنگ دکمه‌ها، حالت فعال و نشانگرهای پنل</p></div></div><form class="ebp-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="ebp_save_settings"><input type="hidden" name="scope" value="appearance"><?php wp_nonce_field( 'ebp_save_settings' ); ?><div class="ebp-color-row"><input aria-label="انتخاب رنگ اصلی" type="color" name="admin_accent" value="<?php echo esc_attr( EBP_Settings::get( 'admin_accent', '#209b78' ) ); ?>"><div><strong>رنگ سفارشی</strong><small>برای خوانایی مناسب، رنگ متوسط یا تیره انتخاب کنید.</small></div></div><button class="ebp-btn is-primary" type="submit">ذخیره ظاهر</button></form></div><?php
	}

	private function payments_table( $payments, $actions ) {
		$labels = array( 'created' => 'ایجادشده', 'sent' => 'در انتظار بله', 'paid' => 'پرداخت موفق', 'awaiting_receipt' => 'در انتظار رسید', 'pending_review' => 'نیازمند بررسی', 'approved' => 'تأییدشده', 'rejected' => 'ردشده', 'failed' => 'ناموفق', 'expired' => 'منقضی' );
		echo '<div class="ebp-panel"><div class="ebp-panel-head"><div><h2>' . ( $actions ? 'همه تراکنش‌ها' : 'تراکنش‌های اخیر' ) . '</h2><p>پرداخت مستقیم بله و کارت به کارت</p></div></div><div class="ebp-table-wrap"><table class="ebp-table"><thead><tr><th>سفارش</th><th>روش</th><th>مبلغ</th><th>وضعیت</th><th>رسید</th><th>تاریخ</th>' . ( $actions ? '<th>عملیات</th>' : '' ) . '</tr></thead><tbody>';
		if ( ! $payments ) { echo '<tr><td colspan="7" class="ebp-empty-cell">تراکنشی ثبت نشده است.</td></tr>'; }
		foreach ( $payments as $p ) {
			$order = wc_get_order( $p->order_id );
			$method = 'card' === $p->method ? 'کارت به کارت' : 'پرداخت بله';
			$status_label = isset( $labels[ $p->status ] ) ? $labels[ $p->status ] : $p->status;
			echo '<tr><td><a href="' . esc_url( $order ? $order->get_edit_order_url() : '#' ) . '">#' . esc_html( $p->order_id ) . '</a></td><td>' . esc_html( $method ) . '</td><td dir="ltr">' . esc_html( number_format_i18n( $p->amount_rial ) ) . ' ریال</td><td><span class="ebp-status is-' . esc_attr( $p->status ) . '">' . esc_html( $status_label ) . '</span></td><td>' . ( $p->receipt_url ? '<a target="_blank" rel="noopener" href="' . esc_url( $p->receipt_url ) . '">مشاهده رسید</a>' : '—' ) . '</td><td dir="ltr">' . esc_html( get_date_from_gmt( $p->created_at, 'Y/m/d H:i' ) ) . '</td>';
			if ( $actions ) {
				echo '<td>';
				if ( 'card' === $p->method && 'pending_review' === $p->status ) {
					echo '<form class="ebp-decision-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="ebp_decide_payment"><input type="hidden" name="payment_id" value="' . esc_attr( $p->id ) . '">';
					wp_nonce_field( 'ebp_decide_payment_' . $p->id );
					echo '<input name="admin_note" aria-label="یادداشت مدیر" placeholder="یادداشت اختیاری"><button class="ebp-btn is-small is-primary" name="decision" value="approve">تأیید</button><button class="ebp-btn is-small is-danger ebp-confirm-reject" name="decision" value="reject">رد</button></form>';
				} else { echo '—'; }
				echo '</td>';
			}
			echo '</tr>';
		}
		echo '</tbody></table></div></div>';
	}

	private function stat_card( $label, $value, $icon ) {
		echo '<article class="ebp-stat-card"><span class="ebp-stat-icon">' . $this->icon( $icon ) . '</span><div><small>' . esc_html( $label ) . '</small><strong>' . esc_html( $value ) . '</strong></div></article>';
	}

	private function toggle( $name, $label, $checked ) {
		echo '<label class="ebp-toggle"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1" ' . checked( true, $checked, false ) . '><span aria-hidden="true"></span><b>' . esc_html( $label ) . '</b></label>';
	}

	private function icon( $name ) {
		$paths = array(
			'dashboard' => '<path d="M4 4h6v7H4V4Zm10 0h6v4h-6V4ZM4 15h6v5H4v-5Zm10-3h6v8h-6v-8Z"/>',
			'transactions' => '<path d="M5 4h14v16H5zM8 8h8M8 12h8M8 16h5"/>',
			'payment' => '<path d="M5 4h14v16H5zM8 8h8M8 13l2 2 5-5"/>',
			'cards' => '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M3 10h18M7 15h4"/>',
			'connections' => '<path d="M9 15l6-6M7.5 12.5l-2 2a3 3 0 104 4l2-2M16.5 11.5l2-2a3 3 0 10-4-4l-2 2"/>',
			'users' => '<circle cx="9" cy="8" r="3"/><path d="M4 20c0-4 2-7 5-7s5 3 5 7M15 6a3 3 0 010 6M16 14c2 .5 4 2.5 4 6"/>',
			'reports' => '<path d="M5 20V10M12 20V4M19 20v-7"/>',
			'logs' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
			'appearance' => '<path d="M12 3a9 9 0 100 18h1.5a2 2 0 000-4H12a2 2 0 010-4h4a5 5 0 000-10h-4Z"/><circle cx="7.5" cy="10" r=".6"/><circle cx="9" cy="6.5" r=".6"/><circle cx="14" cy="6.5" r=".6"/>',
			'templates' => '<path d="M4 5h16v12H9l-5 4V5Z"/><path d="M8 9h8M8 13h5"/>',
			'success' => '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
			'pending' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		);
		$path = isset( $paths[ $name ] ) ? $paths[ $name ] : $paths['dashboard'];
		return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $path . '</svg>';
	}
}
