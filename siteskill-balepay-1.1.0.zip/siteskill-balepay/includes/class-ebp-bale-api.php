<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Bale_API {
	private $token;

	public function __construct() {
		$this->token = EBP_Settings::secret( 'bot_token' );
	}

	private function endpoint( $method ) {
		return 'https://tapi.bale.ai/bot' . rawurlencode( $this->token ) . '/' . rawurlencode( $method );
	}

	public function call( $method, array $params = array() ) {
		if ( '' === $this->token ) {
			return new WP_Error( 'ebp_missing_bot_token', 'توکن ربات بله تنظیم نشده است.' );
		}

		$response = wp_safe_remote_post(
			$this->endpoint( $method ),
			array(
				'timeout'     => 20,
				'redirection' => 0,
				'headers'     => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'        => wp_json_encode( $params ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'ebp_bale_network', 'ارتباط با بله برقرار نشد: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) || ! is_array( $body ) || empty( $body['ok'] ) ) {
			$message = is_array( $body ) && ! empty( $body['description'] ) ? sanitize_text_field( $body['description'] ) : 'پاسخ نامعتبر از بله دریافت شد.';
			return new WP_Error( 'ebp_bale_api', $message );
		}
		return $body['result'] ?? true;
	}

	public function send_message( $chat_id, $text ) {
		return $this->call(
			'sendMessage',
			array(
				'chat_id' => (string) $chat_id,
				'text'    => (string) $text,
			)
		);
	}

	public function send_invoice( $chat_id, $title, $description, $payload, $amount_rial ) {
		$provider_token = EBP_Settings::secret( 'provider_token' );
		if ( '' === $provider_token ) {
			return new WP_Error( 'ebp_missing_provider_token', 'توکن پذیرندهٔ بله‌پی تنظیم نشده است.' );
		}

		return $this->call(
			'sendInvoice',
			array(
				'chat_id'         => (string) $chat_id,
				'title'           => mb_substr( (string) $title, 0, 32 ),
				'description'     => mb_substr( (string) $description, 0, 255 ),
				'payload'         => (string) $payload,
				'provider_token'  => $provider_token,
				'start_parameter' => substr( preg_replace( '/[^A-Za-z0-9_]/', '', $payload ), 0, 32 ),
				'currency'        => 'IRR',
				'prices'          => array(
					array(
						'label'  => mb_substr( (string) $title, 0, 32 ),
						'amount' => absint( $amount_rial ),
					),
				),
			)
		);
	}

	public function answer_pre_checkout( $query_id, $ok, $error_message = '' ) {
		$params = array(
			'pre_checkout_query_id' => (string) $query_id,
			'ok'                    => (bool) $ok,
		);
		if ( ! $ok ) {
			$params['error_message'] = (string) $error_message;
		}
		return $this->call( 'answerPreCheckoutQuery', $params );
	}

	public function set_webhook( $url ) {
		return $this->call( 'setWebhook', array( 'url' => esc_url_raw( $url ) ) );
	}

	public function get_me() {
		return $this->call( 'getMe' );
	}

	public function get_webhook_info() {
		return $this->call( 'getWebhookInfo' );
	}
}
