<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Crypto {
	private static function key() {
		return hash_hmac( 'sha256', 'siteskill-balepay-secrets', wp_salt( 'auth' ), true );
	}

	public static function encrypt( $plaintext ) {
		$plaintext = (string) $plaintext;
		if ( '' === $plaintext ) {
			return '';
		}

		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$ciphertext = sodium_crypto_secretbox( $plaintext, $nonce, self::key() );
			return 's1:' . base64_encode( $nonce . $ciphertext );
		}

		if ( function_exists( 'openssl_encrypt' ) ) {
			$iv  = random_bytes( 12 );
			$tag = '';
			$ciphertext = openssl_encrypt( $plaintext, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag );
			if ( false !== $ciphertext ) {
				return 'g1:' . base64_encode( $iv . $tag . $ciphertext );
			}
		}

		return '';
	}

	public static function decrypt( $encoded ) {
		$encoded = (string) $encoded;
		if ( '' === $encoded || strlen( $encoded ) < 4 ) {
			return '';
		}

		$prefix = substr( $encoded, 0, 3 );
		$raw = base64_decode( substr( $encoded, 3 ), true );
		if ( false === $raw ) {
			return '';
		}

		if ( 's1:' === $prefix && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$nonce_size = SODIUM_CRYPTO_SECRETBOX_NONCEBYTES;
			if ( strlen( $raw ) <= $nonce_size ) {
				return '';
			}
			$plain = sodium_crypto_secretbox_open( substr( $raw, $nonce_size ), substr( $raw, 0, $nonce_size ), self::key() );
			return false === $plain ? '' : $plain;
		}

		if ( 'g1:' === $prefix && function_exists( 'openssl_decrypt' ) && strlen( $raw ) > 28 ) {
			$plain = openssl_decrypt(
				substr( $raw, 28 ),
				'aes-256-gcm',
				self::key(),
				OPENSSL_RAW_DATA,
				substr( $raw, 0, 12 ),
				substr( $raw, 12, 16 )
			);
			return false === $plain ? '' : $plain;
		}

		return '';
	}
}
