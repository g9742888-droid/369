<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Lifecycle {
	public function __construct() {
		add_action( 'woocommerce_checkout_update_order_review', array( $this, 'remember_method' ) );
		add_action( 'woocommerce_cart_calculate_fees', array( $this, 'discount' ) );
		add_action( 'ebp_hourly_maintenance', array( __CLASS__, 'expire_payments' ) );
		if ( ! wp_next_scheduled( 'ebp_hourly_maintenance' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'ebp_hourly_maintenance' );
		}
	}

	public function remember_method( $posted_data ) {
		if ( ! WC()->session ) {
			return;
		}
		parse_str( $posted_data, $data );
		if ( ! empty( $data['payment_method'] ) ) {
			WC()->session->set( 'chosen_payment_method', sanitize_key( $data['payment_method'] ) );
		}
	}

	public function discount( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() || ! WC()->session || ! $cart || $cart->is_empty() ) {
			return;
		}
		$method = WC()->session->get( 'chosen_payment_method' );
		$percent = 0;
		$label = '';
		if ( 'siteskill_balepay' === $method ) {
			$percent = (float) EBP_Settings::get( 'wallet_discount', 0 );
			$label = 'تخفیف پرداخت بله';
		} elseif ( 'siteskill_balepay_card' === $method ) {
			$percent = (float) EBP_Settings::get( 'card_discount', 0 );
			$label = 'تخفیف کارت به کارت';
		}
		if ( $percent > 0 ) {
			$cart->add_fee( $label, -1 * ( $cart->get_cart_contents_total() * $percent / 100 ), false );
		}
	}

	public static function expire_payments() {
		foreach ( EBP_DB::expired_open_payments() as $payment ) {
			EBP_DB::set_payment_status( $payment->id, 'expired' );
			$order = wc_get_order( $payment->order_id );
			if ( $order && ! $order->is_paid() && in_array( $order->get_status(), array( 'pending', 'on-hold' ), true ) ) {
				$order->update_status( 'cancelled', 'مهلت پرداخت بله پی اسکیل به پایان رسید.' );
			}
			EBP_DB::log( 'warning', 'payment_expired', 'تراکنش منقضی شد.', array( 'payment_id' => $payment->id, 'order_id' => $payment->order_id ) );
		}
	}

	public static function deactivate() {
		$timestamp = wp_next_scheduled( 'ebp_hourly_maintenance' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'ebp_hourly_maintenance' );
		}
	}
}
