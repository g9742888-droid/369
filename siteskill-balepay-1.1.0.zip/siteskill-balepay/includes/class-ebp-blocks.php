<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EBP_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
	protected $name = 'siteskill_balepay';

	public function initialize() {
		$this->settings = EBP_Settings::all();
	}

	public function is_active() {
		return EBP_Settings::is_configured()
			&& in_array( get_woocommerce_currency(), array( 'IRR', 'IRT', 'TOMAN' ), true );
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'ebp-blocks',
			EBP_URL . 'assets/blocks.js',
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
			EBP_VERSION,
			true
		);
		return array( 'ebp-blocks' );
	}

	public function get_payment_method_data() {
		$user_id = get_current_user_id();
		$linked  = $user_id ? (bool) EBP_DB::linked_user( $user_id ) : false;
		$data = array(
			'title'       => EBP_Settings::get( 'title', 'بله پی اسکیل' ),
			'description' => EBP_Settings::get( 'description', '' ),
			'loggedIn'    => (bool) $user_id,
			'linked'      => $linked,
			'supports'    => array( 'products' ),
		);
		if ( $user_id && ! $linked ) {
			$code = EBP_DB::create_link_code( $user_id );
			$data['connectUrl']  = EBP_Linking::deep_link( $code );
			$data['connectCode'] = $code;
		}
		return $data;
	}
}

final class EBP_Card_Blocks extends \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType {
	protected $name = 'siteskill_balepay_card';

	public function initialize() {
		$this->settings = EBP_Settings::all();
	}

	public function is_active() {
		return EBP_Settings::card_is_configured()
			&& in_array( get_woocommerce_currency(), array( 'IRR', 'IRT', 'TOMAN' ), true );
	}

	public function get_payment_method_script_handles() {
		wp_register_script(
			'ebp-blocks',
			EBP_URL . 'assets/blocks.js',
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
			EBP_VERSION,
			true
		);
		return array( 'ebp-blocks' );
	}

	public function get_payment_method_data() {
		return array(
			'title'        => EBP_Settings::get( 'card_title', 'کارت به کارت' ),
			'description'  => EBP_Settings::get( 'card_description', '' ),
			'instructions' => EBP_Settings::get( 'card_instructions', '' ),
			'cardCount'    => EBP_DB::count_active_cards(),
			'supports'     => array( 'products' ),
		);
	}
}
