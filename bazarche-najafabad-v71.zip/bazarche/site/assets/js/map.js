/* ==========================================================================
   Bazarche Najafabad — Map layer
   Google Maps when a key is configured, automatic OpenStreetMap/Leaflet
   fallback when it is absent, blocked, or fails to load.

   Both back-ends expose the same tiny surface:
     mount(el, opts)  ->  { addMarker, fitAll, setCenter, onPick, destroy }
   ========================================================================== */

const GMAPS_TIMEOUT = 6000;   // if Google hasn't answered by then, fall back
// Leaflet is vendored locally (like Three.js) — unpkg/other CDNs are blocked
// or throttled on Iranian networks, which used to kill the map entirely with
// «نقشه در دسترس نیست». Local first, CDN only as a last resort.
const OSM_CSS = '/assets/vendor/leaflet/leaflet.css';
const OSM_JS  = '/assets/vendor/leaflet/leaflet.js';
const OSM_CSS_CDN = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
const OSM_JS_CDN  = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';

const cfg = () => (window.__BAZARCHE__ || {});

function loadScript(src, timeout = 8000) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src; s.async = true; s.defer = true;
    const t = setTimeout(() => { s.remove(); reject(new Error('timeout ' + src)); }, timeout);
    s.onload = () => { clearTimeout(t); resolve(); };
    s.onerror = () => { clearTimeout(t); s.remove(); reject(new Error('load fail ' + src)); };
    document.head.appendChild(s);
  });
}
function loadCss(href) {
  return new Promise((resolve) => {
    if (document.querySelector(`link[href="${href}"]`)) return resolve();
    const l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = href;
    l.onload = l.onerror = () => resolve();
    document.head.appendChild(l);
  });
}

/* ---------------------------------------------------------------- Google */
let gmapsPromise = null;
function loadGoogle(key) {
  if (gmapsPromise) return gmapsPromise;
  gmapsPromise = new Promise((resolve, reject) => {
    if (!key) return reject(new Error('no key'));
    const cb = '__gmapsReady' + Date.now();
    const timer = setTimeout(() => reject(new Error('gmaps timeout')), GMAPS_TIMEOUT);
    window[cb] = () => { clearTimeout(timer); resolve(window.google); };
    // gm_authFailure fires on invalid key / billing problems
    window.gm_authFailure = () => { clearTimeout(timer); reject(new Error('gmaps auth')); };
    const s = document.createElement('script');
    s.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}` +
            `&callback=${cb}&language=fa&region=IR&libraries=marker`;
    s.async = true; s.defer = true;
    s.onerror = () => { clearTimeout(timer); reject(new Error('gmaps net')); };
    document.head.appendChild(s);
  });
  return gmapsPromise;
}

function googleBackend(google, el, opts) {
  const styleDark = [
    { elementType: 'geometry', stylers: [{ color: '#0f1a24' }] },
    { elementType: 'labels.text.stroke', stylers: [{ color: '#0f1a24' }] },
    { elementType: 'labels.text.fill', stylers: [{ color: '#8ea9a5' }] },
    { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#0b2a33' }] },
    { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#22333f' }] },
    { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#12352c' }] },
  ];
  const dark = document.documentElement.getAttribute('data-theme') === 'dark';
  const map = new google.maps.Map(el, {
    center: { lat: opts.lat, lng: opts.lng },
    zoom: opts.zoom,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: true,
    styles: dark ? styleDark : undefined,
  });
  const markers = [];
  let info = new google.maps.InfoWindow();
  let pickCb = null;

  map.addListener('click', (e) => {
    if (pickCb) pickCb(e.latLng.lat(), e.latLng.lng());
  });

  return {
    kind: 'google',
    addMarker({ lat, lng, title, html, featured, draggable, onDrag, icon }) {
      const m = new google.maps.Marker({
        position: { lat, lng }, map, title, draggable: !!draggable,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 11,
          fillColor: featured ? '#ea580c' : '#059669',
          fillOpacity: 1, strokeColor: '#fff', strokeWeight: 3,
        },
      });
      if (html) m.addListener('click', () => { info.setContent(html); info.open(map, m); });
      if (draggable && onDrag) {
        m.addListener('dragend', (e) => onDrag(e.latLng.lat(), e.latLng.lng()));
      }
      m._bzFeatured = !!featured;
      m._bzTitle = title || '';
      markers.push(m);
      return m;
    },
    select(marker) {
      markers.forEach(m => {
        const colour = m._bzFeatured ? '#ea580c' : '#059669';
        if (m === marker) {
          // Google pins cannot crop a CSS sprite, so selection enlarges the
          // coloured dot (Leaflet/OSM pins show the category icon instead).
          m.setIcon({
            path: google.maps.SymbolPath.CIRCLE, scale: 17,
            fillColor: colour, fillOpacity: 1,
            strokeColor: '#fff', strokeWeight: 4,
          });
          m.setLabel({
            text: m._bzTitle, fontFamily: 'Vazirmatn, sans-serif',
            fontSize: '12px', fontWeight: '700', color: '#0b1f1a',
            className: 'bz-gm-label',
          });
          m.setZIndex(1000);
        } else {
          m.setIcon({
            path: google.maps.SymbolPath.CIRCLE, scale: 11,
            fillColor: colour, fillOpacity: 1,
            strokeColor: '#fff', strokeWeight: 3,
          });
          m.setLabel(null);
          m.setZIndex(1);
        }
      });
    },
    fitAll() {
      if (!markers.length) return;
      const b = new google.maps.LatLngBounds();
      markers.forEach(m => b.extend(m.getPosition()));
      map.fitBounds(b, 60);
      if (markers.length === 1) map.setZoom(16);
    },
    setCenter(lat, lng, zoom) { map.setCenter({ lat, lng }); if (zoom) map.setZoom(zoom); },
    onPick(cb) { pickCb = cb; },
    destroy() { markers.forEach(m => m.setMap(null)); },
  };
}

/* ---------------------------------------------------------------- Leaflet */
async function leafletBackend(el, opts) {
  await loadCss(OSM_CSS);
  if (!window.L) {
    try { await loadScript(OSM_JS); }
    catch (e) { await loadScript(OSM_JS_CDN); }
  }
  const L = window.L;
  // zoomControl is created explicitly at bottom-left because the top-left
  // corner is where the «موقعیت من» (my-location) button lives — Leaflet's
  // default top-left zoom control sat right on top of it (its z-index 1000
  // beats the button's 900, so the button hid "behind" the zoom +/- icons).
  const map = L.map(el, { scrollWheelZoom: true, attributionControl: true, zoomControl: false })
               .setView([opts.lat, opts.lng], opts.zoom);
  L.control.zoom({ position: 'bottomleft' }).addTo(map);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; مشارکت‌کنندگان OpenStreetMap',
  }).addTo(map);

  const markers = [];
  let pickCb = null;
  map.on('click', (e) => { if (pickCb) pickCb(e.latlng.lat, e.latlng.lng); });

  const esc = (t) => String(t == null ? '' : t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  // Two states. Unselected is a plain dot; selected becomes a teardrop pin
  // carrying the business name, so you can tell at a glance which one you
  // picked without reading the popup.
  const pinIcon = (featured) => L.divIcon({
    className: 'bz-pin',
    html: `<span style="display:block;width:22px;height:22px;border-radius:50%;
            background:${featured ? '#ea580c' : '#059669'};border:3px solid #fff;
            box-shadow:0 3px 10px rgba(0,0,0,.35)"></span>`,
    iconSize: [22, 22], iconAnchor: [11, 11], popupAnchor: [0, -12],
  });

  // The selected pin is deliberately a DIFFERENT OBJECT, not a bigger dot:
  // a white teardrop carrying the shop's own category icon, a coloured ring,
  // a pulse, and the name on a solid chip. At a glance across a map of ten
  // markers there is no ambiguity about which one is picked.
  const pinIconActive = (featured, title) => {
    const c = featured ? '#ea580c' : '#059669';
    const art = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="${c}"
            stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"
            aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>`;
    return L.divIcon({
      className: 'bz-pin bz-pin-active',
      html: `<span class="bz-pin-wrap" style="--pin:${c}">
               <span class="bz-pin-pulse" aria-hidden="true"></span>
               <span class="bz-pin-drop">${art}</span>
               <span class="bz-pin-label">${esc(title || '')}</span>
             </span>`,
      iconSize: [0, 0], iconAnchor: [0, 46], popupAnchor: [0, -50],
    });
  };

  return {
    kind: 'osm',
    addMarker({ lat, lng, title, html, featured, draggable, onDrag, icon }) {
      const m = L.marker([lat, lng], { icon: pinIcon(featured), title, draggable: !!draggable })
                 .addTo(map);
      if (html) m.bindPopup(html);
      if (draggable && onDrag) {
        m.on('dragend', () => { const p = m.getLatLng(); onDrag(p.lat, p.lng); });
      }
      m._bzFeatured = !!featured;
      m._bzTitle = title || '';
      markers.push(m);
      return m;
    },
    select(marker) {
      markers.forEach(m => {
        if (m === marker) {
          m.setIcon(pinIconActive(m._bzFeatured, m._bzTitle));
          m.setZIndexOffset(1000);
        } else {
          m.setIcon(pinIcon(m._bzFeatured));
          m.setZIndexOffset(0);
        }
      });
    },
    fitAll() {
      if (!markers.length) return;
      const g = L.featureGroup(markers);
      map.fitBounds(g.getBounds().pad(0.2));
      if (markers.length === 1) map.setZoom(16);
    },
    setCenter(lat, lng, zoom) { map.setView([lat, lng], zoom || map.getZoom()); },
    onPick(cb) { pickCb = cb; },
    destroy() { map.remove(); },
  };
}

/* ---------------------------------------------------------------- public */
export async function mountMap(el, opts = {}) {
  const c = cfg();
  const o = {
    lat: opts.lat ?? parseFloat(c.mapLat ?? '32.6340'),
    lng: opts.lng ?? parseFloat(c.mapLng ?? '51.3670'),
    zoom: opts.zoom ?? parseInt(c.mapZoom ?? '14', 10),
  };
  const provider = c.mapProvider || 'auto';
  const key = (c.gmapsKey || '').trim();
  const status = (kind, note) => {
    el.closest('[data-map-wrap]')?.setAttribute('data-map', kind);
    const badge = el.closest('[data-map-wrap]')?.querySelector('[data-map-status]');
    if (badge) badge.textContent = note;
  };

  if (provider !== 'osm' && key) {
    try {
      const g = await loadGoogle(key);
      status('google', 'گوگل مپ');
      return googleBackend(g, el, o);
    } catch (err) {
      console.warn('[bazarche] Google Maps unavailable, falling back to OSM:', err.message);
    }
  }
  try {
    const b = await leafletBackend(el, o);
    status('osm', key ? 'OpenStreetMap (جایگزین)' : 'OpenStreetMap');
    return b;
  } catch (err) {
    console.warn('[bazarche] map unavailable:', err.message);
    status('none', 'نقشه در دسترس نیست');
    return null;
  }
}

/* Directions link that works with or without Google */
export function directionsUrl(lat, lng, label = '') {
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
}
