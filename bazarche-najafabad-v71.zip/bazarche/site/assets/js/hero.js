/* Hero scroll showcase (v42)
   - parallaxes the hero backdrop as you scroll (zoom-out drift + fade)
   - retries the muted loop video if autoplay was blocked until first tap
   Degrades to a no-op when reduced-motion is on. */
(() => {
  const visual = document.querySelector('[data-hero-visual]');
  if (!visual) return;

  const vid = visual.querySelector('video');
  if (vid) {
    const tryPlay = () => { const p = vid.play(); if (p) p.catch(() => {}); };
    tryPlay();
    if (vid.paused) {
      const unlock = () => { tryPlay(); };
      window.addEventListener('pointerdown', unlock, { once: true });
      window.addEventListener('touchstart', unlock, { once: true });
      window.addEventListener('scroll', unlock, { once: true, passive: true });
    }
  }

  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.matchMedia('(pointer: coarse)').matches) return;   // v54: no scroll parallax on phones

  let ticking = false;
  const onScroll = () => {
    if (ticking) return;
    ticking = true;
    requestAnimationFrame(() => {
      const y = window.scrollY;
      const k = Math.min(y / (window.innerHeight * 1.15), 1);
      visual.style.transform =
        `translate3d(0, ${(k * 64).toFixed(1)}px, 0) scale(${(1 + k * 0.09).toFixed(3)})`;
      visual.style.opacity = String(Math.max(0.3, 1 - k * 0.6));
      ticking = false;
    });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();
