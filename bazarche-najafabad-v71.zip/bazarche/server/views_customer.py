# -*- coding: utf-8 -*-
"""
Customer-facing pages: account (OTP), chat with shops, orders, favourites.
Standard library only — same constraints as the rest of the app.
"""

import json
import urllib.parse

import db
from ui import (icon, stars, fa, fa_group, esc, page, breadcrumb, empty_state,
                section_head, stat_card, flash, json_embed, password_reminder)


def _msg(q):
    if q.get("ok"):
        return flash("ok", q["ok"][0])
    if q.get("err"):
        return flash("err", q["err"][0])
    return ""


# ------------------------------------------------------------------ auth
def login(s, phone="", err="", code_stage=False, dev_code="", note="", nxt=""):
    cats = db.category_tree()
    if code_stage:
        form_html = f'''<form method="post" action="/me/login/verify" data-validate>
      <input type="hidden" name="phone" value="{esc(phone)}">
      <input type="hidden" name="next" value="{esc(nxt)}">
      <input type="hidden" name="favs" id="c-favs" value="">
      <div class="field"><label class="field-label" for="c-code">کد ورود</label>
        <input class="input nums" id="c-code" name="code" type="tel" dir="ltr" required
               inputmode="numeric" pattern="[0-9]{{5}}" maxlength="5" autocomplete="one-time-code"
               placeholder="•••••"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("check")}<span>ورود</span></button>
      <p class="field-hint" style="text-align:center;margin-top:10px">
        <a href="/me/login">شماره را اشتباه وارد کردم</a></p>
    </form>
    <script>
      try {{
        var favs = JSON.parse(localStorage.getItem('bazarche.v2.favs') || '[]');
        var f = document.getElementById('c-favs');
        if (f && Array.isArray(favs)) f.value = JSON.stringify(favs);
      }} catch (e) {{}}
    </script>'''
        dev_html = (f'<div class="alert alert-warn" style="text-align:center">{icon("eye")}'
                    f'<span>کد نمایشی (بدون پیامک): <strong class="nums" dir="ltr">{esc(dev_code)}</strong></span></div>'
                    if dev_code else '')
    else:
        form_html = f'''<form method="post" action="/me/login" data-validate>
      <input type="hidden" name="next" value="{esc(nxt)}">
      <div class="field"><label class="field-label" for="c-phone">شمارهٔ موبایل</label>
        <input class="input nums" id="c-phone" name="phone" type="tel" dir="ltr" required
               inputmode="numeric" pattern="0[0-9]{{10}}" maxlength="11"
               value="{esc(phone)}" placeholder="۰۹۱۲۳۴۵۶۷۸۹"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("send")}<span>دریافت کد ورود</span></button>
    </form>'''
        dev_html = ''
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head"><span class="mark">{icon("user")}</span>
      <h1>ورود مشتری</h1>
      <p>با شمارهٔ موبایل وارد شوید تا سفارش‌ها، گفتگوها و علاقه‌مندی‌هایتان
        روی همهٔ دستگاه‌ها بماند. رمز عبور لازم نیست.</p></div>
    {flash("err", err) if err else ''}
    {f'<div class="alert alert-success">{icon("check-circle")}<span>{esc(note)}</span></div>' if note else ''}
    {dev_html}
    {form_html}
    <hr class="divider">
    <details class="auth-alt">
      <summary class="btn btn-ghost btn-block">{icon("lock")}<span>ورود با نام کاربری و رمز عبور</span></summary>
      <form method="post" action="/me/login/password" data-validate class="mt-md">
        <input type="hidden" name="next" value="{esc(nxt)}">
        <div class="field">
          <label class="field-label" for="c-lu">نام کاربری</label>
          <input class="input" id="c-lu" name="username" dir="ltr" required autocomplete="username"
                 placeholder="نام کاربری شما">
        </div>
        <div class="field">
          <label class="field-label" for="c-lp">رمز عبور</label>
          <input class="input" id="c-lp" name="password" type="password" dir="ltr" required
                 autocomplete="current-password" placeholder="••••••">
        </div>
        <button class="btn btn-primary btn-block" type="submit" aria-label="ورود با رمز عبور">{icon("lock")}<span>ورود</span></button>
      </form>
    </details>
    <p class="field-hint" style="text-align:center;margin-top:12px">
      با ورود، <a href="/rules">قوانین</a> را می‌پذیرید.</p>
  </div></div></div>'''
    return page(s, "ورود مشتری", body, "", cats=cats)


# --------------------------------------------------- complete profile (v65)
def profile(s, cust, q=None, err=""):
    """Name is REQUIRED after first login; family name is optional."""
    q = q or {}
    cats = db.category_tree()
    name = cust.get("name") or ""
    family = cust.get("family") or ""
    body = f'''<div class="container"><div class="auth-wrap">
  <div class="auth-card glass">
    <div class="auth-head"><span class="mark">{icon("user")}</span>
      <h1>خوش آمدید — نام شما چیست؟</h1>
      <p>برای ادامه، نام خود را بنویسید. نام خانوادگی اختیاری است و
        شمارهٔ تلفن شما همیشه محرمانه می‌ماند.</p></div>
    {flash("err", err) if err else ""}
    <form method="post" action="/me/profile" data-validate>
      <div class="field"><label class="field-label" for="pf-n">نام<span class="req">*</span></label>
        <input class="input" id="pf-n" name="name" maxlength="60" required minlength="2"
               placeholder="مثلاً: علی" value="{esc(name)}"></div>
      <div class="field"><label class="field-label" for="pf-f">نام خانوادگی</label>
        <input class="input" id="pf-f" name="family" maxlength="60"
               placeholder="اختیاری — مثلاً: محمدی" value="{esc(family)}"></div>
      <button class="btn btn-primary btn-block" type="submit">
        {icon("check")}<span>ثبت و ادامه</span></button>
    </form>
  </div></div></div>'''
    return page(s, "تکمیل حساب", body, "", cats=cats)


# ------------------------------------------------------------------ dashboard
def dashboard(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    orders = db.orders_for_customer(cust["id"])[:5]
    chats = db.chat_threads_for_customer(cust["id"])[:5]
    favs = db.fav_list(cust["id"])

    ord_html = "".join(f'''<a class="todo-item" href="/me/order/{o["id"]}">
      {icon("shopping")}<span><strong>{esc(o["bizname"])}</strong><br>
      <small class="text-muted">{fa_group(o["total"])} تومان ·
        <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span></small></span>
      {icon("chevron-left")}</a>''' for o in orders)
    if not ord_html:
        ord_html = empty_state("shopping", "هنوز سفارشی ندارید",
                               "از کاتالوگ محصولات، اولین سفارش خود را ثبت کنید.")

    chat_html = "".join(f'''<a class="todo-item" href="/me/chat/{t["id"]}">
      {icon("message")}<span><strong>{esc(t["bizname"])}</strong><br>
      <small class="text-muted">{esc((t.get("last") or {}).get("body", "")[:60])}</small></span>
      {icon("chevron-left")}</a>''' for t in chats)
    if not chat_html:
        chat_html = empty_state("message", "گفتگویی ندارید",
                                "از صفحهٔ هر کسب‌وکار می‌توانید گفتگو را شروع کنید.")

    _pts = db.points_balance(cust["id"]) if s.get("loyalty_on") == "1" else None
    body = f'''{_msg(q)}
{password_reminder("/me/account") if not db.customer_has_password(cust["id"]) else ""}
<div class="container-wide">
  {breadcrumb(("حساب من", None))}
  <header class="page-hero"><h1>سلام، {esc(cust["name"] or "مشتری عزیز")}</h1>
    <p>سفارش‌ها، گفتگوها و علاقه‌مندی‌های شما — همه در یک جا.</p></header>
  <div class="grid grid-4 mb-lg" data-stagger>
    {stat_card("shopping", len(db.orders_for_customer(cust["id"])), "سفارش")}
    {stat_card("message", len(db.chat_threads_for_customer(cust["id"])), "گفتگو", delay=60)}
    {stat_card("heart", len(favs), "علاقه‌مندی", delay=120)}
    {stat_card("star", _pts if _pts is not None else 0, "امتیاز وفاداری", delay=180) if s.get("loyalty_on") == "1" else ""}
  </div>
  <div class="card glass card-pad mb-lg">
    <h2 class="card-title mb-md">{icon("zap")} دسترسی سریع</h2>
    <div class="quick-grid">
      <a class="quick-tile" href="/catalog">{icon("shopping")}<span>ویترین شهر</span><small>محصولات و خدمات</small></a>
      <a class="quick-tile" href="/cities">{icon("pin")}<span>تغییر شهر</span><small>کسب‌وکارهای شهر دیگر</small></a>
      <a class="quick-tile" href="/businesses">{icon("store")}<span>همهٔ کسب‌وکارها</span><small>جست‌وجو و فیلتر</small></a>
      <a class="quick-tile" href="/me/points">{icon("star")}<span>امتیازها</span><small>کوپن تخفیف بگیرید</small></a>
      <a class="quick-tile" href="/me/account">{icon("lock")}<span>حساب و امنیت</span><small>نام کاربری و رمز</small></a>
    </div>
  </div>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <div class="between mb-md"><h2 class="card-title">{icon("shopping")} آخرین سفارش‌ها</h2>
        <a class="btn btn-ghost btn-sm" href="/me/orders">همه</a></div>
      {ord_html}
    </div>
    <div class="card glass card-pad">
      <div class="between mb-md"><h2 class="card-title">{icon("message")} گفتگوها</h2>
        <a class="btn btn-ghost btn-sm" href="/me/chats">همه</a></div>
      {chat_html}
    </div>
  </div>
  <div class="card glass card-pad mt-lg">
    <div class="between">
      <div><h2 class="card-title">{icon("heart")} علاقه‌مندی‌ها</h2>
        <p class="text-sm text-muted">روی همهٔ دستگاه‌ها همگام می‌ماند.</p></div>
      <a class="btn btn-glass" href="/favorites">{icon("grid")}<span>مشاهده</span></a>
    </div>
  </div>
  <div class="card glass card-pad mt-lg">
    <h2 class="card-title mb-md">{icon("user")} نام و نام خانوادگی</h2>
    <form method="post" action="/me/name" class="grid grid-2" style="gap:var(--space-md)">
      <div class="field"><label class="field-label" for="nm">نام<span class="req">*</span></label>
        <input class="input" id="nm" name="name" maxlength="60" required minlength="2"
               placeholder="نام شما" value="{esc(cust.get('name') or '')}"></div>
      <div class="field"><label class="field-label" for="fm">نام خانوادگی</label>
        <input class="input" id="fm" name="family" maxlength="60"
               placeholder="اختیاری" value="{esc(cust.get('family') or '')}"></div>
      <div class="cluster" style="grid-column:1/-1">
        <button class="btn btn-glass" type="submit">{icon("check")}<span>ذخیره</span></button>
      </div>
    </form>
  </div>
  <div class="cluster mt-lg" style="justify-content:center">
    <form method="post" action="/me/logout" style="display:inline">
      <button class="btn btn-ghost" type="submit">{icon("x")}<span>خروج</span></button>
    </form>
  </div>
</div>'''
    return page(s, "حساب من", body, "", cats=cats)


# ------------------------------------------------------------------ chat
def chats_list(s, cust, q=None):
    cats = db.category_tree()
    rows = db.chat_threads_for_customer(cust["id"])
    items = "".join(f'''<a class="todo-item" href="/me/chat/{t["id"]}">
      {icon("message")}<span><strong>{esc(t["bizname"])}</strong><br>
      <small class="text-muted">{esc((t.get("last") or {}).get("body", "")[:80])}</small></span>
      {icon("chevron-left")}</a>''' for t in rows)
    if not items:
        items = empty_state("message", "گفتگویی ندارید",
                            "از صفحهٔ هر کسب‌وکار می‌توانید گفتگو را شروع کنید.")
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("گفتگوها", None))}
  <header class="page-hero"><h1>گفتگوها</h1><p>تاریخچهٔ گفتگو با کسب‌وکارها.</p></header>
  <div class="card glass card-pad"><div class="todo-list">{items}</div></div>
</div>'''
    return page(s, "گفتگوها", body, "", cats=cats)


def chat_view(s, cust, tid, q=None):
    t = db.chat_thread(tid)
    if not t or t.get("customer_id") != cust["id"]:
        return None
    biz = db.business(bid=t["biz_id"]) or {}
    bizname = biz.get("name", "کسب‌وکار")
    cats = db.category_tree()
    msgs = db.chat_messages(tid)
    last = msgs[-1]["id"] if msgs else 0
    bubbles = "".join(f'''<div class="msg {'me' if m["sender"] == "customer" else 'them'}">
      <div class="msg-bubble">{esc(m["body"])}</div>
      <div class="msg-meta">{esc(m["created"][5:16])}</div></div>''' for m in msgs)
    if not bubbles:
        bubbles = '<p class="text-muted text-sm">هنوز پیامی نیست. اولین پیام را بنویسید.</p>'
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("گفتگوها", "/me/chats"), ("گفتگو", None))}
  <header class="page-hero"><h1>گفتگو با {esc(bizname)}</h1></header>
  <div class="card glass card-pad" style="max-width:640px;margin-inline:auto">
    <div class="chat-box" data-chat data-thread="{tid}" data-last="{last}">{bubbles}</div>
    <form method="post" action="/me/chat/{tid}" class="chat-send" data-chat-form>
      <input class="input" name="body" maxlength="2000" placeholder="پیام خود را بنویسید…" required>
      <button class="btn btn-primary" type="submit">{icon("send")}<span>ارسال</span></button>
    </form>
  </div>
</div>
<script type="module" src="/assets/js/chat.js?v71"></script>'''
    return page(s, "گفتگو", body, "", cats=cats)


# ------------------------------------------------------------------ orders
def orders_list(s, cust, q=None):
    cats = db.category_tree()
    rows = db.orders_for_customer(cust["id"])
    items = "".join(f'''<a class="todo-item" href="/me/order/{o["id"]}">
      {icon("shopping")}<span><strong>{esc(o["bizname"])}</strong><br>
      <small class="text-muted">{fa_group(o["total"])} تومان ·
      {esc(str(o["created"])[:16])}</small></span>
      <span class="badge {db.ORDER_LABELS.get(o["status"], ("badge-neutral",""))[0]}">{esc(o["status_label"])}</span>
      {icon("chevron-left")}</a>''' for o in rows)
    if not items:
        items = empty_state("shopping", "هنوز سفارشی ندارید",
                            "از کاتالوگ محصولات، اولین سفارش خود را ثبت کنید.")
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("سفارش‌ها", None))}
  <header class="page-hero"><h1>سفارش‌های من</h1><p>پیگیری وضعیت همهٔ سفارش‌ها.</p></header>
  <div class="card glass card-pad"><div class="todo-list">{items}</div></div>
</div>'''
    return page(s, "سفارش‌های من", body, "", cats=cats)


def order_view(s, cust, oid, q=None):
    o = db.order(oid)
    if not o or o.get("customer_id") != cust["id"]:
        return None
    biz = db.business(bid=o["biz_id"]) or {}
    cats = db.category_tree()
    rows = db.order_items(oid)
    items = "".join(f'''<tr><td>{esc(r["title"])}</td>
      <td class="nums">{fa_group(r["price"])} × {fa(r["qty"])}</td>
      <td class="nums">{fa_group(r["price"] * r["qty"])}</td></tr>''' for r in rows)
    badge = db.ORDER_LABELS.get(o["status"], ("badge-neutral", o["status"]))
    body = f'''{_msg(q or {})}<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("سفارش‌ها", "/me/orders"), ("سفارش", None))}
  <header class="page-hero"><h1>سفارش #{fa(o["id"])} — {esc(biz.get("name", "کسب‌وکار"))}</h1>
    <div class="cluster mt-md">
      <span class="badge {badge[0]}">{esc(badge[1])}</span>
      <span class="badge badge-neutral">{esc(str(o["created"])[:16])}</span>
    </div></header>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("shopping")} اقلام</h2>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>عنوان</th><th>قیمت</th><th>جمع</th></tr></thead><tbody>{items}</tbody>
        <tfoot><tr><th colspan="2">مجموع</th>
          <td class="nums"><strong>{fa_group(o["total"])}</strong></td></tr></tfoot>
      </table></div>
    </div>
    <div class="card glass card-pad">
      <h2 class="card-title mb-md">{icon("cart")} مشخصات تحویل</h2>
      <p class="text-sm"><strong>نام:</strong> {esc(o["name"])}</p>
      <p class="text-sm"><strong>تلفن:</strong> {esc(o["phone"])}</p>
      <p class="text-sm"><strong>نشانی:</strong> {esc(o["address"] or "—")}</p>
      <p class="text-sm"><strong>یادداشت:</strong> {esc(o["note"] or "—")}</p>
    </div>
  </div>
</div>'''
    return page(s, "سفارش", body, "", cats=cats)


# ------------------------------------------------------------------ server favourites
def favorites_server(s, cust):
    cats = db.category_tree()
    fav_ids = db.fav_list(cust["id"])
    rows = [b for b in db.businesses() if b["id"] in fav_ids]
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("علاقه‌مندی‌ها", None))}
  <header class="page-hero"><h1>علاقه‌مندی‌های من</h1>
    <p>روی همهٔ دستگاه‌ها همگام می‌ماند.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3">{cards or empty_state("heart", "هنوز چیزی ذخیره نکرده‌اید",
    "روی نشان قلب در کارت هر کسب‌وکار بزنید تا اینجا ذخیره شود.")}</div>
</div></section>'''
    return page(s, "علاقه‌مندی‌های من", body, "", cats=cats)


# ------------------------------------------------------------------ order done
def order_done(s, oid):
    cats = db.category_tree()
    o = db.order(oid)
    body = f'''<div class="container-wide"><section class="section">
  {empty_state("check-circle", "سفارش شما ثبت شد",
    "کسب‌وکار به‌زودی با شما تماس می‌گیرد. وضعیت سفارش را از «حساب من → سفارش‌ها» دنبال کنید.",
    f'<div class="cluster" style="justify-content:center"><a class="btn btn-primary" href="/me/order/{oid}">{icon("shopping")}<span>مشاهدهٔ سفارش</span></a><a class="btn btn-glass" href="/catalog">{icon("grid")}<span>ادامهٔ خرید</span></a></div>')}
</section></div>''' if o else ''
    return page(s, "ثبت شد", body, "", cats=cats)


# ------------------------------------------------------------------ cart
def cart_page(s, token=""):
    cats = db.category_tree()
    body = f'''<div class="container-wide">
  {breadcrumb(("سبد خرید", None))}
  <header class="page-hero"><h1>سبد خرید</h1><p>اقلام انتخاب‌شده از کاتالوگ شهر.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div id="cart-root"></div>
</section>
<script type="module" src="/assets/js/cart.js?v71"></script>'''
    return page(s, "سبد خرید", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ areas
def areas_page(s, token=""):
    cats = db.category_tree()
    rows = db.areas()
    tiles = "".join(f'''<a class="cat-tile tilt reveal-3d" data-tilt="7" data-delay="{i*40}"
      href="/area/{urllib.parse.quote(r['area'])}">
      <span class="sheen" aria-hidden="true"></span>
      <span class="art layer-2">{icon("pin")}</span>
      <span class="name layer-1">{esc(r['area'])}</span>
      <span class="count layer-1">{fa(r['c'])} کسب‌وکار</span></a>''' for i, r in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("محله‌ها", None))}
  <header class="page-hero"><h1>محله‌های نجف‌آباد</h1>
    <p>کسب‌وکارها را محله‌به‌محله بگردید.</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="cat-grid">{tiles or empty_state("pin", "هنوز محله‌ای ثبت نشده",
    "از پنل مدیریت، برای کسب‌وکارها «محله» تعیین کنید.")}</div>
</div></section>'''
    return page(s, "محله‌ها", body, "", token=token, cats=cats)


def area_page(s, area, token=""):
    cats = db.category_tree()
    rows = db.businesses_in_area(area)
    if not rows:
        return None
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''<div class="container-wide">
  {breadcrumb(("محله‌ها", "/areas"), (area, None))}
  <header class="page-hero"><h1>محلهٔ {esc(area)}</h1>
    <p>{fa(len(rows))} کسب‌وکار در این محله.</p></header></div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3">{cards}</div>
</div></section>'''
    return page(s, f"محلهٔ {area}", body, "", token=token, cats=cats)


# ------------------------------------------------------------------ loyalty points
def points_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    bal = db.points_balance(cust["id"])
    hist = db.points_history(cust["id"])
    reds = db.redemptions_list(customer_id=cust["id"])
    cost = int(s.get("coupon_cost", "50") or 50)

    hist_rows = "".join(f'''<tr>
      <td class="nums">{fa(r["amount"])}</td>
      <td>{esc(r["reason"])}</td>
      <td class="nums text-muted">{esc(str(r["created"])[:16])}</td>
    </tr>''' for r in hist)
    if not hist_rows:
        hist_rows = f'<tr><td colspan="3">{esc("هنوز امتیازی نگرفته‌اید.")}</td></tr>'

    red_rows = "".join(f'''<tr>
      <td><code class="nums" dir="ltr">{esc(r["code"])}</code></td>
      <td class="nums">{fa(r["percent"])}٪</td>
      <td><span class="badge {"badge-neutral" if r["used"] else "badge-open"}">{"استفاده شد" if r["used"] else "معتبر"}</span></td>
      <td class="nums text-muted">{esc(str(r["created"])[:16])}</td>
    </tr>''' for r in reds)
    if not red_rows:
        red_rows = f'<tr><td colspan="4">{esc("هنوز کوپنی نگرفته‌اید.")}</td></tr>'

    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("امتیازها", None))}
  <header class="page-hero"><h1>{icon("star")} امتیازهای من</h1>
    <p>با سفارش و نظر دادن امتیاز بگیرید و با آن کوپن تخفیف دریافت کنید.</p></header>
  <div class="grid grid-3 mb-lg" data-stagger>
    <div class="card glass card-pad" style="text-align:center">
      <div class="stat-value" style="font-size:2rem">{fa(bal)}</div>
      <div class="stat-label">امتیاز فعلی</div></div>
    <div class="card glass card-pad" style="text-align:center">
      <div class="stat-value" style="font-size:2rem">{fa(cost)}</div>
      <div class="stat-label">هزینهٔ کوپن ۱۰٪</div></div>
    <div class="card glass card-pad" style="text-align:center">
      <div class="stat-value" style="font-size:2rem">{fa(len(reds))}</div>
      <div class="stat-label">کوپن گرفته‌شده</div></div>
  </div>
  <div class="grid grid-2" style="align-items:start">
    <div class="card glass card-pad">
      <h2 class="card-title mb-lg">{icon("star")} تاریخچهٔ امتیاز</h2>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>امتیاز</th><th>دلیل</th><th>تاریخ</th></tr></thead><tbody>{hist_rows}</tbody></table></div>
    </div>
    <div class="card glass card-pad">
      <h2 class="card-title mb-lg">{icon("tag")} کوپن‌های من</h2>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>کد</th><th>تخفیف</th><th>وضعیت</th><th>تاریخ</th></tr></thead><tbody>{red_rows}</tbody></table></div>
      <form method="post" action="/me/points/redeem" class="mt-lg" data-confirm="{esc('امتیاز صرف شود؟')}">
        <button class="btn btn-primary btn-block" type="submit" {"disabled" if bal < cost else ""}>
          {icon("tag")}<span>دریافت کوپن ۱۰٪ ({fa(cost)} امتیاز)</span></button>
        <p class="field-hint">کد کوپن را به کسب‌وکار نشان دهید.</p>
      </form>
    </div>
  </div>
</div>'''
    return page(s, "امتیازهای من", body, "", cats=cats)


# ------------------------------------------------------------------ notifications (v32)
NOTIF_ICON = {"order": "cart", "chat": "message", "reply": "message", "info": "bell"}
NOTIF_LABEL = {"order": "سفارش", "chat": "گفتگو", "reply": "پاسخ", "info": "اطلاعیه"}


def notifications_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    rows = db.notifications(cust["id"])
    items = "".join(f'''<a class="todo-item {'is-unread' if not n['read'] else ''}"
      href="{esc(n['link'] or '/me')}">
      {icon(NOTIF_ICON.get(n['kind'], 'bell'))}
      <span><strong>{esc(NOTIF_LABEL.get(n['kind'], n['kind']))}</strong><br>
      <small class="text-muted">{esc(n['text'])}</small></span>
      <small class="text-muted nums">{esc(str(n['created'])[5:16])}</small>
      {icon('chevron-left')}</a>''' for n in rows)
    if not items:
        items = empty_state("bell", "اعلانی ندارید",
                            "پاسخ‌ها، وضعیت سفارش و پیام‌های جدید اینجا می‌آیند.")
    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("اعلان‌ها", None))}
  <header class="page-hero"><h1>{icon("bell")} اعلان‌های من</h1>
    <form method="post" action="/me/notifications/read" style="display:inline">
      <button class="btn btn-glass btn-sm" type="submit">{icon("check")}<span>خواندن همه</span></button>
    </form></header>
  <div class="card glass card-pad"><div class="todo-list">{items}</div></div>
</div>'''
    return page(s, "اعلان‌های من", body, "", cats=cats)


def following_page(s, cust, q=None):
    q = q or {}
    cats = db.category_tree()
    ids = db.following_ids(cust["id"])
    rows = [b for b in db.businesses() if b["id"] in ids]
    ci = {c["slug"]: c["icon"] for c in db.categories(only_active=False)}
    from ui import biz_card
    cards = "".join(biz_card(b, ci, i * 50) for i, b in enumerate(rows))
    body = f'''{_msg(q)}
<div class="container-wide">
  {breadcrumb(("حساب من", "/me"), ("دنبال‌شده‌ها", None))}
  <header class="page-hero"><h1>{icon("heart")} کسب‌وکارهایی که دنبال می‌کنم</h1>
    <p>تازه‌های این کسب‌وکارها را دنبال کنید.</p></header>
  <section class="section-sm"><div class="container-wide">
    <div class="grid grid-3">{cards or empty_state("heart", "هنوز کسی را دنبال نمی‌کنید",
      "از صفحهٔ هر کسب‌وکار دکمهٔ «دنبال کردن» را بزنید.")}</div>
  </div></section>
</div>'''
    return page(s, "دنبال‌شده‌ها", body, "", cats=cats)


# ------------------------------------------------------------------ account & security
def account(s, cust, q=None):
    """Set a username + password so the customer can sign in without SMS."""
    q = q or {}
    has_pw = db.customer_has_password(cust["id"])
    cur_user = (cust.get("username") or "")
    if has_pw:
        status = (f'<div class="alert alert-success mb-lg">{icon("check-circle")}'
                  f'<span>نام کاربری و رمز عبور فعال است.</span></div>')
    else:
        status = (f'<div class="alert alert-warn mb-lg">{icon("info")}'
                  f'<span>هنوز نام کاربری و رمز تعیین نکرده‌اید. اینجا تنظیمش کنید تا ورود بعدی بدون پیامک باشد.</span></div>')

    body = f'''{_msg(q)}{status}
<div class="container">
  {breadcrumb(("حساب و امنیت", None))}
  <div class="card glass card-pad">
    <h2 class="card-title mb-md">{icon("lock")} نام کاربری و رمز عبور</h2>
    <p class="text-sm text-muted mb-lg">با تعیین نام کاربری و رمز، ورود بعدی شما بدون پیامک انجام می‌شود.</p>
    <form method="post" action="/me/account" data-validate>
      <div class="field">
        <label class="field-label" for="c-ac-user">نام کاربری<span class="req">*</span></label>
        <input class="input" id="c-ac-user" name="username" dir="ltr" required
               autocomplete="username" maxlength="24" value="{esc(cur_user)}"
               placeholder="مثلاً maryam_1370" data-msg-pattern="۳ تا ۲۴ نویسه: حروف، عدد، _ . -">
        <p class="field-hint">۳ تا ۲۴ نویسه؛ حروف فارسی یا انگلیسی، عدد، خط تیره و نقطه. بدون فاصله.</p>
      </div>
      <div class="field">
        <label class="field-label" for="c-ac-pw">رمز عبور جدید<span class="req">*</span></label>
        <input class="input" id="c-ac-pw" name="password" type="password" dir="ltr" required
               autocomplete="new-password" minlength="6" maxlength="72"
               placeholder="دست‌کم ۶ نویسه">
      </div>
      <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیرهٔ نام کاربری و رمز</span></button>
    </form>
  </div>
</div>'''
    cats = db.category_tree()
    return page(s, "حساب و امنیت", body, "", cats=cats)
