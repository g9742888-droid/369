# -*- coding: utf-8 -*-
"""
چانه‌زنی — structured haggling.

The claims this feature makes, each of which must actually hold:

  · a shopkeeper opts in PER PRODUCT and sets a floor only they can see
  · an offer at or above the floor closes the sale with nobody at the phone
  · an insulting lowball is COUNTERED, not rejected — a "no" ends a sale
  · the floor price never leaks to a buyer, in any response
  · one buyer cannot tamper with another buyer's negotiation
  · a seller can only touch offers on their own shop
  · offers expire, so nobody is held to last month's price

    BZ=http://127.0.0.1:8080 python3 tools/test_haggle.py
"""

import os
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
TAG = "آزمون-چانه"
PH_A = "09125551010"       # owner of the haggling shop
PH_B = "09125552020"       # a different owner entirely

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def session():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def req(op, path, data=None):
    url = BASE + path
    if data is None:
        r = urllib.request.Request(url)
    else:
        r = urllib.request.Request(
            url, data=urllib.parse.urlencode(data, doseq=True).encode())
        r.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        res = op.open(r, timeout=25)
        return res.getcode(), res.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def login(op, phone):
    req(op, "/login", {"phone": phone})
    row = db._one("SELECT code FROM otp WHERE phone=?", (db.norm_phone(phone),))
    if not row:
        return False
    c, _ = req(op, "/login/verify", {"phone": phone, "code": row["code"]})
    return c in (200, 303)


print(f"\n\033[1m\033[36mآزمون چانه‌زنی — {BASE}\033[0m")

# ---------------------------------------------------------------- fixture
head("آماده‌سازی")
db.rate_clear()
db._run("DELETE FROM otp")
for b in db.businesses(status=None):
    if TAG in (b.get("tags") or ""):
        db.delete_business(b["id"])
for ph in (PH_A, PH_B):
    o = db.owner_by_phone(ph)
    if o:
        db.delete_owner(o["id"])

owner_a = db.owner_by_phone(PH_A, create=True)
owner_b = db.owner_by_phone(PH_B, create=True)

# v65: haggling is OFF by default site-wide. The feature under test must be
# enabled explicitly, exactly as the panel would — then restored afterwards.
_saved_haggle = db.get_settings().get("haggle_enabled", "0")
db.set_setting("haggle_enabled", "1")
cat = db.categories()[0]["slug"]

BID = db.save_business({"name": "فرش‌فروشی آزمون", "cat_slug": cat,
                        "status": "published", "phone": "09131110000",
                        "owner_id": owner_a["id"], "tags": TAG})
BID2 = db.save_business({"name": "مغازهٔ دیگری آزمون", "cat_slug": cat,
                         "status": "published", "phone": "09131110001",
                         "owner_id": owner_b["id"], "tags": TAG})
db.set_manual_grants(BID, ["inquiry"])
db.set_manual_grants(BID2, ["inquiry"])

LIST, FLOOR = 10_000_000, 8_500_000
IID = db.save_item({"biz_id": BID, "kind": "product", "title": "فرش دستباف آزمون",
                    "price": LIST, "price_type": "fixed", "available": 1,
                    "haggle": 1, "floor_price": FLOOR})
NOHAG = db.save_item({"biz_id": BID, "kind": "product", "title": "کالای بی‌چانه آزمون",
                      "price": 500000, "price_type": "fixed", "available": 1,
                      "haggle": 0})
check("کالای قابل چانه‌زنی ساخته شد", db.haggle_allowed(db.item(IID)), "")
check("کالای بدون چانه‌زنی، بسته است",
      not db.haggle_allowed(db.item(NOHAG)), "")

head("۱) شرط‌های باز بودن چانه‌زنی")
call_item = db.save_item({"biz_id": BID, "kind": "custom", "title": "سفارش آزمون",
                          "price": 0, "price_type": "call", "available": 1,
                          "haggle": 1})
check("کالای «استعلامی» چانه‌زنی نمی‌گیرد (قیمتی نیست که رویش چانه بزنند)",
      not db.haggle_allowed(db.item(call_item)), "")
gone = db.save_item({"biz_id": BID, "kind": "product", "title": "ناموجود آزمون",
                     "price": 100000, "price_type": "fixed", "available": 0,
                     "haggle": 1})
check("کالای ناموجود چانه‌زنی نمی‌گیرد", not db.haggle_allowed(db.item(gone)), "")

head("۲) پیشنهاد بالای کف، خودکار پذیرفته می‌شود")
hid, tok, verdict = db.make_offer(BID, IID, "علی", "09120000001", FLOOR + 100_000)
check("نتیجه «پذیرفته‌شده» است", verdict == "accepted", verdict)
check("و در پایگاه داده هم ثبت شده",
      db.haggle(hid)["status"] == "accepted", db.haggle(hid)["status"])
check("توکن پیگیری صادر شد", bool(tok), "")

hid_eq, _, v_eq = db.make_offer(BID, IID, "دقیقاً کف", "09120000009", FLOOR)
check("پیشنهاد دقیقاً برابر کف هم پذیرفته می‌شود", v_eq == "accepted", v_eq)

head("۳) پیشنهاد توهین‌آمیز، رد نمی‌شود — پاسخ می‌گیرد")
hid2, tok2, v2 = db.make_offer(BID, IID, "رضا", "09120000002", int(LIST * 0.2))
check("نتیجه «پیشنهاد متقابل» است", v2 == "countered", v2)
th = db.haggle_thread(token=tok2)
check("گفت‌وگو دو پیام دارد", len(th) == 2, str(len(th)))
check("پیام دوم از سمت فروشنده است", th[1]["side"] == "seller", th[1]["side"])
check("و قیمت پیشنهادی فروشنده همان کف است",
      th[1]["offer"] == FLOOR, str(th[1]["offer"]))

head("۴) پیشنهاد میانه منتظر تصمیم آدم می‌ماند")
# Genuinely between the two thresholds: above the lowball line (50% of list)
# so it is not auto-countered, but BELOW the floor so it cannot auto-accept.
# This is the band where a human has to decide, which is the default case.
mid = int(FLOOR * 0.95)
assert LIST * 0.5 < mid < FLOOR, (mid, FLOOR)
hid3, tok3, v3 = db.make_offer(BID, IID, "سمیرا", "09120000003", mid)
check("نتیجه «در انتظار» است", v3 == "pending", v3)
check("وضعیت باز مانده", db.haggle(hid3)["status"] == "open", "")

head("۵) کف قیمت هرگز به خریدار نشت نمی‌کند")
anon = session()
paths = [f"/haggle/{IID}", f"/offer/{tok2}", f"/offer/{tok3}"]
for pth in paths:
    code, html = req(anon, pth)
    check(f"{pth} باز می‌شود", code == 200, f"code={code}")
    # the raw number, and the grouped Persian form, must both be absent
    raw = str(FLOOR)
    fa_grouped = db.fa_money(FLOOR)
    leaked = (raw in html) or (f'floor' in html.lower() and raw in html)
    check(f"عدد کف در {pth} دیده نمی‌شود", not leaked, "نشت کرد!")
code, html = req(anon, f"/haggle/{IID}")
check("فرم، «کف قیمت» را به‌عنوان برچسب هم نشان نمی‌دهد",
      "کف قیمت" not in html, "")

head("۶) اعتبارسنجی فرم پیشنهاد")
code, html = req(anon, f"/haggle/{IID}",
                 {"offer": str(LIST + 1), "name": "کسی", "phone": "09120000004"})
check("پیشنهاد بالاتر از قیمت اعلام‌شده رد می‌شود",
      "بیشتر است" in html, "")
code, html = req(anon, f"/haggle/{IID}", {"offer": "0", "name": "", "phone": ""})
check("فرم ناقص رد می‌شود", "کامل وارد کنید" in html, "")
code, html = req(anon, f"/haggle/{NOHAG}", {"offer": "1000", "name": "x", "phone": "0912"})
check("پیشنهاد روی کالای بدون چانه‌زنی ۴۰۴ می‌گیرد", code == 404, f"code={code}")

head("۷) گفت‌وگوی خریدار")
n_before = len(db.haggle_thread(token=tok2))
code, _ = req(anon, f"/offer/{tok2}", {"action": "counter", "offer": str(FLOOR - 500000)})
th = db.haggle_thread(token=tok2)
check("خریدار می‌تواند پیشنهاد تازه بدهد", len(th) == n_before + 1,
      f"{n_before} -> {len(th)}")
check("و پیام تازه از سمت خریدار ثبت شده", th[-1]["side"] == "buyer", th[-1]["side"])

# accept the seller's standing counter on a fresh thread
_, tok4, _ = db.make_offer(BID, IID, "نگار", "09120000005", int(LIST * 0.2))
code, _ = req(anon, f"/offer/{tok4}", {"action": "accept"})
th4 = db.haggle_thread(token=tok4)
check("خریدار می‌تواند پیشنهاد فروشنده را قبول کند",
      th4[-1]["status"] == "accepted", th4[-1]["status"])
code, html = req(anon, f"/offer/{tok4}")
check("پس از پذیرش، فرم پاسخ برداشته می‌شود",
      'action="/offer/' not in html, "فرم هنوز هست")
check("و وضعیت «پذیرفته شد» نمایش داده می‌شود", "پذیرفته شد" in html, "")

head("۸) توکن نامعتبر، درِ گفت‌وگو را باز نمی‌کند")
for bad in ("aaaaaaaaaaaa", "../../etc/passwd", "x" * 70):
    code, _ = req(anon, "/offer/" + urllib.parse.quote(bad, safe=""))
    check(f"توکن جعلی رد شد ({bad[:16]!r})", code == 404, f"code={code}")

head("۹) وضعیت سرصفحه، حقیقت گفت‌وگو را می‌گوید")
_, tok5, _ = db.make_offer(BID, IID, "کاربر", "09120000006", int(LIST * 0.2))
code, html = req(anon, f"/offer/{tok5}")
check("وقتی توپ در زمین خریدار است، «در انتظار فروشنده» نمی‌گوید",
      "در انتظار پاسخ فروشنده" not in html, "پیام گمراه‌کننده")
check("بلکه می‌گوید فروشنده قیمت دیگری داده",
      "قیمت دیگری پیشنهاد داد" in html, "")

head("۱۰) پنل فروشنده")
A = session()
check("ورود صاحب مغازه", login(A, PH_A), "")
code, html = req(A, "/my/offers")
check("صفحهٔ پیشنهادها باز می‌شود", code == 200, f"code={code}")
check("پیشنهاد مشتری دیده می‌شود", "سمیرا" in html, "")
check("کف قیمت برای خودِ فروشنده نمایش داده می‌شود",
      "کف شما" in html, "فروشنده کف خودش را نمی‌بیند")
check("لینک آن در منوی فروشنده هست", "/my/offers" in html, "")

code, _ = req(A, f"/my/offer/{hid3}", {"action": "accept"})
check("فروشنده می‌تواند بپذیرد",
      db.haggle(hid3)["status"] == "accepted", db.haggle(hid3)["status"])

hid6, tok6, _ = db.make_offer(BID, IID, "مهدی", "09120000007", mid)
code, _ = req(A, f"/my/offer/{hid6}", {"action": "counter", "offer": str(mid + 200000)})
th6 = db.haggle_thread(root_id=hid6)
check("فروشنده می‌تواند پیشنهاد متقابل بدهد", len(th6) == 2, str(len(th6)))
check("و پیام از سمت فروشنده ثبت می‌شود", th6[1]["side"] == "seller", th6[1]["side"])

hid7, _, _ = db.make_offer(BID, IID, "حسن", "09120000008", mid)
code, _ = req(A, f"/my/offer/{hid7}", {"action": "decline"})
check("فروشنده می‌تواند رد کند",
      db.haggle(hid7)["status"] == "declined", db.haggle(hid7)["status"])

head("۱۱) جداسازی بین فروشندگان")
B = session()
check("ورود مالک دوم", login(B, PH_B), "")
code, _ = req(B, f"/my/offer/{hid6}", {"action": "accept"})
check("مالک دیگر نمی‌تواند پیشنهاد مغازهٔ من را دست بزند", code == 403, f"code={code}")
check("و وضعیت آن دست‌نخورده ماند",
      db.haggle(hid6)["status"] == "countered", db.haggle(hid6)["status"])
code, html = req(B, "/my/offers")
check("و پیشنهادهای مغازهٔ دیگر را در پنل خود نمی‌بیند",
      "سمیرا" not in html and "مهدی" not in html, "نشت بین فروشندگان")

head("۱۲) قفل قابلیت روی پنل پیشنهادها")
# `inquiry` is one of the founding-member freebies, so a manual revoke alone
# proves nothing while this shop sits inside the founder window. Close the
# window for the duration of the check, then put it back exactly as found.
_saved_limit = db.get_settings().get("founder_limit", "100")
db.set_setting("founder_limit", "0")
db.set_manual_grants(BID, [])
check("پیش‌شرط: قابلیت واقعاً بسته است", not db.can(BID, "inquiry"), "هنوز باز است")
code, html = req(A, "/my/offers")
check("بدون قابلیت، صفحه بن‌بست نمی‌شود", code == 200, f"code={code}")
check("ولی محتوا قفل و تار است", 'data-locked="inquiry"' in html, "")
code, _ = req(A, f"/my/offer/{hid6}", {"action": "accept"})
check("و اقدام روی پیشنهاد سمت سرور رد می‌شود",
      db.haggle(hid6)["status"] == "countered", db.haggle(hid6)["status"])
db.set_setting("founder_limit", _saved_limit)
db.set_manual_grants(BID, ["inquiry"])

head("۱۳) انقضا")
db._run("UPDATE haggles SET expires=datetime('now','-1 hour') WHERE id=?", (hid6,))
db.expire_haggles()
check("پیشنهاد گذشته از مهلت، منقضی می‌شود",
      db.haggle(hid6)["status"] == "expired", db.haggle(hid6)["status"])
db._run("UPDATE haggles SET expires=datetime('now','+1 hour') WHERE id=?", (hid2,))
db.expire_haggles()
check("و پیشنهاد معتبر دست‌نخورده می‌ماند",
      db.haggle(hid2)["status"] != "expired", db.haggle(hid2)["status"])

head("۱۴) آمار")
st = db.haggle_stats(BID)
check("آمار جمع می‌زند", st["total"] > 0, str(st))
check("نرخ موفقیت بین ۰ و ۱۰۰ است", 0 <= st["rate"] <= 100, str(st["rate"]))

head("۱۵) نشان چانه‌زنی روی صفحهٔ عمومی")
biz = db.business(bid=BID)
code, html = req(anon, f"/b/{biz['slug']}")
check("صفحهٔ مغازه باز می‌شود", code == 200, f"code={code}")
check("دکمهٔ «پیشنهاد قیمت» روی کالا هست", f"/haggle/{IID}" in html, "")
check("و کالای بدون چانه‌زنی دکمه ندارد", f"/haggle/{NOHAG}" not in html, "")
check("کف قیمت روی صفحهٔ عمومی مغازه هم نیست", str(FLOOR) not in html, "نشت!")

head("۱۶) پاک‌سازی")
for b in db.businesses(status=None):
    if TAG in (b.get("tags") or ""):
        db.delete_business(b["id"])
for ph in (PH_A, PH_B):
    o = db.owner_by_phone(ph)
    if o:
        db.delete_owner(o["id"])
db.rate_clear()
db.set_setting("haggle_enabled", _saved_haggle)
check("داده‌های آزمایشی حذف شدند", db.business(bid=BID) is None, "")
check("و گفت‌وگوها هم آبشاری پاک شدند",
      db._one("SELECT 1 FROM haggles WHERE biz_id=?", (BID,)) is None, "")

print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
