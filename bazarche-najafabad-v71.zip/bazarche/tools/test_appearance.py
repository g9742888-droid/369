# -*- coding: utf-8 -*-
"""
Appearance and layout regressions the owner reported by hand.

Four complaints, each now pinned by a test:

  1. the animated 3D scene made the front page look like a tech demo — a real
     photograph of the bazaar replaced it, served as WebP with a JPEG fallback
  2. signing in REMOVED items from the hamburger, "دیدن همهٔ امکانات" among them
  3. Chrome for Android's "Desktop site" forces a 980px viewport, and that band
     had no visible navigation at all: .main-nav hides below 1440px but
     .bottom-nav only appeared below 860px
  4. dark mode followed the phone's OS setting, so the site being demonstrated
     to a shopkeeper could open dark

Plus the layout the owner called "بهم ریختگی": nothing may overflow its
viewport at any width, and cards must use the room they have instead of
stacking one per screen.

Run:  python3 tools/test_appearance.py
"""

import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"

passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


# widths that matter: smallest phone in use, common phone, large phone,
# tablet, Chrome-desktop-mode, real laptop
WIDTHS = [320, 360, 412, 540, 768, 980, 1024, 1440]
PAGES = ["/", "/businesses", "/features", "/submit", "/prices", "/nearby",
         "/offers", "/events", "/contact", "/pricing", "/login"]


def main():
    from playwright.sync_api import sync_playwright

    print(f"\n{B}══ آزمون ظاهر و چیدمان ══{X}\n")

    # ------------------------------------------------------- static checks
    print(f"{B}۱) هیچ تصویر هیرو یا صحنهٔ سه‌بعدی روی صفحهٔ اول نیست{X}")
    db = read("server/db.py")
    ok("هیچ تنظیم سه‌بعدی باقی نمانده", '"show_3d"' not in db)
    vp = read("server/views_public.py")
    # The owner's call, after seeing it on a phone: the picture was 414px of
    # scroll that repeated what the headline already said, and it pushed the
    # "open right now" panel below the fold. The 3D scene was removed for
    # speed (v53).
    ok("تصویر هیرو حذف شده", 'class="hero-art"' not in vp)
    ok("صحنهٔ سه‌بعدی حذف شده", 'data-hero-canvas' not in vp)
    ok("جای خالی تصویر پاک است", 'side_art = ""' in vp)

    print(f"\n{B}۲) پوستهٔ روز پیش‌فرض{X}")
    js = read("site/assets/js/app.js")
    ok("پوستهٔ سیستم دنبال نمی‌شود",
       "prefers-color-scheme" not in js, "هنوز به تنظیم سیستم نگاه می‌کند")
    ok("تم واحد لوکس است (بدون toggle)",
       "data-theme-toggle" not in js and "applyTheme" not in js)
    ok("HTML با تم لوکس شروع می‌شود",
       'data-theme="luxury"' in read("server/ui.py"))

    print(f"\n{B}۳) مرزهای ناوبری هم‌تراز{X}")
    css_main = read("site/assets/css/main.css")
    css_pages = read("site/assets/css/pages.css")
    ok("نوار پایین تا ۱۴۴۰ ظاهر می‌شود",
       re.search(r"@media \(max-width: 1440px\) \{\s*\n\s*\.bottom-nav", css_pages)
       is not None)
    ok("نوار تماس همان مرز را دارد",
       re.search(r"@media \(max-width: 1440px\) \{\s*\n\s*\.call-bar", css_pages)
       is not None)
    ok("فضای پایین بدنه همان مرز را دارد",
       "ROOM FOR THE FIXED BOTTOM CHROME" in css_main
       and re.search(r"@media \(max-width: 1440px\) \{\s*\n\s*body \{", css_main)
       is not None)

    # ---------------------------------------------------------- live checks
    print(f"\n{B}۴) هیچ صفحه‌ای در هیچ عرضی سرریز ندارد{X}")
    with sync_playwright() as p:
        br = p.chromium.launch()
        overflow_bad = []
        stray_bad = []
        nav_bad = []
        for w in WIDTHS:
            ctx = br.new_context(viewport={"width": w, "height": 900})
            pg = ctx.new_page()
            for path in PAGES:
                pg.goto(BASE + path, wait_until="networkidle")
                pg.wait_for_timeout(250)
                r = pg.evaluate("""() => {
                  const de = document.documentElement;
                  const over = de.scrollWidth - de.clientWidth;
                  // elements hanging off the edge, ignoring anything inside a
                  // clipped parent (decorative orbs, map tiles) which cannot
                  // actually be reached by the user
                  const stray = [];
                  document.querySelectorAll('main *, header *, footer *').forEach(e => {
                    const cr = e.getBoundingClientRect();
                    if (cr.width < 1) return;
                    let clipped = false;
                    for (let a = e.parentElement; a; a = a.parentElement) {
                      const o = getComputedStyle(a).overflow;
                      if (o === 'hidden' || o === 'clip' || o === 'auto' || o === 'scroll')
                        { clipped = true; break; }
                    }
                    if (clipped) return;
                    // A few px of slop is the .tilt hover effect (matrix3d),
                    // not layout: it is transient, cannot be scrolled to, and
                    // never causes a scrollbar. Anything past 12px is real.
                    if (cr.right > de.clientWidth + 12 || cr.left < -12)
                      stray.push((e.className || e.tagName).toString().slice(0, 30)
                                 + ' @' + Math.round(cr.left) + '..' + Math.round(cr.right));
                  });
                  const bn = document.querySelector('.bottom-nav');
                  const mn = document.querySelector('.main-nav');
                  const tg = document.querySelector('.nav-toggle');
                  const vis = el => el && getComputedStyle(el).display !== 'none';
                  return {over, stray: [...new Set(stray)].slice(0, 3),
                          hasNav: vis(bn) || vis(mn) || vis(tg)};
                }""")
                if r["over"] > 0:
                    overflow_bad.append(f"{w}px {path} +{r['over']}")
                if r["stray"]:
                    stray_bad.append(f"{w}px {path} {r['stray']}")
                if not r["hasNav"]:
                    nav_bad.append(f"{w}px {path}")
            ctx.close()

        ok("هیچ اسکرول افقی وجود ندارد", not overflow_bad, str(overflow_bad[:3]))
        ok("هیچ عنصری از لبه بیرون نمی‌زند", not stray_bad, str(stray_bad[:3]))
        ok("هر عرضی ناوبری قابل دیدن دارد", not nav_bad, str(nav_bad[:4]))

        # ---------------------------------------------- roomier, not smaller
        print(f"\n{B}۵) کارت‌ها از فضای موجود استفاده می‌کنند{X}")
        cols = {}
        for w in (360, 412, 768, 980):
            ctx = br.new_context(viewport={"width": w, "height": 900})
            pg = ctx.new_page()
            pg.goto(BASE + "/", wait_until="networkidle")
            pg.wait_for_timeout(400)
            cols[w] = pg.evaluate("""() => {
              const e = document.querySelector('.cat-grid');
              return e ? getComputedStyle(e).gridTemplateColumns.split(' ').length : 0;
            }""")
            ctx.close()
        ok("روی گوشی معمولی دو ستون دسته", cols.get(412, 0) >= 2, str(cols))
        ok("در حالت رایانه ستون‌ها بیشتر می‌شوند",
           cols.get(980, 0) > cols.get(412, 0), str(cols))
        ok("ستون‌ها با عرض یکنواخت زیاد می‌شوند",
           cols[360] <= cols[412] <= cols[768] <= cols[980], str(cols))

        # text must NOT have been shrunk to achieve the above
        print(f"\n{B}۶) متن کوچک نشده است{X}")
        ctx = br.new_context(viewport={"width": 412, "height": 900})
        pg = ctx.new_page()
        pg.goto(BASE + "/", wait_until="networkidle")
        pg.wait_for_timeout(400)
        small = pg.evaluate("""() => {
          const bad = [];
          document.querySelectorAll('p,span,a,li,small,label,strong').forEach(e => {
            if (e.children.length) return;
            if (!(e.textContent || '').trim()) return;
            if (e.closest('.bottom-nav')) return;   // documented 11px exception
            const fs = parseFloat(getComputedStyle(e).fontSize);
            if (fs && fs < 12) bad.push(Math.round(fs) + 'px ' +
              (e.textContent || '').trim().slice(0, 18));
          });
          return [...new Set(bad)].slice(0, 5);
        }""")
        ok("هیچ متنی زیر ۱۲ پیکسل نیست", not small, str(small))
        theme = pg.evaluate("document.documentElement.getAttribute('data-theme')")
        ok("سایت با تم لوکس باز می‌شود", theme == "luxury", str(theme))
        ok("هیچ تصویر هیرویی رندر نمی‌شود",
           pg.evaluate("!document.querySelector('.hero-art')"))
        # what replaced it must be the thing a visitor acts on
        panel_y = pg.evaluate("""() => {
          const p = document.querySelector('.hero-panel');
          return p ? Math.round(p.getBoundingClientRect().top + scrollY) : -1;
        }""")
        ok("پنل «همین حالا باز هستند» بالاتر آمد", 0 < panel_y < 1200, f"y={panel_y}")
        # v53: the 3D hero was removed for speed — no canvas may exist.
        ok("هیچ بوم سه‌بعدی روی صفحه نیست",
           pg.evaluate("!document.querySelector('[data-hero-canvas]')"))
        ctx.close()

        # ------------------------------------------- menu after signing in
        print(f"\n{B}۷) ورود چیزی از منو کم نمی‌کند{X}")
        ui = read("server/ui.py")
        # both branches must offer the features link and the perk list
        me_branch = ui[ui.index("    if me:\n        who ="):ui.index("    else:\n        # Not signed in")]
        ok("لینک همهٔ امکانات بعد از ورود هست", "/features" in me_branch)
        ok("میان‌برهای پنل بعد از ورود هست", "mnav-perks" in me_branch)
        ok("خروج از حساب هنوز هست", "/my/logout" in me_branch)
        ok("نشان حساب در هدر هست", "account-chip" in ui)

        ctx = br.new_context(viewport={"width": 412, "height": 900})
        pg = ctx.new_page()
        pg.goto(BASE + "/login", wait_until="networkidle")
        # /login redirects straight to /my when a session already exists, so
        # only walk the OTP steps when the form is actually on screen.
        signed_in = "/my" in pg.url
        if not signed_in and pg.query_selector("#ph"):
            pg.fill("#ph", "09134950001")
            pg.click("form[action='/login'] button[type=submit]")
            pg.wait_for_timeout(800)
            code = pg.evaluate("""() => {
              const el = document.querySelector('.alert strong');
              return el ? el.textContent.trim() : '';
            }""")
            if code and code.isdigit():
                # The OTP field auto-submits on the fifth digit (app.js initOtp),
                # so filling it IS the submit — clicking afterwards raced the
                # navigation and timed out against a page that had already left.
                with pg.expect_navigation(wait_until="networkidle"):
                    pg.fill("#otp", code)
                signed_in = "/my" in pg.url
        ok("ورود انجام شد", signed_in, pg.url)
        if signed_in:
            pg.goto(BASE + "/", wait_until="networkidle")
            pg.wait_for_timeout(400)
            pg.click("[data-nav-toggle]")
            pg.wait_for_timeout(500)
            menu = pg.evaluate("""() => {
              const n = document.querySelector('#mobile-nav');
              const hrefs = [...n.querySelectorAll('a')].map(a => a.getAttribute('href'));
              return {n: hrefs.length, features: hrefs.includes('/features'),
                      my: hrefs.includes('/my'),
                      logout: !!n.querySelector('.mnav-logout')};
            }""")
            ok("منو بعد از ورود لینک همهٔ امکانات دارد", menu["features"], str(menu))
            ok("منو بعد از ورود لینک پنل من دارد", menu["my"], str(menu))
            ok("دکمهٔ خروج در منو هست", menu["logout"], str(menu))
            ok("تعداد لینک‌های منو کم نشده", menu["n"] >= 18, f"{menu['n']} لینک")
        ctx.close()
        br.close()

    print(f"\n{B}{'=' * 58}{X}")
    if failed:
        print(f"{B}{R}  {passed} موفق، {failed} ناموفق{X}")
        for f in fails:
            print(f"    ✗ {f}")
    else:
        print(f"{B}{G}  همه موفق — {passed} آزمون، ۰ ناموفق{X}")
    print(f"{B}{'=' * 58}{X}\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
