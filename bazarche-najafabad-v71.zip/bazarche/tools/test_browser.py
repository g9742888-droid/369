#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Browser-level checks: console errors, accessibility, responsive layout."""

import os
import sys
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
SHOT = os.path.join(HERE, "..", "shots")
os.makedirs(SHOT, exist_ok=True)

IGNORE = ("VALIDATE_STATUS", "Shader Error", "GroupMarkerNotSet",
          "software WebGL", "unpkg", "openstreetmap", "tile",
          "net::ERR_INTERNET", "Automatic fallback")

A11Y = """() => {
  const out = {imgNoAlt:0, btnNoName:0, inputNoLabel:0, smallTap:0, contrast:0};
  document.querySelectorAll('img').forEach(i => { if (!i.hasAttribute('alt')) out.imgNoAlt++; });
  document.querySelectorAll('button, a[href]').forEach(b => {
    const t = (b.innerText||'').trim();
    if (!t && !b.getAttribute('aria-label') && !b.getAttribute('title')) out.btnNoName++;
  });
  document.querySelectorAll('input,select,textarea').forEach(i => {
    if (i.type === 'hidden') return;
    const lab = i.id && document.querySelector(`label[for="${i.id}"]`);
    if (!lab && !i.getAttribute('aria-label') && !i.closest('label')) out.inputNoLabel++;
  });
  const inline = (el) => {
    if (el.tagName !== 'A') return false;
    const p = el.parentElement;
    return p && /^(P|SPAN|LI|LABEL|SMALL|TD)$/.test(p.tagName)
             && p.innerText.trim() !== el.innerText.trim();
  };
  document.querySelectorAll('button, a[href], input[type=checkbox]').forEach(el => {
    const r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    if (inline(el)) return;
    // third-party map attribution must stay as the licence requires
    if (el.closest('.leaflet-control-attribution, .gm-style')) return;
    const lab = el.closest('label');
    if (lab && lab.getBoundingClientRect().height >= 40) return;
    if (r.height < 24 || r.width < 24) out.smallTap++;
  });
  return out;
}"""


def main():
    tok = db.owner_token()
    pages = [
        ("/", "خانه"),
        ("/businesses", "کسب‌وکارها"),
        ("/catalog", "کاتالوگ"),
        ("/map", "نقشه"),
        ("/offers", "تخفیف‌ها"),
        ("/blog", "وبلاگ"),
        ("/pricing", "تعرفه‌ها"),
        ("/contact", "تماس"),
        ("/submit", "ثبت کسب‌وکار"),
        ("/login", "ورود"),
        ("/about", "درباره"),
        ("/rules", "قوانین"),
        ("/favorites", "علاقه‌مندی‌ها"),
        (f"/panel?key={tok}", "داشبورد مدیر"),
        (f"/panel/businesses?key={tok}", "مدیر: کسب‌وکارها"),
        (f"/panel/categories?key={tok}", "مدیر: دسته‌ها"),
        (f"/panel/settings?key={tok}", "مدیر: تنظیمات"),
        (f"/panel/appearance?key={tok}", "مدیر: ظاهر"),
        (f"/panel/owners?key={tok}", "مدیر: صاحبان"),
        (f"/panel/claims?key={tok}", "مدیر: تصاحب"),
        (f"/panel/inquiries?key={tok}", "مدیر: استعلام"),
        (f"/panel/backup?key={tok}", "مدیر: پشتیبان"),
    ]

    fails = []
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--enable-unsafe-swiftshader"])

        print("\n" + "═" * 62)
        print("  خطای کنسول و دسترسی‌پذیری (۱۴۴۰px)")
        print("═" * 62)
        for path, name in pages:
            ctx = b.new_context(viewport={"width": 1440, "height": 1000}, locale="fa-IR")
            pg = ctx.new_page()
            errs = []
            pg.on("console", lambda m: errs.append(m.text[:90])
                  if m.type == "error" and not any(k in m.text for k in IGNORE) else None)
            pg.on("pageerror", lambda e: errs.append("JS " + str(e)[:90]))
            pg.goto(BASE + path, wait_until="networkidle", timeout=30000)
            pg.wait_for_timeout(1600)
            a = pg.evaluate(A11Y)
            hs = pg.evaluate("()=>document.documentElement.scrollWidth>document.documentElement.clientWidth+2")
            probs = []
            if errs: probs.append(f"کنسول: {errs[0]}")
            if a["imgNoAlt"]: probs.append(f"{a['imgNoAlt']} تصویر بدون alt")
            if a["btnNoName"]: probs.append(f"{a['btnNoName']} دکمهٔ بی‌نام")
            if a["inputNoLabel"]: probs.append(f"{a['inputNoLabel']} ورودی بدون برچسب")
            if a["smallTap"]: probs.append(f"{a['smallTap']} هدف کوچک")
            if hs: probs.append("اسکرول افقی")
            print(("  ✓ " if not probs else "  ✗ ") + f"{name:22}" +
                  ("" if not probs else " | ".join(probs)))
            if probs: fails.append((name, probs))
            ctx.close()

        print("\n" + "═" * 62)
        print("  واکنش‌گرایی")
        print("═" * 62)
        sample = ["/", "/businesses", "/catalog", "/submit",
                  f"/panel?key={tok}", f"/panel/businesses?key={tok}"]
        for w in (1920, 1440, 1360, 1280, 1024, 900, 768, 600, 430, 390, 360):
            bad = []
            for path in sample:
                mob = w < 520
                ctx = b.new_context(viewport={"width": w, "height": 900},
                                    locale="fa-IR", is_mobile=mob, has_touch=mob)
                pg = ctx.new_page()
                pg.goto(BASE + path, wait_until="domcontentloaded", timeout=30000)
                pg.wait_for_timeout(650)
                if pg.evaluate("()=>document.documentElement.scrollWidth>document.documentElement.clientWidth+2"):
                    bad.append(path.split("?")[0])
                ctx.close()
            print(f"  {'✓' if not bad else '✗'} {w:>5}px" +
                  ("" if not bad else "   " + ", ".join(bad)))
            if bad: fails.append((f"{w}px", bad))

        print("\n" + "═" * 62)
        print("  تعامل واقعی کاربر")
        print("═" * 62)

        # mobile menu
        ctx = b.new_context(viewport={"width": 390, "height": 844},
                            is_mobile=True, has_touch=True, locale="fa-IR")
        pg = ctx.new_page()
        pg.goto(BASE + "/", wait_until="networkidle"); pg.wait_for_timeout(1500)
        pg.click("[data-nav-toggle]"); pg.wait_for_timeout(700)
        opened = pg.eval_on_selector("#mobile-nav", "e=>e.classList.contains('is-open')")
        print(("  ✓ " if opened else "  ✗ ") + "منوی موبایل باز می‌شود")
        if not opened: fails.append(("منوی موبایل", ["باز نشد"]))
        pg.click(".mobile-nav .panel button[data-nav-close]"); pg.wait_for_timeout(500)
        closed = not pg.eval_on_selector("#mobile-nav", "e=>e.classList.contains('is-open')")
        print(("  ✓ " if closed else "  ✗ ") + "منوی موبایل بسته می‌شود")
        ctx.close()

        # single luxury theme (v64) — no toggle, always luxury
        ctx = b.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        pg = ctx.new_page()
        pg.goto(BASE + "/", wait_until="networkidle"); pg.wait_for_timeout(1200)
        luxury = pg.evaluate("()=>document.documentElement.getAttribute('data-theme')")
        print(("  ✓ " if luxury == "luxury" else "  ✗ ") + f"تم لوکس ({luxury})")
        if luxury != "luxury": fails.append(("تم", ["لوکس نیست"]))
        pg.screenshot(path=os.path.join(SHOT, "final-home.png"))
        ctx.close()

        # live duplicate warning
        ctx = b.new_context(viewport={"width": 1000, "height": 1200}, locale="fa-IR")
        pg = ctx.new_page()
        pg.goto(BASE + "/submit", wait_until="networkidle"); pg.wait_for_timeout(1000)
        # use a name that is actually in the database right now instead of a
        # hard-coded fixture that a cleanup run may have removed
        import db as _db
        _live = _db.businesses(status=None)
        _probe = _live[0]["name"] if _live else "کبابی شهرزاد"
        pg.fill("#sb-name", _probe); pg.dispatch_event("#sb-name", "input")
        pg.wait_for_timeout(1800)
        shown = pg.eval_on_selector('.dup-hint[data-dup-for="name"]', "e=>!e.hidden")
        print(("  ✓ " if shown else "  ✗ ") + "هشدار تکراری زنده")
        if not shown: fails.append(("هشدار تکراری", ["نمایش داده نشد"]))
        ctx.close()

        # 3D scene removed for speed (v53) — the hero must carry no canvas
        ctx = b.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        pg = ctx.new_page()
        pg.goto(BASE + "/", wait_until="networkidle"); pg.wait_for_timeout(1500)
        no_canvas = pg.evaluate("!document.querySelector('[data-hero-canvas]')")
        print(("  ✓ " if no_canvas else "  ✗ ") + "هیچ بوم سه‌بعدی نیست")
        if not no_canvas: fails.append(("بوم سه‌بعدی", ["هنوز موجود است"]))
        pg.screenshot(path=os.path.join(SHOT, "final-home.png"))
        ctx.close()

        # map
        ctx = b.new_context(viewport={"width": 1440, "height": 900}, locale="fa-IR")
        pg = ctx.new_page()
        pg.goto(BASE + "/map", wait_until="networkidle"); pg.wait_for_timeout(4000)
        mp = pg.eval_on_selector("[data-map-wrap]", "e=>e.getAttribute('data-map')")
        print(("  ✓ " if mp in ("osm", "google") else "  ! ") + f"نقشه ({mp})")
        pg.screenshot(path=os.path.join(SHOT, "final-map.png"))
        ctx.close()

        b.close()

    print("\n" + "═" * 62)
    if fails:
        print(f"  {len(fails)} ایراد:")
        for n, d in fails:
            print(f"    ✗ {n}: {d}")
    else:
        print("  ✓ همهٔ بررسی‌های مرورگری موفق")
    print("═" * 62)
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
