# -*- coding: utf-8 -*-
"""Accurate contrast audit: only flag text sitting on the NEUTRAL theme
background (page/card), ignoring decorative gradient/colored bands."""
import sys
from playwright.sync_api import sync_playwright

BASE = "http://127.0.0.1:8080"
PAGES = ["/", "/businesses", "/catalog", "/pricing", "/contact"]

NEUTRAL = {"light": [(230,245,250)], "dark": [(5,12,20)]}

def close(c, target, tol=26):
    return all(abs(c[i]-target[i]) <= tol for i in range(3))

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width":1280,"height":900})
    for url in PAGES:
        for theme in ("light","dark"):
            pg.goto(BASE + url, wait_until="networkidle")
            pg.evaluate(f"document.documentElement.setAttribute('data-theme','{theme}')")
            pg.wait_for_timeout(300)
            body_bg = pg.evaluate("getComputedStyle(document.body).backgroundColor")
            print(f"\n===== {url} [{theme}] body={body_bg} =====")
            # collect all text nodes with their effective bg + fg in ONE pass
            data = pg.evaluate("""() => {
                const parse = (c) => {
                    const m = c.match(/rgba?\\(([\\d.]+), *([\\d.]+), *([\\d.]+)(?:, *([\\d.]+))?\\)/);
                    return m ? {r:+m[1],g:+m[2],b:+m[3],a:(m[4]===undefined?1:+m[4])} : null;
                };
                const effBg = (el) => {
                    let node = el;
                    while (node && node.nodeType === 1) {
                        const s = getComputedStyle(node);
                        if (s.backgroundImage && s.backgroundImage !== 'none') return {decorative:true};
                        const bg = parse(s.backgroundColor);
                        if (bg && bg.a > 0.85) {
                            const neutralLight = bg.r>200 && bg.g>200 && bg.b>200;
                            const neutralDark = bg.r<60 && bg.g<60 && bg.b<70;
                            return {bg, decorative: !(neutralLight || neutralDark)};
                        }
                        node = node.parentElement;
                    }
                    return {bg: {r:244,g:248,b:247,a:1}, decorative:false};
                };
                const out = [];
                const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
                let n;
                while (n = walk.nextNode()) {
                    const s = getComputedStyle(n);
                    const rect = n.getBoundingClientRect();
                    if (rect.width===0||rect.height===0) continue;
                    const txt = [...n.childNodes].filter(c=>c.nodeType===3).map(c=>c.textContent).join('').trim();
                    if (!txt || txt.length < 2) continue;
                    const fg = parse(s.color);
                    if (!fg || fg.a < 0.5) continue;
                    const e = effBg(n);
                    out.push({txt: txt.slice(0,36), fg, bg: e.bg, decorative: e.decorative,
                              fs: parseFloat(s.fontSize), w: parseInt(s.fontWeight)||400,
                              tag: n.tagName, cls: (n.className||'').toString().slice(0,40)});
                }
                return out;
            }""")
            for d in data:
                if d["decorative"]:
                    continue  # skip colored bands/buttons — designer-chosen
                bg = d["bg"]
                fg = d["fg"]
                def lum(c):
                    def f(x):
                        x/=255.0
                        return x/12.92 if x<=0.03928 else ((x+0.055)/1.055)**2.4
                    r,g,bb=f(c["r"]),f(c["g"]),f(c["b"])
                    return 0.2126*r+0.7152*g+0.0722*bb
                lf, lb = lum(fg), lum(bg)
                hi, lo = max(lf,lb), min(lf,lb)
                ratio = (hi+0.05)/(lo+0.05)
                thr = 3.0 if (d["fs"]>=24 or (d["fs"]>=18.66 and d["w"]>=700)) else 4.5
                if ratio < thr:
                    print(f"  {ratio:4.2f} {d['fs']:4.1f}px w{d['w']} [{d['cls'] or d['tag']}] "
                          f"{d['txt']!r} fg=rgb({fg['r']},{fg['g']},{fg['b']}) bg=rgb({bg['r']},{bg['g']},{bg['b']})")
    b.close()
