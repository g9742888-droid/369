# -*- coding: utf-8 -*-
"""v69 tests — one door, two roles (unified login).

Proves: a single OTP signs the visitor in as customer AND shopkeeper,
orphan businesses auto-link, /me aliases merge into /my, legacy POST
routes keep working, and the shop_account/owner_login gates still hold.
"""
import os, re, sys, json
import urllib.parse, urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
sys.path.insert(0, HERE)
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")
PASS, FAIL = [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append((name, detail))
    print(("  ✓ " if cond else "  ✗ ") + name + (f"  [{detail}]" if detail and not cond else ""))


class NoRedir(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def client():
    jar = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedir())
    return jar, op


def post(op, path, data):
    try:
        r = op.open(BASE + path, data=urllib.parse.urlencode(data).encode(), timeout=15)
        return r.status, r.headers, r.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:   # 303s are success here (NoRedir)
        return e.code, e.headers, e.read().decode("utf-8", "ignore")


def get(op, path):
    try:
        r = op.open(BASE + path, timeout=15)
        return r.status, r.read().decode("utf-8", "ignore")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore")


def otp_of(phone):
    row = db.connect().execute("SELECT code FROM otp WHERE phone=?",
                               (db.norm_phone(phone),)).fetchone()
    return row["code"] if row else None


def main():
    db.rate_clear()   # earlier dev runs may have exhausted the OTP bucket
    print("\n" + "═" * 60 + "\n  ۱) یک در، دو نقش\n" + "═" * 60)
    phone = "09120006677"
    con = db.connect()
    con.execute("DELETE FROM customers WHERE phone=?", (phone,))
    con.execute("DELETE FROM owners WHERE phone=?", (phone,))
    con.commit(); con.close()

    jar, op = client()
    c, h, body = post(op, "/login", {"phone": phone})
    ok("درخواست کد از درِ واحد", c in (200, 303))
    code = otp_of(phone)
    ok("کد صادر شد", bool(code))
    c, h, body = post(op, "/login/verify", {"phone": phone, "code": code})
    cookies = {ck.name for ck in jar}
    ok("کوکی مشتری + کوکی مغازه‌دار هر دو", {"bzv2_cust", "bzv2_sess"} <= cookies, str(cookies))
    c, body = get(op, "/my")
    ok("داشبورد یکپارچه باز می‌شود", c == 200)
    ok("نوار مشتری روی داشبورد", "data-cust-strip" in body)

    print("\n" + "═" * 60 + "\n  ۲) کسب‌وکارِ هم‌شماره خودبه‌خود وصل می‌شود\n" + "═" * 60)
    ph2 = "09120008899"
    con = db.connect()
    con.execute("DELETE FROM owners WHERE phone=?", (ph2,))
    con.commit(); con.close()
    bid = db.save_business({"name": "مغازهٔ هم‌شماره v69", "cat_slug": "cafe",
                            "status": "published", "phone": ph2,
                            "city": "نجف‌آباد", "address": "تست"})
    jar2, op2 = client()
    post(op2, "/me/login", {"phone": ph2})          # legacy alias still issues
    code2 = otp_of(ph2)
    c, h, body = post(op2, "/me/login/verify", {"phone": ph2, "code": code2})
    loc = h.get("Location", "")
    ok("مسیر قدیمی /me/login هنوز کار می‌کند", bool(code2))
    ok("پیوند خودکار در redirect اعلام شد", "ok=" in loc and urllib.parse.unquote(loc).find("متصل شد") >= 0, loc[:80])
    own = db.connect().execute("SELECT owner_id FROM businesses WHERE id=?", (bid,)).fetchone()
    ok("کسب‌وکار به حساب جدید وصل شد", bool(own and own["owner_id"]), str(own))

    print("\n" + "═" * 60 + "\n  ۳) الایاس‌ها و گیت‌ها\n" + "═" * 60)
    jar3, op3 = client()
    c, h, _ = post(op3, "/me/login", {"phone": "09120001122"})
    ok("/me/login GET-less alias پاسخ می‌دهد", c in (200, 303))
    c, h, _ = post(op3, "/nothing", {})
    r = urllib.request.Request(BASE + "/me")
    try:
        rr = urllib.request.urlopen(rr := urllib.request.Request(BASE + "/me"), timeout=10)
        ok("/me بدون ورود به /login می‌رود", "/login" in rr.url)
    except urllib.error.HTTPError as e:
        ok("/me بدون ورود به /login می‌رود", e.code in (302, 303))
    # gates
    s = db.get_settings()
    db.set_setting("shop_account", "0")
    jar4, op4 = client()
    post(op4, "/login", {"phone": "09120003344"})
    c4 = otp_of("09120003344")
    c, h, _ = post(op4, "/login/verify", {"phone": "09120003344", "code": c4})
    cookies = {ck.name for ck in jar4}
    ok("گیت shop_account: بدون آن کوکی مشتری نمی‌گیرد", "bzv2_cust" not in cookies, str(cookies))
    db.set_setting("shop_account", s.get("shop_account", "1"))

    print("\n" + "═" * 60 + "\n  ۴) صفحهٔ ورود واحد\n" + "═" * 60)
    c, body = get(op3, "/login")
    ok("صفحهٔ واحد باز می‌شود", c == 200)
    ok("کپی هر دو نقش", "مشتری" in body and "مغازه" in body)
    ok("فرم‌ها سازگار با تست‌های قدیمی (#ph/#otp)", 'id="ph"' in body)

    # cleanup
    con = db.connect()
    con.execute("DELETE FROM businesses WHERE name='مغازهٔ هم‌شماره v69'")
    for p_ in (phone, ph2, "09120003344", "09120001122"):
        con.execute("DELETE FROM customers WHERE phone=?", (p_,))
        con.execute("DELETE FROM owners WHERE phone=?", (p_,))
    con.commit(); con.close()

    print("\n" + "═" * 60)
    print(f"  {len(PASS)} موفق ، {len(FAIL)} ناموفق")
    print("═" * 60)
    for name, d in FAIL:
        print("   ✗", name, d)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
