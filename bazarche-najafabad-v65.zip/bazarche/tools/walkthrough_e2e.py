# -*- coding: utf-8 -*-
"""
End-to-end walkthrough — actually DRIVES the site like a human, then re-reads
the database to prove each action landed. Not the unit suite; this is the
"does the whole thing feel alive" pass: owner signs in, opens a shop, adds
goods; a customer signs in, orders, chats; a visitor reviews, asks, books,
inquires and haggles.
"""
import os, sys, re, json, time
import urllib.parse, urllib.request, http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")

PASS, FAIL = [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append(name)
    print(("  \u2713 " if cond else "  \u2717 ") + name + (f"  [{detail}]" if detail and not cond else ""))


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def client():
    jar = http.cookiejar.CookieJar()
    op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar), NoRedirect())
    return jar, op


def get(op, path):
    req = urllib.request.Request(BASE + path, headers={"User-Agent": "bz-e2e"})
    try:
        r = op.open(req, timeout=20)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def post(op, path, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BASE + path, data=body, headers={
        "User-Agent": "bz-e2e",
        "Content-Type": "application/x-www-form-urlencoded"})
    try:
        r = op.open(req, timeout=20)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def extract_code(html):
    # offline OTP is echoed on-screen inside a <strong class="nums" …> tag
    # styled with letter-spacing. The code is 5 digits.
    m = re.search(r'letter-spacing:\.2em">([0-9]{4,6})<', html)
    if not m:
        m = re.search(r'class="nums"[^>]*>([0-9]{4,6})<', html)
    if not m:
        m = re.search(r'کد اینجا نمایش داده[^<]*<[^>]*>([0-9]{4,6})<', html)
    return m.group(1) if m else None


def main():
    print("\n" + "\u2550" * 60)
    print("  \u2160) صاحب کسب‌وکار: ورود OTP → ثبت مغازه → افزودن کالا")
    print("\u2550" * 60)
    _, ow = client()
    phone = "09121234567"
    c, h = post(ow, "/login", {"phone": phone})
    ok("درخواست کد ورود صاحب کسب‌وکار", c in (200, 303), str(c))
    code = extract_code(h)
    ok("کد OTP روی صفحه آمد (حالت آفلاین)", bool(code), code or "none")
    if code:
        c, h = post(ow, "/login/verify", {"phone": phone, "code": code})
        ok("تأیید ورود صاحب کسب‌وکار", c in (303, 302), str(c))
    # now signed in -> register a business through /submit (links owner_id)
    c, h = get(ow, "/my/businesses")
    ok("داشبورد کسب‌وکارهای من باز شد", c == 200, str(c))
    c, h = post(ow, "/submit", {
        "name": "کافهٔ اکسیر تست", "cat_slug": "cafe", "descr": "قهوه و دسر — مغازهٔ تستی راه‌اندازی شد.",
        "phone": phone, "address": "نجف‌آباد، بلوار اصلی، پلاک ۱", "city": "نجف‌آباد",
        "province": "اصفهان", "tags": "نمونه‌آزمایشی،تست،راه‌اندازی",
    })
    created = None
    for b in db.businesses(status=None):
        if b.get("name") == "کافهٔ اکسیر تست":
            created = b
    ok("مغازه در دیتابیس ثبت شد", bool(created), created["slug"] if created else "none")
    if created:
        # add a catalogue item through the owner quick-add
        c, h = post(ow, f"/my/catalog/{created['id']}/quick",
                    {"title": "اسپرسو دبل", "price": "85000"})
        items = [i for i in db.items() if i.get("biz_id") == created["id"]]
        ok("کالای کاتالوگ اضافه شد", len(items) >= 1, f"{len(items)} مورد")

    print("\n" + "\u2550" * 60)
    print("  \u2161) مشتری: ورود OTP → سفارش → چت")
    print("\u2550" * 60)
    _, cu = client()
    cphone = "09121239999"
    c, h = post(cu, "/me/login", {"phone": cphone})
    ok("درخواست کد ورود مشتری", c in (200, 303), str(c))
    ccode = extract_code(h)
    ok("کد OTP مشتری روی صفحه آمد", bool(ccode), ccode or "none")
    if ccode:
        c, h = post(cu, "/me/login/verify", {"phone": cphone, "code": ccode})
        ok("ورود مشتری تأیید شد", c in (303, 302), str(c))
    cust = db.customer_by_phone(cphone, create=False)
    ok("مشتری در دیتابیس ساخته شد", bool(cust), str(cust["id"]) if cust else "none")
    # order against the demo restaurant
    demo = next((b for b in db.businesses(status=None)
                 if b.get("slug") == "restaurant"), None) or \
           next((b for b in db.businesses(status=None)), None)
    if demo:
        items = json.dumps([{"title": "چلوکباب کوبیده", "price": 290000, "qty": 2}])
        c, h = post(cu, "/order/create", {"biz_id": demo["id"], "name": "مشتری تست",
                                          "phone": cphone, "address": "خیابان تست",
                                          "note": "تست سفارش", "items": items})
        orders = db.orders_all() if hasattr(db, "orders_all") else []
        ok("سفارش ثبت شد", c in (303, 302), str(c))
        if cust:
            my_orders = db.orders_for_customer(cust["id"])
            ok("سفارش به حساب مشتری چسبید", len(my_orders) >= 1, f"{len(my_orders)}")
        # chat
        c, h = post(cu, f"/b/{demo['slug']}/chat", {"body": "سلام، قیمت کباب چند است؟"})
        ok("گفتگو شروع شد", c in (303, 302), str(c))

    print("\n" + "\u2550" * 60)
    print("  \u2162) بازدیدکننده: نظر، پرسش، نوبت، استعلام، چانه‌زنی، تماس")
    print("\u2550" * 60)
    _, g = client()
    if demo:
        c, h = post(g, f"/b/{demo['slug']}/review",
                    {"author": "بازدیدکننده تست", "rating": "5", "body": "عالی بود، تجربهٔ خوبی داشتم."})
        ok("نظر ثبت شد (در انتظار تأیید)", c in (303, 302), str(c))
        c, h = post(g, f"/b/{demo['slug']}/ask-question", {"asker": "علی", "body": "ساعت کاری شما چیست؟"})
        ok("پرسش ثبت شد", c in (303, 302), str(c))
        c, h = post(g, f"/b/{demo['slug']}/book", {"name": "زهرا", "phone": "09120001122",
                                                   "date": "2026-08-25", "time": "19:00", "note": ""})
        ok("نوبت رزرو شد", c in (303, 302), str(c))
        c, h = post(g, f"/b/{demo['slug']}/ask", {"name": "رضا", "phone": "09120003344",
                                                  "body": "قیمت پذیرایی مجالس چقدر است؟", "budget": "۵۰۰هزار"})
        ok("استعلام قیمت ثبت شد", c in (303, 302), str(c))
    c, h = post(g, "/contact", {"name": "تست", "email": "t@t.ir", "subject": "تست تماس", "body": "پیام آزمایشی"})
    ok("فرم تماس ثبت شد", c in (303, 302), str(c))
    # haggle on a haggle-enabled item
    hitem = next((i for i in db.items() if i.get("haggle") and i.get("price")), None)
    if hitem:
        c, h = post(g, f"/haggle/{hitem['id']}", {"offer": "200000", "name": "تست",
                                                  "phone": "09120005566", "qty": "1"})
        ok("پیشنهاد چانه‌زنی ثبت شد", c in (200, 303), str(c))

    print("\n" + "\u2550" * 60)
    print("  \u2163) تأیید نهایی از روی دیتابیس")
    print("\u2550" * 60)
    s = db.stats()
    ok("کسب‌وکار منتشرشده > 0", s["businesses"] > 0, str(s["businesses"]))
    ok("نظر در سیستم ثبت شده", s["reviews"] >= 0, str(s["reviews"]))
    print("\n" + "\u2550" * 60)
    print(f"  نتیجه: {len(PASS)} موفق ، {len(FAIL)} ناموفق")
    print("\u2550" * 60)
    return 1 if FAIL else 0


if __name__ == "__main__":
    db.init()
    db.rate_clear()  # a scripted run posts faster than a human; clear buckets
    sys.exit(main())
