#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Full end-to-end test suite for Bazarche Najafabad.
Exercises every route, every workflow, security boundaries and data integrity.
"""

import os
import re
import sys
import json
import time
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
sys.path.insert(0, HERE)
import db

BASE = os.environ.get("BZ", "http://127.0.0.1:8080")

# The site rate-limits public forms (spam protection). A test run legitimately
# posts the same form far more often than a human would, so clear the bucket
# up front instead of pretending the protection is not there.
db.rate_clear()

# Fixtures left behind by an earlier run would make the counts below wrong
# even though the code is fine, so start from a known-empty state.
import reset_testdata as _reset
_reset.wipe_fixtures()

PASS, FAIL, WARN = [], [], []


def ok(name, cond, detail=""):
    (PASS if cond else FAIL).append((name, detail))
    print(("  ✓ " if cond else "  ✗ ") + name + (f"   [{detail}]" if detail and not cond else ""))
    return cond


def warn(name, detail=""):
    WARN.append((name, detail))
    print("  ! " + name + (f"   [{detail}]" if detail else ""))


def section(t):
    print("\n" + "═" * 62)
    print("  " + t)
    print("═" * 62)


class Client:
    """Cookie-aware HTTP client."""

    def __init__(self):
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.jar),
            NoRedirect())

    def get(self, path, follow=False):
        req = urllib.request.Request(BASE + path, headers={"User-Agent": "bz-test"})
        return self._do(req, follow)

    def post(self, path, data, follow=False):
        body = urllib.parse.urlencode(data, doseq=True).encode()
        req = urllib.request.Request(BASE + path, data=body, headers={
            "User-Agent": "bz-test",
            "Content-Type": "application/x-www-form-urlencoded"})
        return self._do(req, follow)

    def _do(self, req, follow):
        try:
            r = self.op.open(req, timeout=20)
            return r.getcode(), r.read().decode("utf-8", "replace"), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode("utf-8", "replace"), e.headers
        except Exception as e:
            return 0, str(e), {}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def code_for(phone):
    con = db.connect()
    r = con.execute("SELECT code FROM otp WHERE phone=?", (db.norm_phone(phone),)).fetchone()
    con.close()
    return r["code"] if r else ""


# ==========================================================================
def main():
    tok = db.owner_token()
    admin = Client()
    guest = Client()

    # ---------------------------------------------------------------- routes
    section("۱) مسیرهای عمومی")
    for p in ["/", "/businesses", "/map", "/catalog", "/offers", "/blog",
              "/favorites", "/pricing", "/contact", "/submit", "/about",
              "/rules", "/login", "/register", "/signup", "/owner",
              "/nearby", "/events", "/compare", "/offline.html",
              "/manifest.webmanifest", "/sw.js", "/robots.txt", "/sitemap.xml",
              "/api/businesses"]:
        c, _, _ = guest.get(p)
        ok(f"GET {p}", c == 200, f"HTTP {c}")

    section("۲) مسیرهای پنل مدیریت")
    for p in ["/panel", "/panel/businesses", "/panel/business/new",
              "/panel/categories", "/panel/reviews", "/panel/claims",
              "/panel/owners", "/panel/inquiries", "/panel/bookings",
              "/panel/coupons", "/panel/posts", "/panel/messages",
              "/panel/pages", "/panel/appearance", "/panel/settings",
              "/panel/backup", "/panel/backup/export",
              "/panel/insights", "/panel/qa", "/panel/reports",
              "/panel/badges", "/panel/plans", "/panel/subscriptions",
              "/panel/ads", "/panel/events", "/panel/edits", "/panel/alerts"]:
        c, _, _ = admin.get(f"{p}?key={tok}")
        ok(f"GET {p}", c == 200, f"HTTP {c}")

    section("۳) امنیت — دسترسی بدون مجوز")
    c, _, _ = guest.get("/panel")
    ok("پنل بدون کلید مسدود", c == 403, f"HTTP {c}")
    c, _, _ = guest.get("/panel?key=wrong-key")
    ok("کلید اشتباه مسدود", c == 403, f"HTTP {c}")
    c, _, _ = guest.get("/my")
    ok("پنل مغازه‌دار بدون ورود → /login", c == 303, f"HTTP {c}")
    c, _, _ = guest.get("/nonexistent-page")
    ok("صفحهٔ ناموجود → 404", c == 404, f"HTTP {c}")
    c, _, _ = guest.post("/panel/business/1/status", {"status": "published"})
    ok("تغییر وضعیت بدون کلید مسدود", c == 403, f"HTTP {c}")

    # ---------------------------------------------------------------- admin
    section("۴) مدیر: ساخت دسته و کسب‌وکار")
    c, _, _ = admin.post("/panel/category/new", {
        "key": tok, "name": "خدمات دامپزشکی", "icon": "medical",
        "blurb": "کلینیک و پت‌شاپ"})
    ok("ساخت دسته", c == 303, f"HTTP {c}")
    ok("دسته در پایگاه داده", any(x["slug"] for x in db.categories()
                                  if x["name"] == "خدمات دامپزشکی"))

    c, _, _ = admin.post("/panel/business/new", {
        "key": tok, "name": "کبابی شهرزاد", "cat_slug": "restaurant",
        "descr": "کباب سنتی با گوشت تازهٔ گوسفندی و برنج ایرانی.",
        "phone": "03142641234", "address": "خیابان امام، نبش کوچهٔ ۱۲",
        "lat": "32.6340", "lng": "51.3670", "status": "published",
        "featured": "on", "verified": "on", "booking_on": "on",
        "tags": "کباب،بیرون‌بر",
        "h_sat_open": "11:00", "h_sat_close": "23:00",
        "h_sun_open": "11:00", "h_sun_close": "23:00",
        "h_mon_open": "11:00", "h_mon_close": "23:00",
        "h_tue_open": "11:00", "h_tue_close": "23:00",
        "h_wed_open": "11:00", "h_wed_close": "23:00",
        "h_thu_open": "11:00", "h_thu_close": "23:00",
        "h_fri_open": "11:00", "h_fri_close": "23:00"})
    ok("ساخت کسب‌وکار", c == 303, f"HTTP {c}")
    # Find OUR record by name instead of assuming an empty site — the suite
    # used to take businesses()[0], which silently attached every later
    # assertion to whatever unrelated shop happened to be first.
    biz = [b for b in db.businesses(status=None) if b["name"] == "کبابی شهرزاد"]
    ok("کسب‌وکار ذخیره شد", len(biz) == 1, f"{len(biz)} مورد با این نام")
    bid = biz[0]["id"]
    slug = biz[0]["slug"]
    ok("اسلاگ لاتین تولید شد", re.fullmatch(r"[a-z0-9\-]+", slug or ""), slug)
    ok("ساعت کاری JSON ذخیره شد", len(biz[0]["hours_map"]) == 7,
       str(len(biz[0]["hours_map"])))
    c, _, _ = guest.get(f"/b/{slug}")
    ok("صفحهٔ کسب‌وکار باز می‌شود", c == 200, f"HTTP {c}")

    # ---------------------------------------------------------------- owner
    section("۵) مغازه‌دار: ورود با پیامک")
    shop = Client()
    PHONE = "09121234567"
    c, body, _ = shop.post("/login", {"phone": PHONE})
    ok("درخواست کد", c == 200, f"HTTP {c}")
    otp = code_for(PHONE)
    ok("کد تولید شد", len(otp) == 5, otp)
    ok("کد روی صفحه نمایش داده شد (بدون کلید پیامک)", otp in body)

    c, body, _ = shop.post("/login/verify", {"phone": PHONE, "code": "00000"})
    ok("کد اشتباه رد می‌شود", "درست نیست" in body or c == 200)

    otp = code_for(PHONE)
    c, _, _ = shop.post("/login/verify", {"phone": PHONE, "code": otp})
    ok("ورود با کد درست", c == 303, f"HTTP {c}")
    c, _, _ = shop.get("/my")
    ok("دسترسی به /my", c == 200, f"HTTP {c}")
    ok("حساب ساخته شد", len(db.owners()) == 1)

    section("۶) مغازه‌دار: مسیرهای پنل")
    for p in ["/my", "/my/businesses", "/my/reviews", "/my/bookings",
              "/my/inquiries", "/my/claim"]:
        c, _, _ = shop.get(p)
        ok(f"GET {p}", c == 200, f"HTTP {c}")

    # ---------------------------------------- the bug you reported
    section("۷) چرخهٔ ثبت — باگی که گزارش دادید")
    c, _, _ = shop.post("/submit", {
        "name": "سوپرمارکت ولیعصر", "cat_slug": "supermarket",
        "descr": "سوپرمارکت محله با لبنیات تازه و ارسال رایگان در محدوده.",
        "phone": PHONE, "address": "بلوار طالقانی، پلاک ۴۵"})
    ok("ثبت توسط مغازه‌دار واردشده", c == 303, f"HTTP {c}")
    mine = db.businesses_of(db.owner_by_phone(PHONE)["id"])
    ok("★ owner_id ذخیره شد", len(mine) == 1, f"{len(mine)} مورد")
    sup = mine[0] if mine else None
    if sup:
        ok("★ وضعیت در انتظار تأیید", sup["status"] == "pending", sup["status"])
        c, body, _ = shop.get("/my/businesses")
        ok("★ در پنل خودش دیده می‌شود", "سوپرمارکت ولیعصر" in body)
        c, body, _ = shop.get("/my")
        ok("★ پیام «دوباره ثبت نکنید»", "دوباره ثبت کنید" in body)

        # admin approves
        c, _, _ = admin.post(f"/panel/business/{sup['id']}/status",
                             {"key": tok, "status": "published"})
        ok("تأیید توسط مدیر", c == 303, f"HTTP {c}")
        fresh = db.business(bid=sup["id"])
        ok("★ پس از تأیید هنوز مال خودش", fresh["owner_id"] == mine[0]["owner_id"])
        ok("★ روی سایت عمومی", "سوپرمارکت ولیعصر" in guest.get("/businesses")[1])

        # owner edits
        c, _, _ = shop.post(f"/my/business/{sup['id']}", {
            "name": "سوپرمارکت ولیعصر", "cat_slug": "supermarket",
            "descr": "توضیح تازه‌ای که خود مغازه‌دار نوشته است.",
            "phone": PHONE, "address": "نشانی به‌روزشده"})
        ok("ویرایش توسط مغازه‌دار", c == 303, f"HTTP {c}")
        ok("★★ ویرایش ذخیره شد",
           "توضیح تازه" in db.business(bid=sup["id"])["descr"])

    section("۸) مهمان ثبت می‌کند، بعد وارد می‌شود")
    GPHONE = "09139998877"
    c, _, _ = guest.post("/submit", {
        "name": "نانوایی بربری سحر", "cat_slug": "bakery",
        "descr": "نان بربری تازه از ساعت پنج صبح هر روز.",
        "phone": GPHONE, "address": "خیابان شریعتی، جنب مسجد"})
    ok("ثبت مهمان", c == 303, f"HTTP {c}")
    # match on the exact name, not a fragment — demo data may contain another
    # shop whose name also happens to include this word
    orphan = [b for b in db.businesses(status=None)
              if b["name"] == "نانوایی بربری سحر"]
    ok("بدون مالک ثبت شد", orphan and not orphan[0]["owner_id"],
       f"{len(orphan)} مورد")

    g2 = Client()
    g2.post("/login", {"phone": GPHONE})
    g2.post("/login/verify", {"phone": GPHONE, "code": code_for(GPHONE)})
    linked = db.business(bid=orphan[0]["id"])
    ok("★ هنگام ورود خودکار متصل شد", bool(linked["owner_id"]))
    ok("★ در پنلش دیده می‌شود", "نانوایی بربری سحر" in g2.get("/my/businesses")[1])

    section("۹) تشخیص ثبت تکراری")
    _, body, _ = guest.post("/api/check-duplicate", {"phone": PHONE})
    dups = json.loads(body)["duplicates"]
    ok("شمارهٔ تکراری تشخیص داده شد", any(d["strength"] == "exact" for d in dups))
    _, body, _ = guest.post("/api/check-duplicate", {"name": "سوپرمارکت ولیعصر"})
    ok("نام یکسان تشخیص داده شد",
       any(d["field"] == "name" and d["strength"] == "exact"
           for d in json.loads(body)["duplicates"]))
    _, body, _ = guest.post("/api/check-duplicate", {"name": "سوپرمارکت ولیعصر شعبه دو"})
    ok("نام شبیه تشخیص داده شد",
       any(d["strength"] == "maybe" for d in json.loads(body)["duplicates"]))
    _, body, _ = guest.post("/api/check-duplicate",
                            {"name": "آهنگری اصفهان", "phone": "09350001122"})
    ok("کسب‌وکار جدید هشدار نمی‌دهد", not json.loads(body)["duplicates"])

    before = len(db.businesses(status=None))
    c, body, _ = guest.post("/submit", {
        "name": "فروشگاه کاملاً دیگر", "cat_slug": "supermarket",
        "descr": "توضیحی به اندازهٔ کافی بلند برای عبور از اعتبارسنجی فرم.",
        "phone": PHONE, "address": "نشانی متفاوت"})
    ok("ثبت تکراری مسدود شد", "قبلاً ثبت شده" in body and
       len(db.businesses(status=None)) == before)
    c, _, _ = guest.post("/submit", {
        "name": "فروشگاه کاملاً دیگر", "cat_slug": "supermarket",
        "descr": "توضیحی به اندازهٔ کافی بلند برای عبور از اعتبارسنجی فرم.",
        "phone": PHONE, "address": "نشانی متفاوت", "confirm_dup": "1"})
    ok("با تأیید صریح ثبت می‌شود", len(db.businesses(status=None)) == before + 1)

    section("۱۰) کاتالوگ: محصول، خدمت، کار سفارشی")
    for kind, title, ptype, price in [
            ("product", "چلوکباب کوبیده", "fixed", "250000"),
            ("service", "پذیرایی مراسم", "from", "180000"),
            ("custom", "منوی سفارشی مجلس", "call", "0")]:
        c, _, _ = admin.post(f"/panel/catalog/{bid}/item/new", {
            "key": tok, "kind": kind, "title": title, "price_type": ptype,
            "price": price, "old_price": "300000" if kind == "product" else "",
            "unit": "هر پرس", "stock": "12" if kind == "product" else "",
            "options": "کوچک، بزرگ", "note": "۲۴ ساعت قبل سفارش دهید",
            "available": "on", "descr": f"توضیح {title}"})
        ok(f"افزودن {kind}", c == 303, f"HTTP {c}")
    items = db.items(biz_id=bid)
    ok("سه مورد ثبت شد", len(items) == 3, str(len(items)))
    prod = [i for i in items if i["kind"] == "product"]
    ok("تخفیف محاسبه شد", prod and prod[0]["has_discount"] and
       prod[0]["discount_pct"] == 17, str(prod[0]["discount_pct"]) if prod else "")
    cust = [i for i in items if i["kind"] == "custom"]
    ok("کار سفارشی = قیمت با تماس",
       cust and cust[0]["price_text"] == "قیمت با تماس")
    body = guest.get("/catalog")[1]
    ok("کاتالوگ عمومی نمایش می‌دهد", "چلوکباب کوبیده" in body)
    ok("دکمهٔ ارتباط با مغازه‌دار", "ارتباط با مغازه‌دار" in body)

    section("۱۱) ارتباط با مغازه‌دار (بدون شمارهٔ تلفن)")
    iid = cust[0]["id"] if cust else ""
    c, _, _ = guest.post(f"/b/{slug}/ask", {
        "name": "مریم احمدی", "item_id": iid,
        "body": "برای مراسم ۱۵۰ نفره در شهریور نیاز به منوی کامل دارم.",
        "budget": "۱۰ میلیون"})
    ok("ثبت درخواست", c == 303, f"HTTP {c}")
    # scope every count to THIS business; the site may legitimately hold
    # other records, and a test that only passes on an empty database is
    # not testing the product people will actually run
    mine_q = db.inquiries(biz_id=bid)
    ok("در پایگاه داده", len(mine_q) == 1, str(len(mine_q)))
    ok("مدیر می‌بیند", "مریم احمدی" in admin.get(f"/panel/inquiries?key={tok}")[1])
    qid = mine_q[0]["id"]
    c, _, _ = admin.post(f"/panel/inquiry/{qid}", {
        "key": tok, "action": "quote", "quote": "۹٬۵۰۰٬۰۰۰ تومان"})
    ok("ثبت قیمت",
       [x for x in db.inquiries(biz_id=bid) if x["id"] == qid][0]["status"] == "quoted")

    section("۱۲) نظر، نوبت، تخفیف، خبر")
    c, _, _ = guest.post(f"/b/{slug}/review", {
        "author": "علی رضایی", "rating": "5",
        "body": "برخورد عالی و کیفیت غذا بی‌نظیر بود."})
    ok("ثبت نظر", c == 303, f"HTTP {c}")
    ok("نظر در انتظار تأیید", db.reviews(biz_id=bid, status="pending"))
    rid = db.reviews(biz_id=bid)[0]["id"]
    admin.post(f"/panel/review/{rid}", {"key": tok, "action": "approve"})
    ok("تأیید نظر", db.reviews(biz_id=bid, status="approved"))
    ok("نظر روی صفحه", "علی رضایی" in guest.get(f"/b/{slug}")[1])

    c, _, _ = guest.post(f"/b/{slug}/book", {
        "name": "حسن مرادی", "phone": "09134445566",
        "date": "2026-09-01", "time": "20:00", "note": "میز ۴ نفره"})
    mine_bk = [k for k in db.bookings() if k["biz_id"] == bid]
    ok("رزرو نوبت", c == 303 and len(mine_bk) == 1, f"HTTP {c}, {len(mine_bk)} نوبت")

    admin.post("/panel/coupon/new", {
        "key": tok, "code": "BAZAR20", "title": "۲۰٪ تخفیف افتتاحیه",
        "percent": "20"})
    ok("ساخت کد تخفیف", any(x["code"] == "BAZAR20" for x in db.coupons()))
    ok("در صفحهٔ تخفیف‌ها", "BAZAR20" in guest.get("/offers")[1])

    admin.post("/panel/post/new", {
        "key": tok, "title": "افتتاح بازارچه", "excerpt": "خبر افتتاح",
        "body": "متن کامل خبر افتتاح بازارچهٔ نجف‌آباد."})
    ok("انتشار خبر", any(x["title"] == "افتتاح بازارچه" for x in db.posts()))
    ok("در وبلاگ", "افتتاح بازارچه" in guest.get("/blog")[1])

    section("۱۳) تصاحب کسب‌وکار")
    orphan2 = [b for b in db.businesses(status=None)
               if not b["owner_id"] and b["id"] != bid]
    if not orphan2:
        db.set_business_owner(bid, None)
        orphan2 = [db.business(bid=bid)]
    target = orphan2[0]
    c, _, _ = shop.post("/my/claim", {"biz_id": target["id"]})
    ok("ثبت درخواست تصاحب", c == 303, f"HTTP {c}")
    cl = db.claims(status="pending")
    ok("در انتظار بررسی مدیر", bool(cl))
    ok("مدیر می‌بیند", PHONE in admin.get(f"/panel/claims?key={tok}")[1])
    if cl:
        admin.post(f"/panel/claim/{cl[0]['id']}", {"key": tok, "action": "approve"})
        ok("★ واگذاری پس از تأیید",
           db.business(bid=target["id"])["owner_id"] is not None)

    section("۱۴) امنیت: دسترسی متقاطع مغازه‌داران")
    other = Client()
    OP = "09355554444"
    other.post("/login", {"phone": OP})
    other.post("/login/verify", {"phone": OP, "code": code_for(OP)})
    victim = db.businesses_of(db.owner_by_phone(PHONE)["id"])
    if victim:
        vid = victim[0]["id"]
        c, _, _ = other.get(f"/my/business/{vid}")
        ok("ویرایش کسب‌وکار دیگری مسدود", c == 403, f"HTTP {c}")
        c, _, _ = other.get(f"/my/catalog/{vid}")
        ok("کاتالوگ دیگری مسدود", c == 403, f"HTTP {c}")
        c, _, _ = other.get(f"/my/stats/{vid}")
        ok("آمار دیگری مسدود", c == 403, f"HTTP {c}")
        c, _, _ = other.post(f"/my/business/{vid}", {"name": "هک‌شده"})
        ok("POST ویرایش دیگری مسدود", c == 403, f"HTTP {c}")
        ok("داده دست‌نخورده", db.business(bid=vid)["name"] != "هک‌شده")

    section("۱۵) آمار و رهگیری")
    for kind in ["view", "phone", "whatsapp", "route"]:
        guest.post(f"/t/{slug}/{kind}", {})
    st = db.stats_for(bid)
    ok("رهگیری بازدید", st["view"] >= 1, str(st["view"]))
    ok("رهگیری تماس", st["phone"] >= 1, str(st["phone"]))
    ok("رهگیری مسیریابی", st["route"] >= 1, str(st["route"]))

    section("۱۶) تنظیمات و ظاهر")
    c, _, _ = admin.post("/panel/settings", {
        "key": tok, "site_name": "بازارچه نجف‌آباد", "tagline": "شعار تست",
        "description": "توضیح", "phone": "۰۳۱", "phone_raw": "031",
        "email": "a@b.ir", "address": "نشانی", "instagram": "", "telegram": "",
        "whatsapp": "", "map_provider": "auto", "gmaps_key": "",
        "map_lat": "32.6340", "map_lng": "51.3670", "map_zoom": "14"})
    ok("ذخیرهٔ تنظیمات", c == 303 and db.get_settings()["tagline"] == "شعار تست")
    ok("روی سایت اعمال شد", "شعار تست" in guest.get("/")[1])

    c, _, _ = admin.post("/panel/appearance", {
        "key": tok, "color_primary": "#7c3aed", "color_accent": "#db2777",
        "color_background": "#f4f8f7", "color_foreground": "#0b1f1a",
        "hero_title": "عنوان تست", "hero_lead": "متن", "hero_cta": "دکمه",
        "footer_note": "پاورقی"})
    ok("تغییر رنگ", "#7c3aed" in guest.get("/")[1])
    admin.post("/panel/appearance", {"key": tok, "reset": "1"})
    ok("بازگشت به پیش‌فرض", "#34d399" in guest.get("/")[1])

    section("۱۷) پشتیبان‌گیری")
    c, body, _ = admin.get(f"/panel/backup/export?key={tok}")
    ok("خروجی JSON", c == 200)
    try:
        data = json.loads(body)
        ok("ساختار معتبر", "businesses" in data and "settings" in data)
        ok("شامل کاتالوگ", "items" in data)
    except Exception as e:
        ok("ساختار معتبر", False, str(e))

    section("۱۸-الف) درخت دسته‌بندی دو سطحی")
    tree = db.category_tree(only_active=False)
    kids_total = sum(len(t["children"]) for t in tree)
    ok("دسته‌های مادر وجود دارند", len(tree) >= 20, f"{len(tree)} مادر")
    ok("زیردسته‌ها وجود دارند", kids_total >= 100, f"{kids_total} زیردسته")
    ok("هر زیردسته والد معتبر دارد",
       all(db.category(k["parent"]) for t in tree for k in t["children"]))
    ok("هیچ دسته‌ای والدِ خودش نیست",
       all(c["slug"] != (c.get("parent") or "") for c in db.categories(only_active=False)))
    ok("عمق درخت حداکثر دو سطح است",
       all(not (db.category(k["parent"]) or {}).get("parent")
           for t in tree for k in t["children"]))
    fam = db.category_family("health")
    ok("خانوادهٔ دسته شامل خودش و فرزندان است",
       "health" in fam and "dentist" in fam, str(len(fam)))
    ok("مسیر زیردسته دو حلقه دارد", len(db.category_path("dentist")) == 2)
    ok("مسیر دستهٔ مادر یک حلقه دارد", len(db.category_path("health")) == 1)
    c, body, _ = guest.get("/businesses?cat=health")
    ok("فیلتر دستهٔ مادر باز می‌شود", c == 200, f"HTTP {c}")
    ok("نوار زیردسته نمایش داده می‌شود", "chip sub" in body)
    c, body, _ = guest.get("/submit")
    ok("فرم ثبت دسته‌ها را گروه‌بندی می‌کند", "<optgroup" in body)

    section("۱۸) یکپارچگی داده")
    for b in db.businesses(status=None):
        ok(f"اسلاگ «{b['name'][:18]}» لاتین",
           bool(re.fullmatch(r"[a-z0-9\-]+", b["slug"] or "")), b["slug"])
    cats = db.categories()
    ok("همهٔ دسته‌ها آیکون دارند", all(c["icon"] for c in cats))
    # icons now live in ONE sprite sheet; verify the grid covers every name
    from icon_grid import ICON_GRID
    missing = [c["slug"] for c in cats if c["icon"] not in ICON_GRID]
    ok("فایل آیکون همهٔ دسته‌ها موجود", not missing, ",".join(missing))

    # ---------------------------------------------------------------- report
    section("نتیجه")
    print(f"\n  موفق : {len(PASS)}")
    print(f"  ناموفق: {len(FAIL)}")
    print(f"  هشدار : {len(WARN)}")
    if FAIL:
        print("\n  موارد ناموفق:")
        for n, d in FAIL:
            print(f"    ✗ {n}" + (f"  [{d}]" if d else ""))
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
