/* ==========================================================================
   Reusable multi-image field.  (v16)
   Pick from gallery OR camera, downscale on the device, drag to reorder,
   submit as JSON payload + binary blobs.

   Robust decode: createImageBitmap is tried first because it handles formats
   (HEIC on capable browsers, some odd WEBPs) that <img> refuses. If even that
   fails, the original file is sent unchanged so the server's magic-byte check
   is the judge — a real JPEG/PNG/WEBP/GIF still gets through instead of the
   field silently rejecting it as "تصویر معتبر نیست".

   Markup contract:
     <div data-imagefield data-name="images" data-max="8"
          data-existing='["/assets/img/uploads/a.jpg"]'>
   ========================================================================== */

const MAX_EDGE = 1600;
const QUALITY  = 0.82;

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = (n) => String(n).replace(/\d/g, d => FA[+d]);
const kb = (b) => b > 1048576 ? (b / 1048576).toFixed(1) + 'MB' : Math.round(b / 1024) + 'KB';
const looksImage = (f) => (f.type && f.type.startsWith('image/')) ||
                          /\.(jpe?g|png|webp|gif|heic|heif)$/i.test(f.name || '');

const ICON = {
  trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/></svg>',
  star:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3Z"/></svg>',
  up:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20V8"/><path d="m7.5 12 4.5-4.5L16.5 12"/><path d="M4 4h16"/></svg>',
  cam:   '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h3l1.5-2h7L17 7h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1Z"/><circle cx="12" cy="13" r="3.5"/></svg>',
  gallery: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>',
};

function loadImage(file) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); res(img); };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('bad')); };
    img.src = url;
  });
}

/* Decode as robustly as possible. createImageBitmap handles formats <img>
   refuses, so try it first, then fall back to <img>. */
async function decodeDrawable(file) {
  if ('createImageBitmap' in window) {
    try {
      const bmp = await createImageBitmap(file);
      return { w: bmp.width, h: bmp.height,
               draw: (ctx, w, h) => ctx.drawImage(bmp, 0, 0, w, h),
               close: () => { try { bmp.close(); } catch (e) {} } };
    } catch (e) { /* fall through */ }
  }
  try {
    const img = await loadImage(file);
    return { w: img.naturalWidth, h: img.naturalHeight,
             draw: (ctx, w, h) => ctx.drawImage(img, 0, 0, w, h), close: () => {} };
  } catch (e) { return null; }
}

async function shrink(file) {
  if (!looksImage(file)) return null;
  const d = await decodeDrawable(file);
  if (!d) return null;                 // undecodable -> caller sends the raw file
  let w = d.w, h = d.h;
  const scale = Math.min(1, MAX_EDGE / Math.max(w, h));
  w = Math.round(w * scale); h = Math.round(h * scale);
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
  d.draw(ctx, w, h);
  d.close();
  const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', QUALITY));
  if (!blob) return null;
  return { blob, before: file.size, after: blob.size,
           url: c.toDataURL('image/jpeg', 0.55) };
}

/* ==========================================================================
   IMAGE EDITOR (before upload): rotate, brightness, contrast, aspect crop.
   Opens a modal the moment a photo is picked, applies non-destructive edits,
   and returns the edited JPEG blob. Cancel -> null (caller uses original).
   ========================================================================== */
async function editImage(file) {
  let img;
  try { img = await loadImage(file); } catch (e) { return null; }  // undecodable -> skip editor
  return new Promise((resolve) => {
    const st = { rot: 0, bright: 0, contr: 0, crop: '' };
    const ov = document.createElement('div');
    ov.className = 'imgedit-overlay';
    ov.innerHTML = `
      <div class="imgedit-modal" role="dialog" aria-modal="true" aria-label="ویرایش تصویر">
        <h3 class="imgedit-title">${ICON.cam} ویرایش تصویر</h3>
        <div class="imgedit-stage"><canvas></canvas></div>
        <div class="imgedit-controls">
          <div class="imgedit-row"><span class="imgedit-lbl">چرخش</span>
            <button type="button" class="imgedit-btn" data-rot>↻ ۹۰°</button></div>
          <div class="imgedit-row"><span class="imgedit-lbl">روشنایی</span>
            <input type="range" data-bright min="-50" max="50" value="0"></div>
          <div class="imgedit-row"><span class="imgedit-lbl">کنتراست</span>
            <input type="range" data-contr min="-50" max="50" value="0"></div>
          <div class="imgedit-row"><span class="imgedit-lbl">برش</span>
            <div class="imgedit-crops">
              <button type="button" class="imgedit-btn is-on" data-crop="">کل</button>
              <button type="button" class="imgedit-btn" data-crop="1">۱:۱</button>
              <button type="button" class="imgedit-btn" data-crop="1.333">۴:۳</button>
              <button type="button" class="imgedit-btn" data-crop="1.778">۱۶:۹</button>
            </div></div>
        </div>
        <div class="imgedit-actions">
          <button type="button" class="imgedit-cancel" data-cancel>انصراف</button>
          <button type="button" class="btn btn-primary" data-apply>اعمال و ادامه</button>
        </div>
      </div>`;
    document.body.appendChild(ov);
    document.body.style.overflow = 'hidden';
    const canvas = $('canvas', ov), ctx = canvas.getContext('2d');

    function render() {
      const w = img.naturalWidth, h = img.naturalHeight;
      const r = ((st.rot % 360) + 360) % 360;
      const ow = r % 180 ? h : w, oh = r % 180 ? w : h;
      const off = document.createElement('canvas'); off.width = ow; off.height = oh;
      const octx = off.getContext('2d');
      octx.fillStyle = '#fff'; octx.fillRect(0, 0, ow, oh);
      octx.filter = `brightness(${100 + st.bright}%) contrast(${100 + st.contr}%)`;
      octx.translate(ow / 2, oh / 2); octx.rotate(r * Math.PI / 180);
      octx.drawImage(img, -w / 2, -h / 2);
      let cw = ow, ch = oh; const a = parseFloat(st.crop);
      if (a) { if (ow / oh > a) cw = oh * a; else ch = ow / a; }
      const cx = (ow - cw) / 2, cy = (oh - ch) / 2;
      canvas.width = cw; canvas.height = ch;
      ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cw, ch);
      ctx.drawImage(off, cx, cy, cw, ch, 0, 0, cw, ch);
    }
    render();

    $('[data-rot]', ov).addEventListener('click', () => { st.rot += 90; render(); });
    $('[data-bright]', ov).addEventListener('input', e => { st.bright = +e.target.value; render(); });
    $('[data-contr]', ov).addEventListener('input', e => { st.contr = +e.target.value; render(); });
    $$('[data-crop]', ov).forEach(b => b.addEventListener('click', () => {
      $$('[data-crop]', ov).forEach(x => x.classList.remove('is-on'));
      b.classList.add('is-on'); st.crop = b.dataset.crop; render();
    }));
    const close = (blob) => { ov.remove(); document.body.style.overflow = ''; resolve(blob); };
    $('[data-cancel]', ov).addEventListener('click', () => close(null));
    $('[data-apply]', ov).addEventListener('click', () =>
      canvas.toBlob(blob => close(blob), 'image/jpeg', QUALITY));
  });
}

function initField(root) {
  const name = root.dataset.name || 'images';
  const max = parseInt(root.dataset.max || '8', 10);
  const single = max === 1;

  let existing = [];
  try { existing = JSON.parse(root.dataset.existing || '[]'); } catch (e) {}

  let list = existing.map(src => ({ kind: 'kept', src, url: src }));
  let dragIndex = null;

  root.innerHTML = `
    <div class="imgf">
      <div class="imgf-pick">
        <label class="imgf-drop" data-drop>
          <input type="file" accept="image/*" ${single ? '' : 'multiple'} hidden data-input>
          <span class="imgf-drop-icon">${ICON.gallery}</span>
          <strong data-drop-label></strong>
          <small class="text-muted">از گالری</small>
        </label>
        <label class="imgf-drop imgf-cam" data-cam>
          <input type="file" accept="image/*" capture="environment" hidden data-cam-input>
          <span class="imgf-drop-icon">${ICON.cam}</span>
          <strong>دوربین</strong>
          <small class="text-muted">عکس مستقیم</small>
        </label>
      </div>
      <div class="imgf-grid" data-grid></div>
      <p class="imgf-hint">
        <span data-count></span>
        <span class="text-muted">تصاویر روی گوشی شما فشرده می‌شوند تا سریع بارگذاری شوند.</span>
      </p>
    </div>`;

  const input = $('[data-input]', root);
  const camInput = $('[data-cam-input]', root);
  const drop = $('[data-drop]', root);
  const grid = $('[data-grid]', root);
  const count = $('[data-count]', root);
  const dropLabel = $('[data-drop-label]', root);

  function syncPayload() {
    let hidden = $(`input[type=hidden][data-payload]`, root);
    if (!hidden) {
      hidden = document.createElement('input');
      hidden.type = 'hidden';
      hidden.name = name + '_keep';
      hidden.dataset.payload = '1';
      root.appendChild(hidden);
    }
    hidden.value = JSON.stringify(
      list.map(x => x.kind === 'kept' ? x.src : '@new'));
  }

  function render() {
    grid.innerHTML = list.map((x, i) => `
      <figure class="imgf-item${i === 0 ? ' is-cover' : ''}" draggable="true" data-i="${i}">
        <img src="${x.url}" alt="تصویر ${fa(i + 1)}">
        ${i === 0 ? '<span class="imgf-cover-tag">تصویر اصلی</span>' : ''}
        <div class="imgf-tools">
          ${i > 0 ? `<button type="button" class="imgf-btn" data-cover="${i}"
                       title="تصویر اصلی" aria-label="انتخاب تصویر ${fa(i + 1)} به‌عنوان اصلی">${ICON.star}</button>` : ''}
          <button type="button" class="imgf-btn imgf-del" data-del="${i}"
                  title="حذف" aria-label="حذف تصویر ${fa(i + 1)}">${ICON.trash}</button>
        </div>
        ${x.kind === 'new' ? `<figcaption>${kb(x.before)} ← <strong>${kb(x.after)}</strong></figcaption>` : ''}
      </figure>`).join('');

    const room = max - list.length;
    drop.style.display = room > 0 ? '' : 'none';
    const cam = $('[data-cam]', root);
    if (cam) cam.style.display = room > 0 ? '' : 'none';
    dropLabel.textContent = single
      ? 'انتخاب تصویر'
      : (list.length ? `افزودن (${fa(room)} جای خالی)` : 'انتخاب از گالری');
    count.textContent = list.length
      ? `${fa(list.length)} از ${fa(max)} تصویر`
      : `حداکثر ${fa(max)} تصویر`;
    if (!single && list.length > 1) {
      count.textContent += ' — برای تغییر ترتیب بکشید';
    }
    syncPayload();
  }

  async function accept(files) {
    const arr = Array.from(files || []);
    if (!arr.length) return;
    drop.classList.add('is-busy');
    for (const f of arr) {
      if (list.length >= max) {
        if (single) { list = []; } else {
          window.Bazarche?.toast(`حداکثر ${fa(max)} تصویر مجاز است.`, 'err');
          break;
        }
      }
      const src = (await editImage(f)) || f;   // editor returns null on cancel/undecodable
      const r = await shrink(src);
      if (r) {
        list.push({ kind: 'new', ...r });
      } else if (looksImage(f)) {
        // Canvas could not decode it (some HEIC builds) but it may still be a
        // real image the server can validate — send the original bytes through.
        list.push({ kind: 'new', blob: f, url: URL.createObjectURL(f),
                    before: f.size, after: f.size });
        window.Bazarche?.toast(`«${f.name}» بدون پردازش ارسال شد.`, 'ok');
      } else {
        window.Bazarche?.toast(`«${f.name}» تصویر معتبری نیست.`, 'err');
      }
    }
    drop.classList.remove('is-busy');
    render();
  }

  input.addEventListener('change', () => { accept(input.files); input.value = ''; });
  camInput?.addEventListener('change', () => { accept(camInput.files); camInput.value = ''; });

  ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => {
    e.preventDefault(); drop.classList.add('is-over');
  }));
  ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => {
    e.preventDefault(); drop.classList.remove('is-over');
  }));
  drop.addEventListener('drop', e => accept(e.dataTransfer?.files));

  grid.addEventListener('click', (e) => {
    const del = e.target.closest('[data-del]');
    const cov = e.target.closest('[data-cover]');
    if (del) { list.splice(+del.dataset.del, 1); render(); }
    else if (cov) {
      const i = +cov.dataset.cover;
      list.unshift(list.splice(i, 1)[0]);
      render();
    }
  });

  grid.addEventListener('dragstart', (e) => {
    const fig = e.target.closest('[data-i]');
    if (!fig) return;
    dragIndex = +fig.dataset.i;
    fig.classList.add('is-dragging');
  });
  grid.addEventListener('dragend', () => {
    dragIndex = null;
    $$('.imgf-item', grid).forEach(f => f.classList.remove('is-dragging', 'is-target'));
  });
  grid.addEventListener('dragover', (e) => {
    e.preventDefault();
    const fig = e.target.closest('[data-i]');
    $$('.imgf-item', grid).forEach(f => f.classList.remove('is-target'));
    if (fig && +fig.dataset.i !== dragIndex) fig.classList.add('is-target');
  });
  grid.addEventListener('drop', (e) => {
    e.preventDefault();
    const fig = e.target.closest('[data-i]');
    if (!fig || dragIndex === null) return;
    const to = +fig.dataset.i;
    list.splice(to, 0, list.splice(dragIndex, 1)[0]);
    dragIndex = null;
    render();
  });

  // hand the blobs to the form on submit
  const form = root.closest('form');
  if (form && !form.dataset.imagefieldBound) {
    form.dataset.imagefieldBound = '1';
    form.addEventListener('submit', (e) => {
      const fields = $$('[data-imagefield]', form);
      const hasNew = fields.some(f => (f._imgList || []).some(x => x.kind === 'new'));
      const changed = fields.some(f => f._imgDirty);
      if (!hasNew && !changed) return;      // nothing to upload -> plain post

      e.preventDefault();
      const fd = new FormData(form);
      fields.forEach(f => {
        const fname = f.dataset.name || 'images';
        fd.delete(fname);
        (f._imgList || []).forEach((x, i) => {
          if (x.kind === 'new') fd.append(fname, x.blob, `photo-${i}.jpg`);
        });
      });

      const btn = $('[type=submit]', form);
      const old = btn ? btn.innerHTML : '';
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner"></span><span>در حال ذخیره…</span>';
      }
      fetch(form.action, { method: 'POST', body: fd, redirect: 'follow' })
        .then(r => r.redirected ? (location.href = r.url)
                                : r.text().then(() => location.reload()))
        .catch(() => {
          if (btn) { btn.disabled = false; btn.innerHTML = old; }
          window.Bazarche?.toast('ذخیره ناموفق بود.', 'err');
        });
    });
  }

  Object.defineProperty(root, '_imgList', { get: () => list });
  Object.defineProperty(root, '_imgDirty', {
    get: () => JSON.stringify(list.map(x => x.kind === 'kept' ? x.src : '@new'))
               !== JSON.stringify(existing),
  });

  render();
}

function boot() { $$('[data-imagefield]').forEach(initField); }

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else { boot(); }
