# -*- coding: utf-8 -*-
"""
Admin screens for the v3 world-class features.

Every screen here is wired to a real table and a real POST route:
Q&A, reports, badges, plans, subscriptions, ads, city events,
edit approvals, saved alerts and whole-site insights.
"""

import json
import db
from ui import (icon, stars, fa, fa_group, esc, panel_page, stat_card, flash,
                empty_state)
from views_panel import _msg, ICON_CHOICES

UP_JS = '<script type="module" src="/assets/js/imagefield.js"></script>'


def _empty(ic, title, text):
    return (f'<div class="empty-state"><span class="icon-wrap">{icon(ic)}</span>'
            f'<h3>{esc(title)}</h3><p>{esc(text)}</p></div>')


def _biz_options(selected=None, blank="— بدون کسب‌وکار —"):
    out = f'<option value="">{esc(blank)}</option>'
    for b in db.businesses(status=None, order="name"):
        sel = " selected" if str(selected or "") == str(b["id"]) else ""
        out += f'<option value="{b["id"]}"{sel}>{esc(b["name"])}</option>'
    return out


def _hidden(token, extra=""):
    return f'<input type="hidden" name="key" value="{esc(token)}">{extra}'


# ==========================================================================
#  QUESTIONS & ANSWERS
# ==========================================================================
Q_BADGE = {"pending": "badge-warn", "published": "badge-open", "rejected": "badge-closed"}
Q_LABEL = {"pending": "در انتظار", "published": "منتشرشده", "rejected": "رد شده"}


def qa_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    rows = db.questions(status=status or None)

    cards = "".join(f'''<article class="review">
      <div class="review-head">
        <span class="avatar" aria-hidden="true">{esc((r['asker'] or '?')[:1])}</span>
        <div style="flex:1"><strong>{esc(r['asker'])}</strong>
          <div class="card-meta" style="margin-top:3px">
            <a href="/b/{esc(r['bizslug'])}" target="_blank" rel="noopener">{esc(r['bizname'])}</a>
            <span aria-hidden="true">·</span>
            <span class="text-xs nums">{fa(str(r['created'])[:16])}</span>
            <span aria-hidden="true">·</span>
            <span class="text-xs">{fa(r['helpful'])} نفر مفید دانستند</span></div></div>
        <span class="badge {Q_BADGE.get(r['status'],'badge-neutral')}">{esc(Q_LABEL.get(r['status'], r['status']))}</span>
      </div>
      <p class="review-body">{esc(r['body'])}</p>
      {f'<div class="review-reply"><strong>{icon("store")}پاسخ</strong>{esc(r["answer"])}</div>' if r['answer'] else ''}
      <form method="post" action="/panel/question/{r['id']}" class="mt-md">
        {_hidden(token)}
        <label class="sr-only" for="qa{r['id']}">پاسخ به پرسش</label>
        <textarea class="textarea" id="qa{r['id']}" name="answer" style="min-height:80px"
          placeholder="پاسخ شما به این پرسش…">{esc(r['answer'])}</textarea>
        <div class="cluster mt-sm">
          <button class="btn btn-primary btn-sm" type="submit" name="action" value="answer">
            {icon("send")}<span>ثبت پاسخ و انتشار</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="publish">
            {icon("check")}<span>انتشار بدون پاسخ</span></button>
          <button class="btn btn-glass btn-sm" type="submit" name="action" value="reject">
            {icon("x")}<span>رد</span></button>
          <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
            style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
        </div>
      </form></article>''' for r in rows)

    if not cards:
        cards = _empty("help", "پرسشی در این بخش نیست",
                       "وقتی بازدیدکنندگان از یک کسب‌وکار سؤال بپرسند، اینجا می‌آید.")

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/qa?key={esc(token)}&status={v}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار"),
                                ("published", "منتشرشده"), ("rejected", "رد شده")])
    content = f'''{_msg(q)}
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad">{cards}</div>'''
    return panel_page(s, "پرسش و پاسخ",
                      "سؤال‌های مشتریان دربارهٔ کسب‌وکارها را پاسخ دهید یا منتشر کنید.",
                      content, "/panel/qa", token)


# ==========================================================================
#  REPORTS
# ==========================================================================
R_BADGE = {"open": "badge-warn", "resolved": "badge-open", "dismissed": "badge-closed"}
R_LABEL = {"open": "باز", "resolved": "رسیدگی‌شده", "dismissed": "رد شده"}
KIND_LABEL = {"business": "کسب‌وکار", "review": "نظر", "item": "کالا/خدمت", "question": "پرسش"}


def report_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    rows = db.reports(status=status or None)

    trs = "".join(f'''<tr>
      <td><span class="badge badge-neutral">{esc(KIND_LABEL.get(r['kind'], r['kind']))}</span></td>
      <td><strong>{esc(db.reason_label(r['reason']))}</strong>
        {f'<br><small class="text-muted">{esc(r["body"][:110])}</small>' if r['body'] else ''}</td>
      <td>{f'<a href="/b/{esc(r["bizslug"])}" target="_blank" rel="noopener">{esc(r["bizname"])}</a>' if r.get('bizslug') else '<span class="text-muted">—</span>'}</td>
      <td class="nums">{esc(r['reporter']) or '<span class="text-muted">ناشناس</span>'}</td>
      <td class="num nums">{fa(str(r['created'])[:10])}</td>
      <td><span class="badge {R_BADGE.get(r['status'],'badge-neutral')}">{esc(R_LABEL.get(r['status'], r['status']))}</span></td>
      <td class="actions">
        <form method="post" action="/panel/report/{r['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="resolve">
          <button class="btn-icon btn-approve" type="submit" title="رسیدگی شد"
            aria-label="رسیدگی به گزارش {r['id']}">{icon("check-circle")}</button></form>
        <form method="post" action="/panel/report/{r['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="dismiss">
          <button class="btn-icon" type="submit" title="بی‌مورد است"
            aria-label="رد گزارش {r['id']}">{icon("x-circle")}</button></form>
        {f'<a class="btn-icon" href="/panel/business/{r["biz_id"]}?key={esc(token)}" title="ویرایش کسب‌وکار" aria-label="ویرایش">{icon("edit")}</a>' if r.get('biz_id') else ''}
        <form method="post" action="/panel/report/{r['id']}" style="display:inline"
              data-confirm="این گزارش حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف گزارش {r['id']}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for r in rows)

    if not trs:
        trs = ('<tr><td colspan="7" class="text-center text-muted" '
               'style="padding:var(--space-xl)">گزارشی ثبت نشده — یعنی اطلاعات سایت سالم است.</td></tr>')

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/reports?key={esc(token)}&status={v}">{t}</a>'
                   for v, t in [("", "همه"), ("open", "باز"),
                                ("resolved", "رسیدگی‌شده"), ("dismissed", "رد شده")])
    content = f'''{_msg(q)}
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>نوع</th><th>دلیل</th><th>کسب‌وکار</th><th>گزارش‌دهنده</th>
      <th>تاریخ</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div></div>'''
    return panel_page(s, "گزارش تخلف",
                      "گزارش کاربران دربارهٔ اطلاعات نادرست، تعطیلی یا محتوای نامناسب.",
                      content, "/panel/reports", token)


# ==========================================================================
#  BADGES
# ==========================================================================
def badge_list(s, token, q=None):
    q = q or {}
    rows = db.badges(only_active=False)
    icon_opts = "".join(f'<option value="{i}">{i}</option>' for i in ICON_CHOICES + ["award", "zap", "clock", "users", "shield", "star", "heart", "target", "trending"])

    trs = "".join(f'''<tr>
      <td><span class="badge" style="background:{esc(b['color'])}1a;color:{esc(b['color'])};border-color:{esc(b['color'])}44">
        {icon(b['icon'] if b['icon'] in ICON_CHOICES + ["award","zap","clock","users","shield","star","heart","target","trending"] else "award")}
        <span>{esc(b['name'])}</span></span></td>
      <td><small class="text-muted">{esc(b['descr'])[:70]}</small></td>
      <td class="num">{fa(b['count'])}</td>
      <td><span class="badge {"badge-open" if b['active'] else "badge-neutral"}">
        {"فعال" if b['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/badge/{b['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="toggle">
          <button class="btn-icon" type="submit" title="فعال/غیرفعال"
            aria-label="تغییر وضعیت {esc(b['name'])}">{icon("eye")}</button></form>
        <form method="post" action="/panel/badge/{b['id']}" style="display:inline"
              data-confirm="نشان «{esc(b['name'])}» و همهٔ اعطاهایش حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف {esc(b['name'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for b in rows)
    if not trs:
        trs = '<tr><td colspan="5" class="text-center text-muted">نشانی تعریف نشده</td></tr>'

    # grant/revoke panel
    bizs = db.businesses(status=None, order="name")
    bmap = db.badges_map()
    grant_rows = "".join(f'''<tr>
      <td><strong>{esc(b['name'])}</strong></td>
      <td><form method="post" action="/panel/badges/grant" class="cluster" style="gap:6px;flex-wrap:wrap">
        {_hidden(token)}<input type="hidden" name="biz_id" value="{b['id']}">
        {"".join(f"""<label class="check" style="margin:0"><input type="checkbox" name="badge_ids" value="{bg['id']}"
          {'checked' if bg['id'] in [x['id'] for x in bmap.get(b['id'], [])] else ''}><span>{esc(bg['name'])}</span></label>"""
          for bg in db.badges())}
        <button class="btn btn-primary btn-sm" type="submit">{icon("check")}<span>ذخیره</span></button>
      </form></td></tr>''' for b in bizs[:60])
    if not grant_rows:
        grant_rows = '<tr><td colspan="2" class="text-center text-muted">هنوز کسب‌وکاری ثبت نشده</td></tr>'

    content = f'''{_msg(q)}
<div class="grid grid-2 mb-lg" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("award")} نشان‌های تعریف‌شده</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>نشان</th><th>توضیح</th><th>تعداد</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{trs}</tbody></table></div>
    <form method="post" action="/panel/badges/auto" class="mt-lg">
      {_hidden(token)}
      <button class="btn btn-glass btn-sm" type="submit">{icon("refresh")}
        <span>محاسبهٔ خودکار نشان «برترین امتیاز»</span></button>
      <p class="field-hint mt-sm">کسب‌وکارهایی با امتیاز ۴٫۵ به بالا و دست‌کم ۱۰ نظر، نشان می‌گیرند؛ بقیه پس گرفته می‌شود.</p>
    </form>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} نشان جدید</h2>
    <form method="post" action="/panel/badge/new" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="bg-name">نام نشان<span class="req">*</span></label>
        <input class="input" id="bg-name" name="name" required placeholder="ارسال رایگان"></div>
      <div class="field"><label class="field-label" for="bg-desc">توضیح</label>
        <input class="input" id="bg-desc" name="descr" placeholder="برای خرید بالای ۵۰۰ هزار تومان"></div>
      <div class="field"><label class="field-label" for="bg-icon">آیکون</label>
        <select class="select" id="bg-icon" name="icon">{icon_opts}</select></div>
      <div class="field"><label class="field-label" for="bg-color">رنگ</label>
        <input class="input" id="bg-color" name="color" type="color" value="#059669"></div>
      <label class="check mb-lg"><input type="checkbox" name="active" checked><span>فعال باشد</span></label>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ایجاد نشان</span></button>
    </form>
  </div>
</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("store")} اعطای نشان به کسب‌وکارها</h2>
  <div class="table-wrap"><table class="table">
    <thead><tr><th style="width:220px">کسب‌وکار</th><th>نشان‌ها</th></tr></thead>
    <tbody>{grant_rows}</tbody></table></div>
</div>'''
    return panel_page(s, "نشان‌ها و اعتماد",
                      "نشان‌های سفارشی بسازید و به کسب‌وکارهای شایسته بدهید.",
                      content, "/panel/badges", token)


# ==========================================================================
#  PLANS & SUBSCRIPTIONS
# ==========================================================================
S_BADGE = {"pending": "badge-warn", "active": "badge-open",
           "expired": "badge-closed", "cancelled": "badge-neutral"}
S_LABEL = {"pending": "در انتظار پرداخت", "active": "فعال",
           "expired": "منقضی", "cancelled": "لغو شده"}


def plan_list(s, token, q=None):
    q = q or {}
    rows = db.plans(only_active=False)
    badge_opts = '<option value="">— بدون نشان —</option>' + "".join(
        f'<option value="{esc(b["slug"])}">{esc(b["name"])}</option>' for b in db.badges())

    cards = "".join(f'''<form class="card glass card-pad" method="post" action="/panel/plan/{p['id']}">
      {_hidden(token)}
      <div class="between mb-md"><h3 class="card-title">{icon("wallet")} {esc(p['name'])}</h3>
        <span class="badge {"badge-open" if p['active'] else "badge-neutral"}">
          {"فعال" if p['active'] else "غیرفعال"}</span></div>
      <div class="grid grid-2" style="gap:10px">
        <div class="field" style="margin:0"><label class="field-label" for="pn{p['id']}">نام</label>
          <input class="input" id="pn{p['id']}" name="name" value="{esc(p['name'])}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pt{p['id']}">شعار کوتاه</label>
          <input class="input" id="pt{p['id']}" name="tagline" value="{esc(p.get('tagline',''))}"
                 placeholder="مناسب کسب‌وکارهای فعال"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pp{p['id']}">قیمت (تومان)</label>
          <input class="input nums" id="pp{p['id']}" name="price" type="number" min="0" value="{p['price']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pm{p['id']}">مدت (ماه)</label>
          <input class="input nums" id="pm{p['id']}" name="months" type="number" min="1" value="{p['months']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pf{p['id']}">جایگاه ویژه</label>
          <input class="input nums" id="pf{p['id']}" name="featured_slots" type="number" min="0" value="{p['featured_slots']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="pi{p['id']}">حداکثر کالا</label>
          <input class="input nums" id="pi{p['id']}" name="max_items" type="number" min="1" value="{p['max_items']}"></div>
        <div class="field" style="margin:0"><label class="field-label" for="ph{p['id']}">حداکثر تصویر</label>
          <input class="input nums" id="ph{p['id']}" name="max_photos" type="number" min="1" value="{p['max_photos']}"></div>
      </div>
      <div class="field mt-md"><label class="field-label" for="pb{p['id']}">نشان همراه پلن</label>
        <select class="select" id="pb{p['id']}" name="badge_slug">{badge_opts.replace(f'value="{esc(p["badge_slug"])}"', f'value="{esc(p["badge_slug"])}" selected') if p['badge_slug'] else badge_opts}</select></div>
      <div class="field"><label class="field-label" for="pk{p['id']}">امکانات (هر خط یک مورد)</label>
        <textarea class="textarea" id="pk{p['id']}" name="perks" style="min-height:150px">{esc(p['perks'])}</textarea></div>
      <label class="check mb-md"><input type="checkbox" name="active" {"checked" if p['active'] else ""}><span>در صفحهٔ تعرفه نمایش داده شود</span></label>
      <div class="cluster">
        <button class="btn btn-primary btn-sm" type="submit" name="action" value="save">
          {icon("check")}<span>ذخیره</span></button>
        <button class="btn btn-ghost btn-sm" type="submit" name="action" value="delete"
          style="color:var(--color-destructive)"
          onclick="return confirm('پلن حذف شود؟')">{icon("trash")}<span>حذف</span></button>
      </div>
    </form>''' for p in rows)

    if not cards:
        cards = _empty("wallet", "پلنی تعریف نشده", "با فرم کناری اولین پلن را بسازید.")

    content = f'''{_msg(q)}
<div class="grid grid-2 mb-lg" style="grid-template-columns:minmax(0,1fr) minmax(0,320px);align-items:start">
  <div class="grid" style="gap:var(--space-lg)">{cards}</div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} پلن جدید</h2>
    <form method="post" action="/panel/plan/new" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="np-name">نام پلن<span class="req">*</span></label>
        <input class="input" id="np-name" name="name" required placeholder="طلایی"></div>
      <div class="field"><label class="field-label" for="np-tag">شعار کوتاه</label>
        <input class="input" id="np-tag" name="tagline" placeholder="مناسب کسب‌وکارهای بزرگ"></div>
      <div class="field"><label class="field-label" for="np-price">قیمت (تومان)</label>
        <input class="input nums" id="np-price" name="price" type="number" min="0" value="0"></div>
      <div class="field"><label class="field-label" for="np-months">مدت (ماه)</label>
        <input class="input nums" id="np-months" name="months" type="number" min="1" value="12"></div>
      <div class="field"><label class="field-label" for="np-perks">امکانات</label>
        <textarea class="textarea" id="np-perks" name="perks" style="min-height:90px"
          placeholder="هر خط یک مورد"></textarea></div>
      <label class="check mb-lg"><input type="checkbox" name="active" checked><span>فعال</span></label>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ایجاد پلن</span></button>
    </form>
    <hr class="divider">
    <h3 class="card-title mb-md">{icon("credit-card")} روش پرداخت</h3>
    <form method="post" action="/panel/plans/payment">
      {_hidden(token)}
      <div class="field"><label class="field-label" for="pay-m">روش</label>
        <select class="select" id="pay-m" name="pay_method">
          <option value="manual"{" selected" if s.get("pay_method")!="zarinpal" else ""}>کارت‌به‌کارت با تأیید مدیر</option>
          <option value="zarinpal"{" selected" if s.get("pay_method")=="zarinpal" else ""}>زرین‌پال (نیازمند کد پذیرنده)</option>
        </select></div>
      <div class="field"><label class="field-label" for="pay-c">شمارهٔ کارت</label>
        <input class="input nums" id="pay-c" name="pay_card" dir="ltr"
               value="{esc(s.get('pay_card',''))}" placeholder="6037-9900-0000-0000"></div>
      <div class="field"><label class="field-label" for="pay-n">نام صاحب کارت</label>
        <input class="input" id="pay-n" name="pay_card_name" value="{esc(s.get('pay_card_name',''))}"></div>
      <div class="field"><label class="field-label" for="pay-z">کد پذیرندهٔ زرین‌پال</label>
        <input class="input" id="pay-z" name="zarinpal_merchant" dir="ltr"
               value="{esc(s.get('zarinpal_merchant',''))}" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"></div>
      <button class="btn btn-glass btn-block" type="submit">{icon("check")}<span>ذخیرهٔ روش پرداخت</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "پلن‌ها و تعرفه",
                      "پلن‌های اشتراک واقعی؛ آنچه اینجا تعریف کنید در صفحهٔ تعرفه دیده می‌شود.",
                      content, "/panel/plans", token)


def sub_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    n_exp = db.expire_subscriptions()
    rows = db.subscriptions(status=status or None)
    soon = db.expiring_soon(14)

    trs = "".join(f'''<tr>
      <td><a href="/b/{esc(r['bizslug'])}" target="_blank" rel="noopener"><strong>{esc(r['bizname'])}</strong></a></td>
      <td>{esc(r.get('planname') or r['plan_slug'])}</td>
      <td class="num nums">{fa_group(r['amount'])}</td>
      <td class="num nums">{fa(r['starts']) if r['starts'] else '—'}</td>
      <td class="num nums">{fa(r['expires']) if r['expires'] else '—'}
        {f'<br><small class="text-muted">{fa(r["days_left"])} روز مانده</small>' if r.get('days_left') is not None and r['status']=='active' else ''}</td>
      <td class="nums">{esc(r['ref']) or '<span class="text-muted">—</span>'}</td>
      <td><span class="badge {S_BADGE.get(r['status'],'badge-neutral')}">{esc(S_LABEL.get(r['status'], r['status']))}</span></td>
      <td class="actions">
        {f"""<form method="post" action="/panel/subscription/{r["id"]}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="activate">
          <button class="btn-icon btn-approve" type="submit" title="تأیید پرداخت و فعال‌سازی"
            aria-label="فعال‌سازی اشتراک {esc(r["bizname"])}">{icon("check-circle")}</button></form>""" if r['status'] in ('pending','expired','cancelled') else ''}
        {f"""<form method="post" action="/panel/subscription/{r["id"]}" style="display:inline"
              data-confirm="اشتراک «{esc(r["bizname"])}» لغو شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="cancel">
          <button class="btn-icon" type="submit" title="لغو اشتراک"
            aria-label="لغو اشتراک {esc(r["bizname"])}">{icon("x-circle")}</button></form>""" if r['status']=='active' else ''}
        <form method="post" action="/panel/subscription/{r['id']}" style="display:inline"
              data-confirm="این ردیف حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف ردیف {r['id']}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for r in rows)
    if not trs:
        trs = ('<tr><td colspan="8" class="text-center text-muted" '
               'style="padding:var(--space-xl)">اشتراکی ثبت نشده</td></tr>')

    warn = ""
    if soon:
        items = "".join(f'<li>{esc(x["bizname"])} — {fa(x["days_left"])} روز تا انقضا</li>' for x in soon)
        warn = (f'<div class="alert alert-warn mb-lg">{icon("bell")}<span>'
                f'<strong>{fa(len(soon))} اشتراک نزدیک به انقضا:</strong><ul style="margin:6px 0 0;padding-inline-start:18px">{items}</ul>'
                f'</span></div>')
    if n_exp:
        warn = flash("info", f"{n_exp} اشتراک منقضی شد و امتیازهایش برداشته شد.") + warn

    revenue = sum(r["amount"] for r in db.subscriptions(status="active"))
    pending_n = len(db.subscriptions(status="pending"))
    live_n = len([r for r in db.subscriptions(status="active") if r["is_live"]])

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/subscriptions?key={esc(token)}&status={v}">{t}</a>'
                   for v, t in [("", "همه"), ("pending", "در انتظار پرداخت"),
                                ("active", "فعال"), ("expired", "منقضی"),
                                ("cancelled", "لغو شده")])

    bizopts = _biz_options(blank="— انتخاب کسب‌وکار —")
    planopts = "".join(f'<option value="{esc(p["slug"])}">{esc(p["name"])} — '
                       f'{fa_group(p["price"])} تومان</option>' for p in db.plans())

    content = f'''{_msg(q)}{warn}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("check-circle", live_n, "اشتراک فعال")}
  {stat_card("clock", pending_n, "در انتظار پرداخت", delay=60)}
  {stat_card("wallet", revenue, "درآمد فعال (تومان)", delay=120)}
  {stat_card("bell", len(soon), "نزدیک انقضا", delay=180)}
</div>
<div class="cluster mb-lg">{filt}</div>
<div class="card glass card-pad mb-lg">
  <div class="table-wrap"><table class="table">
    <thead><tr><th>کسب‌وکار</th><th>پلن</th><th>مبلغ</th><th>شروع</th><th>انقضا</th>
      <th>کد پیگیری</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("plus")} ثبت اشتراک دستی</h2>
  <form method="post" action="/panel/subscription/new" class="grid grid-3" style="align-items:end" data-validate>
    {_hidden(token)}
    <div class="field" style="margin:0"><label class="field-label" for="sb-biz">کسب‌وکار<span class="req">*</span></label>
      <select class="select" id="sb-biz" name="biz_id" required>{bizopts}</select></div>
    <div class="field" style="margin:0"><label class="field-label" for="sb-plan">پلن<span class="req">*</span></label>
      <select class="select" id="sb-plan" name="plan_slug" required>{planopts}</select></div>
    <div class="field" style="margin:0"><label class="field-label" for="sb-ref">کد پیگیری پرداخت</label>
      <input class="input nums" id="sb-ref" name="ref" placeholder="اختیاری"></div>
    <label class="check" style="margin:0"><input type="checkbox" name="activate" checked>
      <span>بلافاصله فعال شود</span></label>
    <button class="btn btn-primary" type="submit">{icon("plus")}<span>ثبت اشتراک</span></button>
  </form>
</div>'''
    return panel_page(s, "اشتراک‌ها",
                      "پرداخت‌ها را تأیید کنید؛ فعال‌سازی، انقضا و نشان‌ها خودکار اعمال می‌شود.",
                      content, "/panel/subscriptions", token)


# ==========================================================================
#  ADS
# ==========================================================================
SLOTS = [("home", "صفحهٔ نخست"), ("directory", "فهرست کسب‌وکارها"),
         ("business", "صفحهٔ کسب‌وکار"), ("sidebar", "ستون کناری")]


def ad_list(s, token, q=None):
    q = q or {}
    rows = db.ads()
    tot_v = sum(a["views"] for a in rows)
    tot_c = sum(a["clicks"] for a in rows)
    ctr = round(tot_c * 100.0 / tot_v, 1) if tot_v else 0

    trs = "".join(f'''<tr>
      <td><strong>{esc(a['title'])}</strong>
        {f'<br><small class="text-muted">{esc(a["body"])[:70]}</small>' if a['body'] else ''}</td>
      <td>{esc(dict(SLOTS).get(a['slot'], a['slot']))}</td>
      <td>{esc(a.get('bizname') or '—')}</td>
      <td class="num nums">{fa_group(a['views'])}</td>
      <td class="num nums">{fa_group(a['clicks'])}</td>
      <td class="num nums">{fa(a['ctr'])}٪</td>
      <td><span class="badge {"badge-open" if a['active'] else "badge-neutral"}">
        {"فعال" if a['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/ad/{a['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="toggle">
          <button class="btn-icon" type="submit" title="فعال/غیرفعال"
            aria-label="تغییر وضعیت {esc(a['title'])}">{icon("eye")}</button></form>
        <form method="post" action="/panel/ad/{a['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="reset">
          <button class="btn-icon" type="submit" title="صفر کردن آمار"
            aria-label="صفر کردن آمار {esc(a['title'])}">{icon("refresh")}</button></form>
        <form method="post" action="/panel/ad/{a['id']}" style="display:inline"
              data-confirm="بنر «{esc(a['title'])}» حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف {esc(a['title'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for a in rows)
    if not trs:
        trs = ('<tr><td colspan="8" class="text-center text-muted" '
               'style="padding:var(--space-xl)">بنری ساخته نشده</td></tr>')

    slot_opts = "".join(f'<option value="{v}">{t}</option>' for v, t in SLOTS)

    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("eye", tot_v, "نمایش کل")}
  {stat_card("target", tot_c, "کلیک کل", delay=60)}
  {stat_card("trending", ctr, "نرخ کلیک", suffix="٪", delay=120)}
  {stat_card("zap", len([a for a in rows if a['active']]), "بنر فعال", delay=180)}
</div>
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("zap")} بنرهای تبلیغاتی</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عنوان</th><th>جایگاه</th><th>کسب‌وکار</th><th>نمایش</th>
        <th>کلیک</th><th>نرخ</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>{trs}</tbody></table></div>
    <p class="field-hint mt-md">{icon("info")} شمارش نمایش و کلیک واقعی است؛ هر بار بنر رندر شود «نمایش» و هر بار کاربر روی آن بزند «کلیک» بالا می‌رود.</p>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} بنر جدید</h2>
    <form method="post" action="/panel/ad/new" enctype="multipart/form-data" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="ad-t">عنوان<span class="req">*</span></label>
        <input class="input" id="ad-t" name="title" required placeholder="افتتاحیهٔ شعبهٔ جدید"></div>
      <div class="field"><label class="field-label" for="ad-b">متن کوتاه</label>
        <textarea class="textarea" id="ad-b" name="body" style="min-height:70px"></textarea></div>
      <div class="field"><label class="field-label" for="ad-u">لینک مقصد</label>
        <input class="input" id="ad-u" name="url" dir="ltr" placeholder="/b/slug یا https://…"></div>
      <div class="field"><label class="field-label" for="ad-s">جایگاه</label>
        <select class="select" id="ad-s" name="slot">{slot_opts}</select></div>
      <div class="field"><label class="field-label" for="ad-z">کسب‌وکار مرتبط</label>
        <select class="select" id="ad-z" name="biz_id">{_biz_options()}</select></div>
      <div class="grid grid-2" style="gap:10px">
        <div class="field" style="margin:0"><label class="field-label" for="ad-st">شروع</label>
          <input class="input nums" id="ad-st" name="starts" type="date"></div>
        <div class="field" style="margin:0"><label class="field-label" for="ad-en">پایان</label>
          <input class="input nums" id="ad-en" name="ends" type="date"></div>
      </div>
      <div class="field"><label class="field-label" for="ad-w">وزن نمایش</label>
        <input class="input nums" id="ad-w" name="weight" type="number" min="1" max="10" value="1">
        <p class="field-hint">هرچه بیشتر، بیشتر نمایش داده می‌شود.</p></div>
      <div class="field"><label class="field-label" for="ad-img">تصویر بنر</label>
        <input class="input" id="ad-img" name="image" type="file" accept="image/*"></div>
      <label class="check mb-lg"><input type="checkbox" name="active" checked><span>فعال باشد</span></label>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ساخت بنر</span></button>
    </form>
  </div>
</div>'''
    return panel_page(s, "تبلیغات",
                      "بنرهای درآمدزا با شمارش واقعی نمایش و کلیک.",
                      content, "/panel/ads", token, extra_js=UP_JS)


# ==========================================================================
#  CITY EVENTS
# ==========================================================================
def event_list(s, token, q=None):
    q = q or {}
    rows = db.cityevents(status=None)
    trs = "".join(f'''<tr>
      <td><strong>{esc(e['title'])}</strong>
        {f'<br><small class="text-muted">{esc(e["descr"])[:70]}</small>' if e['descr'] else ''}</td>
      <td class="nums">{fa(e['date']) if e['date'] else '—'} {fa(e['time']) if e['time'] else ''}</td>
      <td>{esc(e['place'] or '—')}</td>
      <td>{esc(e.get('bizname') or '—')}</td>
      <td><span class="badge {"badge-closed" if e['past'] else ("badge-open" if e['status']=='published' else "badge-neutral")}">
        {"برگزار شده" if e['past'] else ("منتشرشده" if e['status']=='published' else "پیش‌نویس")}</span></td>
      <td class="actions">
        <a class="btn-icon" href="/events/{esc(e['slug'])}" target="_blank" rel="noopener"
           title="مشاهده" aria-label="مشاهدهٔ {esc(e['title'])}">{icon("external")}</a>
        <form method="post" action="/panel/event/{e['id']}" style="display:inline"
              data-confirm="رویداد «{esc(e['title'])}» حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف {esc(e['title'])}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for e in rows)
    if not trs:
        trs = ('<tr><td colspan="6" class="text-center text-muted" '
               'style="padding:var(--space-xl)">رویدادی ثبت نشده</td></tr>')

    content = f'''{_msg(q)}
<div class="grid grid-2" style="grid-template-columns:minmax(0,1fr) minmax(0,340px);align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("calendar")} رویدادهای شهر</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عنوان</th><th>زمان</th><th>مکان</th><th>کسب‌وکار</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>{trs}</tbody></table></div></div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("plus")} رویداد جدید</h2>
    <form method="post" action="/panel/event/new" data-validate>
      {_hidden(token)}
      <div class="field"><label class="field-label" for="ev-t">عنوان<span class="req">*</span></label>
        <input class="input" id="ev-t" name="title" required placeholder="جشنوارهٔ تخفیف پاییزه"></div>
      <div class="field"><label class="field-label" for="ev-d">توضیح</label>
        <textarea class="textarea" id="ev-d" name="descr" style="min-height:80px"></textarea></div>
      <div class="grid grid-2" style="gap:10px">
        <div class="field" style="margin:0"><label class="field-label" for="ev-dt">تاریخ</label>
          <input class="input nums" id="ev-dt" name="date" type="date"></div>
        <div class="field" style="margin:0"><label class="field-label" for="ev-tm">ساعت</label>
          <input class="input nums" id="ev-tm" name="time" type="time"></div>
      </div>
      <div class="field"><label class="field-label" for="ev-p">مکان</label>
        <input class="input" id="ev-p" name="place" placeholder="میدان امام، بازارچهٔ مرکزی"></div>
      <div class="field"><label class="field-label" for="ev-b">کسب‌وکار برگزارکننده</label>
        <select class="select" id="ev-b" name="biz_id">{_biz_options()}</select></div>
      <button class="btn btn-primary btn-block" type="submit">{icon("plus")}<span>ثبت رویداد</span></button>
    </form></div></div>'''
    return panel_page(s, "رویدادهای شهر",
                      "جشنواره‌ها، افتتاحیه‌ها و مناسبت‌های نجف‌آباد.",
                      content, "/panel/events", token)


# ==========================================================================
#  EDIT APPROVALS
# ==========================================================================
def edit_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or ["pending"])[0]
    rows = db.pending_edits(status=status or None)

    cards = "".join(f'''<div class="pending-card">
      <div class="pending-main">
        <strong>{esc(e['bizname'])}</strong>
        <div class="text-xs text-muted nums">{esc(e.get('ownerphone') or 'مدیر')} · {fa(str(e['created'])[:16])}</div>
        <table class="table mt-sm"><tbody>
          {"".join(f"<tr><td style='width:130px'>{esc(db.FIELD_LABELS.get(k, k))}</td><td><strong>{esc(str(v)[:160])}</strong></td></tr>" for k, v in e['fields'].items())}
        </tbody></table>
      </div>
      <div class="pending-actions">
        <form method="post" action="/panel/edit/{e['id']}">
          {_hidden(token)}<input type="hidden" name="action" value="approve">
          <button class="btn btn-primary btn-sm btn-block" type="submit">
            {icon("check")}<span>تأیید و اعمال</span></button></form>
        <form method="post" action="/panel/edit/{e['id']}">
          {_hidden(token)}<input type="hidden" name="action" value="reject">
          <button class="btn btn-glass btn-sm btn-block" type="submit">
            {icon("x")}<span>رد</span></button></form>
      </div></div>''' for e in rows)

    if not cards:
        cards = _empty("check-circle", "تغییری در انتظار نیست",
                       "وقتی صاحب کسب‌وکاری اطلاعاتش را عوض کند، اینجا برای تأیید می‌آید.")

    filt = "".join(f'<a class="chip{" is-active" if status==v else ""}" '
                   f'href="/panel/edits?key={esc(token)}&status={v}">{t}</a>'
                   for v, t in [("pending", "در انتظار"), ("approved", "تأییدشده"),
                                ("rejected", "رد شده"), ("", "همه")])
    onoff = s.get("edit_approval") == "1"
    content = f'''{_msg(q)}
<div class="card glass card-pad mb-lg">
  <form method="post" action="/panel/edits/toggle" class="between" style="gap:12px;flex-wrap:wrap">
    {_hidden(token)}
    <div><strong>{"تأیید تغییرات روشن است" if onoff else "تأیید تغییرات خاموش است"}</strong>
      <p class="text-sm text-muted" style="margin:4px 0 0">
        {"هر ویرایش صاحب کسب‌وکار اول به شما نشان داده می‌شود." if onoff else "ویرایش‌های صاحبان کسب‌وکار مستقیم روی سایت اعمال می‌شود."}</p></div>
    <button class="btn {"btn-glass" if onoff else "btn-primary"} btn-sm" type="submit">
      {icon("shield")}<span>{"خاموش کردن" if onoff else "روشن کردن"}</span></button>
  </form>
</div>
<div class="cluster mb-lg">{filt}</div>
<div class="pending-grid">{cards}</div>'''
    return panel_page(s, "تأیید تغییرات",
                      "ویرایش‌هایی که صاحبان کسب‌وکار درخواست کرده‌اند.",
                      content, "/panel/edits", token)


# ==========================================================================
#  SAVED SEARCH ALERTS
# ==========================================================================
def alert_list(s, token, q=None):
    q = q or {}
    rows = db.alerts()
    cats = {c["slug"]: c["name"] for c in db.categories(only_active=False)}
    trs = "".join(f'''<tr>
      <td class="nums">{esc(a['phone'])}</td>
      <td>{esc(a['term']) or '<span class="text-muted">—</span>'}</td>
      <td>{esc(cats.get(a['cat_slug'], a['cat_slug'])) or '<span class="text-muted">همه</span>'}</td>
      <td class="num nums">{fa(a['sent'])}</td>
      <td><span class="badge {"badge-open" if a['active'] else "badge-neutral"}">
        {"فعال" if a['active'] else "غیرفعال"}</span></td>
      <td class="actions">
        <form method="post" action="/panel/alert/{a['id']}" style="display:inline">
          {_hidden(token)}<input type="hidden" name="action" value="toggle">
          <button class="btn-icon" type="submit" title="فعال/غیرفعال"
            aria-label="تغییر وضعیت هشدار {a['id']}">{icon("eye")}</button></form>
        <form method="post" action="/panel/alert/{a['id']}" style="display:inline"
              data-confirm="این هشدار حذف شود؟">
          {_hidden(token)}<input type="hidden" name="action" value="delete">
          <button class="btn-icon" type="submit" title="حذف" aria-label="حذف هشدار {a['id']}"
            style="color:var(--color-destructive)">{icon("trash")}</button></form>
      </td></tr>''' for a in rows)
    if not trs:
        trs = ('<tr><td colspan="6" class="text-center text-muted" '
               'style="padding:var(--space-xl)">کسی هشدار جست‌وجو ثبت نکرده</td></tr>')

    content = f'''{_msg(q)}
<div class="card glass card-pad">
  <h2 class="card-title mb-lg">{icon("bell")} هشدارهای جست‌وجو</h2>
  <p class="text-sm text-muted mb-lg">وقتی جست‌وجوی کاربری نتیجه ندارد، می‌تواند شماره‌اش را بگذارد.
    به‌محض ثبت کسب‌وکار مطابق، برایش پیامک می‌رود.</p>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>موبایل</th><th>عبارت</th><th>دسته</th><th>پیامک‌شده</th><th>وضعیت</th><th></th></tr></thead>
    <tbody>{trs}</tbody></table></div>
</div>'''
    return panel_page(s, "هشدار جست‌وجو",
                      "کاربرانی که منتظر ثبت یک کسب‌وکار خاص هستند.",
                      content, "/panel/alerts", token)


# ==========================================================================
#  SITE INSIGHTS
# ==========================================================================
def insights(s, token, q=None):
    q = q or {}
    days = (q.get("days") or ["30"])[0]
    days = int(days) if days.isdigit() and 7 <= int(days) <= 365 else 30
    d = db.site_insights(days)
    t = d["totals"]

    peak = max((x["view"] for x in d["daily"]), default=0) or 1
    bars = "".join(
        f'<div class="ins-bar" style="--h:{max(2, round(x["view"]*100/peak))}%" '
        f'title="{x["day"]}: {x["view"]} بازدید"><span class="sr-only">{x["day"]}: {x["view"]}</span></div>'
        for x in d["daily"])

    toprows = "".join(f'''<tr><td><a href="/b/{esc(x['slug'])}" target="_blank" rel="noopener">
      {esc(x['name'])}</a></td><td class="num nums">{fa_group(x['t'])}</td></tr>'''
      for x in d["top"]) or '<tr><td colspan="2" class="text-center text-muted">داده‌ای نیست</td></tr>'

    catmax = max((c["n"] for c in d["cats"]), default=0) or 1
    catrows = "".join(f'''<div class="ins-row">
      <span class="ins-label">{esc(c['name'])}</span>
      <span class="ins-track"><span class="ins-fill" style="width:{round(c['n']*100/catmax)}%"></span></span>
      <span class="nums">{fa(c['n'])}</span></div>''' for c in d["cats"]) or \
      '<p class="text-sm text-muted">دسته‌ای داده ندارد</p>'

    gmax = max((g["n"] for g in d["growth"]), default=0) or 1
    growrows = "".join(f'''<div class="ins-row">
      <span class="ins-label nums">{esc(g['m'])}</span>
      <span class="ins-track"><span class="ins-fill alt" style="width:{round(g['n']*100/gmax)}%"></span></span>
      <span class="nums">{fa(g['n'])}</span></div>''' for g in d["growth"]) or \
      '<p class="text-sm text-muted">هنوز کسب‌وکاری ثبت نشده</p>'

    c = d["counts"]
    todo = ""
    for cond, ic, label, href in (
        (c["reports_open"], "alert", f'{fa(c["reports_open"])} گزارش تخلف باز', "/panel/reports"),
        (c["questions_open"], "help", f'{fa(c["questions_open"])} پرسش بی‌پاسخ', "/panel/qa"),
        (c["subs_pending"], "wallet", f'{fa(c["subs_pending"])} پرداخت در انتظار تأیید', "/panel/subscriptions"),
        (c["edits_pending"], "edit", f'{fa(c["edits_pending"])} ویرایش در انتظار', "/panel/edits"),
    ):
        if cond:
            todo += (f'<a class="todo-item" href="{href}?key={esc(token)}">{icon(ic)}'
                     f'<span>{label}</span>{icon("chevron-left")}</a>')
    if not todo:
        todo = (f'<div class="alert alert-success">{icon("check-circle")}'
                f'<span>هیچ کار معوقی در بخش‌های جدید نیست.</span></div>')

    # ---- what the city searched for
    st_search = db.search_totals(days)
    srows = db.top_searches(days, limit=12)
    searchrows = "".join(f'''<tr>
      <td>{esc(r['term'])}</td>
      <td class="num nums">{fa(r['n'])}</td>
      <td>{'<span class="badge badge-closed">بی‌نتیجه</span>' if not r['best']
           else f'<span class="badge badge-open">{fa(r["best"])} مورد</span>'}</td>
    </tr>''' for r in srows) or (
        '<tr><td colspan="3" class="text-center text-muted" '
        'style="padding:var(--space-lg)">هنوز کسی جست‌وجو نکرده</td></tr>')

    zrows = db.top_searches(days, limit=12, zero_only=True)
    zerorows = "".join(f'''<tr>
      <td><strong>{esc(r['term'])}</strong></td>
      <td class="num nums">{fa(r['n'])}</td></tr>''' for r in zrows) or (
        '<tr><td colspan="2" class="text-center text-muted" '
        'style="padding:var(--space-lg)">هر جست‌وجو نتیجه داشته — عالی است</td></tr>')

    dopts = "".join(f'<a class="chip{" is-active" if days==n else ""}" '
                    f'href="/panel/insights?key={esc(token)}&days={n}">{fa(n)} روز</a>'
                    for n in (7, 30, 90, 365))

    content = f'''{_msg(q)}
<div class="cluster mb-lg">{dopts}</div>
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("eye", t['view'], f"بازدید صفحهٔ کسب‌وکار ({fa(days)} روز)")}
  {stat_card("phone", t['phone'], "کلیک تماس", delay=60)}
  {stat_card("whatsapp", t['whatsapp'], "کلیک واتساپ", delay=120)}
  {stat_card("map", t['route'], "درخواست مسیر", delay=180)}
</div>
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("wallet", d['revenue'], "درآمد اشتراک فعال (تومان)")}
  {stat_card("search", st_search['total'], "جست‌وجو", delay=60)}
  {stat_card("alert", st_search['zero'], "جست‌وجوی بی‌نتیجه", delay=120)}
  {stat_card("calendar", c['events'], "رویداد پیش‌رو", delay=180)}
</div>

<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-lg">{icon("chart")} روند بازدید روزانه</h2>
  <div class="ins-chart" role="img" aria-label="نمودار بازدید {fa(days)} روز اخیر">{bars}</div>
  <div class="between text-xs text-muted mt-sm">
    <span>{esc(d['daily'][0]['day'])}</span><span>{esc(d['daily'][-1]['day'])}</span></div>
</div>

<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("trending")} پربازدیدترین کسب‌وکارها</h2>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>کسب‌وکار</th><th>بازدید</th></tr></thead>
      <tbody>{toprows}</tbody></table></div>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("bell")} کارهای در انتظار</h2>
    <div class="todo-list">{todo}</div>
  </div>
</div>

<div class="grid grid-2 mb-lg" style="align-items:start">
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("layers")} توزیع دسته‌ها</h2>{catrows}</div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("trending")} رشد ماهانهٔ ثبت‌نام</h2>{growrows}</div>
</div>

<div class="grid grid-2" style="align-items:start">
  <div class="card glass card-pad">
    <div class="between mb-lg">
      <h2 class="card-title">{icon("search")} پرجست‌وجوترین عبارت‌ها</h2>
      <span class="badge badge-neutral">{icon("target")}
        <span>نرخ موفقیت {fa(st_search['hit_rate'])}٪</span></span></div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عبارت</th><th>دفعات</th><th>نتیجه</th></tr></thead>
      <tbody>{searchrows}</tbody></table></div>
  </div>
  <div class="card glass card-pad">
    <h2 class="card-title mb-lg">{icon("alert")} جست‌وجوهای بی‌نتیجه</h2>
    <p class="text-sm text-muted mb-md">مردم این‌ها را خواستند و چیزی پیدا نکردند.
      هر ردیف یعنی یک صنف که جایش در بازارچه خالی است.</p>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>عبارت</th><th>دفعات</th></tr></thead>
      <tbody>{zerorows}</tbody></table></div>
    {f"""<form method="post" action="/panel/searches/clear" class="mt-md">
      {_hidden(token)}
      <button class="btn btn-ghost btn-sm" type="submit"
        onclick="return confirm('همهٔ آمار جست‌وجو پاک شود؟')">
        {icon("trash")}<span>پاک کردن آمار جست‌وجو</span></button></form>"""
     if st_search['total'] else ''}
  </div>
</div>'''
    return panel_page(s, "بینش و آمار سایت",
                      "تصویر کامل از رفتار کاربران، درآمد و رشد بازارچه.",
                      content, "/panel/insights", token)


# ==========================================================================
#  FEATURE UNLOCKS  —  the key the site owner holds
# ==========================================================================
def unlock_list(s, token, q=None):
    """One screen to see every shop's plan and flip any feature by hand.

    This is the lever behind the whole business model: a shopkeeper pays you
    however they pay you, and you turn the switch here. Nothing about it is
    decorative — every checkbox writes to biz_features and takes effect on
    the next page load.
    """
    q = q or {}
    term = (q.get("q") or [""])[0].strip()
    only = (q.get("only") or [""])[0]

    rows = db.businesses(status=None, order="newest")
    if term:
        t = db.normalize_fa(term)
        rows = [b for b in rows
                if t in db.normalize_fa(f"{b['name']} {b.get('phone','')}")]
    if only == "founder":
        rows = [b for b in rows if db.is_founder(b["id"])]
    elif only == "paid":
        rows = [b for b in rows if db.access(b["id"])["paid"]]
    elif only == "granted":
        rows = [b for b in rows if db._manual_grants(b["id"])]

    cfg = db.founder_settings()
    left = db.founders_left()

    cards = ""
    for b in rows[:40]:
        acc = db.access(b["id"])
        manual = db._manual_grants(b["id"])
        boxes = ""
        for key, label, _ic, _f, why in db.FEATURES:
            on = key in acc["keys"]
            src = acc["source"].get(key, "")
            by_manual = key in manual
            # a feature already granted by plan or founder status cannot be
            # switched off here — say so instead of showing a dead checkbox
            fixed = on and not by_manual
            note = ""
            if fixed:
                lbl = {"plan": "از پلن", "founder": "بنیان‌گذار"}.get(src, src)
                note = f'<span class="unlock-src src-{src}">{esc(lbl)}</span>'
            boxes += f'''<label class="unlock-row{" is-on" if on else ""}">
          <input type="checkbox" name="feat" value="{esc(key)}"
                 {"checked" if by_manual else ""} {"disabled" if fixed else ""}>
          <span class="u-label">{esc(label)}<span class="u-why">{esc(why)}</span></span>
          {note}</label>'''

        badge = ""
        if acc["founder"]:
            badge = (f'<span class="badge" style="background:#b4530922;color:#b45309">'
                     f'{icon("award")}<span>بنیان‌گذار #{fa(acc["rank"])}</span></span>')
        if acc["paid"]:
            badge += (f'<span class="badge badge-featured">{icon("wallet")}'
                      f'<span>{esc(acc["plan_name"])}</span></span>')

        cards += f'''<form class="card glass card-pad mb-lg" method="post"
        action="/panel/unlock/{b["id"]}">
      {_hidden(token)}
      <div class="between mb-md" style="flex-wrap:wrap;gap:8px">
        <div><h3 class="card-title">{esc(b["name"])}</h3>
          <div class="text-xs text-muted nums">{esc(b.get("phone") or "—")} ·
            {fa(len(acc["keys"]))} از {fa(len(db.FEATURES))} قابلیت فعال ·
            سقف {fa(acc["max_items"])} کالا / {fa(acc["max_photos"])} عکس</div></div>
        <div class="cluster">{badge}</div>
      </div>
      <div class="unlock-grid">{boxes}</div>
      <div class="cluster mt-md">
        <button class="btn btn-primary btn-sm" type="submit" name="action" value="save">
          {icon("check")}<span>ذخیرهٔ دسترسی‌ها</span></button>
        <button class="btn btn-glass btn-sm" type="submit" name="action" value="all">
          {icon("zap")}<span>باز کردن همه</span></button>
        <button class="btn btn-ghost btn-sm" type="submit" name="action" value="none"
          style="color:var(--color-destructive)">{icon("lock")}<span>بستن همه</span></button>
        <a class="btn btn-ghost btn-sm" href="/b/{esc(b["slug"])}" target="_blank"
           rel="noopener">{icon("external")}<span>دیدن صفحه</span></a>
      </div>
    </form>'''

    if not cards:
        cards = _empty("lock", "کسب‌وکاری پیدا نشد",
                       "عبارت جست‌وجو را تغییر دهید یا فیلتر را بردارید.")

    chips = "".join(
        f'<a class="chip{" is-active" if only == v else ""}" '
        f'href="/panel/unlocks?key={esc(token)}{"&only=" + v if v else ""}">{t}</a>'
        for v, t in [("", "همه"), ("founder", "بنیان‌گذاران"),
                     ("paid", "پلن پولی"), ("granted", "دسترسی دستی")])

    content = f'''{_msg(q)}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("store", len(db.businesses(status=None)), "کل کسب‌وکارها")}
  {stat_card("award", cfg["limit"] - left, "عضو بنیان‌گذار", delay=60)}
  {stat_card("lock", left, "جای باقی‌ماندهٔ بنیان‌گذار", delay=120)}
  {stat_card("wallet", len([x for x in db.subscriptions(status="active") if x["is_live"]]),
             "اشتراک فعال", delay=180)}
</div>

<div class="card glass card-pad mb-lg">
  <h2 class="card-title mb-md">{icon("award")} پنجرهٔ عضویت بنیان‌گذار</h2>
  <p class="text-sm text-muted mb-lg">قولی که سر در مغازه می‌دهید: صد کسب‌وکار
    نخست، قابلیت‌های پایه را همیشه رایگان دارند. شمارهٔ هر کسب‌وکار بر پایهٔ
    ترتیب ثبت است و هرگز عوض نمی‌شود.</p>
  <form method="post" action="/panel/unlocks/founder" class="grid grid-4" style="align-items:end">
    {_hidden(token)}
    <div class="field" style="margin:0"><label class="field-label" for="f-lim">تعداد بنیان‌گذاران</label>
      <input class="input nums" id="f-lim" name="founder_limit" type="number" min="0"
             value="{cfg['limit']}"></div>
    <div class="field" style="margin:0"><label class="field-label" for="f-it">سقف کالا (بنیان‌گذار)</label>
      <input class="input nums" id="f-it" name="founder_max_items" type="number" min="1"
             value="{cfg['items']}"></div>
    <div class="field" style="margin:0"><label class="field-label" for="f-ph">سقف عکس (بنیان‌گذار)</label>
      <input class="input nums" id="f-ph" name="founder_max_photos" type="number" min="1"
             value="{cfg['photos']}"></div>
    <button class="btn btn-primary" type="submit">{icon("check")}<span>ذخیره</span></button>
  </form>
  <hr class="divider">
  <form method="post" action="/panel/unlocks/founder" class="grid grid-4" style="align-items:end">
    {_hidden(token)}
    <div class="field" style="margin:0"><label class="field-label" for="p-it">سقف کالا (رایگان عادی)</label>
      <input class="input nums" id="p-it" name="free_max_items" type="number" min="1"
             value="{cfg['plain_items']}"></div>
    <div class="field" style="margin:0"><label class="field-label" for="p-ph">سقف عکس (رایگان عادی)</label>
      <input class="input nums" id="p-ph" name="free_max_photos" type="number" min="1"
             value="{cfg['plain_photos']}"></div>
    <button class="btn btn-glass" type="submit">{icon("check")}<span>ذخیرهٔ سقف رایگان</span></button>
  </form>
</div>

<form class="dir-toolbar mb-lg" method="get" action="/panel/unlocks">
  <input type="hidden" name="key" value="{esc(token)}">
  <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="uq">جست‌وجوی کسب‌وکار</label>
      <input class="input" id="uq" name="q" type="search" value="{esc(term)}"
             placeholder="نام یا شمارهٔ کسب‌وکار…"></span>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
  </div>
  <div class="dir-chips">{chips}</div>
</form>

{cards}
{f'<p class="text-sm text-muted text-center">{fa(len(rows) - 40)} مورد دیگر — برای دیدنشان جست‌وجو کنید.</p>' if len(rows) > 40 else ''}'''

    return panel_page(s, "کلید قابلیت‌ها",
                      "هر قابلیت را برای هر کسب‌وکار دستی باز یا بسته کنید.",
                      content, "/panel/unlocks", token)


# ==========================================================================
#  TICKETS  --  the admin's inbox
# ==========================================================================
def ticket_list(s, token, q=None):
    q = q or {}
    status = (q.get("status") or [""])[0]
    term = (q.get("q") or [""])[0]
    rows = db.tickets(status=status or None, q=term)
    st = db.ticket_stats()

    tabs = ""
    for val, lbl in (("", "همه"), ("open", "باز"), ("answered", "پاسخ‌داده"),
                     ("waiting", "در انتظار کاربر"), ("closed", "بسته")):
        on = " is-active" if status == val else ""
        n = {"": st["total"], "open": st["open"], "answered": st["answered"],
             "closed": st["closed"]}.get(val)
        _cnt = f'<small class="chip-n nums">{fa(n)}</small>' if n else ""
        tabs += (f'<a class="chip{on}" href="/panel/tickets?key={esc(token)}'
                 f'{f"&status={val}" if val else ""}">{esc(lbl)}'
                 f'{_cnt}</a>')

    items = ""
    for t in rows:
        unread = '<span class="tk-dot"></span>' if t["unread_admin"] else ""
        pri = ('<span class="badge badge-closed">فوری</span>'
               if t["priority"] == "high" else "")
        items += f'''<a class="tk-row" href="/panel/ticket/{t['id']}?key={esc(token)}">
      {unread}
      <div class="tk-main">
        <strong>{esc(t['subject'])}</strong>
        <div class="tk-meta">
          <span>{esc(t['name'] or '—')}</span>
          {f'<a href="tel:{esc(t["phone"])}" class="nums">· {esc(t["phone"])}</a>' if t.get('phone') else ''}
          <span>· {esc(t['topic_label'])}</span>
          {f'<span>· {esc(t["bizname"])}</span>' if t.get('bizname') else ''}
          <span>· {fa(t['nmsg'])} پیام</span>
          <span>· {esc(str(t['updated'])[:16])}</span>
        </div>
      </div>
      {pri}
      <span class="badge {t['status_cls']}">{esc(t['status_label'])}</span>
      {icon("chevron-left")}
    </a>'''

    if not items:
        items = _empty("message", "تیکتی نیست",
                       "وقتی مغازه‌داران سؤالی داشته باشند، اینجا می‌بینید.")

    content = f'''{_msg(q) if callable(globals().get("_msg")) else ""}
<div class="grid grid-4 mb-lg" data-stagger>
  {stat_card("message", st['total'], "کل تیکت‌ها")}
  {stat_card("bell", st['unread'], "خوانده‌نشده", delay=60)}
  {stat_card("clock", st['open'], "در انتظار پاسخ شما", delay=120)}
  {stat_card("check-circle", st['closed'], "بسته‌شده", delay=180)}
</div>

<form class="dir-toolbar mb-lg" method="get" action="/panel/tickets">
  <input type="hidden" name="key" value="{esc(token)}">
  <div class="dir-row">
    <span class="search-wrap">{icon("search", cls="search-icon")}
      <label class="sr-only" for="tq">جست‌وجو</label>
      <input class="input" id="tq" name="q" type="search" value="{esc(term)}"
             placeholder="عنوان، نام یا شمارهٔ تماس…"></span>
    <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
  </div>
  <div class="dir-chips mt-md">{tabs}</div>
</form>

<div class="card glass card-pad"><div class="tk-list">{items}</div></div>'''
    return panel_page(s, "تیکت‌های پشتیبانی",
                      "گفت‌وگوی مستقیم با مغازه‌داران.",
                      content, "/panel/tickets", token)


def ticket_detail(s, token, tid, q=None):
    t = db.ticket(tid=tid)
    if not t:
        return None
    msgs = db.ticket_msgs(tid)
    db.set_ticket(tid, unread_admin=0)

    bubbles = ""
    for m in msgs:
        admin = m["side"] == "admin"
        bubbles += f'''<div class="tk-bubble {"is-me" if admin else "is-admin"}">
      <div class="tk-who">{icon("shield" if admin else "user")}
        <span>{"شما (مدیر)" if admin else esc(t['name'] or 'کاربر')}</span>
        <time class="nums">{esc(str(m['created'])[:16])}</time></div>
      <p>{esc(m['body'])}</p>
    </div>'''

    # if this person owns a shop, one click to their unlock page — this is
    # the most common reason a ticket exists at all
    quick = ""
    if t.get("biz_id"):
        quick = (f'<a class="btn btn-glass btn-sm" '
                 f'href="/panel/unlocks?key={esc(token)}&q={esc(t.get("bizname") or "")}">'
                 f'{icon("lock")}<span>کلید قابلیت‌های این کسب‌وکار</span></a>')

    sel = lambda v, cur: ' selected' if v == cur else ''
    content = f'''
<div class="card glass card-pad mb-lg">
  <div class="between mb-md" style="align-items:flex-start;gap:10px">
    <div>
      <h2 class="card-title">{esc(t['subject'])}</h2>
      <div class="tk-meta">
        <strong>{esc(t['name'] or '—')}</strong>
        {f'· <a href="tel:{esc(t["phone"])}" class="nums">{esc(t["phone"])}</a>' if t.get('phone') else ''}
        · {esc(t['topic_label'])}
        {f'· <a href="/b/{esc(t["bizslug"])}" target="_blank" rel="noopener">{esc(t["bizname"])}</a>' if t.get('bizname') else ''}
        · <span class="nums">{esc(str(t['created'])[:16])}</span>
      </div>
    </div>
    <span class="badge {t['status_cls']}">{esc(t['status_label'])}</span>
  </div>
  <div class="cluster">
    {f'<a class="btn btn-accent btn-sm" href="tel:{esc(t["phone"])}">{icon("phone")}<span>تماس مستقیم</span></a>' if t.get('phone') else ''}
    {quick}
  </div>
</div>

<div class="tk-thread">{bubbles}</div>

<form class="card glass card-pad mt-lg" method="post" action="/panel/ticket/{tid}">
  <input type="hidden" name="key" value="{esc(token)}">
  <div class="field"><label class="field-label" for="ad-rp">پاسخ شما</label>
    <textarea class="textarea" id="ad-rp" name="body"
      placeholder="پاسخ خود را بنویسید…"></textarea></div>
  <div class="grid grid-2" style="gap:0 var(--space-md)">
    <div class="field"><label class="field-label" for="ad-st">وضعیت</label>
      <select class="select" id="ad-st" name="status">
        <option value="open"{sel("open", t["status"])}>باز</option>
        <option value="answered"{sel("answered", t["status"])}>پاسخ داده شد</option>
        <option value="waiting"{sel("waiting", t["status"])}>در انتظار کاربر</option>
        <option value="closed"{sel("closed", t["status"])}>بسته</option>
      </select></div>
    <div class="field"><label class="field-label" for="ad-pr">اولویت</label>
      <select class="select" id="ad-pr" name="priority">
        <option value="low"{sel("low", t["priority"])}>کم</option>
        <option value="normal"{sel("normal", t["priority"])}>عادی</option>
        <option value="high"{sel("high", t["priority"])}>فوری</option>
      </select></div>
  </div>
  <div class="cluster">
    <button class="btn btn-primary" type="submit" name="action" value="reply">
      {icon("send")}<span>ارسال پاسخ</span></button>
    <button class="btn btn-glass" type="submit" name="action" value="save" formnovalidate>
      {icon("check")}<span>فقط ذخیرهٔ وضعیت</span></button>
    <button class="btn btn-ghost" type="submit" name="action" value="delete"
      formnovalidate data-confirm="این تیکت حذف شود؟"
      style="color:var(--color-destructive)">{icon("trash")}<span>حذف</span></button>
  </div>
</form>'''
    return panel_page(s, f"تیکت: {t['subject'][:40]}",
                      "پاسخ به مغازه‌دار.", content, "/panel/tickets", token)


# ==========================================================================
#  INBOX  --  the single place that answers "does anything need me?"
# ==========================================================================
def inbox_page(s, token, q=None):
    data = db.inbox()
    K = esc(token)

    if not data["total"]:
        body = _empty("check-circle", "همه‌چیز رسیدگی شده",
                      "هیچ درخواستی منتظر تأیید شما نیست. "
                      "هر وقت کاسبی چیزی بفرستد، همین‌جا می‌بینید.")
        return panel_page(s, "درخواست‌های کاسبان",
                          "هرچه منتظر تأیید شماست، یکجا.",
                          f'<div class="card glass card-pad">{body}</div>',
                          "/panel/inbox", token)

    blocks = ""
    for g in data["groups"]:
        rows = ""
        for it in g["items"]:
            rows += f'''<a class="ib-row" href="{esc(it['href'])}?key={K}">
        <div class="ib-main">
          <strong>{esc(it['title'])}</strong>
          {f'<div class="ib-sub">{esc(it["sub"])}</div>' if it.get('sub') else ''}
        </div>
        <time class="ib-when nums">{esc(it['when'])}</time>
        {icon("chevron-left")}
      </a>'''
        more = ""
        if g["n"] > len(g["items"]):
            more = (f'<a class="ib-more" href="{esc(g["href"])}'
                    f'{"&" if "?" in g["href"] else "?"}key={K}">'
                    f'{fa(g["n"] - len(g["items"]))} مورد دیگر ←</a>')
        blocks += f'''<div class="card glass card-pad mb-lg">
      <div class="between mb-md">
        <h2 class="card-title">{icon(g['icon'])} {esc(g['label'])}
          <span class="badge badge-warn nums">{fa(g['n'])}</span></h2>
        <a class="btn btn-glass btn-sm" href="{esc(g['href'])}{"&" if "?" in g["href"] else "?"}key={K}">
          {icon("external")}<span>مدیریت</span></a>
      </div>
      <div class="ib-list">{rows}</div>
      {more}
    </div>'''

    head = f'''<div class="alert alert-warn mb-lg">{icon("bell")}<span>
      <strong>{fa(data['total'])} مورد</strong> منتظر تأیید یا پاسخ شماست.
      هرچه زودتر رسیدگی کنید، کاسب‌ها بیشتر به سایت اعتماد می‌کنند.</span></div>'''

    return panel_page(s, "درخواست‌های کاسبان",
                      "هرچه منتظر تأیید شماست، یکجا.",
                      head + blocks, "/panel/inbox", token)


# ==========================================================================
#  FEATURE SWITCHES  --  turn whole capabilities on and off
# ==========================================================================
# Every switch here maps to a settings key the rest of the site already
# honours. Nothing is deleted when a feature is off — the pages simply stop
# being offered, and turning it back on restores everything untouched.
SITE_FEATURES = [
    ("قابلیت‌های ویژه", [
        ("haggle_enabled",  "چانه‌زنی",
         "مشتری روی کالا قیمت پیشنهاد می‌دهد؛ بالاتر از کف قیمت خودکار پذیرفته می‌شود.",
         "tag"),
        ("prices_enabled",  "مقایسهٔ قیمت محلی",
         "یک کالا در چند مغازهٔ شهر، قیمت‌ها کنار هم.", "chart"),
        ("compare_enabled", "مقایسهٔ کسب‌وکارها",
         "انتخاب چند مغازه و مقایسهٔ کنار هم.", "layers"),
        ("nearby_enabled",  "نزدیک من",
         "جست‌وجوی شعاعی بر پایهٔ موقعیت مشتری.", "compass"),
    ]),
    ("تعامل با مشتری", [
        ("booking_enabled", "نوبت‌دهی آنلاین", "رزرو نوبت بدون تماس.", "calendar"),
        ("qa_enabled",      "پرسش و پاسخ", "سؤال عمومی زیر صفحهٔ هر مغازه.", "help"),
        ("inquiry_enabled", "درخواست قیمت", "استعلام برای کارهای سفارشی.", "send"),
        ("reports_enabled", "گزارش تخلف", "مشتری اطلاعات غلط را گزارش کند.", "alert"),
        ("alerts_enabled",  "اعلان کسب‌وکار تازه",
         "به کسانی که خبرم کن زده‌اند پیامک می‌رود.", "bell"),
    ]),
    ("محتوا و فروش", [
        ("catalog_enabled", "ویترین محصولات", "کاتالوگ کالا و خدمات هر مغازه.", "shopping"),
        ("coupons_enabled", "کد تخفیف", "صفحهٔ تخفیف‌های شهر.", "tag"),
        ("events_enabled",  "رویدادهای شهر", "حراج، افتتاحیه و جشنواره.", "calendar"),
        ("blog_enabled",    "اخبار شهر", "بخش خبر و مقاله.", "book"),
        ("ads_enabled",     "بنر تبلیغاتی", "جایگاه تبلیغ در صفحات.", "zap"),
        ("plans_enabled",   "تعرفه و اشتراک", "صفحهٔ پلن‌ها و خرید.", "wallet"),
    ]),
    ("ثبت‌نام و ورود", [
        ("reg_open",        "ثبت کسب‌وکار جدید", "فرم ثبت عمومی باز باشد.", "plus"),
        ("owner_login",     "ورود صاحبان کسب‌وکار", "پنل مغازه‌دار فعال باشد.", "user"),
        ("claims_enabled",  "تصاحب کسب‌وکار", "درخواست مالکیت یک صفحهٔ موجود.", "shield"),
        ("support_widget",  "ویجت پشتیبانی", "دکمهٔ شناور راهنما و سؤالات متداول.", "help"),
    ]),
]


def features_page(s, token, q=None):
    K = esc(token)
    groups = ""
    n_on = n_tot = 0
    for title, items in SITE_FEATURES:
        rows = ""
        for key, label, why, ic in items:
            on = s.get(key, "1") == "1"
            n_tot += 1
            n_on += 1 if on else 0
            rows += f'''<label class="feat-row">
        <input type="checkbox" name="{esc(key)}" value="1"{" checked" if on else ""}>
        <span class="feat-ic">{icon(ic)}</span>
        <span class="feat-txt"><strong>{esc(label)}</strong>
          <small>{esc(why)}</small></span>
        <span class="feat-state">{"روشن" if on else "خاموش"}</span>
      </label>'''
        groups += f'''<div class="card glass card-pad mb-lg">
      <h2 class="card-title mb-md">{esc(title)}</h2>
      <div class="feat-list">{rows}</div>
    </div>'''

    content = f'''
<div class="alert alert-info mb-lg">{icon("info")}<span>
  هر قابلیتی را که الان نمی‌خواهید خاموش کنید — <strong>هیچ داده‌ای پاک
  نمی‌شود</strong>. هر وقت دوباره روشن کنید، همه‌چیز سر جایش برمی‌گردد.
  الان <strong>{fa(n_on)}</strong> از {fa(n_tot)} قابلیت روشن است.</span></div>

<form method="post" action="/panel/features">
  <input type="hidden" name="key" value="{K}">
  {groups}
  <div class="cluster">
    <button class="btn btn-primary btn-lg" type="submit">
      {icon("check")}<span>ذخیرهٔ تغییرات</span></button>
    <a class="btn btn-ghost" href="/panel/settings?key={K}">
      {icon("settings")}<span>بقیهٔ تنظیمات</span></a>
  </div>
</form>'''
    return panel_page(s, "قابلیت‌های سایت",
                      "هر بخش را جداگانه روشن یا خاموش کنید.",
                      content, "/panel/features", token)
