# -*- coding: utf-8 -*-
"""
Image uploads without any third-party library.

`cgi` was removed in Python 3.13, so multipart/form-data is parsed by hand.
Pillow is not available in Pydroid either, so images are downscaled in the
BROWSER (canvas -> JPEG) before upload; the server validates the magic bytes,
enforces a size cap, and stores the file.
"""

import os
import re
import json
import time
import secrets

HERE = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.abspath(os.path.join(HERE, "..", "site", "assets", "img", "uploads"))
os.makedirs(UPLOAD_DIR, exist_ok=True)

PUBLIC_PREFIX = "/assets/img/uploads/"
MAX_FILE = 3 * 1024 * 1024          # 3 MB per image after browser downscale
MAX_FILES = 15
MAX_BODY = 30 * 1024 * 1024

MAGIC = {
    b"\xff\xd8\xff": ".jpg",
    b"\x89PNG\r\n\x1a\n": ".png",
    b"RIFF": ".webp",               # RIFF....WEBP
    b"GIF87a": ".gif",
    b"GIF89a": ".gif",
}


def sniff(data):
    """Return an extension if the bytes really are an image, else None."""
    for magic, ext in MAGIC.items():
        if data.startswith(magic):
            if ext == ".webp" and data[8:12] != b"WEBP":
                continue
            return ext
    return None


# --------------------------------------------------------------------------
# multipart/form-data parser
# --------------------------------------------------------------------------
def parse_multipart(body, content_type):
    """
    -> (fields: {name: str}, files: [(field, filename, bytes)])
    Tolerant of CRLF/LF and quoted or bare boundary values.
    """
    m = re.search(r'boundary=(?:"([^"]+)"|([^;\s]+))', content_type or "", re.I)
    if not m:
        return {}, []
    boundary = (m.group(1) or m.group(2)).encode()
    delim = b"--" + boundary

    fields, files = {}, []
    for part in body.split(delim):
        if not part or part in (b"--", b"--\r\n", b"\r\n"):
            continue
        part = part.lstrip(b"\r\n")
        if part.startswith(b"--"):
            continue
        head, sep, payload = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        payload = payload.rstrip(b"\r\n")

        headers = head.decode("utf-8", "replace")
        name_m = re.search(r'name="([^"]*)"', headers)
        if not name_m:
            continue
        name = name_m.group(1)
        file_m = re.search(r'filename="([^"]*)"', headers)

        if file_m:
            fn = file_m.group(1)
            if fn and payload:
                files.append((name, fn, payload))
        else:
            fields[name] = payload.decode("utf-8", "replace")
    return fields, files


# --------------------------------------------------------------------------
# storage
# --------------------------------------------------------------------------
def save_image(data, prefix="img"):
    """-> (public_path, error). Validates real image bytes."""
    if len(data) > MAX_FILE:
        return None, "حجم تصویر بیش از حد مجاز است (حداکثر ۳ مگابایت)."
    ext = sniff(data)
    if not ext:
        return None, "فایل انتخابی یک تصویر معتبر نیست."
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, None


def delete_image(public_path):
    """Remove a stored upload. Refuses anything outside the upload dir."""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def disk_usage():
    total = 0
    n = 0
    for f in os.listdir(UPLOAD_DIR):
        try:
            total += os.path.getsize(os.path.join(UPLOAD_DIR, f))
            n += 1
        except OSError:
            pass
    return n, total
