# -*- coding: utf-8 -*-
"""
Public pages for the v3 features:
compare, nearby (radius search), city events, report form,
plus the reusable Q&A / criteria / badge / ad blocks used by
the business detail page.
"""

import json
import urllib.parse
import db
from ui import (icon, stars, fa, fa_group, esc, page, biz_card, stat_card,
                section_head, breadcrumb, empty_state, flash)

def urlq(v):
    """Percent-encode a value for a query string. Comparison keys are Persian
    words joined by spaces, so they must be encoded or the link breaks."""
    return urllib.parse.quote(str(v), safe="")


MAP_JS = '<script type="module" src="/assets/js/mappage.js"></script>'
CMP_JS = '<script type="module" src="/assets/js/compare.js"></script>'
NEAR_JS = '<script type="module" src="/assets/js/nearby.js"></script>'
QA_JS = '<script type="module" src="/assets/js/qa.js"></script>'


def _cat_icons():
    return {c["slug"]: c["icon"] for c in db.categories(only_active=False)}


def jsonld(*objs):
    out = ""
    for o in objs:
        if o:
            out += ('<script type="application/ld+json">'
                    + json.dumps(o, ensure_ascii=False) + '</script>')
    return out


# ==========================================================================
#  REUSABLE BLOCKS (used inside the business detail page)
# ==========================================================================
def badge_strip(biz_id, badges=None):
    rows = badges if badges is not None else db.biz_badges(biz_id)
    if not rows:
        return ""
    out = ""
    for b in rows:
        try:
            ic = icon(b["icon"])
        except KeyError:
            ic = icon("award")
        out += (f'<span class="badge badge-custom" title="{esc(b["descr"])}" '
                f'style="background:{esc(b["color"])}18;color:{esc(b["color"])};'
                f'border-color:{esc(b["color"])}55">{ic}<span>{esc(b["name"])}</span></span>')
    return f'<div class="badge-strip">{out}</div>'


def criteria_block(biz_id):
    rows = db.criteria_averages(biz_id)
    if not rows:
        return ""
    bars = "".join(f'''<div class="crit-row">
      <span>{esc(r['label'])}</span>
      <span class="crit-track"><span class="crit-fill" style="width:{round(r['avg']*20)}%"></span></span>
      <strong class="nums">{fa(r['avg'])}</strong></div>''' for r in rows)
    return f'''<div class="crit-grid" role="group" aria-label="امتیاز تفکیکی">
      {bars}</div>'''


def criteria_inputs():
    """The star pickers on the review form — real inputs, posted with the form."""
    rows = ""
    for code, label in db.REVIEW_CRITERIA:
        btns = "".join(
            f'<button type="button" data-v="{i}" aria-pressed="{"true" if i <= 5 else "false"}" '
            f'aria-label="{esc(label)}: {fa(i)} ستاره">{icon("star")}</button>'
            for i in range(1, 6))
        rows += f'''<div class="row" data-crit="{code}">
          <span>{esc(label)}</span>
          <span class="crit-stars">{btns}
            <input type="hidden" name="crit_{code}" value="5"></span></div>'''
    return f'''<div class="field"><span class="field-label">امتیاز تفکیکی</span>
      <div class="crit-input" data-crit-input>{rows}</div>
      <p class="field-hint">این امتیازها میانگین معیارها را در صفحهٔ کسب‌وکار می‌سازد.</p></div>'''


def qa_block(s, b, token=""):
    if s.get("qa_enabled") != "1":
        return ""
    rows = db.questions(biz_id=b["id"], status="published")
    items = "".join(f'''<div class="qa-item">
      <div class="qa-q"><span class="qmark">؟</span><span>{esc(q['body'])}</span></div>
      {f'<div class="qa-a"><span class="amark">✓</span><span>{esc(q["answer"])}</span></div>' if q['answer'] else '<p class="text-xs text-muted mt-sm">هنوز پاسخی داده نشده.</p>'}
      <div class="qa-meta">
        <span>{esc(q['asker'])}</span><span aria-hidden="true">·</span>
        <span class="nums">{esc(str(q['created'])[:10])}</span>
        <button class="qa-helpful" type="button" data-helpful="{q['id']}"
          aria-pressed="false" aria-label="این پرسش مفید بود">
          {icon("check")}<span>مفید بود (<span class="nums" data-helpful-n>{fa(q['helpful'])}</span>)</span></button>
      </div></div>''' for q in rows)
    if not items:
        items = ('<p class="text-sm text-muted">هنوز پرسشی ثبت نشده. '
                 'اولین سؤال را شما بپرسید.</p>')
    note = ("پرسش شما پس از بررسی و پاسخ صاحب کسب‌وکار منتشر می‌شود."
            if s.get("qa_moderated") == "1" else "پرسش شما بلافاصله منتشر می‌شود.")
    return f'''<section class="card glass card-pad mt-lg reveal" id="qa">
  <h2 class="card-title mb-lg">{icon("help")} پرسش و پاسخ</h2>
  {items}
  <hr class="divider">
  <h3 class="card-title mb-md">{icon("edit")} سؤال خود را بپرسید</h3>
  <form method="post" action="/b/{esc(b['slug'])}/ask-question" data-validate>
    <div class="field"><label class="field-label" for="qa-name">نام شما<span class="req">*</span></label>
      <input class="input" id="qa-name" name="asker" required minlength="2"></div>
    <div class="field"><label class="field-label" for="qa-body">پرسش<span class="req">*</span></label>
      <textarea class="textarea" id="qa-body" name="body" required minlength="8"
        placeholder="مثلاً: پارکینگ دارید؟ ارسال به شهرک دارید؟"></textarea>
      <p class="field-hint">{esc(note)}</p></div>
    <button class="btn btn-primary" type="submit">{icon("send")}<span>ارسال پرسش</span></button>
  </form>
</section>'''


def report_block(s, b):
    if s.get("reports_enabled") != "1":
        return ""
    opts = "".join(f'<option value="{esc(c)}">{esc(t)}</option>'
                   for c, t in db.REPORT_REASONS)
    return f'''<details class="card glass card-pad mt-lg reveal">
  <summary style="cursor:pointer;font-weight:700;display:flex;align-items:center;gap:8px">
    {icon("alert")}<span>گزارش مشکل در این صفحه</span></summary>
  <p class="text-sm text-muted mt-md">اطلاعات اشتباه است؟ مغازه تعطیل شده؟ به ما بگویید تا اصلاح کنیم.</p>
  <form method="post" action="/b/{esc(b['slug'])}/report" class="mt-md" data-validate>
    <div class="field"><label class="field-label" for="rp-reason">دلیل<span class="req">*</span></label>
      <select class="select" id="rp-reason" name="reason" required>{opts}</select></div>
    <div class="field"><label class="field-label" for="rp-body">توضیح</label>
      <textarea class="textarea" id="rp-body" name="body" style="min-height:70px"
        placeholder="هرچه بیشتر توضیح دهید، سریع‌تر رسیدگی می‌کنیم."></textarea></div>
    <div class="field"><label class="field-label" for="rp-who">شمارهٔ تماس شما</label>
      <input class="input nums" id="rp-who" name="reporter" dir="ltr" inputmode="numeric"
             placeholder="اختیاری — برای پیگیری"></div>
    <button class="btn btn-glass" type="submit">{icon("send")}<span>ارسال گزارش</span></button>
  </form>
</details>'''


def ad_block(slot, s):
    """Renders one ad and counts the impression. Click goes through /ad/<id>
    so the click counter is real, not a guess."""
    if s.get("ads_enabled") != "1":
        return ""
    a = db.pick_ad(slot)
    if not a:
        return ""
    img = (f'<img src="{esc(a["image"])}" alt="" loading="lazy" decoding="async">'
           if a.get("image") else "")
    return f'''<a class="ad-slot reveal" href="/ad/{a['id']}" rel="nofollow sponsored noopener">
  <span class="ad-flag">تبلیغ</span>
  <span class="inner">{img}
    <span><span class="t">{esc(a['title'])}</span>
      {f'<span class="s">{esc(a["body"])}</span>' if a.get('body') else ''}</span>
    {icon("chevron-left")}</span></a>'''


def compare_button(slug, name):
    return (f'<button class="cmp-btn" type="button" data-cmp="{esc(slug)}" '
            f'data-cmp-name="{esc(name)}" aria-pressed="false">'
            f'{icon("layers")}<span>مقایسه</span></button>')


def compare_tray():
    return f'''<div class="cmp-tray" data-cmp-tray hidden>
  <strong>{icon("layers")} مقایسه</strong>
  <div class="chips" data-cmp-chips></div>
  <a class="btn btn-primary btn-sm" href="/compare" data-cmp-go>
    {icon("arrow-left")}<span>مقایسه کن</span></a>
  <button class="btn btn-ghost btn-sm" type="button" data-cmp-clear>
    {icon("x")}<span>پاک کردن</span></button>
</div>'''


# ==========================================================================
#  COMPARE PAGE
# ==========================================================================
def compare(s, slugs, token=""):
    cats = db.category_tree()
    ci = _cat_icons()
    catnames = {c["slug"]: c["name"] for c in db.categories(only_active=False)}
    rows = [b for b in (db.business(slug=x) for x in slugs[:4]) if b]

    if not rows:
        body = f'''<div class="container-wide">{breadcrumb(("مقایسه", None))}
  <header class="page-hero"><span class="eyebrow">{icon("layers")}<span>ابزار انتخاب</span></span>
    <h1>مقایسهٔ کسب‌وکارها</h1>
    <p>تا چهار کسب‌وکار را کنار هم بگذارید و ویژگی‌هایشان را مقایسه کنید.</p></header></div>
<section class="section-sm"><div class="container-wide">
  {empty_state("layers", "چیزی برای مقایسه انتخاب نشده",
    "در فهرست کسب‌وکارها روی دکمهٔ «مقایسه» هر کارت بزنید تا اینجا بیاید.",
    f'<a class="btn btn-primary mt-lg" href="/businesses">{icon("grid")}<span>مرور کسب‌وکارها</span></a>')}
</div></section>'''
        return page(s, "مقایسه", body, "/businesses", token=token, cats=cats,
                    extra_js=CMP_JS)

    bmap = db.badges_map([b["id"] for b in rows])
    heads = "".join(f'''<th><a href="/b/{esc(b['slug'])}">
      <img src="/assets/img/icons/{esc(ci.get(b['cat_slug'],'store'))}@2x.png" alt=""
        width="48" height="48" loading="lazy"><br>{esc(b['name'])}</a>
      <div class="mt-sm"><button class="btn btn-ghost btn-sm" type="button"
        data-cmp="{esc(b['slug'])}" data-cmp-name="{esc(b['name'])}"
        aria-pressed="true">{icon("x")}<span>حذف</span></button></div></th>''' for b in rows)

    def row(label, fn):
        return (f'<tr><th>{esc(label)}</th>'
                + "".join(f'<td>{fn(b)}</td>' for b in rows) + '</tr>')

    def rating_cell(b):
        if not b.get("nreviews"):
            return '<span class="text-muted">بدون نظر</span>'
        return (f'{stars(b["rating"])} <strong class="nums">{fa(b["rating"])}</strong>'
                f'<br><small class="text-muted">{fa(b["nreviews"])} نظر</small>')

    def hours_cell(b):
        hm = b.get("hours_map") or {}
        if not hm:
            return '<span class="text-muted">ثبت نشده</span>'
        DAYS = [("sat", "شنبه"), ("sun", "یک‌شنبه"), ("mon", "دوشنبه"), ("tue", "سه‌شنبه"),
                ("wed", "چهارشنبه"), ("thu", "پنج‌شنبه"), ("fri", "جمعه")]
        out = []
        for k, lbl in DAYS:
            v = hm.get(k)
            out.append(f'{lbl}: ' + (f'<span class="nums">{v[0][0]}–{v[0][1]}</span>'
                                     if v else 'تعطیل'))
        return '<span class="text-xs">' + "<br>".join(out) + "</span>"

    def crit_cell(b):
        cr = db.criteria_averages(b["id"])
        if not cr:
            return '<span class="text-muted">—</span>'
        return "<br>".join(f'<span class="text-xs">{esc(c["label"])}: '
                           f'<strong class="nums">{fa(c["avg"])}</strong></span>' for c in cr)

    def badge_cell(b):
        bl = bmap.get(b["id"], [])
        return badge_strip(b["id"], bl) if bl else '<span class="text-muted">—</span>'

    def yn(v):
        return (f'<span style="color:var(--color-primary);font-weight:700">'
                f'{icon("check")} بله</span>' if v else
                '<span class="text-muted">خیر</span>')

    trs = "".join([
        row("دسته", lambda b: esc(catnames.get(b["cat_slug"], b["cat_slug"]))),
        row("امتیاز", rating_cell),
        row("امتیاز تفکیکی", crit_cell),
        row("نشان‌ها", badge_cell),
        row("نشانی", lambda b: esc(b.get("address")) or '<span class="text-muted">—</span>'),
        row("تلفن", lambda b: (f'<a class="nums" href="tel:{esc(b["phone"])}">{esc(b["phone"])}</a>'
                               if b.get("phone") else '<span class="text-muted">—</span>')),
        row("ساعت کاری", hours_cell),
        row("محصول/خدمت", lambda b: f'<span class="nums">{fa(db.items_count(b["id"]))}</span> مورد'),
        row("گالری تصویر", lambda b: f'<span class="nums">{fa(len(b.get("images") or []))}</span> عکس'),
        row("نوبت‌دهی آنلاین", lambda b: yn(b.get("booking_on"))),
        row("واتساپ", lambda b: yn(b.get("whatsapp"))),
        row("تأییدشده", lambda b: yn(b.get("verified"))),
        row("بازدید", lambda b: f'<span class="nums">{fa_group(b.get("views") or 0)}</span>'),
        row("", lambda b: f'<a class="btn btn-primary btn-sm" href="/b/{esc(b["slug"])}">'
                          f'{icon("arrow-left")}<span>مشاهده</span></a>'),
    ])

    body = f'''<div class="container-wide">
  {breadcrumb(("کسب‌وکارها", "/businesses"), ("مقایسه", None))}
  <header class="page-hero"><span class="eyebrow">{icon("layers")}<span>ابزار انتخاب</span></span>
    <h1>مقایسهٔ {fa(len(rows))} کسب‌وکار</h1>
    <p>همهٔ ویژگی‌ها کنار هم، تا بدون رفت‌وبرگشت بین صفحه‌ها تصمیم بگیرید.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="card glass card-pad">
    <div class="table-wrap"><table class="cmp-table">
      <thead><tr><th></th>{heads}</tr></thead><tbody>{trs}</tbody></table></div>
  </div>
  <div class="text-center mt-xl">
    <a class="btn btn-glass" href="/businesses">{icon("grid")}<span>افزودن کسب‌وکار دیگر</span></a>
  </div>
</div></section>
{compare_tray()}'''
    return page(s, "مقایسهٔ کسب‌وکارها", body, "/businesses", token=token,
                cats=cats, extra_js=CMP_JS)


# ==========================================================================
#  NEARBY (radius search)
# ==========================================================================
def nearby_page(s, token=""):
    cats = db.category_tree()
    copts = '<option value="">همهٔ دسته‌ها</option>' + "".join(
        f'<option value="{esc(c["slug"])}">{esc(c["name"])}</option>' for c in cats)
    withgeo = len([b for b in db.businesses() if b["lat"] and b["lng"]])

    body = f'''<div class="container-wide">
  {breadcrumb(("نزدیک من", None))}
  <header class="page-hero"><span class="eyebrow">{icon("compass")}<span>جست‌وجوی شعاعی</span></span>
    <h1>کسب‌وکارهای نزدیک من</h1>
    <p>موقعیت خود را بدهید تا نزدیک‌ترین کسب‌وکارها را با فاصلهٔ دقیق ببینید.
      موقعیت شما فقط در مرورگر شما می‌ماند و ذخیره نمی‌شود.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="near-bar mb-lg">
    <button class="btn btn-primary" type="button" data-geo>
      {icon("target")}<span>پیدا کردن موقعیت من</span></button>
    <label class="sr-only" for="near-cat">دسته</label>
    <select class="select" id="near-cat" data-near-cat>{copts}</select>
    <label class="range">
      <span class="text-xs text-muted">شعاع: <strong class="nums" data-near-r>۳</strong> کیلومتر</span>
      <input type="range" min="1" max="15" value="3" step="1" data-near-range
             aria-label="شعاع جست‌وجو به کیلومتر" style="width:100%">
    </label>
    <span class="text-xs text-muted" data-near-status>در انتظار اجازهٔ دسترسی به موقعیت…</span>
  </div>
  <div class="grid grid-3" data-near-grid></div>
  <div data-near-empty>{empty_state("compass", "هنوز موقعیتی مشخص نشده",
    f"روی «پیدا کردن موقعیت من» بزنید. در حال حاضر {withgeo} کسب‌وکار روی نقشه ثبت شده‌اند.")}</div>
</div></section>'''
    return page(s, "نزدیک من", body, "/map", token=token, cats=cats, extra_js=NEAR_JS)


# ==========================================================================
#  CITY EVENTS
# ==========================================================================
FA_MONTH = ["ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن", "ژوئیه",
            "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"]


def _date_box(d, past=False):
    if not d:
        return f'<span class="event-date{" is-past" if past else ""}"><span class="d">—</span></span>'
    try:
        y, m, day = d[:10].split("-")
        return (f'<span class="event-date"><span class="d nums">{fa(int(day))}</span>'
                f'<span class="m">{FA_MONTH[int(m)-1]}</span></span>')
    except Exception:
        return f'<span class="event-date"><span class="d">—</span></span>'


def events(s, token=""):
    cats = db.category_tree()
    rows = db.cityevents(status="published")
    upcoming = [e for e in rows if not e["past"]]
    past = [e for e in rows if e["past"]]

    def card(e):
        return f'''<article class="card card-hover glass card-pad reveal event-card{" is-past" if e['past'] else ""}">
      {_date_box(e['date'], e['past'])}
      <div style="flex:1;min-width:0">
        <h3 class="card-title"><a href="/events/{esc(e['slug'])}">{esc(e['title'])}</a></h3>
        <div class="card-meta">
          {f'{icon("clock")}<span class="nums">{fa(e["time"])}</span>' if e.get('time') else ''}
          {f'{icon("pin")}<span>{esc(e["place"])}</span>' if e.get('place') else ''}</div>
        <p class="card-desc">{esc(e['descr'])[:140]}</p>
        {f'<a class="btn btn-ghost btn-sm mt-sm" href="/b/{esc(e["bizslug"])}">{icon("store")}<span>{esc(e["bizname"])}</span></a>' if e.get('bizslug') else ''}
      </div></article>'''

    up_html = (f'<div class="grid grid-2">{"".join(card(e) for e in upcoming)}</div>'
               if upcoming else empty_state("calendar", "رویداد پیش‌رویی ثبت نشده",
                   "جشنواره‌ها و مناسبت‌های شهر به‌محض اعلام اینجا منتشر می‌شود."))
    past_html = ""
    if past:
        past_html = f'''<section class="section-sm"><div class="container-wide">
      {section_head("بایگانی", "رویدادهای گذشته", eyebrow_icon="clock")}
      <div class="grid grid-2">{"".join(card(e) for e in past[:8])}</div></div></section>'''

    body = f'''<div class="container-wide">
  {breadcrumb(("رویدادهای شهر", None))}
  <header class="page-hero"><span class="eyebrow">{icon("calendar")}<span>تقویم نجف‌آباد</span></span>
    <h1>رویدادهای شهر</h1>
    <p>جشنواره‌ها، افتتاحیه‌ها، حراج‌های فصلی و مناسبت‌های بازارچه.</p></header>
</div>
<section class="section-sm"><div class="container-wide">{up_html}</div></section>
{past_html}
{jsonld(*[db.jsonld_event(e) for e in upcoming[:10]])}'''
    return page(s, "رویدادهای شهر", body, "/events", token=token, cats=cats)


def event_detail(s, slug, token=""):
    e = db.cityevent(slug=slug)
    if not e or e["status"] != "published":
        return None
    cats = db.category_tree()
    paras = "".join(f"<p>{esc(x)}</p>" for x in (e["descr"] or "").split("\n") if x.strip())
    body = f'''<div class="container-wide">
  {breadcrumb(("رویدادهای شهر", "/events"), (e["title"], None))}
  <header class="page-hero"><h1>{esc(e['title'])}</h1>
    <div class="cluster mt-md">
      {f'<span class="badge badge-info">{icon("calendar")}<span class="nums">{fa(e["date"])}</span></span>' if e.get('date') else ''}
      {f'<span class="badge badge-neutral">{icon("clock")}<span class="nums">{fa(e["time"])}</span></span>' if e.get('time') else ''}
      {f'<span class="badge badge-neutral">{icon("pin")}<span>{esc(e["place"])}</span></span>' if e.get('place') else ''}
    </div></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="card glass card-pad prose reveal" style="max-width:none">
    {paras or '<p class="text-muted">توضیحی ثبت نشده.</p>'}
    {f'<hr class="divider"><a class="btn btn-primary" href="/b/{esc(e["bizslug"])}">{icon("store")}<span>صفحهٔ {esc(e["bizname"])}</span></a>' if e.get('bizslug') else ''}
  </div>
  <div class="text-center mt-xl"><a class="btn btn-glass" href="/events">
    {icon("arrow-left")}<span>همهٔ رویدادها</span></a></div>
</div></section>
{jsonld(db.jsonld_event(e))}'''
    return page(s, e["title"], body, "/events", desc=e["descr"][:150],
                token=token, cats=cats)


# ==========================================================================
#  LOCAL PRICE COMPARISON  ("چند فروشی؟")
#
#  Torob answers "who sells this cheapest online". Nobody answers it for the
#  shops you can walk to. This page does, from the catalogues shopkeepers
#  already keep, and it is honest about its limits: it shows when a price was
#  last updated and never claims to cover shops that have not listed anything.
# ==========================================================================
def price_compare(s, term="", cat="", key="", token=""):
    cats = db.category_tree()
    groups = db.comparable_items(cat=cat or None, term=term)
    st = db.price_stats()

    copts = '<option value="">همهٔ دسته‌ها</option>' + "".join(
        f'<option value="{esc(c["slug"])}"'
        f'{" selected" if cat == c["slug"] else ""}>{esc(c["name"])}</option>'
        for c in cats)

    # ---- a single expanded group, when one is asked for
    detail = ""
    if key:
        g = next((x for x in groups if x["key"] == key), None) or db.price_group(key)
        if g:
            rows = ""
            for i, o in enumerate(g["offers"]):
                cheap = o["is_cheapest"]
                rows += f'''<tr class="{"is-best" if cheap else ""}">
          <td class="rank nums">{fa(i + 1)}</td>
          <td><a href="/b/{esc(o["bizslug"])}"><strong>{esc(o["bizname"])}</strong></a>
            {f'<span class="badge badge-open">{icon("award")}<span>ارزان‌ترین</span></span>' if cheap else ''}
          </td>
          <td class="num"><strong class="nums">{esc(o["price_text"])}</strong></td>
          <td class="num">{'<span class="text-muted">—</span>' if cheap else
                           f'<span class="over-pct nums">+{fa(o["over_pct"])}٪</span>'}</td>
          <td class="actions"><a class="btn btn-primary btn-sm" href="/b/{esc(o["bizslug"])}">
            {icon("store")}<span>دیدن مغازه</span></a></td>
        </tr>'''
            detail = f'''<div class="card glass card-pad mb-lg" id="cmp-detail">
  <div class="between mb-md">
    <h2 class="card-title">{icon("chart")} {esc(g["title"])}</h2>
    <a class="btn btn-ghost btn-sm" href="/prices">{icon("x")}<span>بستن</span></a>
  </div>
  <div class="price-summary mb-lg">
    <div><span class="k">ارزان‌ترین</span><strong class="v nums">{esc(g["min_text"])}</strong></div>
    <div><span class="k">گران‌ترین</span><strong class="v nums">{esc(g["max_text"])}</strong></div>
    <div class="save"><span class="k">اختلاف</span>
      <strong class="v nums">{esc(g["spread_text"])}</strong>
      <small class="nums">{fa(g["spread_pct"])}٪</small></div>
  </div>
  <div class="table-wrap"><table class="table price-table">
    <thead><tr><th>#</th><th>مغازه</th><th>قیمت</th><th>اختلاف</th><th></th></tr></thead>
    <tbody>{rows}</tbody></table></div>
</div>'''

    # ---- the list of comparable goods
    cards = ""
    for i, g in enumerate(groups):
        bars = ""
        for o in g["offers"][:4]:
            pct = int(o["price"] / g["max"] * 100) if g["max"] else 0
            bars += f'''<div class="pbar-row">
        <span class="pbar-name">{esc(o["bizname"])}</span>
        <span class="pbar-track"><span class="pbar-fill{" is-best" if o["is_cheapest"] else ""}"
              style="width:{max(8, pct)}%"></span></span>
        <span class="pbar-val nums">{esc(o["price_text"])}</span>
      </div>'''
        save = ""
        if g["spread"] > 0:
            save = (f'<span class="badge badge-open">{icon("trending")}'
                    f'<span>تا {fa_group(g["spread"])} تومان ارزان‌تر</span></span>')
        else:
            save = (f'<span class="badge badge-neutral">{icon("check")}'
                    f'<span>قیمت یکسان</span></span>')
        cards += f'''<article class="card glass card-pad price-card reveal-3d" data-delay="{i * 40}">
  <div class="between mb-sm" style="align-items:flex-start;gap:8px">
    <h3 class="card-title">{esc(g["title"])}</h3>
    <span class="badge badge-info nums">{fa(g["n"])} مغازه</span>
  </div>
  {f'<div class="text-xs text-muted mb-sm">{esc(g["unit"])}</div>' if g["unit"] else ''}
  <div class="pbars mb-md">{bars}</div>
  <div class="between">
    {save}
    <a class="btn btn-glass btn-sm" href="/prices?key={urlq(g["key"])}{f'&cat={esc(cat)}' if cat else ''}#cmp-detail">
      {icon("layers")}<span>مقایسهٔ کامل</span></a>
  </div>
</article>'''

    if not cards:
        cards = empty_state(
            "chart",
            "هنوز کالای قابل مقایسه‌ای نیست" if not (term or cat) else "چیزی پیدا نشد",
            "مقایسه وقتی ممکن است که دست‌کم دو مغازه یک کالا را با قیمت مشخص "
            "ثبت کرده باشند. هرچه مغازه‌داران بیشتری کاتالوگ خود را پر کنند، "
            "این صفحه کامل‌تر می‌شود.",
            f'<a class="btn btn-primary mt-lg" href="/submit">{icon("plus")}'
            f'<span>کسب‌وکار خود را ثبت کنید</span></a>')
    else:
        cards = f'<div class="grid grid-3 price-grid" data-stagger>{cards}</div>'

    body = f'''<div class="container-wide">
  {breadcrumb(("مقایسهٔ قیمت", None))}
  <header class="page-hero"><span class="eyebrow">{icon("chart")}<span>ویژهٔ نجف‌آباد</span></span>
    <h1>یک کالا، چند مغازه، چند قیمت</h1>
    <p>قیمت کالاهای پرمصرف را بین مغازه‌های شهر مقایسه کنید و قبل از
       بیرون رفتن بدانید کجا ارزان‌تر است. قیمت‌ها را خودِ مغازه‌داران
       ثبت می‌کنند.</p></header>
</div>
<section class="section-sm"><div class="container-wide">
  <div class="grid grid-3 mb-lg" data-stagger>
    {stat_card("layers", st["groups"], "کالای قابل مقایسه")}
    {stat_card("store", st["offers"], "قیمت ثبت‌شده", delay=60)}
    {stat_card("trending", st["best_saving"], "بیشترین صرفه‌جویی (تومان)",
               suffix="", delay=120)}
  </div>

  <form class="dir-toolbar mb-lg" method="get" action="/prices">
    <div class="dir-row">
      <span class="search-wrap">{icon("search", cls="search-icon")}
        <label class="sr-only" for="pq">جست‌وجوی کالا</label>
        <input class="input" id="pq" name="q" type="search" value="{esc(term)}"
               placeholder="نام کالا — مثلاً شیر، برنج، نان…" autocomplete="off"></span>
      <label class="sr-only" for="pcat">دسته</label>
      <select class="select" id="pcat" name="cat" onchange="this.form.submit()">{copts}</select>
      <button class="btn btn-primary" type="submit">{icon("search")}<span>جست‌وجو</span></button>
    </div>
  </form>

  {detail}
  {cards}

  <div class="alert alert-info mt-lg">{icon("info")}<span>
    قیمت‌ها را مغازه‌داران در کاتالوگ خودشان وارد می‌کنند و ممکن است
    تغییر کرده باشد. پیش از خرید، تلفنی تأیید بگیرید. اگر مغازه‌دارید و
    می‌خواهید قیمت‌هایتان اینجا دیده شود،
    <a href="/submit">کسب‌وکارتان را ثبت کنید</a>.</span></div>
</div></section>'''
    return page(s, "مقایسهٔ قیمت در نجف‌آباد", body, "/prices", token=token,
                cats=cats,
                desc="قیمت کالاهای پرمصرف را بین مغازه‌های نجف‌آباد مقایسه کنید.")


def price_context_block(biz_id):
    """On a shop's own page: for each product it sells that other shops also
    sell, say plainly where this shop stands.

    This is deliberately even-handed. When the shop is cheapest it says so —
    that is a selling point it earned. When it is not, it says that too,
    because a directory that only ever flatters shops is worth nothing to the
    shopper it is supposed to serve, and shoppers are who bring the shops.
    """
    groups = [g for g in db.comparable_items()
              if any(o["biz_id"] == biz_id for o in g["offers"])]
    if not groups:
        return ""

    wins = rows = ""
    n_best = 0
    for g in groups:
        mine = next(o for o in g["offers"] if o["biz_id"] == biz_id)
        if mine["is_cheapest"]:
            n_best += 1
        rank = g["offers"].index(mine) + 1
        if mine["is_cheapest"]:
            verdict = (f'<span class="badge badge-open">{icon("award")}'
                       f'<span>ارزان‌ترین در شهر</span></span>')
        else:
            verdict = (f'<span class="text-xs text-muted">'
                       f'رتبهٔ {fa(rank)} از {fa(g["n"])} — '
                       f'{fa_group(mine["over_min"])} تومان بیشتر از ارزان‌ترین</span>')
        rows += f'''<div class="info-row">
      <span class="k">{esc(g["title"])}</span>
      <span class="v"><strong class="nums">{esc(mine["price_text"])}</strong> {verdict}</span>
    </div>'''

    if n_best:
        wins = (f'<div class="alert alert-success mb-md">{icon("award")}<span>'
                f'این مغازه در <strong>{fa(n_best)}</strong> کالا '
                f'ارزان‌ترین قیمت شهر را دارد.</span></div>')

    return f'''<div class="card glass card-pad reveal" id="price-context">
  <div class="between mb-md">
    <h3 class="card-title">{icon("chart")} قیمت‌ها در مقایسه با شهر</h3>
    <a class="btn btn-ghost btn-sm" href="/prices">{icon("layers")}<span>همهٔ مقایسه‌ها</span></a>
  </div>
  {wins}
  {rows}
  <p class="text-xs text-muted mt-md">{icon("info")} مقایسه بر پایهٔ قیمت‌هایی است
    که مغازه‌داران خودشان ثبت کرده‌اند.</p>
</div>'''


# ==========================================================================
#  چانه‌زنی — the offer form and the negotiation thread
# ==========================================================================
HAG_STATUS = {
    "open":      ("badge-warn",   "در انتظار پاسخ فروشنده"),
    "countered": ("badge-info",   "فروشنده قیمت دیگری پیشنهاد داد"),
    "accepted":  ("badge-open",   "پذیرفته شد"),
    "declined":  ("badge-closed", "رد شد"),
    "expired":   ("badge-neutral", "منقضی شد"),
}


def haggle_button(it):
    """The 'make an offer' control that sits next to a haggle-able price."""
    if not db.haggle_allowed(it):
        return ""
    return (f'<a class="btn btn-accent btn-sm" href="/haggle/{it["id"]}">'
            f'{icon("tag")}<span>پیشنهاد قیمت بدهید</span></a>')


def haggle_badge(it):
    if not db.haggle_allowed(it):
        return ""
    return (f'<span class="badge badge-accent haggle-flag">{icon("tag")}'
            f'<span>قابل چانه‌زنی</span></span>')


def haggle_form(s, item_id, token="", sent=None, err=""):
    """Where a buyer names their price."""
    it = db.item(item_id)
    if not it:
        return None
    biz = db.business(bid=it["biz_id"])
    if not db.haggle_allowed(it):
        return page(s, "چانه‌زنی", f'''<div class="container">
  {breadcrumb(("چانه‌زنی", None))}
  {empty_state("tag", "این کالا چانه‌زنی ندارد",
               "فروشندهٔ این کالا قیمت ثابت گذاشته است. می‌توانید مستقیم تماس بگیرید.",
               f'<a class="btn btn-primary mt-lg" href="/b/{esc(biz["slug"]) if biz else ""}">'
               f'{icon("store")}<span>دیدن مغازه</span></a>')}
</div>''', "", token=token, cats=db.category_tree())

    listed = int(it.get("price") or 0)
    cfg = db.haggle_settings()

    # The hint must point at a price that would actually be ACCEPTED. The old
    # version quoted min_pct (50% of list) — the threshold below which an
    # offer is auto-countered — so it was steering buyers straight into a
    # refusal. Nudge just above the real floor instead, without ever
    # revealing the floor itself: rounding to the nearest 1,000 keeps the
    # seller's exact number private while still being useful.
    floor = int(it.get("floor_price") or 0)
    if floor:
        floor_hint = int(round(floor * 1.02 / 1000.0)) * 1000
    else:
        floor_hint = int(round(listed * 0.9 / 1000.0)) * 1000

    if sent:
        st = sent["verdict"]
        if st == "accepted":
            box = f'''<div class="hag-result is-yes">
        <span class="hag-emoji" aria-hidden="true">{icon("check-circle")}</span>
        <h2>پیشنهاد شما پذیرفته شد</h2>
        <p>فروشنده از قبل اعلام کرده بود تا این قیمت می‌فروشد، پس معامله
           همین حالا قطعی شد. برای هماهنگی تحویل تماس بگیرید.</p>
        <div class="cluster" style="justify-content:center">
          <a class="btn btn-primary" href="tel:{esc(biz["phone"])}">
            {icon("phone")}<span>تماس با {esc(biz["name"])}</span></a>
          <a class="btn btn-glass" href="/offer/{esc(sent["token"])}">
            {icon("list")}<span>دیدن گفت‌وگو</span></a>
        </div></div>'''
        elif st == "countered":
            box = f'''<div class="hag-result is-mid">
        <span class="hag-emoji" aria-hidden="true">{icon("tag")}</span>
        <h2>فروشنده قیمت دیگری پیشنهاد داد</h2>
        <p>پیشنهاد شما از کمترین قیمت این کالا پایین‌تر بود، ولی فروشنده
           در را نبسته — قیمت پیشنهادی او را ببینید.</p>
        <a class="btn btn-primary" href="/offer/{esc(sent["token"])}">
          {icon("list")}<span>دیدن پیشنهاد فروشنده</span></a></div>'''
        else:
            box = f'''<div class="hag-result">
        <span class="hag-emoji" aria-hidden="true">{icon("send")}</span>
        <h2>پیشنهاد شما ثبت شد</h2>
        <p>فروشنده پیشنهاد شما را می‌بیند و تا {fa(cfg["ttl"])} ساعت آینده
           پاسخ می‌دهد. این نشانی را نگه دارید تا نتیجه را ببینید.</p>
        <a class="btn btn-primary" href="/offer/{esc(sent["token"])}">
          {icon("list")}<span>پیگیری پیشنهاد</span></a></div>'''
        body = f'<div class="container"><section class="section-sm">{box}</section></div>'
        return page(s, "پیشنهاد شما ثبت شد", body, "", token=token,
                    cats=db.category_tree())

    body = f'''<div class="container">
  {breadcrumb((biz["name"], f"/b/{biz['slug']}"), ("پیشنهاد قیمت", None))}
  <header class="page-hero"><span class="eyebrow">{icon("tag")}<span>چانه‌زنی</span></span>
    <h1>قیمت خودتان را پیشنهاد بدهید</h1>
    <p>مثل خرید حضوری در بازار — شما قیمت می‌گویید، فروشنده قبول می‌کند،
       رد می‌کند، یا قیمت دیگری پیشنهاد می‌دهد.</p></header>
</div>
<section class="section-sm"><div class="container">
  {flash("err", err) if err else ""}
  <div class="card glass card-pad mb-lg">
    <div class="hag-item">
      {f'<img src="{esc(it["cover"])}" alt="" width="72" height="72" class="hag-thumb">' if it.get("cover") else ''}
      <div>
        <strong>{esc(it["title"])}</strong>
        <div class="text-sm text-muted">{esc(biz["name"])}</div>
        <div class="hag-listed">قیمت اعلام‌شده:
          <strong class="nums">{esc(it["price_text"])}</strong></div>
      </div>
    </div>
  </div>

  <form class="card glass card-pad" method="post" action="/haggle/{it["id"]}" data-validate>
    <div class="field">
      <label class="field-label" for="hg-offer">پیشنهاد شما (تومان)<span class="req">*</span></label>
      <input class="input nums" id="hg-offer" name="offer" inputmode="numeric"
             required placeholder="مثلاً {fa_group(int(listed * 0.9))}">
      <p class="field-hint">پیشنهاد خیلی پایین معمولاً جواب نمی‌گیرد —
         قیمت‌های نزدیک به {fa_group(floor_hint)} تومان شانس بیشتری دارند.</p>
    </div>
    <div class="grid grid-2" style="gap:0 var(--space-md)">
      <div class="field"><label class="field-label" for="hg-qty">تعداد</label>
        <input class="input nums" id="hg-qty" name="qty" type="number" min="1" value="1"></div>
      <div class="field"><label class="field-label" for="hg-name">نام شما<span class="req">*</span></label>
        <input class="input" id="hg-name" name="name" required minlength="2"></div>
    </div>
    <div class="field"><label class="field-label" for="hg-phone">شمارهٔ تماس<span class="req">*</span></label>
      <input class="input nums" id="hg-phone" name="phone" type="tel" required
             placeholder="09xxxxxxxxx">
      <p class="field-hint">فقط برای همین معامله استفاده می‌شود و روی سایت نمایش داده نمی‌شود.</p></div>
    <div class="field"><label class="field-label" for="hg-note">توضیح (اختیاری)</label>
      <textarea class="textarea" id="hg-note" name="note" style="min-height:80px"
        placeholder="مثلاً: نقد پرداخت می‌کنم، یا امروز می‌آیم می‌برم."></textarea></div>
    <button class="btn btn-primary btn-lg" type="submit">
      {icon("send")}<span>ارسال پیشنهاد</span></button>
    <p class="text-xs text-muted mt-md">{icon("info")} پیشنهاد شما تا
      {fa(cfg["ttl"])} ساعت معتبر است. اگر فروشنده قبول کند، خودتان خبردار می‌شوید.</p>
  </form>
</div></section>'''
    return page(s, f"پیشنهاد قیمت — {it['title']}", body, "", token=token,
                cats=db.category_tree())


def haggle_thread_page(s, thread_token, token="", err=""):
    """The negotiation itself, readable by whoever holds the link."""
    rows = db.haggle_thread(token=thread_token)
    if not rows:
        return None
    root = rows[0]
    biz = db.business(bid=root["biz_id"])
    it = db.item(root["item_id"]) if root.get("item_id") else None
    last = rows[-1]

    # The headline status describes the NEGOTIATION, not the last row. The
    # last row of a countered thread is the seller's fresh offer, whose own
    # status is 'open' — reading that literally told the buyer they were
    # "awaiting the seller" while the seller's counter sat right above it.
    if last["status"] == "accepted" or root["status"] == "accepted":
        state = "accepted"
    elif root["status"] in ("declined", "expired"):
        state = root["status"]
    elif not last["is_buyer"]:
        state = "countered"      # the ball is in the buyer's court
    else:
        state = "open"           # waiting on the shopkeeper
    cls, label = HAG_STATUS.get(state, ("badge-neutral", state))

    bubbles = ""
    for r in rows:
        who = "شما" if r["is_buyer"] else esc(biz["name"])
        side = "is-buyer" if r["is_buyer"] else "is-seller"
        bubbles += f'''<div class="hag-bubble {side}">
      <div class="hag-who">{icon("user" if r["is_buyer"] else "store")}<span>{who}</span>
        <time class="nums">{esc(str(r["created"])[:16])}</time></div>
      <div class="hag-price nums">{esc(r["offer_text"])}</div>
      {f'<p class="hag-note">{esc(r["note"])}</p>' if r.get("note") else ''}
    </div>'''

    # A buyer may counter only while the thread is still live.
    reply = ""
    if last["status"] in ("open", "countered") and not last["is_buyer"]:
        reply = f'''<form class="card glass card-pad mt-lg" method="post"
      action="/offer/{esc(thread_token)}" data-validate>
  <h3 class="card-title mb-md">{icon("tag")} پاسخ شما</h3>
  <div class="field"><label class="field-label" for="rp-offer">قیمت پیشنهادی تازه (تومان)</label>
    <input class="input nums" id="rp-offer" name="offer" inputmode="numeric" required></div>
  <div class="field"><label class="field-label" for="rp-note">توضیح</label>
    <input class="input" id="rp-note" name="note"></div>
  <div class="cluster">
    <button class="btn btn-primary" type="submit" name="action" value="counter">
      {icon("send")}<span>ارسال پیشنهاد تازه</span></button>
    <button class="btn btn-glass" type="submit" name="action" value="accept"
      formnovalidate>{icon("check")}<span>قبول می‌کنم</span></button>
  </div>
</form>'''

    done = ""
    if state == "accepted":
        done = f'''<div class="alert alert-success mt-lg">{icon("check-circle")}<span>
      این معامله در قیمت <strong class="nums">{esc(last["offer_text"])}</strong> قطعی شد.
      برای هماهنگی با <a href="tel:{esc(biz["phone"])}">{esc(biz["phone"])}</a> تماس بگیرید.
    </span></div>'''

    body = f'''<div class="container">
  {breadcrumb((biz["name"], f"/b/{biz['slug']}"), ("گفت‌وگوی قیمت", None))}
  <header class="page-hero"><span class="eyebrow">{icon("tag")}<span>چانه‌زنی</span></span>
    <h1>{esc(it["title"]) if it else "گفت‌وگوی قیمت"}</h1>
    <p>{esc(biz["name"])} — <span class="badge {cls}">{esc(label)}</span></p></header>
</div>
<section class="section-sm"><div class="container">
  {flash("err", err) if err else ""}
  {f'<div class="card glass card-pad mb-lg"><div class="info-row">{icon("tag")}'
   f'<span class="k">قیمت اعلام‌شده</span>'
   f'<span class="v nums">{esc(it["price_text"])}</span></div></div>' if it else ''}
  <div class="hag-thread">{bubbles}</div>
  {done}
  {reply}
  <p class="text-xs text-muted mt-lg">{icon("info")} این نشانی خصوصی شماست؛
     هرکس آن را داشته باشد می‌تواند این گفت‌وگو را ببیند.</p>
</div></section>'''
    return page(s, "گفت‌وگوی قیمت", body, "", token=token, cats=db.category_tree())


# ---------------------------------------------------------------- features map
# Every capability the site has, on one page, each row a real link. Built
# because the shopkeeper features were invisible: they live behind /login, and
# a sign-in button with nothing written on it tells you nothing about what is
# on the other side. This doubles as the page to show a shopkeeper in person.
FEATURE_MAP = [
    ("برای مردم شهر", "users", [
        ("/businesses", "grid", "فهرست همهٔ کسب‌وکارها",
         "جست‌وجو بر پایهٔ نام، دسته، محله و امتیاز"),
        ("/map", "map", "نقشهٔ شهر",
         "روی نقشه ببینید کجاست؛ با یک کلیک مسیریابی"),
        ("/nearby", "compass", "نزدیک من",
         "نزدیک‌ترین مغازه‌ها بر پایهٔ موقعیت شما"),
        ("/catalog", "shopping", "محصولات و خدمات",
         "کالاها را مستقیم ببینید، نه فقط اسم مغازه"),
        ("/prices", "chart", "مقایسهٔ قیمت",
         "قیمت یک کالا را بین چند مغازه بسنجید"),
        ("/offers", "tag", "تخفیف‌های شهر",
         "همهٔ تخفیف‌های فعال یک‌جا"),
        ("/events", "calendar", "رویدادهای شهر",
         "نمایشگاه، جشنواره و بازارچه"),
        ("/blog", "book", "اخبار شهر",
         "نوشته‌ها و اطلاعیه‌های نجف‌آباد"),
        ("/compare", "layers", "مقایسهٔ کسب‌وکارها",
         "دو مغازه را کنار هم بگذارید"),
        ("/favorites", "heart", "علاقه‌مندی‌ها",
         "مغازه‌های موردعلاقه را نشان کنید"),
    ]),
    ("برای صاحبان کسب‌وکار", "store", [
        ("/submit", "plus", "ثبت کسب‌وکار — رایگان",
         "سه فیلد: نام، دسته و شماره تلفن"),
        ("/my/businesses", "store", "صفحهٔ اختصاصی مغازه",
         "عکس، ساعت کار، آدرس، شبکه‌های اجتماعی و پس‌زمینهٔ دلخواه"),
        ("/my/businesses", "grid", "بارکد QR ویترین",
         "دانلود کنید، چاپ کنید، روی شیشه بزنید"),
        ("/my/bookings", "calendar", "نوبت‌دهی اینترنتی",
         "مشتری خودش نوبت می‌گیرد، شما تأیید می‌کنید"),
        ("/my/inquiries", "send", "استعلام قیمت",
         "مشتری قیمت می‌پرسد، شما پاسخ می‌دهید"),
        ("/my/reviews", "message", "نظرات و امتیاز",
         "به نظر مشتری پاسخ بدهید"),
        ("/my/questions", "help", "پرسش و پاسخ",
         "سؤال‌های پرتکرار مشتری را همان‌جا جواب بدهید"),
        ("/my/tickets", "mail", "پشتیبانی مستقیم",
         "هر وقت کاری داشتید با مدیر سایت گفت‌وگو کنید"),
        ("/my/plan", "wallet", "اشتراک و آمار",
         "ببینید چند نفر شمارهٔ شما را گرفته‌اند"),
        ("/my/claim", "shield", "تصاحب کسب‌وکار",
         "مغازه‌تان از قبل ثبت شده؟ آن را به نام خود کنید"),
    ]),
]


def features(s, token="", me=None):
    cats = db.category_tree()
    blocks = ""
    for title, ic, rows in FEATURE_MAP:
        cards = ""
        for href, ri, rt, rd in rows:
            # An owner link is useless to a signed-out visitor unless it takes
            # them through the door and back — so it does exactly that.
            link = href
            if href.startswith("/my") and not me:
                link = "/login?next=" + urllib.parse.quote(href)
            lock = ('<span class="feat-lock">'
                    + icon("lock") + "<span>نیاز به ورود</span></span>"
                    ) if href.startswith("/my") and not me else ""
            cards += f'''<a class="feat-card" href="{esc(link)}">
              <span class="feat-ico">{icon(ri)}</span>
              <span class="feat-txt"><strong>{esc(rt)}</strong>
                <small>{esc(rd)}</small>{lock}</span>
              {icon("chevron-left")}</a>'''
        blocks += f'''<section class="section-sm"><div class="container-wide">
          {section_head("امکانات", title, eyebrow_icon=ic)}
          <div class="feat-grid">{cards}</div>
        </div></section>'''

    cta = "" if me else f'''<section class="section-sm"><div class="container-wide">
      <div class="card glass card-pad center">
        <h2 class="h3">مغازه دارید؟</h2>
        <p class="text-muted">ثبت کسب‌وکار رایگان است و کمتر از یک دقیقه طول می‌کشد.</p>
        <div class="row-center gap-sm mt-md wrap">
          <a class="btn btn-accent btn-lg" href="/submit">{icon("plus")}<span>ثبت کسب‌وکار</span></a>
          <a class="btn btn-ghost btn-lg" href="/login">{icon("store")}<span>ورود مغازه‌داران</span></a>
        </div>
      </div></div></section>'''

    body = f'''<div class="container-wide">{breadcrumb(("همهٔ امکانات", None))}
  <header class="page-hero">
    <span class="eyebrow">{icon("sparkles")}<span>راهنمای کامل</span></span>
    <h1>هر کاری در بازارچه می‌شود کرد</h1>
    <p class="lede">همهٔ امکانات سایت در یک صفحه. روی هر کدام بزنید تا مستقیم
       همان‌جا بروید.</p>
  </header></div>
{blocks}{cta}'''
    return page(s, "همهٔ امکانات", body, "", token=token, cats=cats)
