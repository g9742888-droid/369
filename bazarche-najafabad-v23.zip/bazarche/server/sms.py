# -*- coding: utf-8 -*-
"""
SMS delivery (Kavenegar-compatible), standard library only.

If no API key is configured the code is NOT sent anywhere — it is returned
so the interface can display it on screen. That keeps local/Pydroid use
fully working offline, and turns into real SMS the moment a key is saved.
"""

import json
import urllib.parse
import urllib.request

TIMEOUT = 8


def configured(settings):
    return bool((settings.get("sms_key") or "").strip())


def send_otp(settings, phone, code):
    """-> (delivered: bool, note: str)"""
    key = (settings.get("sms_key") or "").strip()
    if not key:
        return False, "کلید پیامک تنظیم نشده — کد روی صفحه نمایش داده می‌شود."

    template = (settings.get("sms_template") or "").strip()
    try:
        if template:
            # verification lookup: template-based, works even for users who
            # blocked promotional SMS
            url = (f"https://api.kavenegar.com/v1/{urllib.parse.quote(key)}"
                   f"/verify/lookup.json?receptor={urllib.parse.quote(phone)}"
                   f"&token={urllib.parse.quote(str(code))}"
                   f"&template={urllib.parse.quote(template)}")
        else:
            sender = (settings.get("sms_sender") or "").strip()
            text = f"کد ورود شما: {code}"
            url = (f"https://api.kavenegar.com/v1/{urllib.parse.quote(key)}"
                   f"/sms/send.json?receptor={urllib.parse.quote(phone)}"
                   f"&message={urllib.parse.quote(text)}")
            if sender:
                url += f"&sender={urllib.parse.quote(sender)}"

        with urllib.request.urlopen(url, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        status = (data.get("return") or {}).get("status")
        if status == 200:
            return True, "پیامک ارسال شد."
        return False, f"سرویس پیامک خطا داد ({status})."
    except Exception as e:
        return False, f"ارسال پیامک ناموفق بود: {type(e).__name__}"


def notify(settings, phone, text):
    """Plain informational SMS (booking, claim result...). Never raises."""
    key = (settings.get("sms_key") or "").strip()
    if not key or not phone:
        return False
    try:
        sender = (settings.get("sms_sender") or "").strip()
        url = (f"https://api.kavenegar.com/v1/{urllib.parse.quote(key)}"
               f"/sms/send.json?receptor={urllib.parse.quote(phone)}"
               f"&message={urllib.parse.quote(text)}")
        if sender:
            url += f"&sender={urllib.parse.quote(sender)}"
        with urllib.request.urlopen(url, timeout=TIMEOUT) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        return (data.get("return") or {}).get("status") == 200
    except Exception:
        return False
