# -*- coding: utf-8 -*-
"""
دادهٔ نمونه برای دیدن سایت پیش از انتشار

Ten believable Najafabad businesses spread across the tree, with reviews,
questions, a catalogue, an event and a banner — so you can judge the design
with something in it. Everything created here is tagged, and

    python3 tools/seed_demo.py --clear

removes every trace in one go. Nothing from this file should ever survive
into the live site.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

TAG = "نمونه‌آزمایشی"     # written into tags so cleanup is exact

BUSINESSES = [
    dict(slug="restaurant", name="کبابی برادران حیدری",
         descr="کباب کوبیده و برگ با گوشت تازهٔ روز، برنج ایرانی و نان داغ. پذیرش سفارش مجالس.",
         phone="09131110011", address="نجف‌آباد، خیابان امام، نبش کوچه ۱۴",
         lat=32.6352, lng=51.3661, featured=1, verified=1),
    dict(slug="coffeeshop", name="کافه ویونا",
         descr="قهوهٔ تخصصی با دان تازه‌رست، صبحانهٔ کامل و فضای دنج برای کار و مطالعه.",
         phone="09131110022", address="نجف‌آباد، بلوار آیت‌الله اشرفی، پلاک ۴۴",
         lat=32.6331, lng=51.3648, featured=1, verified=1),
    dict(slug="confectionery", name="قنادی گل‌محمدی",
         descr="شیرینی‌تر و خشک روزانه، کیک تولد سفارشی و دسر. تحویل در محل.",
         phone="09131110033", address="نجف‌آباد، خیابان شریعتی، جنب بانک ملی",
         lat=32.6368, lng=51.3679, featured=1, verified=1),
    dict(slug="mechanic", name="تعمیرگاه مرکزی نجف",
         descr="مکانیکی تخصصی خودروهای ایرانی و خارجی، دیاگ و سرویس دوره‌ای.",
         phone="09131110044", address="نجف‌آباد، جادهٔ اصفهان، کیلومتر ۲",
         lat=32.6301, lng=51.3702, verified=1),
    dict(slug="supermarket", name="سوپرمارکت ولیعصر",
         descr="خواربار، لبنیات، میوهٔ تازه و اقلام روزانه با قیمت مناسب.",
         phone="09131110055", address="نجف‌آباد، خیابان ولیعصر، پلاک ۸",
         lat=32.6344, lng=51.3690),
    dict(slug="dentist", name="دندان‌پزشکی دکتر رضوی",
         descr="ترمیم، عصب‌کشی، جرم‌گیری و طراحی لبخند. پذیرش با نوبت قبلی.",
         phone="09131110066", address="نجف‌آباد، خیابان منتظری، ساختمان پزشکان",
         lat=32.6359, lng=51.3634, verified=1, booking_on=1),
    dict(slug="salon", name="سالن زیبایی نگین",
         descr="میکاپ عروس، رنگ و مش، کراتین و شینیون با کادر مجرب.",
         phone="09131110077", address="نجف‌آباد، خیابان طالقانی، کوچه ۹",
         lat=32.6338, lng=51.3712, booking_on=1),
    dict(slug="mobileshop", name="موبایل ایده",
         descr="گوشی نو و کارکرده، لوازم جانبی و تعمیر تخصصی برد و گلس.",
         phone="09131110088", address="نجف‌آباد، خیابان امام، پاساژ مرکزی",
         lat=32.6349, lng=51.3667),
    dict(slug="breadshop", name="نانوایی سنگک سحر",
         descr="سنگک تازه با آرد درجه‌یک، پخت از ساعت ۵ صبح.",
         phone="09131110099", address="نجف‌آباد، محلهٔ جوی‌آباد، خیابان اصلی",
         lat=32.6390, lng=51.3625),
    dict(slug="carpetwash", name="قالیشویی الماس",
         descr="شستشوی فرش، موکت و مبل با ضمانت. رفت و برگشت رایگان.",
         phone="09131110100", address="نجف‌آباد، شهرک صنعتی، فاز ۱",
         lat=32.6280, lng=51.3740),
]

import json as _json

# Real trades keep different hours, and the "open now" badge is only worth
# looking at if the demo data reflects that. A bakery opening at dawn, a cafe
# running past midnight and a Friday-closed workshop each exercise a
# different branch of db.open_state().
def _h(spec):
    return _json.dumps(spec, ensure_ascii=False)

_ALLWEEK = ["sat", "sun", "mon", "tue", "wed", "thu", "fri"]
_SAT_THU = ["sat", "sun", "mon", "tue", "wed", "thu"]

HOURS_SHOP    = _h({d: [["09:00", "21:00"]] for d in _SAT_THU})          # عادی
HOURS_BAKERY  = _h({d: [["05:30", "11:00"], ["16:00", "20:30"]]          # دو شیفت
                    for d in _ALLWEEK})
HOURS_CAFE    = _h({d: [["10:00", "23:30"]] for d in _ALLWEEK})          # تا دیروقت
HOURS_LATE    = _h({d: [["20:00", "02:00"]] for d in _ALLWEEK})          # عبور از نیمه‌شب
HOURS_WORKSHOP= _h({d: [["08:00", "17:00"]] for d in _SAT_THU})          # جمعه تعطیل
HOURS_CLINIC  = _h({d: [["08:30", "13:00"], ["17:00", "20:00"]]
                    for d in _SAT_THU})

# assigned round-robin so the list always shows a mix of states
HOURS_SET = [HOURS_SHOP, HOURS_BAKERY, HOURS_CAFE, HOURS_WORKSHOP,
             HOURS_CLINIC, HOURS_LATE]
HOURS = HOURS_SHOP

REVIEWS = [
    ("مریم احمدی", 5, "کیفیت عالی بود و برخوردشان محترمانه. حتماً دوباره می‌آیم.",
     {"quality": 5, "price": 4, "speed": 5, "behaviour": 5}),
    ("رضا کاظمی", 4, "راضی بودم، فقط کمی شلوغ بود و باید صبر می‌کردم.",
     {"quality": 4, "price": 4, "speed": 3, "behaviour": 5}),
    ("سعید موسوی", 5, "قیمت منصفانه و کار تمیز. به دوستانم معرفی کردم.",
     {"quality": 5, "price": 5, "speed": 4, "behaviour": 5}),
]

QUESTIONS = [
    ("سارا", "پارکینگ دارید؟", "بله، پارکینگ رایگان برای مشتریان داریم."),
    ("حسین", "جمعه‌ها هم باز هستید؟", "جمعه‌ها تعطیل هستیم، شنبه تا پنجشنبه در خدمتیم."),
]

ITEMS = [
    dict(kind="product", title="چلوکباب کوبیده", price=290000, price_type="fixed",
         unit="هر پرس", descr="دو سیخ کوبیده با برنج ایرانی، گوجه و کره."),
    dict(kind="service", title="پذیرایی مجالس", price=0, price_type="call",
         descr="منوی کامل برای مراسم تا ۳۰۰ نفر، با سرویس‌دهی."),
    dict(kind="custom", title="سفارش ویژه", price=0, price_type="call",
         descr="منوی دلخواه شما را با هماهنگی قبلی آماده می‌کنیم."),
]

# --------------------------------------------------------------------------
#  Goods several shops in one town genuinely both sell.
#
#  The price-comparison page is only worth looking at when the same product
#  carries DIFFERENT prices, so each shop gets its own multiplier. These are
#  plausible 1405 prices in toman, not round numbers, because a demo full of
#  identical figures teaches the shopkeeper nothing about the feature.
# --------------------------------------------------------------------------
SHARED_GOODS = {
    # slug of the demo shop -> multiplier applied to the base price
    "supermarket": 1.00,
    "breadshop":   0.96,
    "confectionery": 1.08,
    "coffeeshop":  1.14,
    "restaurant":  1.05,
    "mobileshop":  1.00,
}

BASKET = [
    # (title, base price, unit, which demo shops stock it)
    ("شیر پرچرب کاله ۱ لیتری", 42000, "هر عدد",
     ["supermarket", "breadshop", "coffeeshop"]),
    ("تخم‌مرغ بسته ۹ عددی", 78000, "هر بسته",
     ["supermarket", "breadshop", "confectionery"]),
    ("روغن سرخ‌کردنی لادن ۱٫۵ لیتری", 165000, "هر عدد",
     ["supermarket", "breadshop"]),
    ("پنیر لیقوان سنتی", 235000, "هر کیلو",
     ["supermarket", "confectionery", "breadshop"]),
    ("برنج هاشمی درجه یک", 890000, "هر ۵ کیلو",
     ["supermarket", "restaurant"]),
    ("نان سنگک کنجدی", 25000, "هر عدد",
     ["breadshop", "supermarket"]),
    ("قهوه اسپرسو ۲۵۰ گرمی", 320000, "هر بسته",
     ["coffeeshop", "supermarket", "confectionery"]),
    ("شارژر فست شارژ ۳۳ وات", 480000, "هر عدد",
     ["mobileshop", "supermarket"]),
]


def basket_items_for(slug):
    """The shared goods this particular demo shop stocks, priced its own way."""
    mult = SHARED_GOODS.get(slug)
    if mult is None:
        return []
    out = []
    for title, base, unit, shops in BASKET:
        if slug not in shops:
            continue
        price = int(round(base * mult / 500.0)) * 500     # tidy to 500 toman
        # Bigger-ticket goods are the ones people actually haggle over; a
        # 25,000-toman loaf of bread is not negotiated, a carpet is. The
        # floor sits ~8% under list, which is a realistic bazaar margin.
        hag = 1 if base >= 150000 else 0
        out.append(dict(kind="product", title=title, price=price,
                        price_type="fixed", unit=unit, available=1,
                        haggle=hag,
                        floor_price=int(price * 0.92 / 500) * 500 if hag else 0,
                        descr=f"{title} — موجود در فروشگاه."))
    return out


def clear():
    n = 0
    for b in db.businesses(status=None):
        if TAG in (b.get("tags") or ""):
            db.delete_business(b["id"])
            n += 1
    print(f"  {n} کسب‌وکار نمونه حذف شد")

    m = 0
    for e in db.cityevents(status=None):
        if TAG in (e.get("descr") or ""):
            db.delete_cityevent(e["id"])
            m += 1
    k = 0
    for a in db.ads():
        if TAG in (a.get("body") or ""):
            db.delete_ad(a["id"])
            k += 1
    p = 0
    for c in db.coupons():
        if c["code"].startswith("DEMO"):
            db.delete_coupon(c["id"])
            p += 1
    q = 0
    for po in db.posts(status=None):
        if TAG in (po.get("excerpt") or ""):
            db.delete_post(po["id"])
            q += 1
    print(f"  {m} رویداد، {k} بنر، {p} کد تخفیف، {q} مطلب حذف شد")
    db.clear_searches()
    print("  آمار جست‌وجو پاک شد")


def seed():
    made = []
    for i, spec in enumerate(BUSINESSES):
        cat = spec.pop("slug")
        if not db.category(cat):
            print(f"  ! دستهٔ {cat} پیدا نشد، رد شد")
            continue
        bid = db.save_business(dict(spec, cat_slug=cat, status="published",
                                    hours=HOURS_SET[i % len(HOURS_SET)], tags=TAG))
        made.append(bid)

        # reviews with per-criterion scores
        for j, (author, rating, body, scores) in enumerate(REVIEWS):
            if j > i % 3:
                break
            db.add_review_full(bid, author, rating, body, scores=scores,
                               auto_approve=True)

        # a couple of answered questions on the first few
        if i < 4:
            for asker, q, a in QUESTIONS:
                qid = db.add_question(bid, asker, q, auto_publish=True)
                db.answer_question(qid, a, by="owner")

        # a small catalogue for the food places
        if i < 3:
            for it in ITEMS:
                db.save_item(dict(it, biz_id=bid))

        # shared goods, so the local price comparison has something real to
        # compare — the same product at three shops at three prices
        for it in basket_items_for(cat):
            db.save_item(dict(it, biz_id=bid))

        # some traffic so the charts are not flat
        for kind, times in (("view", 12 + i * 3), ("phone", 3 + i),
                            ("whatsapp", 2), ("route", 1)):
            for _ in range(times):
                db.track(bid, kind)

    # badges on the first two
    for bid, slug in zip(made[:2], ("verified-shop", "top-rated")):
        bg = db.badge(slug=slug)
        if bg:
            db.grant_badge(bid, bg["id"])

    # one live subscription so the plan machinery is visible
    if made:
        sid, _ = db.request_subscription(made[0], "plus", "DEMO-REF")
        if sid:
            db.activate_subscription(sid)

    db.save_cityevent({"title": "جشنوارهٔ شب یلدای بازارچه",
                       "descr": f"غرفه‌های آجیل، انار و شیرینی سنتی. {TAG}",
                       "place": "بازارچهٔ مرکزی نجف‌آباد",
                       "date": "2026-12-20", "time": "17:00"})
    db.save_ad({"title": "کسب‌وکار خود را ویژه کنید",
                "body": f"با پلن حرفه‌ای بالای فهرست دیده شوید. {TAG}",
                "url": "/pricing", "slot": "home", "active": "1", "weight": "1"})
    db.save_coupon({"code": "DEMO20", "title": "۲۰٪ تخفیف اولین خرید",
                    "percent": 20, "biz_id": made[0] if made else None})
    db.save_post({"title": "بازارچهٔ نجف‌آباد افتتاح شد",
                  "excerpt": f"راهنمای زندهٔ کسب‌وکارهای شهر. {TAG}",
                  "body": "از امروز می‌توانید کسب‌وکارهای شهر را اینجا پیدا کنید."})

    # a few searches, including ones with no result
    for term, n in (("کباب", 1), ("قنادی", 1), ("پیتزا", 0), ("استخر", 0)):
        db.log_search(term, "", n)

    print(f"  {len(made)} کسب‌وکار نمونه ساخته شد")
    print(f"  نظر، پرسش، کاتالوگ، نشان، اشتراک، رویداد، بنر و آمار اضافه شد")


if __name__ == "__main__":
    db.init()
    print("\nدادهٔ نمونه")
    print("─" * 46)
    if "--clear" in sys.argv:
        clear()
    else:
        clear()          # never stack two runs on top of each other
        seed()
    print("─" * 46)
    print(f"  اکنون: {len(db.businesses(status=None))} کسب‌وکار، "
          f"{len(db.categories(only_active=False))} دسته\n")
