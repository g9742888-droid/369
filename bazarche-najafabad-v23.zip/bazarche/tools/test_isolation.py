# -*- coding: utf-8 -*-
"""
Isolation from the prototype build.

A browser scopes cookies, localStorage, the service worker and its cache by
ORIGIN — host plus port — not by which program answers there. The prototype
also served on 127.0.0.1:8000 under the same cookie and storage names, so on a
phone that had run it the old session and the old cached shell bled into the
new site and made it look unchanged.

These tests lock in the separation:

  * the server listens on 8080, not the prototype's 8000
  * the session cookie is versioned, and the legacy one is actively expired
  * a stale legacy session is never accepted
  * localStorage keys are namespaced, and favourites migrate rather than vanish
  * the service worker cache name is bumped
  * QR codes and the sitemap use site_url when set, the live host otherwise —
    never a hard-coded address

Run:  python3 tools/test_isolation.py
"""

import os
import re
import sys
import sqlite3
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
DB = os.path.join(ROOT, "data", "bazarche.db")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"

passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


class NoRedir(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def fetch(path, cookie=None, follow=False):
    handlers = [] if follow else [NoRedir()]
    op = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(BASE + path)
    if cookie:
        req.add_header("Cookie", cookie)
    try:
        r = op.open(req, timeout=20)
        return r.getcode(), r.read().decode("utf-8", "ignore"), r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "ignore"), e.headers


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def main():
    print(f"\n{B}══ آزمون جدایی از نمونهٔ اولیه ══{X}\n")

    # ------------------------------------------------------------- port
    print(f"{B}۱) پورت{X}")
    runpy = read("run.py")
    ok("پورت پیش‌فرض ۸۰۸۰ است", "DEFAULT_PORT = 8080" in runpy)
    ok("پورت ۸۰۰۰ نمونهٔ اولیه دیگر پیش‌فرض نیست",
       "DEFAULT_PORT = 8000" not in runpy)
    code, _, _ = fetch("/")
    ok("سایت روی پورت تازه پاسخ می‌دهد", code == 200, f"HTTP {code}")

    # ----------------------------------------------------------- cookies
    print(f"\n{B}۲) کوکی{X}")
    app = read("server/app.py")
    ok("نام کوکی نسخه‌دار شد", 'SESSION_COOKIE = "bzv2_sess"' in app)
    ok("نام قدیمی فقط برای پاک‌کردن مانده",
       'LEGACY_COOKIES = ("bz_sess",)' in app)
    ok("هیچ جای دیگری bz_sess را مستقیم نمی‌خواند",
       len(re.findall(r'cookies\(\)\.get\("bz_sess"', app)) == 0)

    _, _, hd = fetch("/", cookie="bz_sess=STALE_FROM_PROTOTYPE")
    setc = hd.get_all("Set-Cookie") or []
    ok("کوکی نمونهٔ اولیه باطل می‌شود",
       any(c.startswith("bz_sess=") and "Max-Age=0" in c for c in setc),
       str(setc))

    # a visitor with no legacy cookie must not be handed pointless headers
    _, _, hd2 = fetch("/")
    setc2 = hd2.get_all("Set-Cookie") or []
    ok("بازدیدکنندهٔ تازه کوکی اضافی نمی‌گیرد",
       not any(c.startswith("bz_sess=") for c in setc2), str(setc2))

    code, _, hd = fetch("/my", cookie="bz_sess=whatever")
    ok("نشست قدیمی پذیرفته نمی‌شود",
       code in (302, 303) and "/login" in hd.get("Location", ""),
       f"HTTP {code} {hd.get('Location','')}")

    # ------------------------------------------------------- browser storage
    print(f"\n{B}۳) حافظهٔ مرورگر{X}")
    js = read("site/assets/js/app.js")
    ok("کلید پوسته نسخه‌دار شد", "'bazarche.v2.theme'" in js)
    ok("کلید علاقه‌مندی نسخه‌دار شد", "'bazarche.v2.favs'" in js)
    ok("کلید پشتیبانی نسخه‌دار شد", "'bazarche.v2.support.dismissed'" in js)
    ok("مهاجرت نوشته شده", "migrateLegacyStorage" in js)
    ok("علاقه‌مندی منتقل می‌شود نه حذف",
       "'bazarche.favs': 'bazarche.v2.favs'" in js)
    ok("کلیدهای دورریختنی پاک می‌شوند", "DROP.forEach" in js)
    ok("فهرست تازهٔ کاربر بازنویسی نمی‌شود",
       "localStorage.getItem(to) === null" in js)
    # a one-shot flag strands data that arrives after the first visit
    ok("مهاجرت پرچم یک‌بارمصرف ندارد", "bazarche.v2.migrated" not in js)
    # no un-namespaced key may survive anywhere in the JS
    # The migration block necessarily names the old keys; everywhere else must
    # use the v2 namespace. Check only the code outside that block.
    start = js.index("(function migrateLegacyStorage()")
    end = js.index("})();", start) + 5
    outside = js[:start] + js[end:]
    stale = sorted(set(re.findall(r"'bazarche\.(?!v2\.)[a-z.]+'", outside)))
    ok("خارج از بلوک مهاجرت کلید قدیمی نمانده", not stale, str(stale))

    # -------------------------------------------------------- service worker
    print(f"\n{B}۴) سرویس‌ورکر{X}")
    sw = read("site/sw.js")
    ok("نسخهٔ کش بالا رفت", "bazarche-v6" in sw)
    ok("نسخهٔ قدیمی v5 نمانده", "'bazarche-v5'" not in sw)
    ok("کش‌های ناهم‌نام پاک می‌شوند", "caches.delete(k)" in sw)
    ok("صفحه‌های تحت کنترل ورکر قدیمی تازه‌سازی می‌شوند",
       "c.navigate(c.url)" in sw)
    code, body, _ = fetch("/sw.js")
    ok("سرویس‌ورکر سرو می‌شود", code == 200 and "bazarche-v6" in body,
       f"HTTP {code}")

    # ------------------------------------------------------------ site_url
    print(f"\n{B}۵) آدرس سایت{X}")
    # Only executable lines count — the explanation of WHY the address was
    # removed naturally has to name it, and a comment cannot serve a QR code.
    # Strip comments AND docstrings before looking: the docstring on
    # site_origin() has to name the old address to explain what it replaced.
    import ast
    tree = ast.parse(app)
    doc_lines = set()
    for node in ast.walk(tree):
        if (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef,
                              ast.ClassDef, ast.Module))
                and ast.get_docstring(node, clean=False) is not None):
            body0 = node.body[0]
            for n in range(body0.lineno, (body0.end_lineno or body0.lineno) + 1):
                doc_lines.add(n)
    hard = [ln.strip()[:70] for i, ln in enumerate(app.splitlines(), 1)
            if "127.0.0.1:8000" in ln
            and not ln.lstrip().startswith("#")
            and i not in doc_lines]
    ok("هیچ آدرس ثابتی در کد اجرایی نمانده", not hard, str(hard[:2]))
    ok("تابع مرکزی آدرس ساخته شد", "def site_origin" in app)
    ok("site_url در تنظیمات پیش‌فرض هست", '"site_url"' in read("server/db.py"))
    ok("site_url در فرم پنل هست", 'name="site_url"' in read("server/views_panel.py"))
    ok("site_url هنگام ذخیره پذیرفته می‌شود",
       '"site_url","site_name"' in app or '"site_url", "site_name"' in app)

    con = sqlite3.connect(DB)
    before = con.execute(
        "SELECT value FROM settings WHERE key='site_url'").fetchone()
    before = before[0] if before else ""

    # with no site_url the live host must be used, not a baked-in address
    con.execute("UPDATE settings SET value='' WHERE key='site_url'")
    con.commit()
    _, sm, _ = fetch("/sitemap.xml")
    first = re.search(r"<loc>([^<]+)</loc>", sm)
    loc = first.group(1) if first else ""
    # Assert against the port actually in use, not a literal: run.py walks
    # forward when 8080 is busy, and hard-coding it made this test fail on a
    # perfectly healthy server running at 8081.
    live_port = urllib.parse.urlparse(BASE).port or 80
    ok("بدون دامنه، آدرس زنده استفاده می‌شود",
       f":{live_port}" in loc and ":8000" not in loc, f"{loc} (پورت {live_port})")

    # with site_url set, everything must switch to it
    con.execute("UPDATE settings SET value='bazarche-najafabad.ir' "
                "WHERE key='site_url'")
    con.commit()
    _, sm2, _ = fetch("/sitemap.xml")
    first2 = re.search(r"<loc>([^<]+)</loc>", sm2)
    loc2 = first2.group(1) if first2 else ""
    ok("با دامنه، نقشهٔ سایت به دامنه اشاره می‌کند",
       loc2.startswith("https://bazarche-najafabad.ir"), loc2)

    row = con.execute("SELECT slug FROM businesses LIMIT 1").fetchone()
    if row:
        code, svg, _ = fetch(f"/qr/{row[0]}.svg")
        ok("بارکد QR ساخته می‌شود", code == 200 and "<svg" in svg, f"HTTP {code}")

    # restore whatever the owner had
    con.execute("UPDATE settings SET value=? WHERE key='site_url'", (before,))
    con.commit()
    con.close()

    # ---------------------------------------------------------- tool ports
    print(f"\n{B}۶) پورت ابزارها یکسان است{X}")
    bad = []
    for name in sorted(os.listdir(HERE)):
        # this file names the old port when explaining what it guards against
        if not name.endswith(".py") or name == "test_isolation.py":
            continue
        txt = read(os.path.join("tools", name))
        for m in re.findall(r"127\.0\.0\.1:(\d+)", txt):
            if m != "8080":
                bad.append(f"{name}:{m}")
    ok("همهٔ ابزارها روی ۸۰۸۰ تنظیم‌اند", not bad, str(bad[:5]))

    print(f"\n{B}{'=' * 58}{X}")
    if failed:
        print(f"{B}{R}  {passed} موفق، {failed} ناموفق{X}")
        for f in fails:
            print(f"    ✗ {f}")
    else:
        print(f"{B}{G}  همه موفق — {passed} آزمون، ۰ ناموفق{X}")
    print(f"{B}{'=' * 58}{X}\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
