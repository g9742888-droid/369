# -*- coding: utf-8 -*-
"""
QR code generation, standard library only.

Why hand-rolled: Pydroid on Android cannot install packages, so `qrcode`
and `Pillow` are not available on the machine this actually runs on. The
whole site is built on that constraint, and a QR code is simple enough to
encode directly.

Scope is deliberately narrow — byte mode, error correction level M, the
smallest version that fits the URL. That covers every shop URL this site
will ever produce (well under 200 characters) without carrying the weight
of a general-purpose encoder.

Output is SVG: it scales to any print size without blurring, costs a few
KB, and a shopkeeper can hand the file straight to a print shop.
"""

# --------------------------------------------------------------- tables
# Galois field for Reed-Solomon error correction
_EXP = [0] * 512
_LOG = [0] * 256
_x = 1
for _i in range(255):
    _EXP[_i] = _x
    _LOG[_x] = _i
    _x <<= 1
    if _x & 0x100:
        _x ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]

# (version, EC level M): total codewords, EC codewords per block, block layout
# Only the versions a URL of this length needs.
_SPECS = {
    2:  (44, 16, [(1, 28)]),
    3:  (70, 26, [(1, 44)]),
    4:  (100, 18, [(2, 32)]),
    5:  (134, 24, [(2, 43)]),
    6:  (172, 16, [(4, 27)]),
    7:  (196, 18, [(4, 31)]),
    8:  (242, 22, [(2, 38), (2, 39)]),
    9:  (292, 22, [(3, 36), (2, 37)]),
    10: (346, 26, [(4, 43), (1, 44)]),
}
# capacity in byte mode at EC level M
_CAP = {2: 26, 3: 42, 4: 62, 5: 84, 6: 106, 7: 122,
        8: 152, 9: 180, 10: 213}

_ALIGN = {2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
          7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50]}

# format information for EC level M, masks 0-7 (pre-computed, BCH encoded)
_FORMAT = [0x5412, 0x5125, 0x5E7C, 0x5B4B, 0x45F9, 0x40CE, 0x4F97, 0x4AA0]


def _mul(a, b):
    if a == 0 or b == 0:
        return 0
    return _EXP[_LOG[a] + _LOG[b]]


def _rs_generator(n):
    g = [1]
    for i in range(n):
        ng = [0] * (len(g) + 1)
        for j, c in enumerate(g):
            ng[j] ^= c
            ng[j + 1] ^= _mul(c, _EXP[i])
        g = ng
    return g


def _rs_encode(data, n):
    gen = _rs_generator(n)
    res = list(data) + [0] * n
    for i in range(len(data)):
        f = res[i]
        if f:
            for j, gv in enumerate(gen):
                res[i + j] ^= _mul(gv, f)
    return res[len(data):]


def _pick_version(n):
    for v in sorted(_CAP):
        if n <= _CAP[v]:
            return v
    raise ValueError("متن برای این نسخه‌های QR بلند است")


def _bitstream(data, version):
    total, ecw, blocks = _SPECS[version]
    n_data = total - ecw * sum(c for c, _ in blocks)

    bits = []
    def put(val, ln):
        for i in range(ln - 1, -1, -1):
            bits.append((val >> i) & 1)

    put(0b0100, 4)                 # byte mode
    put(len(data), 8)              # length (versions 1-9 use 8 bits)
    for b in data:
        put(b, 8)
    put(0, min(4, n_data * 8 - len(bits)))     # terminator
    while len(bits) % 8:
        bits.append(0)

    codewords = [int("".join(str(x) for x in bits[i:i + 8]), 2)
                 for i in range(0, len(bits), 8)]
    pad = [0xEC, 0x11]
    i = 0
    while len(codewords) < n_data:
        codewords.append(pad[i % 2])
        i += 1

    # split into blocks, compute EC for each
    dblocks, eblocks = [], []
    pos = 0
    for count, size in blocks:
        for _ in range(count):
            blk = codewords[pos:pos + size]
            pos += size
            dblocks.append(blk)
            eblocks.append(_rs_encode(blk, ecw))

    # interleave
    out = []
    for i in range(max(len(b) for b in dblocks)):
        for b in dblocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ecw):
        for b in eblocks:
            out.append(b[i])
    return out


def _matrix(version, codewords):
    size = version * 4 + 17
    m = [[None] * size for _ in range(size)]

    def finder(r, c):
        for dr in range(-1, 8):
            for dc in range(-1, 8):
                rr, cc = r + dr, c + dc
                if not (0 <= rr < size and 0 <= cc < size):
                    continue
                inring = (dr in (0, 6) and 0 <= dc <= 6) or \
                         (dc in (0, 6) and 0 <= dr <= 6)
                incore = 2 <= dr <= 4 and 2 <= dc <= 4
                m[rr][cc] = 1 if (inring or incore) else 0

    finder(0, 0)
    finder(0, size - 7)
    finder(size - 7, 0)

    for i in range(8, size - 8):          # timing patterns
        v = 1 if i % 2 == 0 else 0
        if m[6][i] is None:
            m[6][i] = v
        if m[i][6] is None:
            m[i][6] = v

    for r in _ALIGN.get(version, []):      # alignment patterns
        for c in _ALIGN.get(version, []):
            if (r < 8 and c < 8) or (r < 8 and c > size - 9) or \
               (r > size - 9 and c < 8):
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    m[r + dr][c + dc] = 1 if (abs(dr) == 2 or abs(dc) == 2
                                              or (dr == 0 and dc == 0)) else 0

    m[size - 8][8] = 1                     # dark module

    # reserve format areas
    for i in range(9):
        if m[8][i] is None:
            m[8][i] = 0
        if m[i][8] is None:
            m[i][8] = 0
    for i in range(8):
        if m[8][size - 1 - i] is None:
            m[8][size - 1 - i] = 0
        if m[size - 1 - i][8] is None:
            m[size - 1 - i][8] = 0

    # place data, zig-zag from bottom-right
    bits = []
    for cw in codewords:
        for i in range(7, -1, -1):
            bits.append((cw >> i) & 1)
    idx = 0
    col = size - 1
    up = True
    while col > 0:
        if col == 6:
            col -= 1
        rows = range(size - 1, -1, -1) if up else range(size)
        for row in rows:
            for c in (col, col - 1):
                if m[row][c] is None:
                    bit = bits[idx] if idx < len(bits) else 0
                    idx += 1
                    # mask 0: (row + col) % 2 == 0
                    if (row + c) % 2 == 0:
                        bit ^= 1
                    m[row][c] = bit
        up = not up
        col -= 2

    # Write the 15 format bits, twice.
    #
    # The module order below was not guessed — it was read back out of a
    # reference encoder and matched bit for bit. Two earlier attempts at
    # deriving it from the spec text left 12 modules wrong in the corners,
    # which produced a code that looked perfectly plausible to the eye and
    # simply would not scan.
    #
    # Both copies carry the same 15 bits, most-significant first.
    fmt = _FORMAT[0]
    bits = [(fmt >> (14 - i)) & 1 for i in range(15)]

    # copy 1: along row 8 then up column 8, skipping the timing module
    c1 = [(8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 7), (8, 8),
          (7, 8), (5, 8), (4, 8), (3, 8), (2, 8), (1, 8), (0, 8)]
    # copy 2: up the bottom-left finder, then across the top-right one
    c2 = [(size - 1, 8), (size - 2, 8), (size - 3, 8), (size - 4, 8),
          (size - 5, 8), (size - 6, 8), (size - 7, 8),
          (8, size - 8), (8, size - 7), (8, size - 6), (8, size - 5),
          (8, size - 4), (8, size - 3), (8, size - 2), (8, size - 1)]
    for (r, c), b in zip(c1, bits):
        m[r][c] = b
    for (r, c), b in zip(c2, bits):
        m[r][c] = b

    m[size - 8][8] = 1          # the always-dark module
    return m


def matrix(text):
    """-> list[list[0|1]] ready to draw."""
    data = text.encode("utf-8")
    version = _pick_version(len(data))
    return _matrix(version, _bitstream(data, version))


def svg(text, size=320, quiet=4, dark="#0b1f1a", light="#ffffff"):
    """A standalone SVG string. Scales to any print size without blurring."""
    m = matrix(text)
    n = len(m)
    total = n + quiet * 2
    scale = size / total

    # one <path> for every dark module keeps the file small and crisp
    parts = []
    for r in range(n):
        run = None
        for c in range(n + 1):
            on = c < n and m[r][c]
            if on and run is None:
                run = c
            elif not on and run is not None:
                parts.append(f"M{run + quiet} {r + quiet}"
                             f"h{c - run}v1h-{c - run}z")
                run = None
    path = "".join(parts)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" '
            f'height="{size}" viewBox="0 0 {total} {total}" '
            f'shape-rendering="crispEdges" role="img" '
            f'aria-label="QR code">'
            f'<rect width="{total}" height="{total}" fill="{light}"/>'
            f'<path d="{path}" fill="{dark}"/></svg>')
