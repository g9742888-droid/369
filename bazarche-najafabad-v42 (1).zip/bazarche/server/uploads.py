# -*- coding: utf-8 -*-
"""
Image uploads without any third-party library.

`cgi` was removed in Python 3.13, so multipart/form-data is parsed by hand.
Pillow is not available in Pydroid either, so images are downscaled in the
BROWSER (canvas -> JPEG) before upload; the server validates the magic bytes,
enforces a size cap, and stores the file.
"""

import os
import re
import json
import time
import secrets

HERE = os.path.dirname(os.path.abspath(__file__))
UPLOAD_DIR = os.path.abspath(os.path.join(HERE, "..", "site", "assets", "img", "uploads"))
os.makedirs(UPLOAD_DIR, exist_ok=True)

PUBLIC_PREFIX = "/assets/img/uploads/"
MAX_FILE = 3 * 1024 * 1024          # 3 MB per image after browser downscale
MAX_FILES = 15
MAX_BODY = 30 * 1024 * 1024

MAGIC = {
    b"\xff\xd8\xff": ".jpg",
    b"\x89PNG\r\n\x1a\n": ".png",
    b"RIFF": ".webp",               # RIFF....WEBP
    b"GIF87a": ".gif",
    b"GIF89a": ".gif",
}

# Video magic bytes (story videos). The server stores the bytes verbatim;
# playback happens client-side so no re-encoding is needed.
VIDEO_MAGIC = {
    b"\x00\x00\x00\x18ftyp": ".mp4",   # MP4/MOV (ftyp box)
    b"\x00\x00\x00\x1cftyp": ".mp4",
    b"\x1aE\xdf\xa3": ".webm",          # Matroska/WebM
}


def sniff(data):
    """Return an extension if the bytes really are an image, else None."""
    for magic, ext in MAGIC.items():
        if data.startswith(magic):
            if ext == ".webp" and data[8:12] != b"WEBP":
                continue
            return ext
    return None


def sniff_media(data):
    """-> (ext, kind) where kind is 'image' | 'video', or (None, None)."""
    ext = sniff(data)
    if ext:
        return ext, "image"
    for magic, ext in VIDEO_MAGIC.items():
        if data.startswith(magic):
            return ext, "video"
    return None, None


# --------------------------------------------------------------------------
# multipart/form-data parser
# --------------------------------------------------------------------------
def parse_multipart(body, content_type):
    """
    -> (fields: {name: str}, files: [(field, filename, bytes)])
    Tolerant of CRLF/LF and quoted or bare boundary values.
    """
    m = re.search(r'boundary=(?:"([^"]+)"|([^;\s]+))', content_type or "", re.I)
    if not m:
        return {}, []
    boundary = (m.group(1) or m.group(2)).encode()
    delim = b"--" + boundary

    fields, files = {}, []
    for part in body.split(delim):
        if not part or part in (b"--", b"--\r\n", b"\r\n"):
            continue
        part = part.lstrip(b"\r\n")
        if part.startswith(b"--"):
            continue
        head, sep, payload = part.partition(b"\r\n\r\n")
        if not sep:
            continue
        payload = payload.rstrip(b"\r\n")

        headers = head.decode("utf-8", "replace")
        name_m = re.search(r'name="([^"]*)"', headers)
        if not name_m:
            continue
        name = name_m.group(1)
        file_m = re.search(r'filename="([^"]*)"', headers)

        if file_m:
            fn = file_m.group(1)
            if fn and payload:
                files.append((name, fn, payload))
        else:
            fields[name] = payload.decode("utf-8", "replace")
    return fields, files


# --------------------------------------------------------------------------
# storage
# --------------------------------------------------------------------------
def save_image(data, prefix="img"):
    """-> (public_path, error). Validates real image bytes."""
    if len(data) > MAX_FILE:
        return None, "حجم تصویر بیش از حد مجاز است (حداکثر ۳ مگابایت)."
    ext = sniff(data)
    if not ext:
        return None, "فایل انتخابی یک تصویر معتبر نیست."
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, None


VIDEO_MAX = 20 * 1024 * 1024        # 20 MB story videos


def save_media(data, prefix="story"):
    """-> (public_path, kind, error). Accepts a real image OR a short video
    (mp4/webm/mov by magic bytes) — used for stories."""
    if len(data) > VIDEO_MAX:
        return None, None, "حجم فایل بیش از حد مجاز است (حداکثر ۲۰ مگابایت)."
    ext, kind = sniff_media(data)
    if not ext:
        return None, None, "فایل انتخابی تصویر یا ویدیوی معتبر نیست."
    name = f"{prefix}-{int(time.time())}-{secrets.token_hex(4)}{ext}"
    with open(os.path.join(UPLOAD_DIR, name), "wb") as f:
        f.write(data)
    return PUBLIC_PREFIX + name, kind, None


def delete_image(public_path):
    """Remove a stored upload. Refuses anything outside the upload dir."""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def disk_usage():
    total = 0
    n = 0
    for f in os.listdir(UPLOAD_DIR):
        try:
            total += os.path.getsize(os.path.join(UPLOAD_DIR, f))
            n += 1
        except OSError:
            pass
    return n, total


def list_files():
    """-> [{name, path, size, mtime}] for the media manager."""
    out = []
    for f in sorted(os.listdir(UPLOAD_DIR)):
        if f == ".gitkeep":
            continue
        full = os.path.join(UPLOAD_DIR, f)
        if not os.path.isfile(full):
            continue
        try:
            st = os.stat(full)
            out.append({"name": f, "path": PUBLIC_PREFIX + f,
                        "size": st.st_size, "mtime": st.st_mtime})
        except OSError:
            continue
    return out


def delete_file(public_path):
    """Delete one upload by its public path. Refuses paths outside the upload
    dir. -> bool"""
    if not public_path or not public_path.startswith(PUBLIC_PREFIX):
        return False
    name = os.path.basename(public_path)
    full = os.path.abspath(os.path.join(UPLOAD_DIR, name))
    if not full.startswith(UPLOAD_DIR):
        return False
    try:
        os.remove(full)
        return True
    except OSError:
        return False


def gc(referenced, min_age_seconds=3600):
    """Delete upload files nobody references anymore. A file must be BOTH
    unreferenced AND older than min_age so an upload still in flight (or a
    preview the user hasn't saved yet) is never touched.

    -> (removed_count, freed_bytes)"""
    if referenced is None:
        referenced = set()
    now = time.time()
    removed, freed = 0, 0
    for f in os.listdir(UPLOAD_DIR):
        if f == ".gitkeep":
            continue
        full = os.path.join(UPLOAD_DIR, f)
        if not os.path.isfile(full):
            continue
        if PUBLIC_PREFIX + f in referenced:
            continue
        try:
            if now - os.path.getmtime(full) < min_age_seconds:
                continue
            freed += os.path.getsize(full)
            os.remove(full)
            removed += 1
        except OSError:
            continue
    return removed, freed
