# -*- coding: utf-8 -*-
"""Shared HTML chrome for the dynamic server (icons, layout, components)."""

import os, sys, json, threading, html as _html
import re as _re
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

from layout import (icon, stars, fa, fa_group, cat_icon,
                     ICON_GRID, ICON_COLS, ICON_ROWS, ICON_CELL)  # sprite grid
import db

esc = lambda s: _html.escape(str(s or ""), quote=True)


def json_embed(obj):
    """Serialize for embedding inside <script> or a single-quoted HTML
    attribute. json.dumps does NOT escape <, >, &, ' or U+2028/2029, so
    user text like "</script><script>…" could close the tag and execute.
    The unicode escapes below stay valid JSON (JSON.parse turns them back)
    but the browser no longer sees the raw characters, which keeps the
    injection inert in HTML. (Security fix — stored XSS via JSON-LD/map.)"""
    return (json.dumps(obj, ensure_ascii=False)
            .replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("&", "\\u0026").replace("'", "\\u0027")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


# ---------------------------------------------------------------- request ctx
# The header needs to know who is signed in and which area of the site we are
# in. Passing that through every one of the ~50 page() call sites would be
# noise, so the request handler stashes it here instead. ThreadingHTTPServer
# gives each request its own thread, so thread-local storage is the right fit.
_ctx = threading.local()


def set_context(owner=None, area="public", admin_token="", customer=None):
    _ctx.owner = owner
    _ctx.area = area              # public | panel | my | me
    _ctx.admin_token = admin_token or ""
    _ctx.customer = customer


def clear_context():
    set_context(None, "public", "")


def ctx_owner():
    return getattr(_ctx, "owner", None)


def ctx_customer():
    return getattr(_ctx, "customer", None)


def ctx_area():
    return getattr(_ctx, "area", "public")


def ctx_token():
    return getattr(_ctx, "admin_token", "")


# ---------------------------------------------------------------- nav
# Measured, not guessed: at the 1440px container the header can spare
# 942px for the nav (1440 − brand 103 − actions 363 − 2×16 gap). Eleven
# links at their full labels wanted 995px and overflowed at every desktop
# width, so the two longest labels are shortened rather than dropping a
# whole section behind the hamburger. Re-measure with tools/navfit.py
# before adding a twelfth link.
PUBLIC_NAV = [
    ("/", "خانه", "store"),
    ("/businesses", "کسب‌وکارها", "grid"),
    ("/lists", "برترین‌ها", "trophy"),
    ("/deals", "پیشنهادها", "zap"),
    ("/map", "نقشه", "map"),
    ("/nearby", "نزدیک من", "compass"),
    ("/catalog", "محصولات", "shopping"),
    ("/prices", "مقایسهٔ قیمت", "chart"),
    ("/events", "رویدادها", "calendar"),
    ("/offers", "تخفیف‌ها", "tag"),
    ("/blog", "اخبار شهر", "book"),
    ("/pricing", "تعرفه‌ها", "wallet"),
    ("/contact", "تماس", "phone"),
]

# Grouped so 25 screens stay findable instead of turning into a wall of links.
OWNER_NAV_GROUPS = [
    ("مرور", [
        ("/panel", "داشبورد", "dashboard"),
        ("/panel/inbox", "درخواست‌های کاسبان", "bell"),
        ("/panel/orders", "همهٔ سفارش‌ها", "cart"),
        ("/panel/chats", "همهٔ گفتگوها", "message"),
        ("/panel/insights", "بینش و آمار", "chart"),
    ]),
    ("محتوای شهر", [
        ("/panel/businesses", "کسب‌وکارها", "store"),
        ("/panel/categories", "دسته‌بندی‌ها", "layers"),
        ("/panel/lists", "برترین‌های شهر", "trophy"),
        ("/panel/deals", "پیشنهادهای روز", "zap"),
        ("/panel/stories", "استوری‌ها", "image"),
        ("/panel/events", "رویدادهای شهر", "calendar"),
        ("/panel/posts", "اخبار و مقالات", "book"),
        ("/panel/coupons", "تخفیف‌ها", "tag"),
    ]),
    ("تعامل مشتری", [
        ("/panel/reviews", "نظرات", "message"),
        ("/panel/qa", "پرسش و پاسخ", "help"),
        ("/panel/reports", "گزارش تخلف", "alert"),
        ("/panel/inquiries", "درخواست قیمت", "send"),
        ("/panel/bookings", "نوبت‌ها", "calendar"),
        ("/panel/messages", "پیام‌ها", "mail"),
        ("/panel/tickets", "تیکت‌های پشتیبانی", "message"),
        ("/panel/alerts", "هشدار جست‌وجو", "bell"),
    ]),
    ("صاحبان و اعتماد", [
        ("/panel/owners", "صاحبان کسب‌وکار", "users"),
        ("/panel/claims", "درخواست تصاحب", "shield"),
        ("/panel/edits", "تأیید تغییرات", "edit"),
        ("/panel/badges", "نشان‌ها", "award"),
    ]),
    ("درآمد", [
        ("/panel/plans", "پلن‌ها و تعرفه", "wallet"),
        ("/panel/unlocks", "کلید قابلیت‌ها", "lock"),
        ("/panel/subscriptions", "اشتراک‌ها", "credit-card"),
        ("/panel/loyalty", "برنامهٔ وفاداری", "star"),
        ("/panel/ads", "تبلیغات", "zap"),
    ]),
    ("سیستم", [
        ("/panel/editor", "ویرایش محتوای سایت", "edit"),
        ("/panel/pages", "صفحات ثابت", "file"),
        ("/panel/appearance", "ظاهر و رنگ‌ها", "palette"),
        ("/panel/features", "قابلیت‌های سایت", "layers"),
        ("/panel/media", "مدیریت فایل‌ها", "image"),
        ("/panel/areas", "محله‌ها", "pin"),
        ("/panel/customers", "مشتری‌ها", "users"),
        ("/panel/follows", "دنبال‌کننده‌ها", "heart"),
        ("/panel/broadcast", "اعلان همگانی", "send"),
        ("/panel/audit", "گزارش فعالیت‌ها", "activity"),
        ("/panel/settings", "تنظیمات سایت", "settings"),
        ("/panel/backup", "پشتیبان‌گیری", "database"),
    ]),
]

OWNER_NAV = [item for _g, items in OWNER_NAV_GROUPS for item in items]

# The shopkeeper's own area. Defined here (not only in views_owner) so the
# mobile menu can offer it without importing that module and creating a cycle.
OWNER_AREA_NAV = [
    ("/my", "داشبورد", "dashboard"),
    ("/my/businesses", "کسب‌وکارهای من", "store"),
    ("/my/reviews", "نظرات", "message"),
    ("/my/questions", "پرسش و پاسخ", "help"),
    ("/my/bookings", "نوبت‌ها", "calendar"),
    ("/my/inquiries", "درخواست قیمت", "send"),
    ("/my/offers", "پیشنهادهای قیمت", "tag"),
    ("/my/tickets", "پشتیبانی", "message"),
    ("/my/plan", "اشتراک من", "wallet"),
    ("/my/claim", "تصاحب کسب‌وکار", "shield"),
]

# What a shopkeeper actually gets. Shown in the menu BEFORE sign-in too, so the
# features stop being invisible behind a login wall: the whole point of the
# door is that people can see what is behind it. Each row links straight to the
# page; /login bounces back there after sign-in via ?next=.
OWNER_PERKS = [
    ("/my/businesses", "صفحهٔ اختصاصی مغازه", "store",
     "نام، آدرس، ساعت کار، عکس و شمارهٔ تماس"),
    ("/my/businesses", "بارکد QR ویترین", "grid",
     "چاپش کنید و روی شیشه بزنید"),
    ("/my/bookings", "نوبت‌دهی اینترنتی", "calendar",
     "مشتری خودش نوبت می‌گیرد"),
    ("/my/inquiries", "استعلام قیمت", "send",
     "مشتری قیمت می‌پرسد، شما جواب می‌دهید"),
    ("/my/reviews", "نظرات و امتیاز", "message",
     "به نظر مشتری پاسخ بدهید"),
    ("/my/tickets", "پشتیبانی مستقیم", "help",
     "با مدیر سایت گفت‌وگو کنید"),
]


def cat_options(tree, selected="", blank=None, group_selectable=False):
    """<option> markup for the two-level category tree.

    With 140+ trades a flat list is unusable, so children are nested under an
    <optgroup>. A parent that has children is a heading only — a shop belongs
    to a specific trade, not to "food" — unless group_selectable is set, which
    the admin filters want so you can filter a whole branch at once.
    """
    out = ""
    if blank is not None:
        out += f'<option value="">{esc(blank)}</option>'
    for c in tree:
        kids = c.get("children") or []
        sel = ' selected' if selected == c["slug"] else ''
        if not kids:
            out += f'<option value="{esc(c["slug"])}"{sel}>{esc(c["name"])}</option>'
            continue
        if group_selectable:
            out += (f'<option value="{esc(c["slug"])}"{sel}>'
                    f'{esc(c["name"])} (همه)</option>')
        out += f'<optgroup label="{esc(c["name"])}">'
        for k in kids:
            ksel = ' selected' if selected == k["slug"] else ''
            out += f'<option value="{esc(k["slug"])}"{ksel}>{esc(k["name"])}</option>'
        out += '</optgroup>'
    return out


def theme_css(s):
    """Owner-chosen colours injected as a token override."""
    return f""":root{{
  --color-primary:{esc(s.get('color_primary','#059669'))};
  --color-accent:{esc(s.get('color_accent','#ea580c'))};
  --color-ring:{esc(s.get('color_primary','#059669'))};
}}
html[data-theme="light"]{{
  --color-background:{esc(s.get('color_background','#f4f8f7'))};
  --color-foreground:{esc(s.get('color_foreground','#0b1f1a'))};
}}"""


def _aria(h, active):
    # 'aria-current="page"' built without an escaped quote so the literal can
    # live inside an f-string on Python 3.11 (no backslash in {expr}).
    return ' aria-current="page"' if h == active else ""


def header(s, active, token=""):
    nav = "".join(
        f'<a href="{h}"{_aria(h, active)}>{t}</a>'
        for h, t, _ in PUBLIC_NAV)
    mark = (f'<img class="brand-logo" src="{esc(s.get("site_logo"))}" alt="{esc(s.get("site_name"))}">'
            if s.get("site_logo") else
            f'<span class="brand-mark">{icon("store")}</span>')
    mnav = "".join(
        f'<a href="{h}"{_aria(h, active)} data-nav-close>'
        f'{icon(i)}<span>{t}</span></a>' for h, t, i in PUBLIC_NAV)
    owner_link = f'<a class="btn btn-primary btn-sm hide-mobile" href="/panel?key={esc(token)}">{icon("settings")}<span>پنل مدیریت</span></a>' if token else ""

    # ---- signed-in state. Showing "ورود / ثبت‌نام" to somebody who is
    # already signed in is the single most confusing thing a header can do.
    me = ctx_owner()
    if me:
        who = (me.get("name") or "").strip() or me.get("phone", "")
        auth_btn = (
            f'<a class="btn btn-glass btn-sm hide-mobile account-chip" href="/my" '
            f'title="پنل شما">'
            f'<span class="account-avatar" aria-hidden="true">{esc(who[:1])}</span>'
            f'<span class="account-text"><small>وارد شده‌اید</small>'
            f'<strong>{esc(who)}</strong></span></a>'
            f'<form method="post" action="/my/logout" class="hide-mobile" style="display:inline">'
            f'<button class="btn-icon" type="submit" title="خروج از حساب" '
            f'aria-label="خروج از حساب">{icon("logout")}</button></form>')
    else:
        cust = ctx_customer()
        if cust:
            who = (cust.get("name") or "").strip() or cust.get("phone", "")
            auth_btn = (f'<a class="btn btn-glass btn-sm hide-mobile account-chip" href="/me" '
                        f'title="حساب شما">'
                        f'<span class="account-avatar" aria-hidden="true">{esc(who[:1])}</span>'
                        f'<span class="account-text"><small>حساب من</small>'
                        f'<strong>{esc(who)}</strong></span></a>')
        else:
            auth_btn = (f'<a class="btn btn-glass btn-sm hide-mobile" href="/login">'
                        f'{icon("user")}<span>ورود / ثبت‌نام</span></a>')

    # ---- notification bell (visible only to signed-in customers)
    notif_btn = ""
    cust = ctx_customer()
    if cust and s.get("notif_enabled") == "1":
        unread = db.notifications_unread(cust["id"])
        notif_btn = (f'<a class="btn-icon" href="/me/notifications" aria-label="اعلان‌ها" title="اعلان‌ها">'
                     f'{icon("bell")}'
                     + (f'<span class="fav-dot">{unread if unread < 100 else "۹۹+"}</span>'
                        if unread else '')
                     + '</a>')

    # ---- the hamburger must offer the CURRENT area, not always the public
    # site. In a panel on a phone the sidebar sits far below the content, so
    # without this the menu button was effectively useless there.
    area = ctx_area()
    area_nav = ""
    if area == "panel" and token:
        groups = ""
        for gname, gitems in OWNER_NAV_GROUPS:
            links = "".join(
                f'<a href="{h}?key={esc(token)}" data-nav-close>{icon(i)}'
                f'<span>{t}</span></a>' for h, t, i in gitems)
            groups += (f'<span class="mnav-title">{esc(gname)}</span>{links}')
        area_nav = (f'<div class="mnav-area"><strong class="mnav-head">'
                    f'{icon("shield")}<span>پنل مدیریت</span></strong>'
                    f'{groups}</div><hr class="divider">'
                    f'<span class="mnav-title">سایت</span>')
    elif area == "my" and me:
        links = "".join(
            f'<a href="{h}" data-nav-close>{icon(i)}<span>{t}</span></a>'
            for h, t, i in OWNER_AREA_NAV)
        area_nav = (f'<div class="mnav-area"><strong class="mnav-head">'
                    f'{icon("store")}<span>پنل کسب‌وکار من</span></strong>'
                    f'{links}</div><hr class="divider">'
                    f'<span class="mnav-title">سایت</span>')

    if me:
        who = (me.get("name") or "").strip() or me.get("phone", "")
        # Signing in used to REMOVE things from this menu: the perk list and the
        # "all features" link both lived in the else-branch, so the moment a
        # shopkeeper logged in the map of the site vanished. Nothing may get
        # smaller on sign-in — the account block replaces the sign-in button,
        # and the way to the rest of the site stays exactly where it was.
        account_block = (
            f'<a class="nav-cta" href="/my" data-nav-close>{icon("user")}'
            f'<span>{esc(who)}<small>وارد شده‌اید — پنل من</small></span></a>'
            f'<div class="mnav-perks">'
            f'<span class="mnav-title">میان‌برهای پنل شما</span>'
            + "".join(
                f'<a href="{h}" data-nav-close>{icon(i)}'
                f'<span>{esc(t_)}<small>{esc(d)}</small></span></a>'
                for h, t_, i, d in OWNER_PERKS)
            + f'<a class="mnav-perk-all" href="/features" data-nav-close>'
              f'{icon("grid")}<span>دیدن همهٔ امکانات سایت</span></a></div>'
            f'<form method="post" action="/my/logout">'
            f'<button class="mnav-logout" type="submit">{icon("logout")}'
            f'<span>خروج از حساب</span></button></form>')
    else:
        # Not signed in. A bare "sign in" button hides every shopkeeper feature
        # behind a door with nothing written on it, so list the perks right
        # here — each one a real link that lands on the feature after login.
        perks = "".join(
            f'<a href="/login?next={urllib.parse.quote(h)}" data-nav-close>'
            f'{icon(i)}<span>{esc(t_)}<small>{esc(d)}</small></span></a>'
            for h, t_, i, d in OWNER_PERKS)
        account_block = (
            f'<a class="nav-cta" href="/login" data-nav-close>{icon("store")}'
            f'<span>پنل مغازه‌داران<small>ورود و ثبت‌نام</small></span></a>'
            f'<div class="mnav-perks">'
            f'<span class="mnav-title">با ثبت مغازه چه چیزی می‌گیرید</span>'
            f'{perks}'
            f'<a class="mnav-perk-all" href="/features" data-nav-close>'
            f'{icon("grid")}<span>دیدن همهٔ امکانات سایت</span></a></div>')

    return f'''<a class="skip-link" href="#main">پرش به محتوای اصلی</a>
<header class="site-header">
  <div class="container-wide header-inner">
    <a class="brand" href="/">
      {mark}
      <span class="brand-text">{esc(s.get('site_name'))}<small>{esc(s.get('tagline'))}</small></span>
    </a>
    <nav class="main-nav" aria-label="ناوبری اصلی">{nav}</nav>
    <div class="header-actions">
      <a class="btn btn-glass btn-sm hide-mobile" href="/cities" title="انتخاب شهر">
        {icon("pin")}<span>شهر</span></a>
      <button class="btn-icon" data-theme-toggle aria-pressed="false" aria-label="تغییر پوسته" type="button">
        <span class="theme-sun">{icon("sun")}</span><span class="theme-moon">{icon("moon")}</span>
      </button>
      <a class="btn-icon hide-mobile" href="/favorites" aria-label="علاقه‌مندی‌ها" title="علاقه‌مندی‌ها">
        {icon("heart")}<span class="fav-dot" data-fav-count hidden></span></a>
      <a class="btn-icon" href="/cart" aria-label="سبد خرید" title="سبد خرید">
        {icon("cart")}<span class="fav-dot" data-cart-count hidden></span></a>
      {notif_btn}
      {auth_btn}
      <a class="btn btn-accent btn-sm hide-mobile" href="/submit">{icon("plus")}<span>ثبت کسب‌وکار</span></a>
      {owner_link}
      <button class="btn-icon nav-toggle" data-nav-toggle aria-expanded="false" aria-controls="mobile-nav"
              aria-label="باز کردن منو" type="button">{icon("menu")}</button>
    </div>
  </div>
</header>
<div class="mobile-nav" id="mobile-nav" aria-hidden="true">
  <div class="backdrop" data-nav-close></div>
  <div class="panel" role="dialog" aria-modal="true" aria-label="منوی ناوبری">
    <div class="between mb-lg"><strong>منو</strong>
      <button class="btn-icon" data-nav-close aria-label="بستن منو" type="button">{icon("x")}</button></div>
    {area_nav}
    {mnav}
    <hr class="divider">
    <a href="/favorites" data-nav-close>{icon("heart")}<span>علاقه‌مندی‌ها</span></a>
    <a href="/cart" data-nav-close>{icon("cart")}<span>سبد خرید</span></a>
    <a href="/cities" data-nav-close>{icon("pin")}<span>انتخاب شهر</span></a>
    <a href="/me" data-nav-close>{icon("user")}<span>حساب من</span></a>
    {account_block}
    <a href="/submit" data-nav-close>{icon("plus")}<span>ثبت کسب‌وکار جدید</span></a>
    <a href="/rules" data-nav-close>{icon("shield")}<span>قوانین</span></a>
  </div>
</div>'''


def social_links(s):
    """Only render an icon when there is somewhere for it to go.

    An <a href=""> reloads the current page and reads to a screen reader as a
    real link, so an unconfigured social account was shipping three dead
    controls onto all 46 pages. No URL, no link.
    """
    out = ""
    for key, ic, label in (("instagram", "instagram", "اینستاگرام"),
                           ("telegram", "telegram", "تلگرام"),
                           ("whatsapp", "whatsapp", "واتساپ")):
        url = (s.get(key) or "").strip()
        # a bare "https://instagram.com/" with no account is not a destination
        if not url or url.rstrip("/") in ("https://instagram.com", "http://instagram.com",
                                          "https://t.me", "http://t.me",
                                          "https://wa.me", "http://wa.me"):
            continue
        out += (f'<a href="{esc(url)}" aria-label="{label}" '
                f'target="_blank" rel="noopener">{icon(ic)}</a>')
    email = (s.get("email") or "").strip()
    if email:
        out += f'<a href="mailto:{esc(email)}" aria-label="ایمیل">{icon("mail")}</a>'
    return out


def footer(s, cats):
    catlinks = "".join(
        f'<li><a href="/businesses?cat={esc(c["slug"])}">{esc(c["name"])}</a></li>'
        for c in cats[:6])
    links = "".join(f'<li><a href="{h}">{t}</a></li>' for h, t, _ in PUBLIC_NAV[1:6])
    return f'''<footer class="site-footer">
  <div class="container-wide">
    <div class="footer-grid">
      <div class="footer-col footer-about">
        <a class="brand" href="/">
          <span class="brand-mark">{icon("store")}</span>
          <span class="brand-text">{esc(s.get('site_name'))}<small>{esc(s.get('tagline'))}</small></span>
        </a>
        <p>{esc(s.get('description'))}</p>
        <div class="social-row mt-lg">
          {social_links(s)}
        </div>
      </div>
      <div class="footer-col"><h4>دسترسی سریع</h4><ul>{links}</ul></div>
      <div class="footer-col"><h4>دسته‌های پرمخاطب</h4><ul>{catlinks or '<li><span class="text-muted">—</span></li>'}</ul></div>
      <div class="footer-col"><h4>تماس با ما</h4><ul>
        <li><a href="tel:{esc(s.get('phone_raw'))}">{esc(s.get('phone'))}</a></li>
        <li><a href="mailto:{esc(s.get('email'))}">{esc(s.get('email'))}</a></li>
        <li><span class="text-muted">{esc(s.get('address'))}</span></li>
        <li><a href="/rules">قوانین و مقررات</a></li></ul></div>
    </div>
    <div class="footer-bottom">
      <span>© {fa(1405)} {esc(s.get('site_name'))} — همهٔ حقوق محفوظ است.</span>
      <span>{esc(s.get('footer_note'))}</span>
    </div>
  </div>
</footer>'''


def page(s, title, body, active="", desc=None, extra_head="", extra_js="",
         token="", cats=None, body_class="", show_chrome=True):
    cats = cats if cats is not None else []
    d = desc or s.get("description", "")
    boot = {
        "mapProvider": s.get("map_provider", "auto"),
        "gmapsKey": s.get("gmaps_key", ""),
        "mapLat": s.get("map_lat", "32.6340"),
        "mapLng": s.get("map_lng", "51.3670"),
        "mapZoom": s.get("map_zoom", "14"),
        "show3d": s.get("show_3d", "1") == "1",
        "token": token,
        # category-icon sprite grid (client-side cropping for map pins etc.)
        "iconCell": ICON_CELL,
        "iconCols": ICON_COLS,
        "iconRows": ICON_ROWS,
        "iconGrid": ICON_GRID,
    }
    chrome_top = header(s, active, token) if show_chrome else ""
    chrome_bot = footer(s, cats) if show_chrome else ""
    # NOTE: the site-wide inline-edit bar was removed from public pages. Editing
    # lives exclusively inside the admin panel (/panel/editor etc.), so visitors
    # never see any admin UI on the public site.
    return f'''<!DOCTYPE html>
<html lang="fa" dir="rtl" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="{esc(s.get('color_background','#f4f8f7'))}">
<title>{esc(title)} | {esc(s.get('site_name'))}</title>
<meta name="description" content="{esc(d)}">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(d)}">
<meta property="og:type" content="website">
<meta property="og:locale" content="fa_IR">
<link rel="icon" href="/assets/img/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="preload" href="/assets/fonts/Vazirmatn-Variable.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/css/tokens.css?v42">
<link rel="stylesheet" href="/assets/css/main.css?v42">
<link rel="stylesheet" href="/assets/css/pages.css?v42">
<link rel="stylesheet" href="/assets/css/mobile-refine.css?v42">
<link rel="stylesheet" href="/assets/css/mobile-standard.css?v42">
<style>{theme_css(s)}</style>
{extra_head}
<script>window.__BAZARCHE__={json_embed(boot)};</script>
</head>
<body class="{body_class}">
<div class="spatial-bg" aria-hidden="true">
  <span class="orb orb-1"></span><span class="orb orb-2"></span><span class="orb orb-3"></span>
</div>
<div class="spatial-grain" aria-hidden="true"></div>
{chrome_top}
<main id="main" class="main-content">
{body}
</main>
{chrome_bot}
{bottom_nav(s, active, token) if show_chrome else ""}
{support_widget(s) if show_chrome else ""}
<script type="module" src="/assets/js/app.js?v42"></script>
<script type="module" src="/assets/js/cart.js?v42"></script>
{extra_js}
</body>
</html>'''


# ---------------------------------------------------------------- components
def biz_card(b, cat_icons, delay=0, token=""):
    ic = cat_icons.get(b["cat_slug"], "store")
    badges = ""
    if b.get("featured"):
        badges += f'<span class="badge badge-featured">{icon("sparkles")}<span>ویژه</span></span>'
    if b.get("verified"):
        badges += f'<span class="badge badge-info">{icon("shield")}<span>تأییدشده</span></span>'
    tags = "".join(f'<span class="badge badge-neutral">{esc(t)}</span>'
                   for t in b.get("tag_list", [])[:3])
    rating = b.get("rating") or 0
    nrev = b.get("nreviews") or 0
    rat_html = (f'{stars(rating)}<strong class="nums">{fa(round(rating,1))}</strong>'
                f'<span>({fa(nrev)} نظر)</span>') if nrev else \
               '<span class="text-muted text-xs">هنوز نظری ثبت نشده</span>'
    hours = esc(b.get("hours") or "")
    # Computed once here, in Iran time, so the filter and the badge can never
    # disagree with each other the way a client-only clock would.
    ost = b.get("open_state") or db.open_state(b)
    # Instagram-style story ring when the shop has a live 24h story
    has_story = bool(b.get("has_story"))
    story_badge = (f'<button class="story-chip" type="button" data-story-biz="{esc(b["slug"])}" '
                   f'aria-label="استوری {esc(b["name"])}">{icon("image")}<span>استوری</span></button>'
                   if has_story else '')
    return f'''<article class="card card-hover tilt biz-card reveal-3d" data-tilt="6" data-delay="{delay}"
  data-biz data-open="{esc(ost['state'])}" data-cat="{esc(b['cat_slug'])}" data-name="{esc(b['name'])}"
  data-rating="{rating}" data-reviews="{nrev}" data-featured="{b.get('featured',0)}"
  data-hours-json="{hours}" data-slug="{esc(b['slug'])}"
  data-search="{esc(b['name'] + ' ' + (b.get('descr') or '') + ' ' + (b.get('tags') or '') + ' ' + (b.get('address') or ''))}">
  <span class="sheen" aria-hidden="true"></span>
  <div class="card-media biz-thumb{" has-photo" if b.get("images") else ""}{" story-ring" if has_story else ""}">
    {f'<img class="biz-cover" src="{esc(b["images"][0])}" alt="{esc(b["name"])}" loading="lazy" decoding="async">'
     if b.get("images") else
     f'<div class="biz-thumb-art" aria-hidden="true">{cat_icon(ic, 128)}</div>'}
    <div class="media-badges layer-2">{badges}</div>
    {story_badge}
    <button class="fav-btn" type="button" data-fav="{esc(b['slug'])}"
            aria-pressed="false" aria-label="افزودن {esc(b['name'])} به علاقه‌مندی‌ها">{icon("heart")}</button>
  </div>
  <div class="card-body layer-1">
    <div class="between" style="align-items:flex-start;gap:8px">
      <h3 class="card-title"><a href="/b/{esc(b['slug'])}" class="stretch-link">{esc(b['name'])}</a></h3>
      {open_badge(b, compact=True)}
    </div>
    <div class="card-meta">{rat_html}</div>
    <p class="card-desc">{esc(b.get('descr'))}</p>
    <div class="cluster mt-md">{tags}</div>
    <div class="card-foot">
      <span class="card-meta" style="margin:0">{icon("pin")}<span>{esc(b.get('address'))}</span></span>
      <span class="btn btn-ghost btn-sm" aria-hidden="true">{icon("chevron-left")}</span>
    </div>
  </div>
</article>'''


OPEN_CLS = {"open": "badge-open", "closing": "badge-warn",
            "closed": "badge-closed", "unknown": "badge-neutral"}
OPEN_ICON = {"open": "clock", "closing": "bell",
             "closed": "x-circle", "unknown": "clock"}


def open_badge(b, compact=False):
    """The live 'open now' pill, rendered server-side in Iran time.

    Rendering it on the server matters: a phone with a wrong timezone would
    otherwise be told a shop is open when it is shut. app.js refreshes the
    same element every minute so a page left sitting on screen stays honest.
    """
    st = b.get("open_state") or db.open_state(b)
    cls = OPEN_CLS.get(st["state"], "badge-neutral")
    text = st["label"]
    if compact and st["state"] == "closing":
        text = f"{fa(st['minutes'])} دقیقه تا بستن"
    elif compact and st["state"] == "unknown":
        text = "نامشخص"
    title = f' title="{esc(st["detail"])}"' if st.get("detail") else ""
    return (f'<span class="badge {cls}" data-open-badge '
            f'data-open-state="{esc(st["state"])}"{title}>'
            f'{icon(OPEN_ICON.get(st["state"], "clock"))}'
            f'<span>{esc(text)}</span></span>')


def open_line(b):
    """The fuller two-line version used on a business's own page."""
    st = b.get("open_state") or db.open_state(b)
    if st["state"] == "unknown":
        return ""
    cls = {"open": "is-open", "closing": "is-closing",
           "closed": "is-closed"}.get(st["state"], "")
    return (f'<div class="open-line {cls}" data-open-line '
            f'data-open-state="{esc(st["state"])}">'
            f'<span class="open-dot" aria-hidden="true"></span>'
            f'<strong>{esc(st["label"])}</strong>'
            + (f'<span class="open-detail">{esc(st["detail"])}</span>'
               if st.get("detail") else "")
            + '</div>')


def empty_state(icon_name, title, text, action=""):
    return f'''<div class="empty-state">
  <span class="icon-wrap">{icon(icon_name)}</span>
  <h3>{esc(title)}</h3><p>{esc(text)}</p>{action}
</div>'''


def stat_card(icon_name, value, label, suffix="", delay=0):
    # The counter animation parses data-count as a float. Passing it a
    # preformatted string (Persian digits, thousands separators, "تومان")
    # renders a literal "NaN" on the page — so anything non-numeric is shown
    # as static text instead of being handed to the animator.
    try:
        num = float(str(value).replace(",", "").replace("٬", ""))
        numeric = True
    except (TypeError, ValueError):
        numeric = False

    if numeric:
        inner = (f'<div class="stat-value nums" data-count="{num:g}" '
                 f'data-suffix="{esc(suffix)}">۰</div>')
    else:
        inner = f'<div class="stat-value nums">{esc(value)}{esc(suffix)}</div>'

    return f'''<div class="card glass stat tilt reveal" data-tilt="5" data-delay="{delay}">
  <span class="sheen" aria-hidden="true"></span>
  <span class="stat-icon layer-1">{icon(icon_name)}</span>
  <div class="layer-1">
    {inner}
    <div class="stat-label">{esc(label)}</div>
  </div></div>'''


def section_head(eyebrow, title, sub=None, center=False, eyebrow_icon="sparkles"):
    c = " center" if center else ""
    sb = f'<p>{esc(sub)}</p>' if sub else ""
    return f'''<div class="section-head{c} reveal">
  <span class="eyebrow">{icon(eyebrow_icon)}<span>{esc(eyebrow)}</span></span>
  <h2>{esc(title)}</h2>{sb}</div>'''


def breadcrumb(*parts):
    out = ['<nav class="breadcrumb" aria-label="مسیر صفحه"><a href="/">خانه</a>']
    for i, (label, href) in enumerate(parts):
        out.append(icon("chevron-left"))
        if href and i < len(parts) - 1:
            out.append(f'<a href="{href}">{esc(label)}</a>')
        else:
            out.append(f'<span aria-current="page">{esc(label)}</span>')
    out.append("</nav>")
    return "".join(out)


# ---------------------------------------------------------------- owner shell
def _panel_counts():
    """Live counters shown as pills next to the nav entries. One cheap query
    each — the admin should never have to click around to find pending work."""
    try:
        return {
            "/panel/businesses": len(db.businesses(status="pending")),
            "/panel/reviews": len(db.reviews(status="pending")),
            "/panel/qa": len(db.questions(status="pending")),
            "/panel/reports": len(db.reports(status="open")),
            "/panel/claims": len(db.claims(status="pending")),
            "/panel/edits": len(db.pending_edits()),
            "/panel/subscriptions": len(db.subscriptions(status="pending")),
            "/panel/messages": len([m for m in db.messages() if m["status"] == "new"]),
            "/panel/bookings": len(db.bookings(status="new")),
        }
    except Exception:
        return {}


def panel_page(s, title, subtitle, content, active, token, extra_head="", extra_js=""):
    counts = _panel_counts()
    groups = []
    for gname, gitems in OWNER_NAV_GROUPS:
        links = ""
        for h, t, i in gitems:
            n = counts.get(h, 0)
            pill = f'<span class="nav-count">{fa(n)}</span>' if n else ""
            cur = ' aria-current="page"' if h == active else ""
            links += (f'<a href="{h}?key={esc(token)}"{cur}>'
                      f'{icon(i)}<span>{t}</span>{pill}</a>')
        groups.append(f'<div class="panel-nav-group">'
                      f'<span class="panel-nav-title">{esc(gname)}</span>{links}</div>')
    items = "".join(groups)
    st = db.stats()
    todo_n = sum(counts.values())
    badge = ""
    if todo_n:
        badge = (f'<span class="badge badge-warn">{icon("bell")}'
                 f'<span>{fa(todo_n)} کار در انتظار</span></span>')

    body = f'''
<div class="container-wide panel-layout">
  <aside class="panel-side glass">
    <div class="panel-side-head">
      <span class="stat-icon">{icon("shield")}</span>
      <div><strong>پنل مالک</strong><small class="text-muted">دسترسی کامل</small></div>
    </div>
    <nav class="panel-nav" aria-label="ناوبری پنل">{items}</nav>
    <hr class="divider">
    <a class="panel-nav-extra" href="/" target="_blank" rel="noopener"
       style="display:flex;align-items:center;gap:11px;padding:11px 13px;border-radius:var(--radius-md);font-size:var(--fs-sm);font-weight:600;min-height:46px;color:var(--color-primary)">
      {icon("external")}<span>مشاهدهٔ سایت</span></a>
  </aside>
  <div>
    <header class="panel-head">
      <div class="between">
        <div><h1>{esc(title)}</h1><p>{esc(subtitle)}</p></div>
        {badge}
      </div>
    </header>
    {content}
  </div>
</div>'''
    return page(s, title, body, active="", token=token, cats=[],
                body_class="page-panel", show_chrome=True,
                extra_head=extra_head, extra_js=extra_js)


def flash(kind, text):
    ic = {"ok": "check-circle", "err": "x-circle", "warn": "alert", "info": "info"}[kind]
    cls = {"ok": "success", "err": "error", "warn": "warn", "info": "info"}[kind]
    return f'<div class="alert alert-{cls} mb-lg">{icon(ic)}<span>{esc(text)}</span></div>'


# ==========================================================================
#  FEATURE GATE UI
#  Research is unambiguous: a locked feature that stays VISIBLE but blurred
#  converts far better than one that is hidden, because the owner can see
#  exactly what they are missing. Never hide — blur, label, and price it.
# ==========================================================================
def lock_overlay(key, compact=False):
    """The padlock layer that sits on top of a blurred feature."""
    label = db.FEATURE_LABELS.get(key, key)
    why = db.FEATURE_WHY.get(key, "")
    if compact:
        return (f'<span class="lock-chip">{icon("lock")}'
                f'<span>نیازمند ارتقا</span></span>')
    return f'''<div class="lock-veil">
  <div class="lock-card">
    <span class="lock-badge">{icon("lock")}</span>
    <strong>{esc(label)}</strong>
    <p>{esc(why)}</p>
    <a class="btn btn-primary btn-sm" href="/pricing">
      {icon("zap")}<span>باز کردن این قابلیت</span></a>
    <a class="lock-help" href="/contact">یا با پشتیبانی تماس بگیرید</a>
  </div>
</div>'''


def gated(key, biz_id, content, compact=False, hide=False):
    """Wrap a feature. If the shop has it, the content renders untouched.

    If not, the same markup renders blurred and inert behind a lock. Note the
    content is still generated — that is deliberate, so the owner sees the
    real shape of what they are buying rather than a generic placeholder.
    Anything genuinely secret must be gated server-side with db.can() as well.
    """
    if db.can(biz_id, key):
        return content
    if hide:
        return ""
    return (f'<div class="gated" data-locked="{esc(key)}">'
            f'<div class="gated-inner" aria-hidden="true" inert>{content}</div>'
            f'{lock_overlay(key, compact)}</div>')


def lock_note(key, biz_id):
    """A one-line inline notice, for places where a full veil is too heavy."""
    if db.can(biz_id, key):
        return ""
    label = db.FEATURE_LABELS.get(key, key)
    return (f'<div class="alert alert-warn mb-lg">{icon("lock")}<span>'
            f'<strong>{esc(label)}</strong> در پلن فعلی شما قفل است. '
            f'<a href="/pricing">ارتقا دهید</a> یا با پشتیبانی تماس بگیرید.'
            f'</span></div>')


def founder_ribbon():
    """Scarcity that is true: the count comes straight from the table."""
    left = db.founders_left()
    if left <= 0:
        return ""
    total = db.founder_settings()["limit"]
    return (f'<div class="founder-ribbon">{icon("award")}'
            f'<span><strong>{fa(left)} جای باقی‌مانده</strong> از '
            f'{fa(total)} عضو بنیان‌گذار — این افراد امکانات ویژه را '
            f'<strong>همیشه رایگان</strong> دارند.</span></div>')


# ==========================================================================
#  SUPPORT WIDGET
#  Appears after a delay, opens on FAQ first. Answering the common question
#  costs nothing; a human reply costs you time, so the FAQ goes first and
#  direct contact sits underneath it.
# ==========================================================================
DEFAULT_FAQ = [
    ("ثبت کسب‌وکار در بازارچه چقدر هزینه دارد؟",
     "ثبت کاملاً رایگان است و رایگان می‌ماند. اگر بعداً امکانات بیشتری خواستید، "
     "پلن‌های اختیاری هست، ولی برای دیده‌شدن لازم نیست."),
    ("چطور کسب‌وکارم را ثبت کنم؟",
     "روی «ثبت کسب‌وکار» بزنید و فرم را پر کنید. با شمارهٔ موبایل وارد می‌شوید و "
     "رمز عبور لازم نیست. پس از تأیید مدیر، صفحهٔ شما منتشر می‌شود."),
    ("کسب‌وکار من از قبل اینجا هست، چطور تحویلش بگیرم؟",
     "وارد شوید و از بخش «تصاحب کسب‌وکار» درخواست بدهید. اگر شمارهٔ ثبت‌شده با "
     "شمارهٔ شما یکی باشد، بلافاصله به حساب شما وصل می‌شود."),
    ("چطور عکس و محصولاتم را اضافه کنم؟",
     "پس از ورود، از «کسب‌وکارهای من» گالری و کاتالوگ را باز کنید. عکس‌ها را "
     "می‌توانید مستقیم از گوشی بارگذاری کنید."),
    ("اطلاعاتم را چطور ویرایش کنم؟",
     "از پنل خودتان، بخش «کسب‌وکارهای من» و بعد «ویرایش». تغییرات بلافاصله "
     "روی سایت اعمال می‌شود."),
    ("نظر منفی یا اطلاعات غلط دیدم، چه کنم؟",
     "پایین صفحهٔ هر کسب‌وکار دکمهٔ «گزارش مشکل» هست. گزارش شما مستقیم به "
     "مدیر سایت می‌رسد و رسیدگی می‌شود."),
]


# ==========================================================================
#  BOTTOM NAVIGATION  (mobile only)
#
#  Research is unambiguous: a hamburger in the TOP corner is the worst place
#  to put navigation on a phone. Roughly half of people drive a phone with
#  one thumb, and the top corners are the "ow" zone that needs a grip change.
#  A fixed bottom bar with 3-5 destinations is the pattern every app these
#  shopkeepers already use -- Instagram, Digikala, Snapp -- relies on.
#
#  Five slots, chosen from what this site is actually for: find a shop, find
#  it on a map, compare a price, and manage your own listing.
# ==========================================================================
BOTTOM_NAV = [
    ("/",           "خانه",       "store"),
    ("/businesses", "کسب‌وکارها", "grid"),
    ("/map",        "نقشه",       "map"),
    ("/prices",     "قیمت‌ها",    "chart"),
]


def bottom_nav(s, active, token=""):
    """The thumb-zone navigation. Always rendered, revealed by CSS only
    below 860px, so a desktop visitor never sees it."""
    owner = ctx_owner()
    # the fifth slot is context-aware: it is whatever THIS visitor needs
    if token:
        last = ("/panel?key=" + token, "پنل", "settings")
    elif owner:
        last = ("/my", "پنل من", "user")
    else:
        last = ("/login", "ورود", "user")

    items = ""
    for h, t, i in BOTTOM_NAV + [last]:
        base = h.split("?")[0]
        on = ""
        if base == active or (base != "/" and active.startswith(base)):
            on = ' aria-current="page"'
        items += ('<a href="' + esc(h) + '"' + on + '>' + icon(i)
                  + '<span>' + esc(t) + '</span></a>')
    return ('<nav class="bottom-nav" aria-label="ناوبری اصلی موبایل">'
            + items + '</nav>')


def call_bar(b):
    """A shop page's own sticky action bar.

    Measured on a 360px screen: the "تماس" button sat at y=834, below the
    fold -- the single most important action on the whole site needed a
    scroll to reach. Now it sits under the thumb on every shop page.
    """
    if not b:
        return ""
    slug = esc(b.get("slug", ""))
    acts = ""
    if b.get("phone"):
        acts += ('<a class="cb-main" href="tel:' + esc(b["phone"]) + '"'
                 ' data-track="phone" data-slug="' + slug + '">'
                 + icon("phone") + '<span>تماس</span></a>')
    if b.get("whatsapp"):
        wa = _re.sub(r"\D", "", str(b["whatsapp"]))
        if wa.startswith("0"):
            wa = "98" + wa[1:]
        acts += ('<a class="cb-side" href="https://wa.me/' + esc(wa) + '"'
                 ' target="_blank" rel="noopener" data-track="whatsapp"'
                 ' data-slug="' + slug + '" aria-label="واتساپ">'
                 + icon("whatsapp") + '</a>')
    if b.get("lat") and b.get("lng"):
        acts += ('<a class="cb-side" target="_blank" rel="noopener"'
                 ' data-track="route" data-slug="' + slug + '"'
                 ' href="https://www.google.com/maps/dir/?api=1&destination='
                 + str(b["lat"]) + ',' + str(b["lng"]) + '"'
                 ' aria-label="مسیریابی">' + icon("compass") + '</a>')
    if not acts:
        return ""
    return '<div class="call-bar" data-call-bar>' + acts + '</div>'


def support_widget(s):
    """The floating helper. Hidden until the visitor has settled — an
    immediate popup reads as an ad; a delayed one reads as help."""
    if s.get("support_widget", "1") != "1":
        return ""
    try:
        delay = int(s.get("support_delay", "60"))
    except Exception:
        delay = 60

    faq = ""
    for i, (q, a) in enumerate(DEFAULT_FAQ):
        faq += f'''<details class="sup-faq"{" open" if i == 0 else ""}>
      <summary>{esc(q)}</summary><p>{esc(a)}</p></details>'''

    wa = (s.get("whatsapp") or "").strip()
    wa_btn = ""
    if wa and wa.rstrip("/") not in ("https://wa.me", "http://wa.me"):
        wa_btn = (f'<a class="btn btn-accent btn-block" href="{esc(wa)}" '
                  f'target="_blank" rel="noopener">{icon("whatsapp")}'
                  f'<span>گفت‌وگو در واتساپ</span></a>')
    tel = (s.get("phone_raw") or "").strip()
    tel_btn = ""
    if tel:
        tel_btn = (f'<a class="btn btn-glass btn-block" href="tel:{esc(tel)}">'
                   f'{icon("phone")}<span>تماس تلفنی</span></a>')

    return f'''
<button class="sup-fab" type="button" data-sup-open aria-expanded="false"
        aria-controls="support-panel" hidden
        aria-label="راهنما و پشتیبانی">
  {icon("help")}
  <span class="sup-fab-label">راهنما</span>
  <span class="sup-fab-dot" aria-hidden="true"></span>
</button>

<div class="sup-panel" id="support-panel" role="dialog" aria-modal="false"
     aria-label="راهنما و پشتیبانی" hidden data-sup-delay="{delay}">
  <div class="sup-head">
    <div><strong>{icon("help")} چطور کمکتان کنیم؟</strong>
      <small>اول پرسش‌های پرتکرار را ببینید</small></div>
    <button class="btn-icon" type="button" data-sup-close
            aria-label="بستن راهنما">{icon("x")}</button>
  </div>
  <div class="sup-body">
    {faq}
    <hr class="divider">
    <p class="sup-direct-title">{icon("send")} پاسخ سؤالتان را پیدا نکردید؟</p>
    <div class="sup-actions">
      <a class="btn btn-primary btn-block" href="/contact">
        {icon("mail")}<span>ارتباط مستقیم با پشتیبانی</span></a>
      {wa_btn}
      {tel_btn}
    </div>
  </div>
</div>'''
