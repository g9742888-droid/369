# -*- coding: utf-8 -*-
"""
Feature subsystems — customers, chat, orders, areas, server favourites,
top lists, flash deals, loyalty, stories, follows, notifications, and
admin moderation (v28→v34).

Split out of db.py (which was a 5500-line god-file) so the core data layer
stays focused on schema/settings/CRUD, while each feature group lives here.

Design contract:
  • Every function talks to the database through db.connect / db._run /
    db._rows / db._one — the single SQLite layer (standard library only,
    Pydroid-compatible).
  • No HTML here; views_*.py handle presentation. app.py handles routing.
  • `import db` is safe at import time because db.py imports this module
    ONLY at its very end, after the core functions are already defined.
"""
import json
import time
import secrets
import datetime
import db

# ==========================================================================
#  CUSTOMERS  ·  CHAT  ·  ORDERS  ·  AREAS  ·  SERVER FAVORITES   (v28)
# ==========================================================================
CUSTOMER_OTP_TTL = 180
CUSTOMER_SESSION_TTL = 60 * 60 * 24 * 30


# ---------------------------------------------------------------- customers
def customer_by_phone(phone, create=False):
    phone = db.norm_phone(phone)
    con = db.connect()
    r = con.execute("SELECT * FROM customers WHERE phone=?", (phone,)).fetchone()
    if not r and create:
        con.execute("INSERT INTO customers(phone) VALUES(?)", (phone,))
        con.commit()
        r = con.execute("SELECT * FROM customers WHERE phone=?", (phone,)).fetchone()
    con.close()
    return dict(r) if r else None


def customer_by_id(cid):
    con = db.connect()
    r = con.execute("SELECT * FROM customers WHERE id=?", (cid,)).fetchone()
    con.close()
    return dict(r) if r else None


def customer_otp_issue(phone):
    """Same table as owner OTP — one code per phone regardless of role."""
    phone = db.norm_phone(phone)
    now = time.time()
    con = db.connect()
    con.execute("DELETE FROM otp WHERE expires < ?", (now,))
    row = con.execute("SELECT * FROM otp WHERE phone=?", (phone,)).fetchone()
    if row:
        con.close()
        return row["code"], int(row["expires"] - now), True
    code = "".join(secrets.choice("0123456789") for _ in range(5))
    con.execute("INSERT INTO otp(phone,code,tries,expires) VALUES(?,?,0,?)",
                (phone, code, now + CUSTOMER_OTP_TTL))
    con.commit()
    con.close()
    return code, CUSTOMER_OTP_TTL, False


def customer_session_new(cid):
    tok = secrets.token_urlsafe(24)
    con = db.connect()
    con.execute("DELETE FROM customer_sessions WHERE expires < ?", (time.time(),))
    con.execute("INSERT INTO customer_sessions(token,customer_id,expires) VALUES(?,?,?)",
                (tok, cid, time.time() + CUSTOMER_SESSION_TTL))
    con.execute("UPDATE customers SET last_login=datetime('now') WHERE id=?", (cid,))
    con.commit()
    con.close()
    return tok


def customer_session_get(token):
    if not token:
        return None
    con = db.connect()
    r = con.execute(
        "SELECT c.* FROM customer_sessions s JOIN customers c ON c.id=s.customer_id "
        "WHERE s.token=? AND s.expires > ?", (token, time.time())).fetchone()
    con.close()
    if not r:
        return None
    d = dict(r)
    # a blocked customer's session must stop working immediately
    return None if d.get("status") == "blocked" else d


def customer_session_kill(token):
    if not token:
        return
    con = db.connect()
    con.execute("DELETE FROM customer_sessions WHERE token=?", (token,))
    con.commit()
    con.close()


def customer_set_name(cid, name):
    con = db.connect()
    con.execute("UPDATE customers SET name=? WHERE id=?", (str(name)[:60], cid))
    con.commit()
    con.close()


# ---------------------------------------------------------------- chat
def chat_start(biz_id, customer_id, subject=""):
    """Open (or reuse) the thread between a customer and a business."""
    con = db.connect()
    r = con.execute(
        "SELECT * FROM chat_threads WHERE biz_id=? AND customer_id=? AND status='open'",
        (biz_id, customer_id)).fetchone()
    if r:
        con.close()
        return r["id"]
    con.execute("INSERT INTO chat_threads(biz_id,customer_id,subject,status,last_activity) "
                "VALUES(?,?,?,'open',?)", (biz_id, customer_id, subject, time.time()))
    con.commit()
    tid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.close()
    return tid


def chat_send(thread_id, sender, body):
    if not body or not str(body).strip():
        return False
    con = db.connect()
    con.execute("INSERT INTO chat_messages(thread_id,sender,body) VALUES(?,?,?)",
                (thread_id, sender, str(body).strip()[:2000]))
    con.execute("UPDATE chat_threads SET last_activity=?, status='open' WHERE id=?",
                (time.time(), thread_id))
    con.commit()
    con.close()
    return True


def chat_thread(tid):
    con = db.connect()
    r = con.execute("SELECT * FROM chat_threads WHERE id=?", (tid,)).fetchone()
    con.close()
    return dict(r) if r else None


def chat_messages(tid):
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT * FROM chat_messages WHERE thread_id=? ORDER BY id", (tid,))]
    con.close()
    return rows


def chat_threads_for_owner(owner_id):
    """Threads for every business an owner controls, newest activity first."""
    con = db.connect()
    biz_ids = [r["id"] for r in con.execute(
        "SELECT id FROM businesses WHERE owner_id=?", (owner_id,))]
    con.close()
    if not biz_ids:
        return []
    return _thread_rows(biz_ids=biz_ids)


def chat_threads_all():
    """Every thread on the site — for the admin inbox."""
    return _thread_rows()


def _thread_rows(biz_ids=None):
    where, p = "", []
    if biz_ids:
        where = " WHERE t.biz_id IN (%s)" % ",".join("?" * len(biz_ids))
        p = list(biz_ids)
    q = ("SELECT t.*, b.name bizname, b.slug bizslug, c.phone custphone, "
         "c.name custname FROM chat_threads t "
         "JOIN businesses b ON b.id=t.biz_id "
         "LEFT JOIN customers c ON c.id=t.customer_id "
         + where + " ORDER BY t.last_activity DESC")
    rows = db._rows(q, p)
    for r in rows:
        last = db.connect()
        m = last.execute("SELECT * FROM chat_messages WHERE thread_id=? "
                         "ORDER BY id DESC LIMIT 1", (r["id"],)).fetchone()
        last.close()
        r["last"] = dict(m) if m else None
        c = db.connect()
        n = c.execute("SELECT COUNT(*) c FROM chat_messages WHERE thread_id=? "
                      "AND sender='customer'", (r["id"],)).fetchone()["c"]
        c.close()
        r["n_msgs"] = n
    return rows


def chat_unread_owner(owner_id):
    """Count threads with a fresh customer message (for the owner badge)."""
    n = 0
    for t in chat_threads_for_owner(owner_id):
        if t.get("last") and t["last"]["sender"] == "customer":
            n += 1
    return n


def chat_set_status(tid, status):
    con = db.connect()
    con.execute("UPDATE chat_threads SET status=? WHERE id=?", (status, tid))
    con.commit()
    con.close()


def chat_threads_for_customer(customer_id):
    """Threads a customer opened, newest activity first."""
    con = db.connect()
    ids = [r["id"] for r in con.execute(
        "SELECT id FROM chat_threads WHERE customer_id=? ORDER BY last_activity DESC",
        (customer_id,))]
    con.close()
    if not ids:
        return []
    return _thread_rows_by_id(ids)


def _thread_rows_by_id(thread_ids):
    q = ("SELECT t.*, b.name bizname, b.slug bizslug, c.phone custphone, "
         "c.name custname FROM chat_threads t "
         "JOIN businesses b ON b.id=t.biz_id "
         "LEFT JOIN customers c ON c.id=t.customer_id "
         "WHERE t.id IN (%s) ORDER BY t.last_activity DESC"
         % ",".join("?" * len(thread_ids)))
    rows = db._rows(q, thread_ids)
    for r in rows:
        last = db.connect()
        m = last.execute("SELECT * FROM chat_messages WHERE thread_id=? "
                         "ORDER BY id DESC LIMIT 1", (r["id"],)).fetchone()
        last.close()
        r["last"] = dict(m) if m else None
        r["n_msgs"] = db_chat_msg_ids(r["id"])
    return rows


def db_chat_msg_ids(tid):
    con = db.connect()
    n = con.execute("SELECT COUNT(*) c FROM chat_messages WHERE thread_id=?",
                    (tid,)).fetchone()["c"]
    con.close()
    return n


# ---------------------------------------------------------------- orders
ORDER_STATUS = ["new", "confirmed", "ready", "done", "cancelled"]
ORDER_LABELS = {
    "new": ("badge-warn", "جدید"),
    "confirmed": ("badge-info", "تأیید شد"),
    "ready": ("badge-open", "آمادهٔ تحویل"),
    "done": ("badge-neutral", "تحویل شد"),
    "cancelled": ("badge-closed", "لغو شد"),
}


def create_order(biz_id, customer_id, name, phone, address, note, items):
    """items: [{item_id, title, price, qty}] -> order id."""
    def _safe_int(v, d=0):
        try:
            return int(v)
        except (TypeError, ValueError):
            return d
    total = sum(max(0, _safe_int(i.get("price"), 0)) * max(1, min(99, _safe_int(i.get("qty"), 1)))
                for i in items)
    con = db.connect()
    con.execute("INSERT INTO orders(biz_id,customer_id,name,phone,address,note,total,status) "
                "VALUES(?,?,?,?,?,?,?,'new')",
                (biz_id, customer_id, str(name)[:100], db.norm_phone(phone),
                 str(address)[:300], str(note)[:500], total))
    oid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    for i in items:
        con.execute("INSERT INTO order_items(order_id,item_id,title,price,qty) "
                    "VALUES(?,?,?,?,?)",
                    (oid, i.get("item_id"), str(i.get("title", ""))[:150],
                     max(0, _safe_int(i.get("price"), 0)),
                     max(1, min(99, _safe_int(i.get("qty"), 1)))))
    con.commit()
    con.close()
    return oid


def order(oid):
    con = db.connect()
    r = con.execute("SELECT * FROM orders WHERE id=?", (oid,)).fetchone()
    con.close()
    return dict(r) if r else None


def order_items(oid):
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT * FROM order_items WHERE order_id=? ORDER BY id", (oid,))]
    con.close()
    return rows


def orders_for_owner(owner_id):
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT o.id FROM orders o JOIN businesses b ON b.id=o.biz_id "
        "WHERE b.owner_id=? ORDER BY o.id DESC LIMIT 2000", (owner_id,))]
    con.close()
    if not rows:
        return []
    return _order_rows([r["id"] for r in rows])


def orders_all():
    con = db.connect()
    rows = [r["id"] for r in con.execute(
        "SELECT id FROM orders ORDER BY id DESC LIMIT 2000")]
    con.close()
    return _order_rows([r for r in rows])


def _order_rows(oid_list):
    if not oid_list:
        return []
    q = ("SELECT o.*, b.name bizname, b.slug bizslug FROM orders o "
         "JOIN businesses b ON b.id=o.biz_id WHERE o.id IN (%s) "
         "ORDER BY o.id DESC" % ",".join("?" * len(oid_list)))
    rows = db._rows(q, oid_list)
    for r in rows:
        r["items"] = order_items(r["id"])
        r["status_label"] = ORDER_LABELS.get(r["status"], ("badge-neutral", r["status"]))[1]
    return rows


def orders_for_customer(customer_id):
    con = db.connect()
    ids = [r["id"] for r in con.execute(
        "SELECT id FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 500",
        (customer_id,))]
    con.close()
    return _order_rows([i for i in ids])


def set_order_status(oid, status):
    if status not in ORDER_STATUS:
        return False
    con = db.connect()
    con.execute("UPDATE orders SET status=? WHERE id=?", (status, oid))
    con.commit()
    con.close()
    return True


# ---------------------------------------------------------------- areas
def areas():
    """Distinct neighbourhood names from published businesses, with counts."""
    con = db.connect()
    rows = [dict(r) for r in con.execute(
        "SELECT area, COUNT(*) c FROM businesses "
        "WHERE status='published' AND COALESCE(area,'')<>'' "
        "GROUP BY area ORDER BY c DESC, area")]
    con.close()
    return rows


def businesses_in_area(area, limit=None):
    con = db.connect()
    q = ("SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved') rating, "
         "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews "
         "FROM businesses b WHERE b.status='published' AND b.area=? "
         "ORDER BY b.featured DESC, rating DESC NULLS LAST, b.id DESC")
    p = [area]
    if limit:
        q += " LIMIT ?"; p.append(int(limit))
    rows = [db._biz_row(r) for r in con.execute(q, p)]
    con.close()
    return annotate_stories(rows)


# ---------------------------------------------------------------- server favorites
def fav_list(customer_id):
    if not customer_id:
        return []
    con = db.connect()
    rows = [r["biz_id"] for r in con.execute(
        "SELECT biz_id FROM favorites WHERE customer_id=? ORDER BY id DESC",
        (customer_id,))]
    con.close()
    return rows


def fav_toggle(customer_id, biz_id):
    if not customer_id:
        return False
    con = db.connect()
    r = con.execute("SELECT 1 FROM favorites WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id)).fetchone()
    if r:
        con.execute("DELETE FROM favorites WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id))
        on = False
    else:
        con.execute("INSERT INTO favorites(customer_id,biz_id) VALUES(?,?)",
                    (customer_id, biz_id))
        on = True
    con.commit()
    con.close()
    return on


def fav_merge(customer_id, values):
    """Adopt the device-local favorites after sign-in. `values` may contain
    business ids OR slugs (the device stores slugs)."""
    if not customer_id:
        return 0
    con = db.connect()
    n = 0
    for b in (values or []):
        bid = None
        try:
            bid = int(b)
            if not con.execute("SELECT 1 FROM businesses WHERE id=?", (bid,)).fetchone():
                bid = None
        except (TypeError, ValueError):
            bid = None
        if bid is None:
            r = con.execute("SELECT id FROM businesses WHERE slug=?",
                            (str(b).strip(),)).fetchone()
            bid = r["id"] if r else None
        if bid is None:
            continue
        if not con.execute("SELECT 1 FROM favorites WHERE customer_id=? AND biz_id=?",
                           (customer_id, bid)).fetchone():
            con.execute("INSERT INTO favorites(customer_id,biz_id) VALUES(?,?)",
                        (customer_id, bid))
            n += 1
    con.commit()
    con.close()
    return n


# ==========================================================================
#  ADMIN PANEL SUPPORT  (v29): audit log, customers, areas
# ==========================================================================
def audit_log(limit=120):
    return db._rows("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (int(limit),))


def customers_list():
    """Every customer account with live counts, for the admin panel."""
    rows = db._rows("SELECT * FROM customers ORDER BY id DESC")
    con = db.connect()
    for r in rows:
        r["n_orders"] = con.execute(
            "SELECT COUNT(*) c FROM orders WHERE customer_id=?", (r["id"],)).fetchone()["c"]
        r["n_chats"] = con.execute(
            "SELECT COUNT(*) c FROM chat_threads WHERE customer_id=?", (r["id"],)).fetchone()["c"]
        r["n_favs"] = con.execute(
            "SELECT COUNT(*) c FROM favorites WHERE customer_id=?", (r["id"],)).fetchone()["c"]
    con.close()
    return rows


def rename_area(old, new):
    """Rename a neighbourhood everywhere it is used. -> count updated."""
    if not old or not new or old == new:
        return 0
    con = db.connect()
    con.execute("UPDATE businesses SET area=? WHERE area=?", (new, old))
    con.commit()
    n = con.execute("SELECT COUNT(*) c FROM businesses WHERE area=?", (new,)).fetchone()["c"]
    con.close()
    return n


def customer_counts():
    con = db.connect()
    out = {
        "customers": con.execute("SELECT COUNT(*) c FROM customers").fetchone()["c"],
        "orders": con.execute("SELECT COUNT(*) c FROM orders").fetchone()["c"],
        "chats": con.execute("SELECT COUNT(*) c FROM chat_threads").fetchone()["c"],
        "messages": con.execute("SELECT COUNT(*) c FROM messages WHERE status='new'").fetchone()["c"],
    }
    con.close()
    return out


# ==========================================================================
#  TOP LISTS  (v31) — "برترین‌های شهر"
# ==========================================================================
TOP_AUTO = {
    "auto_rating":  ("ORDER BY rating DESC NULLS LAST, nreviews DESC, id DESC"),
    "auto_views":   ("ORDER BY views DESC, id DESC"),
    "auto_featured": ("ORDER BY featured DESC, rating DESC NULLS LAST, id DESC"),
    "auto_new":     ("ORDER BY id DESC"),
}


def toplists(active_only=True):
    q = "SELECT * FROM toplists"
    if active_only:
        q += " WHERE active=1"
    q += " ORDER BY sort, id"
    return db._rows(q)


def toplist(slug=None, tid=None):
    if slug:
        r = db._one("SELECT * FROM toplists WHERE slug=?", (slug,))
    else:
        r = db._one("SELECT * FROM toplists WHERE id=?", (tid,))
    return r


def toplist_businesses(t, limit=None):
    """The ranked businesses of a list. Auto kinds are computed live; manual
    lists read their saved id list. Returns rows in rank order (1-based)."""
    if t.get("kind") in TOP_AUTO:
        rows = db._rows(
            "SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved') rating, "
            "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews "
            "FROM businesses b WHERE b.status='published' " + TOP_AUTO[t["kind"]])
    else:
        try:
            ids = [int(x) for x in json.loads(t.get("items") or "[]")]
        except (TypeError, ValueError):
            ids = []
        rows = []
        for bid in ids:
            r = db._one("SELECT b.*, (SELECT AVG(rating) FROM reviews WHERE biz_id=b.id AND status='approved') rating, "
                     "(SELECT COUNT(*) FROM reviews WHERE biz_id=b.id AND status='approved') nreviews "
                     "FROM businesses b WHERE b.id=? AND b.status='published'", (bid,))
            if r:
                rows.append(r)
    n = int(limit or t.get("limit_n") or 10)
    rows = [db._biz_row(r) for r in rows[:n]]
    for i, r in enumerate(rows):
        r["rank"] = i + 1
    return rows


def save_toplist(data, tid=None):
    con = db.connect()
    if "items" in data and not isinstance(data["items"], str):
        data["items"] = json.dumps(data["items"], ensure_ascii=False)
    if tid:
        sets = ", ".join(f"{k}=?" for k in data)
        con.execute(f"UPDATE toplists SET {sets} WHERE id=?", list(data.values()) + [tid])
    else:
        data.setdefault("slug", db.unique_slug("toplists", db.slugify(data.get("title", "لیست"))))
        cols = ", ".join(data)
        con.execute(f"INSERT INTO toplists({cols}) VALUES({','.join('?' * len(data))})",
                    list(data.values()))
        tid = con.execute("SELECT last_insert_rowid() i").fetchone()["i"]
    con.commit()
    con.close()
    return tid


def delete_toplist(tid):
    db._run("DELETE FROM toplists WHERE id=?", (tid,))


# ==========================================================================
#  FLASH DEALS  (v31) — "پیشنهاد روز / فلش‌سیل"
# ==========================================================================
def flashdeals(active_only=True):
    now = datetime.datetime.now().isoformat(timespec="seconds")
    q = "SELECT f.*, b.name bizname, b.slug bizslug FROM flashdeals f JOIN businesses b ON b.id=f.biz_id WHERE 1=1"
    p = []
    if active_only:
        q += " AND f.active=1 AND (f.starts='' OR f.starts<=?) AND f.ends>=?"
        p += [now, now]
    q += " ORDER BY f.ends, f.id DESC"
    return db._rows(q, p)


def save_flashdeal(data, did=None):
    if did:
        con = db.connect()
        sets = ", ".join(f"{k}=?" for k in data)
        con.execute(f"UPDATE flashdeals SET {sets} WHERE id=?", list(data.values()) + [did])
        con.commit()
        con.close()
        return did
    return db._run(
        "INSERT INTO flashdeals(biz_id,title,descr,percent,starts,ends,active) "
        "VALUES(?,?,?,?,?,?,?)",
        (data.get("biz_id"), data.get("title", ""), data.get("descr", ""),
         int(data.get("percent") or 0), data.get("starts", ""), data.get("ends", ""),
         int(data.get("active", 1) or 1)))


def delete_flashdeal(did):
    db._run("DELETE FROM flashdeals WHERE id=?", (did,))


# ==========================================================================
#  LOYALTY  (v31) — points for engagement, redeem for coupons
# ==========================================================================
def points_add(customer_id, amount, reason=""):
    if not customer_id or not amount:
        return 0
    db._run("INSERT INTO points(customer_id,amount,reason) VALUES(?,?,?)",
         (customer_id, int(amount), reason[:100]))
    return points_balance(customer_id)


def points_balance(customer_id):
    if not customer_id:
        return 0
    r = db._one("SELECT COALESCE(SUM(amount),0) s FROM points WHERE customer_id=?", (customer_id,))
    spent = db._one("SELECT COALESCE(SUM(points_spent),0) s FROM redemptions WHERE customer_id=?", (customer_id,))
    return int((r["s"] if r else 0)) - int((spent["s"] if spent else 0))


def points_history(customer_id):
    return db._rows("SELECT * FROM points WHERE customer_id=? ORDER BY id DESC LIMIT 100", (customer_id,))


def loyalty_redeem(customer_id):
    """Spend `coupon_cost` points -> a unique 10% coupon code."""
    s = db.get_settings()
    if s.get("loyalty_on") != "1":
        return None, "برنامهٔ وفاداری غیرفعال است."
    cost = int(s.get("coupon_cost", "50") or 50)
    if points_balance(customer_id) < cost:
        return None, "امتیاز کافی ندارید."
    code = "BZ" + secrets.token_hex(3).upper()
    db._run("INSERT INTO redemptions(customer_id,code,percent,points_spent) VALUES(?,?,10,?)",
         (customer_id, code, cost))
    return code, f"کوپن ۱۰٪ شما ساخته شد: {code}"


def redemptions_list(customer_id=None):
    q = "SELECT r.*, c.phone custphone, c.name custname FROM redemptions r LEFT JOIN customers c ON c.id=r.customer_id"
    p = []
    if customer_id:
        q += " WHERE r.customer_id=?"
        p.append(customer_id)
    q += " ORDER BY r.id DESC LIMIT 200"
    return db._rows(q, p)


def top_customers(limit=20):
    return db._rows(
        "SELECT c.id, c.phone, c.name, COALESCE(SUM(p.amount),0) pts "
        "FROM customers c LEFT JOIN points p ON p.customer_id=c.id "
        "GROUP BY c.id ORDER BY pts DESC LIMIT ?", (int(limit),))


# ==========================================================================
#  STORIES  (v31) — 24-hour shop stories
# ==========================================================================
STORY_TTL = 24 * 3600


def stories_active_ids():
    """The set of business ids that currently have a live story — used to draw
    an Instagram-style ring on their cards and pages without a query per card."""
    con = db.connect()
    rows = con.execute("SELECT DISTINCT biz_id FROM stories WHERE expires>=?",
                       (time.time(),)).fetchall()
    con.close()
    return {r["biz_id"] for r in rows}


def annotate_stories(rows):
    """Mark `has_story` on every business row in one pass (one query total)."""
    ids = stories_active_ids()
    for r in rows:
        r["has_story"] = r.get("id") in ids
    return rows


def stories_add(biz_id, image, caption="", kind="image"):
    return db._run("INSERT INTO stories(biz_id,image,kind,caption,created,expires) "
                "VALUES(?,?,?,?,datetime('now'),?)",
                (biz_id, image, kind if kind == "video" else "image",
                 caption[:200], time.time() + STORY_TTL))


def stories_active():
    """Stories grouped by business, newest first, only unexpired and published."""
    con = db.connect()
    con.execute("DELETE FROM stories WHERE expires < ?", (time.time(),))
    con.commit()
    rows = db._rows(
        "SELECT s.*, b.name bizname, b.slug bizslug FROM stories s "
        "JOIN businesses b ON b.id=s.biz_id WHERE s.expires>=? AND b.status='published' "
        "ORDER BY s.id DESC LIMIT 200", (time.time(),))
    con.close()
    return rows


def stories_for_owner(owner_id):
    biz_ids = [b["id"] for b in db.businesses_of(owner_id)]
    if not biz_ids:
        return []
    return db._rows(
        "SELECT s.*, b.name bizname FROM stories s JOIN businesses b ON b.id=s.biz_id "
        "WHERE s.biz_id IN (%s) ORDER BY s.id DESC LIMIT 100" % ",".join("?" * len(biz_ids)),
        biz_ids)


def stories_for_biz(biz_id, active_only=True):
    q = "SELECT * FROM stories WHERE biz_id=?"
    p = [biz_id]
    if active_only:
        q += " AND expires>=?"
        p.append(time.time())
    q += " ORDER BY id DESC LIMIT 50"
    return db._rows(q, p)


def story_delete(sid):
    return db._run("DELETE FROM stories WHERE id=?", (sid,))


# ==========================================================================
#  FOLLOW + NOTIFICATIONS  (v32 — Instagram-style)
# ==========================================================================
def follow_state(customer_id, biz_id):
    if not customer_id:
        return False
    r = db._one("SELECT 1 FROM follows WHERE customer_id=? AND biz_id=?",
             (customer_id, biz_id))
    return bool(r)


def follow_toggle(customer_id, biz_id):
    if not customer_id:
        return False
    con = db.connect()
    r = con.execute("SELECT 1 FROM follows WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id)).fetchone()
    if r:
        con.execute("DELETE FROM follows WHERE customer_id=? AND biz_id=?",
                    (customer_id, biz_id))
        on = False
    else:
        con.execute("INSERT INTO follows(customer_id,biz_id) VALUES(?,?)",
                    (customer_id, biz_id))
        on = True
    con.commit()
    con.close()
    return on


def follow_count(biz_id):
    r = db._one("SELECT COUNT(*) c FROM follows WHERE biz_id=?", (biz_id,))
    return int(r["c"]) if r else 0


def following_ids(customer_id):
    if not customer_id:
        return []
    con = db.connect()
    rows = [r["biz_id"] for r in con.execute(
        "SELECT biz_id FROM follows WHERE customer_id=? ORDER BY id DESC", (customer_id,))]
    con.close()
    return rows


def notify(customer_id, kind, text, link=""):
    """Push an in-app notification to a customer."""
    if not customer_id:
        return
    db._run("INSERT INTO notifications(customer_id,kind,text,link) VALUES(?,?,?,?)",
         (customer_id, kind, str(text)[:200], str(link)[:200]))


def notifications(customer_id, unread_only=False, limit=100):
    q = "SELECT * FROM notifications WHERE customer_id=?"
    p = [customer_id]
    if unread_only:
        q += " AND read=0"
    q += " ORDER BY id DESC LIMIT ?"
    p.append(int(limit))
    return db._rows(q, p)


def notifications_unread(customer_id):
    if not customer_id:
        return 0
    r = db._one("SELECT COUNT(*) c FROM notifications WHERE customer_id=? AND read=0",
             (customer_id,))
    return int(r["c"]) if r else 0


def notifications_mark_read(customer_id):
    db._run("UPDATE notifications SET read=1 WHERE customer_id=?", (customer_id,))


# helpful votes on reviews (Instagram-style like)
def review_helpful(rid):
    db._run("UPDATE reviews SET helpful = COALESCE(helpful,0)+1 WHERE id=?", (rid,))
    r = db._one("SELECT helpful FROM reviews WHERE id=?", (rid,))
    return int(r["helpful"] or 0) if r else 0


# ==========================================================================
#  ADMIN MODERATION  (v34): block/delete customers, broadcast, follows
# ==========================================================================
def customer_set_status(cid, status):
    if status not in ("active", "blocked"):
        return False
    db._run("UPDATE customers SET status=? WHERE id=?", (status, cid))
    if status == "blocked":
        db._run("DELETE FROM customer_sessions WHERE customer_id=?", (cid,))
    return True


def customer_delete(cid):
    """Delete a customer and every trace (orders, chats, favs, follows,
    notifications, points, redemptions, sessions)."""
    con = db.connect()
    con.execute("DELETE FROM customer_sessions WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM notifications WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM favorites WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM follows WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM points WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM redemptions WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM chat_messages WHERE thread_id IN "
                "(SELECT id FROM chat_threads WHERE customer_id=?)", (cid,))
    con.execute("DELETE FROM chat_threads WHERE customer_id=?", (cid,))
    con.execute("UPDATE orders SET customer_id=NULL WHERE customer_id=?", (cid,))
    con.execute("DELETE FROM customers WHERE id=?", (cid,))
    con.commit()
    con.close()


def notify_all(kind, text, link=""):
    """Broadcast a notification to every customer account."""
    con = db.connect()
    ids = [r["id"] for r in con.execute("SELECT id FROM customers WHERE status='active'")]
    for cid in ids:
        con.execute("INSERT INTO notifications(customer_id,kind,text,link) VALUES(?,?,?,?)",
                    (cid, kind, str(text)[:200], str(link)[:200]))
    con.commit()
    con.close()
    return len(ids)


def top_followed(limit=30):
    return db._rows(
        "SELECT b.id, b.name, b.slug, COUNT(f.id) n FROM businesses b "
        "LEFT JOIN follows f ON f.biz_id=b.id "
        "WHERE b.status='published' GROUP BY b.id ORDER BY n DESC, b.id LIMIT ?",
        (int(limit),))

__all__ = [
    "annotate_stories",
    "areas",
    "audit_log",
    "businesses_in_area",
    "chat_messages",
    "chat_send",
    "chat_set_status",
    "chat_start",
    "chat_thread",
    "chat_threads_all",
    "chat_threads_for_customer",
    "chat_threads_for_owner",
    "chat_unread_owner",
    "create_order",
    "customer_by_id",
    "customer_by_phone",
    "customer_counts",
    "customer_delete",
    "customer_otp_issue",
    "customer_session_get",
    "customer_session_kill",
    "customer_session_new",
    "customer_set_name",
    "customer_set_status",
    "customers_list",
    "db_chat_msg_ids",
    "delete_flashdeal",
    "delete_toplist",
    "fav_list",
    "fav_merge",
    "fav_toggle",
    "flashdeals",
    "follow_count",
    "follow_state",
    "follow_toggle",
    "following_ids",
    "loyalty_redeem",
    "notifications",
    "notifications_mark_read",
    "notifications_unread",
    "notify",
    "notify_all",
    "order",
    "order_items",
    "orders_all",
    "orders_for_customer",
    "orders_for_owner",
    "points_add",
    "points_balance",
    "points_history",
    "redemptions_list",
    "rename_area",
    "review_helpful",
    "save_flashdeal",
    "save_toplist",
    "set_order_status",
    "stories_active",
    "stories_active_ids",
    "stories_add",
    "stories_for_biz",
    "stories_for_owner",
    "story_delete",
    "top_customers",
    "top_followed",
    "toplist",
    "toplist_businesses",
    "toplists",
    "ORDER_LABELS",
    "ORDER_STATUS",
    "CUSTOMER_OTP_TTL",
    "CUSTOMER_SESSION_TTL",
    "TOP_AUTO",
    "STORY_TTL",
]
