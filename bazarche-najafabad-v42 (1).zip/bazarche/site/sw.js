/* Bazarche Najafabad — service worker
   Cache-first for immutable assets, network-first for HTML.
   Anything session-dependent is never cached, so a stale shell can never
   make the site look blank or logged-out. */

/* Bumped from v5. The activate handler below deletes every cache whose name
   is not exactly VERSION, so changing this string is what evicts the shell the
   prototype saved on a phone. If a stale page ever reappears, bump it again. */
const VERSION = 'bazarche-v22';

const OFFLINE = '/offline.html';

const SHELL = [
  OFFLINE,
  '/assets/css/tokens.css',
  '/assets/css/main.css',
  '/assets/css/pages.css',
  '/assets/css/mobile-refine.css',
  '/assets/css/mobile-standard.css',
  '/assets/js/app.js',
  '/assets/js/map.js',
  '/assets/vendor/leaflet/leaflet.css',
  '/assets/vendor/leaflet/leaflet.js',
  '/assets/fonts/Vazirmatn-Variable.woff2',
  '/assets/img/favicon.svg',
  '/assets/img/icons/sprite.webp',
];

// Never cache: owner panel, shop-owner area, auth, tracking, API.
const NO_CACHE = ['/panel', '/my', '/login', '/logout', '/t/', '/api/'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(VERSION)
      .then(c => c.addAll(SHELL).catch(() => {}))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k))))
      // A phone that ran the prototype may still hold a worker registered from
      // that build. Claiming clients is not enough on its own — the old worker
      // keeps serving until every tab closes — so force a reload of anything
      // still controlled by it once the new cache is in place.
      .then(() => self.clients.claim())
      .then(() => self.clients.matchAll({ type: 'window' }))
      .then(list => list.forEach(c => { try { c.navigate(c.url); } catch (err) {} }))
  );
});

self.addEventListener('message', (e) => {
  if (e.data === 'skipWaiting') self.skipWaiting();
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (NO_CACHE.some(p => url.pathname.startsWith(p))) return;

  // Immutable assets: cache first.
  if (url.pathname.startsWith('/assets/')) {
    e.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(res => {
        const copy = res.clone();
        caches.open(VERSION).then(c => c.put(req, copy)).catch(() => {});
        return res;
      }))
    );
    return;
  }

  // HTML: network first. Never store the response — every page now renders a
  // header that depends on who is signed in, so a cached copy would show the
  // previous visitor's account (or a stale "ورود / ثبت‌نام" after login).
  // The offline fallback is a single generic shell, not the real page.
  e.respondWith(
    fetch(req)
      .catch(() => caches.match(OFFLINE).then(hit => hit || caches.match('/offline.html')))
  );
});
