/* Bazarche — cart: localStorage basket + "add to cart" buttons + checkout.
   Guest checkout is allowed (name + phone); a logged-in customer's orders are
   linked to their account automatically server-side. */
const KEY = 'bazarche_cart_v1';
const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } };
const write = (c) => localStorage.setItem(KEY, JSON.stringify(c));
const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = n => String(n).replace(/\d/g, d => FA[+d]);
const g = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

const cartCount = () => read().reduce((s, i) => s + (i.qty || 1), 0);

function updateBadge() {
  document.querySelectorAll('[data-cart-count]').forEach(el => {
    const n = cartCount();
    el.textContent = fa(n);
    el.hidden = n === 0;
  });
}

// ---- add to cart (buttons on catalog cards)
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-add-cart]');
  if (!btn) return;
  const cart = read();
  const id = btn.dataset.id;
  const existing = cart.find(i => i.id === id && i.biz === btn.dataset.biz);
  if (existing) existing.qty += 1;
  else cart.push({
    id, biz: btn.dataset.biz, bizname: btn.dataset.bizname,
    title: btn.dataset.title, price: +btn.dataset.price, qty: 1,
  });
  write(cart);
  updateBadge();
  window.Bazarche?.toast?.('«' + btn.dataset.title + '» به سبد اضافه شد.', 'ok');
});

// ---- cart page rendering
const root = document.getElementById('cart-root');
if (root) {
  const cart = read();
  if (!cart.length) {
    root.innerHTML = `<div class="card glass card-pad" style="text-align:center">
      <p class="text-muted">سبد خرید شما خالی است.</p>
      <a class="btn btn-primary mt-md" href="/catalog">${''}مرور محصولات</a></div>`;
  } else {
    const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
    const rows = cart.map((i, idx) => `<tr>
      <td>${i.title.replace(/&/g,'&amp;').replace(/</g,'&lt;')}</td>
      <td class="text-muted text-sm">${(i.bizname||'').replace(/&/g,'&amp;').replace(/</g,'&lt;')}</td>
      <td class="nums">${g(i.price)}</td>
      <td><input type="number" min="1" max="99" value="${i.qty}" data-qty="${idx}" style="width:64px"></td>
      <td class="nums">${g(i.price * i.qty)}</td>
      <td><button type="button" class="btn-icon" data-rm="${idx}" aria-label="حذف">✕</button></td></tr>`).join('');
    root.innerHTML = `<div class="grid grid-2" style="align-items:start">
      <div class="card glass card-pad">
        <h2 class="card-title mb-md">اقلام سبد</h2>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>عنوان</th><th>کسب‌وکار</th><th>قیمت</th><th>تعداد</th><th>جمع</th><th></th></tr></thead>
          <tbody>${rows}</tbody>
          <tfoot><tr><th colspan="4">مجموع</th><td class="nums"><strong>${g(total)}</strong></td><td></td></tr></tfoot>
        </table></div>
      </div>
      <form class="card glass card-pad" method="post" action="/order/create" data-validate>
        <h2 class="card-title mb-md">ثبت سفارش</h2>
        <input type="hidden" name="biz_id" value="${cart[0].biz || ''}">
        <input type="hidden" name="items" id="cart-items" value="">
        <div class="field"><label class="field-label">نام شما</label>
          <input class="input" name="name" required minlength="2" maxlength="100"></div>
        <div class="field"><label class="field-label">شمارهٔ موبایل</label>
          <input class="input nums" name="phone" type="tel" dir="ltr" required
                 inputmode="numeric" pattern="0[0-9]{10}" maxlength="11"></div>
        <div class="field"><label class="field-label">نشانی (اختیاری)</label>
          <input class="input" name="address" maxlength="300"></div>
        <div class="field"><label class="field-label">یادداشت</label>
          <textarea class="textarea" name="note" maxlength="500" rows="2"></textarea></div>
        <button class="btn btn-primary btn-block" type="submit">ثبت سفارش</button>
        <p class="field-hint">برای پیگیری سفارش، با همین شماره وارد «حساب من» شوید.</p>
      </form>
    </div>`;

    const itemsInput = document.getElementById('cart-items');
    const sync = () => {
      itemsInput.value = JSON.stringify(read().map(i => ({ item_id: +i.id, title: i.title, price: i.price, qty: i.qty })));
    };
    sync();
    root.addEventListener('input', (e) => {
      const q = e.target.closest('[data-qty]');
      if (!q) return;
      const c = read();
      const idx = +q.dataset.qty;
      c[idx].qty = Math.max(1, Math.min(99, +q.value || 1));
      write(c); sync(); updateBadge();
      location.reload();
    });
    root.addEventListener('click', (e) => {
      const rm = e.target.closest('[data-rm]');
      if (!rm) return;
      const c = read();
      c.splice(+rm.dataset.rm, 1);
      write(c); updateBadge(); location.reload();
    });
  }
}

updateBadge();
