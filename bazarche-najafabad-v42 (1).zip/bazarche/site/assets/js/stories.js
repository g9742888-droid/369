/* Bazarche — story bar + fullscreen story viewer (v32) */
const esc = t => String(t == null ? '' : t)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

// ---------- fullscreen story viewer (shared) ----------
function openGroup(group) {
  if (!group || !group.items || !group.items.length) return;
  let idx = 0;
  const ov = document.createElement('div');
  ov.className = 'story-viewer';
  ov.innerHTML = `
    <div class="sv-progress">${group.items.map(() => '<span></span>').join('')}</div>
    <button class="sv-close" type="button" aria-label="بستن">✕</button>
    <button class="sv-nav sv-prev" type="button" aria-label="قبلی">‹</button>
    <button class="sv-nav sv-next" type="button" aria-label="بعدی">›</button>
    <div class="sv-media"><img src="${esc(group.items[0].image)}" alt=""></div>
    <div class="sv-caption">
      <strong>${esc(group.name)}</strong>
      <span>${esc(group.items[0].caption || '')}</span>
    </div>
    <a class="sv-link" href="/b/${esc(group.slug)}">مشاهدهٔ صفحهٔ کسب‌وکار</a>`;
  document.body.appendChild(ov);
  document.body.style.overflow = 'hidden';

  const bars = ov.querySelectorAll('.sv-progress span');
  const media = ov.querySelector('.sv-media img');
  const capName = ov.querySelector('.sv-caption strong');
  const capText = ov.querySelector('.sv-caption span');
  let timer = null;
  const DUR = 5000;

  const render = () => {
    const s = group.items[idx];
    capName.textContent = group.name;
    capText.textContent = s.caption || '';
    bars.forEach((b, i) => b.classList.toggle('is-on', i === idx));
    bars.forEach((b, i) => b.classList.toggle('is-done', i < idx));
    clearInterval(timer);
    if (s.kind === 'video') {
      // swap the <img> for a muted autoplay <video>
      const wrap = ov.querySelector('.sv-media');
      const vid = document.createElement('video');
      vid.src = s.image;
      vid.autoplay = true; vid.muted = true; vid.playsInline = true; vid.loop = true;
      vid.controls = false;
      wrap.innerHTML = ''; wrap.appendChild(vid);
      // advance manually at the end, or after a long cap
      vid.onended = () => next();
      timer = setInterval(() => {}, 10_000_000);   // let the video drive
      setTimeout(next, 15_000);                   // safety cap
    } else {
      const wrap = ov.querySelector('.sv-media');
      if (wrap.querySelector('video')) {
        wrap.innerHTML = ''; wrap.appendChild(media);
      }
      media.src = s.image;
      timer = setInterval(next, DUR);
    }
  };
  const next = () => { if (idx + 1 >= group.items.length) return close(); idx++; render(); };
  const prev = () => { if (idx > 0) { idx--; render(); } };
  const close = () => { clearInterval(timer); ov.remove(); document.body.style.overflow = ''; };

  ov.querySelector('.sv-close').addEventListener('click', close);
  ov.querySelector('.sv-next').addEventListener('click', next);
  ov.querySelector('.sv-prev').addEventListener('click', prev);
  ov.addEventListener('click', (e) => { if (e.target === ov) close(); });
  document.addEventListener('keydown', function onKey(e) {
    if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); }
  });
  render();
}

// ---------- per-business story buttons (cards + business page) ----------
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-story-biz]');
  if (!btn) return;
  e.preventDefault();
  e.stopPropagation();
  const slug = btn.dataset.storyBiz;
  try {
    const r = await fetch('/api/stories');
    const j = await r.json();
    const mine = (j.stories || []).filter(s => s.bizslug === slug);
    if (!mine.length) return;
    openGroup({ name: mine[0].bizname, slug, items: mine });
  } catch (err) { /* offline */ }
});

// ---------- story bar on the homepage ----------
const bar = document.querySelector('[data-stories-bar]');
if (bar) {
  (async function boot() {
    let stories = [];
    try {
      const r = await fetch('/api/stories');
      const j = await r.json();
      stories = j.stories || [];
    } catch (e) { return; }

    const groups = new Map();
    for (const s of stories) {
      if (!groups.has(s.bizslug)) groups.set(s.bizslug, { name: s.bizname, slug: s.bizslug, items: [] });
      groups.get(s.bizslug).items.push(s);
    }
    const list = Array.from(groups.values());
    if (!list.length) { bar.hidden = true; return; }

    bar.innerHTML = list.map((g, i) => {
      const last = g.items[g.items.length - 1];
      const isVid = last.kind === 'video';
      const thumb = isVid
        ? `<span class="story-vid-tag" aria-hidden="true">▶</span>`
        : `<img src="${esc(last.image)}" alt="" loading="lazy" decoding="async">`;
      return `<button class="story-ring" type="button" data-story-group="${i}" aria-label="استوری‌های ${esc(g.name)}">
        <span class="story-ring-inner">${thumb}</span>
        <span class="story-name">${esc(g.name)}</span>
      </button>`;
    }).join('');

    bar.addEventListener('click', (e) => {
      const b = e.target.closest('[data-story-group]');
      if (!b) return;
      openGroup(list[+b.dataset.storyGroup]);
    });
  })();
}
