/* ==========================================================================
   Admin site-wide edit mode (v20)
   Active only when an admin token is present (window.__BAZARCHE__.token) and
   the admin bar is rendered. Flips the page into edit mode: every element
   marked [data-edit="type:id:field"] becomes editable in place, and a save
   fires on blur to /panel/inline-edit. Visitors never see any of this.

   data-edit grammar:  data-edit="<type>:<id>:<field>"
     business:<id>:name | descr | address | phone | tags
     setting::hero_lead | hero_cta | site_name | ...
     category:<id>:name | blurb
     page:<slug>:body
   ========================================================================== */
const B = window.__BAZARCHE__ || {};
const bar = document.querySelector('[data-admin-bar]');
if (B.token && bar) {
  const $ = (s, r = document) => r.querySelector(s);
  const toggle = $('[data-edit-toggle]', bar);
  const quick = $('[data-quick-edit]', bar);
  const K = '?key=' + encodeURIComponent(B.token);
  const toast = (m, k) => window.Bazarche?.toast?.(m, k || 'ok');

  // context-aware "edit this page" deep link -> the right admin screen
  if (quick) {
    const p = location.pathname;
    const map = [
      [/^\/b\//, null],                       // handled per-business by data-edit
      [/^\/$/, '/panel/appearance'],
      [/^\/businesses/, '/panel/businesses'],
      [/^\/blog/, '/panel/posts'],
      [/^\/pricing/, '/panel/plans'],
      [/^\/offers/, '/panel/coupons'],
      [/^\/map/, '/panel/businesses'],
      [/^\/(about|rules)/, '/panel/pages'],
      [/^\/contact/, '/panel/settings'],
    ];
    let dest = '/panel';
    for (const [re, d] of map) if (re.test(p)) { dest = d || dest; break; }
    quick.href = dest + K;
  }

  let on = false;
  const setMode = (v) => {
    on = v;
    document.body.classList.toggle('admin-editing', v);
    toggle.setAttribute('aria-pressed', String(v));
    const lbl = $('span', toggle);
    if (lbl) lbl.textContent = v ? 'پایان ویرایش' : 'حالت ویرایش';
    document.querySelectorAll('[data-edit]').forEach(el => {
      el.contentEditable = v ? 'true' : 'false';
      el.classList.toggle('is-editable', v);
      if (v) el.setAttribute('title', 'کلیک کنید و ویرایش کنید، بعد بیرون بزنید تا ذخیره شود');
      else el.removeAttribute('title');
    });
    if (v) toast('حالت ویرایش روشن شد — روی متن‌های مشخص‌شده کلیک کنید.', 'ok');
  };
  toggle.addEventListener('click', () => setMode(!on));

  // save an edited field when it loses focus
  document.addEventListener('blur', (e) => {
    const el = e.target;
    if (!on || !el || !el.dataset || !el.dataset.edit) return;
    const [type, id, field] = el.dataset.edit.split(':');
    const value = (el.innerText || el.textContent || '').replace(/\u00a0/g, ' ').trim();
    const fd = new FormData();
    fd.set('key', B.token); fd.set('type', type);
    fd.set('id', id || ''); fd.set('field', field); fd.set('value', value);
    el.classList.add('is-saving');
    fetch('/panel/inline-edit', { method: 'POST', body: fd })
      .then(r => r.json())
      .then(j => {
        el.classList.remove('is-saving');
        toast(j.ok ? 'ذخیره شد ✓' : ('ذخیره نشد: ' + (j.error || '')), j.ok ? 'ok' : 'err');
      })
      .catch(() => { el.classList.remove('is-saving'); toast('ذخیره ناموفق بود.', 'err'); });
  }, true);

  // keyboard: Ctrl/Cmd+E toggles edit mode
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'e') {
      e.preventDefault(); setMode(!on);
    }
  });
}
