/* ==========================================================================
   Q&A helpers: "this was helpful" counter (real POST, real column)
   and the multi-criteria star pickers on the review form.
   ========================================================================== */
const FA = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
const fa = (n) => String(n).replace(/\d/g, d => FA[+d]);
const VOTED = 'bazarche.qavotes';

const voted = () => {
  try { return JSON.parse(localStorage.getItem(VOTED) || '[]'); }
  catch (e) { return []; }
};

function markVoted(id) {
  const v = voted();
  if (!v.includes(id)) { v.push(id); }
  try { localStorage.setItem(VOTED, JSON.stringify(v)); } catch (e) {}
}

function initHelpful() {
  const already = voted();
  document.querySelectorAll('[data-helpful]').forEach(btn => {
    const id = btn.dataset.helpful;
    if (already.includes(id)) {
      btn.setAttribute('aria-pressed', 'true');
      btn.disabled = true;
    }
    btn.addEventListener('click', async () => {
      if (btn.disabled) return;
      btn.disabled = true;
      try {
        const res = await fetch('/api/question-helpful', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'id=' + encodeURIComponent(id)
        });
        const data = await res.json();
        const n = btn.querySelector('[data-helpful-n]');
        if (n && typeof data.helpful === 'number') n.textContent = fa(data.helpful);
        btn.setAttribute('aria-pressed', 'true');
        markVoted(id);
        window.Bazarche?.toast('ممنون از بازخورد شما.', 'ok');
      } catch (e) {
        btn.disabled = false;
        window.Bazarche?.toast('ثبت نشد. دوباره تلاش کنید.', 'err');
      }
    });
  });
}

function initCriteria() {
  document.querySelectorAll('[data-crit-input] .row').forEach(row => {
    const input = row.querySelector('input[type="hidden"]');
    const stars = Array.from(row.querySelectorAll('button'));
    const paint = (v) => stars.forEach((s, i) => s.setAttribute('aria-pressed', String(i < v)));
    stars.forEach((s, i) => {
      s.addEventListener('click', () => { if (input) input.value = i + 1; paint(i + 1); });
      s.addEventListener('mouseenter', () => paint(i + 1));
      s.addEventListener('focus', () => paint(i + 1));
    });
    row.addEventListener('mouseleave', () => paint(parseInt(input?.value || '0', 10)));
    paint(parseInt(input?.value || '5', 10));
  });
}

function boot() { initHelpful(); initCriteria(); }

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}
