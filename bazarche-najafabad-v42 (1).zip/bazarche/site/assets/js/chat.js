/* Bazarche — chat page: poll for new messages and scroll to the bottom. */
const box = document.querySelector('[data-chat]');
if (box) {
  const tid = box.dataset.thread;
  const me = box.dataset.me || 'customer';
  let lastId = parseInt(box.dataset.last || '0', 10) || 0;

  const scroll = () => { box.scrollTop = box.scrollHeight; };
  scroll();

  const esc = t => String(t == null ? '' : t)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  async function poll() {
    try {
      const r = await fetch(`/api/chat/${tid}/msgs?after=${lastId}`);
      const j = await r.json();
      if (!j.ok || !j.msgs || !j.msgs.length) return;
      for (const m of j.msgs) {
        if (m.id <= lastId) continue;
        lastId = m.id;
        const cls = m.sender === me ? 'me' : (m.sender === 'admin' ? 'admin' : 'them');
        const div = document.createElement('div');
        div.className = 'msg ' + cls;
        div.innerHTML = `<div class="msg-bubble">${esc(m.body)}</div>
          <div class="msg-meta">${esc(m.sender)} · ${esc((m.created || '').slice(5, 16))}</div>`;
        box.appendChild(div);
      }
      scroll();
    } catch (e) { /* offline — ignore */ }
  }
  setInterval(poll, 3000);
}
