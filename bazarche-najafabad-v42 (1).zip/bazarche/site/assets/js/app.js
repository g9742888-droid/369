/* ==========================================================================
   Bazarche Najafabad — Application layer
   Theme, navigation, 3D tilt engine, scroll reveal, filters, forms, toasts.
   Vanilla ES module. No build step. Degrades safely without JS.
   ========================================================================== */

/* -------------------------------------------------------------------------
   0. Boot flag — CSS uses .js to opt into reveal animations
   ---------------------------------------------------------------------- */
document.documentElement.classList.add('js');

const RM = window.matchMedia('(prefers-reduced-motion: reduce)');
const prefersReduced = () => RM.matches;
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

/* -------------------------------------------------------------------------
   0. MIGRATE FROM THE PROTOTYPE  (runs once, then never touches storage)
   -------------------------------------------------------------------------
   The early build stored under un-namespaced keys on the same origin. Left
   alone they shadow the new ones and the site behaves like the old version.
   Favourites are carried across because a shopkeeper's saved list is real;
   everything else from that build is dropped.
   ---------------------------------------------------------------------- */
(function migrateLegacyStorage() {
  // No "already done" flag on purpose. A one-shot flag looked tidier, but it
  // fails the exact case it exists for: the first visit sets the flag, and if
  // the legacy data shows up a moment later (another tab, a restored session,
  // a phone that opened the new site before the old one) it is stranded for
  // good. This costs two localStorage reads per page load and cannot strand
  // anything: it simply moves whatever legacy keys are present, whenever they
  // appear, and does nothing at all once they are gone.
  const LEGACY = { 'bazarche.favs': 'bazarche.v2.favs' };
  const DROP = ['bazarche.theme', 'bazarche.support.dismissed'];
  try {
    for (const [from, to] of Object.entries(LEGACY)) {
      const val = localStorage.getItem(from);
      if (val === null) continue;
      // Never clobber a newer list the visitor has already built here.
      if (localStorage.getItem(to) === null) localStorage.setItem(to, val);
      localStorage.removeItem(from);
    }
    DROP.forEach(k => localStorage.removeItem(k));
  } catch (e) { /* private mode or storage disabled — nothing to migrate */ }
})();

/* -------------------------------------------------------------------------
   1. THEME  (light / dark, persisted, respects OS default)
   ---------------------------------------------------------------------- */
/* Namespaced to v2. localStorage is keyed by ORIGIN, so a phone that ran the
   prototype on the same host/port handed its old values straight to this
   build. Theme is disposable, but favourites are real user data — so the
   migration below MOVES them instead of dropping them. */
const THEME_KEY = 'bazarche.v2.theme';

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  $$('[data-theme-toggle]').forEach(btn => {
    btn.setAttribute('aria-pressed', String(theme === 'dark'));
    const label = theme === 'dark' ? 'روشن کردن پوسته' : 'تاریک کردن پوسته';
    btn.setAttribute('aria-label', label);
    btn.setAttribute('title', label);
  });
  const meta = $('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme === 'dark' ? '#070d14' : '#f4f8f7');
}

function initTheme() {
  let saved = null;
  try { saved = localStorage.getItem(THEME_KEY); } catch (e) {}
  // Light by default, deliberately. Following the OS setting meant a shopkeeper
  // whose phone sits in dark mode saw a dark site the first time it was shown
  // to them — not the look the site is being sold on. A visitor who picks dark
  // still keeps it, because a saved choice always wins over this default.
  applyTheme(saved === 'dark' || saved === 'light' ? saved : 'light');

  $$('[data-theme-toggle]').forEach(btn => {
    btn.addEventListener('click', () => {
      const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      try { localStorage.setItem(THEME_KEY, next); } catch (e) {}
    });
  });
}

/* -------------------------------------------------------------------------
   2. HEADER + MOBILE NAV  (focus trap, Esc, scroll lock)
   ---------------------------------------------------------------------- */
function initHeader() {
  const header = $('.site-header');
  if (header) {
    const onScroll = () => header.classList.toggle('is-stuck', window.scrollY > 8);
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  const toggle = $('[data-nav-toggle]');
  const nav = $('#mobile-nav');
  if (!toggle || !nav) return;

  const panel = $('.panel', nav);
  let lastFocus = null;

  const open = () => {
    lastFocus = document.activeElement;
    nav.classList.add('is-open');
    nav.removeAttribute('aria-hidden');
    toggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    ($('a, button', panel) || panel).focus();
  };
  const close = () => {
    nav.classList.remove('is-open');
    nav.setAttribute('aria-hidden', 'true');
    toggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    lastFocus && lastFocus.focus();
  };

  toggle.addEventListener('click', () => nav.classList.contains('is-open') ? close() : open());
  $$('[data-nav-close]', nav).forEach(el => el.addEventListener('click', close));

  nav.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key !== 'Tab') return;
    const f = $$('a[href], button:not([disabled]), input, select, textarea', panel)
      .filter(el => el.offsetParent !== null);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  });
}

/* -------------------------------------------------------------------------
   3. 3D TILT ENGINE
   Pointer-driven rotateX/rotateY + cursor sheen. Clamped, damped, and
   disabled on coarse pointers / reduced motion.
   ---------------------------------------------------------------------- */
function initTilt() {
  if (prefersReduced() || window.matchMedia('(pointer: coarse)').matches) return;

  $$('[data-tilt]').forEach(el => {
    const max = parseFloat(el.dataset.tilt) || 8;      // degrees
    let raf = 0, tx = 0, ty = 0, cx = 50, cy = 50;
    let rx = 0, ry = 0, mx = 50, my = 50;

    const loop = () => {
      rx += (tx - rx) * 0.14;
      ry += (ty - ry) * 0.14;
      mx += (cx - mx) * 0.18;
      my += (cy - my) * 0.18;
      el.style.setProperty('--rx', rx.toFixed(3) + 'deg');
      el.style.setProperty('--ry', ry.toFixed(3) + 'deg');
      el.style.setProperty('--mx', mx.toFixed(2) + '%');
      el.style.setProperty('--my', my.toFixed(2) + '%');
      if (Math.abs(tx - rx) > 0.01 || Math.abs(ty - ry) > 0.01 ||
          Math.abs(cx - mx) > 0.1 || Math.abs(cy - my) > 0.1) {
        raf = requestAnimationFrame(loop);
      } else { raf = 0; }
    };
    const kick = () => { if (!raf) raf = requestAnimationFrame(loop); };

    const onMove = (e) => {
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width;
      const py = (e.clientY - r.top) / r.height;
      // RTL-safe: rotateY follows horizontal position directly
      ty = (px - 0.5) * 2 * max;
      tx = -(py - 0.5) * 2 * max;
      cx = px * 100; cy = py * 100;
      kick();
    };
    const onLeave = () => { tx = 0; ty = 0; cx = 50; cy = 50; kick(); };

    el.addEventListener('pointerenter', () => el.classList.add('is-tracking'));
    el.addEventListener('pointermove', onMove);
    el.addEventListener('pointerleave', () => { el.classList.remove('is-tracking'); onLeave(); });
    el.addEventListener('focusin', kick);
    el.addEventListener('focusout', onLeave);
  });
}

/* -------------------------------------------------------------------------
   4. SCROLL REVEAL  (IntersectionObserver, staggered)
   ---------------------------------------------------------------------- */
function initReveal() {
  const items = $$('.reveal, .reveal-3d');
  if (!items.length) return;

  if (prefersReduced() || !('IntersectionObserver' in window)) {
    items.forEach(el => el.classList.add('is-in'));
    return;
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const delay = parseInt(el.dataset.delay || '0', 10);
      setTimeout(() => el.classList.add('is-in'), delay);
      io.unobserve(el);
    });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.06 });

  items.forEach((el, i) => {
    // auto-stagger siblings that don't declare an explicit delay
    if (!el.dataset.delay && el.parentElement?.dataset.stagger) {
      el.dataset.delay = String((i % 8) * 70);
    }
    io.observe(el);
  });
}

/* -------------------------------------------------------------------------
   5. PARALLAX LAYERS  (decorative only — never text, per motion rules)
   ---------------------------------------------------------------------- */
function initParallax() {
  const layers = $$('[data-parallax]');
  if (!layers.length || prefersReduced()) return;

  let raf = 0;
  const update = () => {
    raf = 0;
    const vh = window.innerHeight;
    layers.forEach(el => {
      const speed = parseFloat(el.dataset.parallax) || 0.08;
      const r = el.getBoundingClientRect();
      if (r.bottom < -200 || r.top > vh + 200) return;
      const progress = (r.top + r.height / 2 - vh / 2) / vh;
      el.style.transform = `translate3d(0, ${(-progress * speed * 100).toFixed(2)}px, 0)`;
    });
  };
  const onScroll = () => { if (!raf) raf = requestAnimationFrame(update); };
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll, { passive: true });
  update();
}

/* -------------------------------------------------------------------------
   6. COUNT-UP  (stat numbers, Persian digits preserved)
   ---------------------------------------------------------------------- */
const FA_DIGITS = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
export const toFa = (n) => String(n).replace(/\d/g, d => FA_DIGITS[+d]);
// Persian text uses ٬ (U+066C) as the thousands separator, not a Latin
// comma. db.fa_money() on the server already does this, so matching it here
// keeps the animated counter and the static prices visually identical.
export const faGroup = (n) =>
  toFa(Number(n).toLocaleString('en-US')).replace(/,/g, '٬');

function initCountUp() {
  const els = $$('[data-count]');
  if (!els.length) return;

  const run = (el) => {
    const target = parseFloat(el.dataset.count);
    const suffix = el.dataset.suffix || '';
    if (prefersReduced()) { el.textContent = faGroup(target) + suffix; return; }
    const dur = 1400;
    const t0 = performance.now();
    const step = (now) => {
      const p = Math.min((now - t0) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = faGroup(Math.round(target * eased)) + suffix;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  if (!('IntersectionObserver' in window)) { els.forEach(run); return; }
  const io = new IntersectionObserver((es) => es.forEach(e => {
    if (e.isIntersecting) { run(e.target); io.unobserve(e.target); }
  }), { threshold: 0.4 });
  els.forEach(el => io.observe(el));
}

/* -------------------------------------------------------------------------
   7. TOASTS
   ---------------------------------------------------------------------- */
const ICON_OK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>';
const ICON_ERR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>';

export function toast(message, kind = 'ok') {
  let stack = $('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    stack.setAttribute('role', 'status');
    stack.setAttribute('aria-live', 'polite');
    document.body.appendChild(stack);
  }
  const t = document.createElement('div');
  t.className = 'toast ' + kind;
  t.innerHTML = (kind === 'ok' ? ICON_OK : ICON_ERR) + '<span></span>';
  $('span', t).textContent = message;
  stack.appendChild(t);
  setTimeout(() => {
    t.style.transition = 'opacity .3s, transform .3s';
    t.style.opacity = '0';
    t.style.transform = 'translateY(10px)';
    setTimeout(() => t.remove(), 320);
  }, 3600);
}

/* -------------------------------------------------------------------------
   8. TABS / ACCORDION
   ---------------------------------------------------------------------- */
function initTabs() {
  $$('[data-tabs]').forEach(group => {
    const btns = $$('[role="tab"]', group);
    const select = (btn) => {
      btns.forEach(b => {
        const on = b === btn;
        b.setAttribute('aria-selected', String(on));
        b.tabIndex = on ? 0 : -1;
        const panel = document.getElementById(b.getAttribute('aria-controls'));
        if (panel) panel.hidden = !on;
      });
    };
    btns.forEach((b, i) => {
      b.addEventListener('click', () => select(b));
      b.addEventListener('keydown', (e) => {
        const dir = e.key === 'ArrowLeft' ? 1 : e.key === 'ArrowRight' ? -1 : 0; // RTL
        if (!dir) return;
        e.preventDefault();
        const next = btns[(i + dir + btns.length) % btns.length];
        next.focus(); select(next);
      });
    });
  });
}

function initAccordion() {
  $$('.accordion-trigger').forEach(btn => {
    btn.addEventListener('click', () => {
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!expanded));
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      if (panel) panel.hidden = expanded;
    });
  });
}

/* -------------------------------------------------------------------------
   9. MODALS
   ---------------------------------------------------------------------- */
function initModals() {
  $$('[data-modal-open]').forEach(btn => {
    btn.addEventListener('click', () => {
      const m = document.getElementById(btn.dataset.modalOpen);
      if (!m) return;
      m.hidden = false;
      document.body.style.overflow = 'hidden';
      ($('button, a, input', m) || m).focus();
    });
  });
  $$('.modal-backdrop').forEach(m => {
    const close = () => { m.hidden = true; document.body.style.overflow = ''; };
    m.addEventListener('click', (e) => { if (e.target === m) close(); });
    $$('[data-modal-close]', m).forEach(b => b.addEventListener('click', close));
    m.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  });
}

/* -------------------------------------------------------------------------
   10. FORM VALIDATION  (inline, error near field, focus first invalid)
   ---------------------------------------------------------------------- */
const MSG = {
  valueMissing: 'این فیلد الزامی است.',
  typeMismatch: 'قالب واردشده معتبر نیست.',
  tooShort: 'متن واردشده کوتاه‌تر از حد مجاز است.',
  patternMismatch: 'قالب واردشده معتبر نیست.',
  default: 'مقدار واردشده معتبر نیست.'
};

function messageFor(input) {
  const v = input.validity;
  if (v.valueMissing) return input.dataset.msgRequired || MSG.valueMissing;
  if (v.typeMismatch) return input.dataset.msgType || MSG.typeMismatch;
  if (v.tooShort) return `حداقل ${toFa(input.minLength)} کاراکتر لازم است.`;
  if (v.patternMismatch) return input.dataset.msgPattern || MSG.patternMismatch;
  return MSG.default;
}

function showError(input, msg) {
  input.setAttribute('aria-invalid', 'true');
  const id = input.id + '-err';
  let box = document.getElementById(id);
  if (!box) {
    box = document.createElement('p');
    box.id = id;
    box.className = 'field-error';
    box.innerHTML = ICON_ERR + '<span></span>';
    input.insertAdjacentElement('afterend', box);
  }
  $('span', box).textContent = msg;
  const describedBy = (input.getAttribute('aria-describedby') || '').split(' ').filter(Boolean);
  if (!describedBy.includes(id)) input.setAttribute('aria-describedby', [...describedBy, id].join(' '));
}

function clearError(input) {
  input.removeAttribute('aria-invalid');
  document.getElementById(input.id + '-err')?.remove();
}

function initForms() {
  $$('form[data-validate]').forEach(form => {
    form.setAttribute('novalidate', '');
    const fields = $$('input, textarea, select', form).filter(f => f.willValidate && f.type !== 'hidden');

    fields.forEach(f => {
      f.addEventListener('blur', () => { if (f.value) f.checkValidity() ? clearError(f) : showError(f, messageFor(f)); });
      f.addEventListener('input', () => { if (f.getAttribute('aria-invalid') === 'true' && f.checkValidity()) clearError(f); });
    });

    form.addEventListener('submit', (e) => {
      // Validate, then LET THE FORM SUBMIT. This handler used to call
      // preventDefault() unconditionally and fake a success toast, so every
      // form carrying data-validate — login, submit a business, reviews,
      // questions, bookings, the whole panel — silently did nothing in a
      // real browser while looking like it had worked.
      // A button may opt out of validation (formnovalidate) — an "accept"
      // action has no fields to fill, and blocking it on a required input it
      // does not use makes the button silently dead.
      const via = e.submitter;
      if (via && (via.hasAttribute('formnovalidate') || via.formNoValidate)) {
        fields.forEach(clearError);
        return;                        // let the browser submit it as-is
      }

      let firstBad = null;
      fields.forEach(f => {
        if (f.checkValidity()) clearError(f);
        else { showError(f, messageFor(f)); firstBad = firstBad || f; }
      });

      if (firstBad) {
        e.preventDefault();            // the only case that blocks submission
        firstBad.focus();
        firstBad.scrollIntoView({ block: 'center', behavior: prefersReduced() ? 'auto' : 'smooth' });
        toast('لطفاً خطاهای مشخص‌شده را برطرف کنید.', 'err');
        return;
      }

      // Valid: show progress on the button and hand over to the browser.
      const btn = $('[type="submit"]', form);
      if (btn && !btn.dataset.busy) {
        btn.dataset.busy = '1';
        const old = btn.innerHTML;
        btn.innerHTML = '<span class="spinner"></span><span>در حال ارسال…</span>';
        // Do NOT set disabled before submit — a disabled button is omitted
        // from the payload, which would drop name="action" values the server
        // relies on. Guard against double-submit with the busy flag instead.
        setTimeout(() => {
          if (!btn.isConnected) return;
          btn.innerHTML = old;
          delete btn.dataset.busy;
        }, 8000);
      }
    });
  });
}

/* -------------------------------------------------------------------------
   11. BUSINESS DIRECTORY  — search / filter / sort / open-now
   Works entirely client-side over data-* attributes on the cards.
   ---------------------------------------------------------------------- */
function normalizeFa(s) {
  return (s || '')
    .replace(/[يﻱﻲ]/g, 'ی').replace(/[كﻙﻚ]/g, 'ک')
    .replace(/[ًٌٍَُِّْـ]/g, '')
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .trim().toLowerCase();
}

/* ==========================================================================
   OPEN NOW
   The server renders these badges in Iran time and they are correct on
   arrival. This code only REFRESHES them while the page stays open, so a
   tab left on screen at closing time does not keep claiming "open".

   It deliberately uses a fixed UTC+3:30 offset rather than the device clock:
   a phone with the wrong timezone would otherwise be shown the wrong answer,
   which is the exact mistake this feature exists to prevent.
   ========================================================================== */
const DAY_KEYS = ['mon','tue','wed','thu','fri','sat','sun'];  // by weekday index
const IRAN_OFFSET_MIN = 210;
const FA_D = '۰۱۲۳۴۵۶۷۸۹';
const faNum = (n) => String(n).replace(/\d/g, d => FA_D[+d]);

function iranNow() {
  const now = new Date();
  return new Date(now.getTime() + (now.getTimezoneOffset() + IRAN_OFFSET_MIN) * 60000);
}

const hhmm = (t) => {
  const p = String(t).trim().split(':');
  const h = +p[0], m = +p[1];
  if (!isFinite(h) || !isFinite(m)) return null;
  return h * 60 + m;
};

/* Mirrors db.open_state() exactly. Returns {state,label,detail,minutes}. */
function openState(hoursJson) {
  let map;
  try { map = JSON.parse(hoursJson || '{}'); } catch (e) { return null; }
  if (!map || !DAY_KEYS.some(k => (map[k] || []).length)) {
    return { state: 'unknown', label: 'ساعت کاری ثبت نشده', detail: '', minutes: null };
  }
  const now = iranNow();
  // JS getDay() is Sunday=0; DAY_KEYS is Monday-first like Python's weekday()
  const wd  = (now.getDay() + 6) % 7;
  const cur = now.getHours() * 60 + now.getMinutes();
  const FA_DAY = { sat:'شنبه', sun:'یک‌شنبه', mon:'دوشنبه', tue:'سه‌شنبه',
                   wed:'چهارشنبه', thu:'پنج‌شنبه', fri:'جمعه' };

  for (const r of (map[DAY_KEYS[wd]] || [])) {
    if (!r || r.length !== 2) continue;
    const o = hhmm(r[0]), c = hhmm(r[1]);
    if (o === null || c === null) continue;
    const wraps = c <= o;
    const inside = wraps ? (cur >= o || cur < c) : (cur >= o && cur < c);
    if (inside) {
      const left = wraps ? ((c + 1440 - cur) % 1440) : (c - cur);
      if (left <= 60) return { state:'closing', label:`تا ${faNum(left)} دقیقهٔ دیگر می‌بندد`,
                               detail:`تا ساعت ${faNum(r[1])}`, minutes:left };
      return { state:'open', label:'الان باز است', detail:`تا ساعت ${faNum(r[1])}`, minutes:left };
    }
  }

  for (let step = 0; step < 8; step++) {
    const d = DAY_KEYS[(wd + step) % 7];
    const ranges = (map[d] || []).slice()
      .filter(r => r && r.length === 2 && hhmm(r[0]) !== null)
      .sort((a, b) => hhmm(a[0]) - hhmm(b[0]));
    for (const r of ranges) {
      const o = hhmm(r[0]);
      if (step === 0 && o <= cur) continue;
      if (step === 0) {
        const mins = o - cur;
        if (mins <= 90) return { state:'closed', label:`تا ${faNum(mins)} دقیقهٔ دیگر باز می‌شود`,
                                 detail:`ساعت ${faNum(r[0])}`, minutes:null };
        return { state:'closed', label:'الان بسته است',
                 detail:`امروز ساعت ${faNum(r[0])} باز می‌شود`, minutes:null };
      }
      const when = step === 1 ? 'فردا' : (FA_DAY[d] || d);
      return { state:'closed', label:'الان بسته است',
               detail:`${when} ساعت ${faNum(r[0])} باز می‌شود`, minutes:null };
    }
  }
  return { state:'closed', label:'الان بسته است', detail:'', minutes:null };
}

/* Exposed so tools/test_open_parity.py can drive this exact function and
   prove it agrees with db.open_state() in Python. Two implementations of one
   rule drift silently otherwise. */
if (typeof window !== 'undefined') window.__openState = openState;

const OPEN_CLS  = { open:'badge-open', closing:'badge-warn',
                    closed:'badge-closed', unknown:'badge-neutral' };

function paintOpenBadges(root = document) {
  const ICON = {
    open:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    closing: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
    closed:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m15 9-6 6M9 9l6 6"/></svg>',
    unknown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
  };

  $$('[data-open-badge]', root).forEach(badge => {
    const host = badge.closest('[data-hours-json]') || badge;
    const json = badge.dataset.hoursJson || host.dataset.hoursJson || '';
    if (!json) return;                     // server already rendered it; leave it
    const st = openState(json);
    if (!st) return;
    const card = badge.closest('[data-biz]');
    const compact = card !== null;
    let text = st.label;
    if (compact && st.state === 'closing') text = `${faNum(st.minutes)} دقیقه تا بستن`;
    else if (compact && st.state === 'unknown') text = 'نامشخص';

    badge.className = 'badge ' + (OPEN_CLS[st.state] || 'badge-neutral');
    badge.dataset.openState = st.state;
    if (st.detail) badge.title = st.detail; else badge.removeAttribute('title');
    badge.innerHTML = (ICON[st.state] || ICON.unknown) + '<span>' + text + '</span>';
    if (card) card.dataset.open = st.state;
  });

  $$('[data-open-line]', root).forEach(line => {
    const host = line.closest('[data-hours-json]') || line;
    const json = line.dataset.hoursJson || host.dataset.hoursJson || '';
    if (!json) return;
    const st = openState(json);
    if (!st || st.state === 'unknown') return;
    line.dataset.openState = st.state;
    line.className = 'open-line ' + ({ open:'is-open', closing:'is-closing',
                                       closed:'is-closed' }[st.state] || '');
    line.innerHTML = '<span class="open-dot" aria-hidden="true"></span>' +
      '<strong>' + st.label + '</strong>' +
      (st.detail ? '<span class="open-detail">' + st.detail + '</span>' : '');
  });
}

/* Keep the badges honest on a page nobody reloads. */
let _openTimer = null;
function startOpenTicker() {
  if (_openTimer) return;
  _openTimer = setInterval(() => paintOpenBadges(), 60000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) paintOpenBadges();   // catch up after a sleeping tab
  });
}

function initDirectory() {
  const root = $('[data-directory]');
  if (!root) return;

  const grid     = $('[data-dir-grid]', root);
  const cards    = $$('[data-biz]', grid);
  const q        = $('[data-dir-search]', root);
  const sortSel  = $('[data-dir-sort]', root);
  const openOnly = $('[data-dir-open]', root);
  const chips    = $$('[data-dir-cat]', root);
  const countEl  = $('[data-dir-count]', root);
  const empty    = $('[data-dir-empty]', root);
  const clearBtn = $('[data-dir-clear]', root);

  let activeCat = root.dataset.initialCat || 'all';

  paintOpenBadges(root);

  /* The server handles search/category/sort. This only refines the rendered
     page live: instant typing feedback and the "open now" toggle. */
  function apply() {
    const term = normalizeFa(q?.value);
    let shown = 0;
    cards.forEach(card => {
      const okTerm = !term || normalizeFa(card.dataset.search).includes(term);
      const okOpen = !openOnly?.checked ||
        card.dataset.open === 'open' || card.dataset.open === 'closing' ||
        card.dataset.open === 'unknown';
      const show = okTerm && okOpen;
      card.hidden = !show;
      if (show) shown++;
    });
    if (countEl) countEl.textContent = toFa(shown);
    if (empty) empty.hidden = shown > 0;
    if (grid) grid.hidden = shown === 0;
  }

  let debounce;
  q?.addEventListener('input', () => { clearTimeout(debounce); debounce = setTimeout(apply, 180); });
  sortSel?.addEventListener('change', apply);
  openOnly?.addEventListener('change', apply);

  clearBtn?.addEventListener('click', () => {
    if (q) q.value = '';
    if (openOnly) openOnly.checked = false;
    apply();
    q?.focus();
  });

  apply();
}

/* -------------------------------------------------------------------------
   12. GALLERY LIGHTBOX  (business page)
   ---------------------------------------------------------------------- */
function initGallery() {
  const gal = $('[data-gallery]');
  if (!gal) return;
  const main = $('[data-gallery-main]', gal);
  const thumbs = $$('[data-gallery-thumb]', gal);

  thumbs.forEach((t, i) => {
    t.addEventListener('click', () => {
      const img = $('img', t);
      if (main && img) {
        main.src = img.dataset.full || img.src;
        main.alt = img.alt;
      }
      thumbs.forEach(x => x.setAttribute('aria-current', String(x === t)));
    });
  });
}

/* -------------------------------------------------------------------------
   13. STAR RATING INPUT
   ---------------------------------------------------------------------- */
function initRating() {
  $$('[data-rating-input]').forEach(group => {
    const input = $('input[type="hidden"]', group);
    const stars = $$('button', group);
    const paint = (v) => stars.forEach((s, i) => s.setAttribute('aria-pressed', String(i < v)));
    stars.forEach((s, i) => {
      s.addEventListener('click', () => { if (input) input.value = i + 1; paint(i + 1); });
      s.addEventListener('mouseenter', () => paint(i + 1));
    });
    group.addEventListener('mouseleave', () => paint(parseInt(input?.value || '0', 10)));
  });
}

/* -------------------------------------------------------------------------
   14. COPY TO CLIPBOARD
   ---------------------------------------------------------------------- */
function initCopy() {
  $$('[data-copy]').forEach(btn => {
    btn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(btn.dataset.copy);
        toast('در حافظه کپی شد.', 'ok');
      } catch (e) { toast('کپی ناموفق بود.', 'err'); }
    });
  });
}

/* -------------------------------------------------------------------------
   15. HERO 3D SCENE loader (dynamic import so non-hero pages stay light)
   ---------------------------------------------------------------------- */
async function initScenes() {
  const hero = $('[data-hero-canvas]');
  const marker = $('[data-marker-canvas]');
  if (!hero && !marker) return;
  try {
    const mod = await import('./scene3d.js');
    if (hero) mod.initHeroScene(hero, { variant: hero.dataset.variant || 'city' });
    if (marker) mod.initMarkerScene(marker);
  } catch (err) {
    console.warn('[bazarche] 3D scene unavailable:', err);
    hero?.closest('[data-scene-wrap]')?.setAttribute('data-webgl', 'unsupported');
  }
}

/* -------------------------------------------------------------------------
   16. FAVORITES  (localStorage, per-device)
   ---------------------------------------------------------------------- */
const FAV_KEY = 'bazarche.v2.favs';
const favRead = () => { try { return JSON.parse(localStorage.getItem(FAV_KEY) || '[]'); } catch (e) { return []; } };
const favWrite = (a) => { try { localStorage.setItem(FAV_KEY, JSON.stringify(a)); } catch (e) {} };

function paintFavCount() {
  const n = favRead().length;
  $$('[data-fav-count]').forEach(el => {
    el.hidden = n === 0;
    el.textContent = toFa(n);
  });
}

function initFavorites() {
  const favs = favRead();
  $$('[data-fav]').forEach(btn => {
    const slug = btn.dataset.fav;
    const on = favs.includes(slug);
    btn.setAttribute('aria-pressed', String(on));
    btn.classList.toggle('is-on', on);

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const cur = favRead();
      const idx = cur.indexOf(slug);
      const nowOn = idx === -1;
      if (nowOn) cur.push(slug); else cur.splice(idx, 1);
      favWrite(cur);
      btn.setAttribute('aria-pressed', String(nowOn));
      btn.classList.toggle('is-on', nowOn);
      paintFavCount();
      toast(nowOn ? 'به علاقه‌مندی‌ها اضافه شد.' : 'از علاقه‌مندی‌ها حذف شد.');
    });
  });
  paintFavCount();
}

/* -------------------------------------------------------------------------
   17. SHARE  (Web Share API with clipboard fallback)
   ---------------------------------------------------------------------- */
function initShare() {
  $$('[data-share]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const data = { title: btn.dataset.share || document.title, url: location.href };
      if (navigator.share) {
        try { await navigator.share(data); return; } catch (e) { if (e.name === 'AbortError') return; }
      }
      try {
        await navigator.clipboard.writeText(location.href);
        toast('نشانی صفحه کپی شد.');
      } catch (e) { toast('اشتراک‌گذاری ممکن نبود.', 'err'); }
    });
  });
}

/* -------------------------------------------------------------------------
   18. CONFIRM  (destructive form actions)
   ---------------------------------------------------------------------- */
function initConfirm() {
  $$('form[data-confirm]').forEach(f => {
    f.addEventListener('submit', (e) => {
      if (!window.confirm(f.dataset.confirm)) e.preventDefault();
    });
  });
}

/* -------------------------------------------------------------------------
   19. ICON PICKER preview (owner panel)
   ---------------------------------------------------------------------- */
function initIconPicker() {
  const G = (window.__BAZARCHE__ || {});
  const bg = (name, size) => {
    const grid = G.iconGrid || {};
    const [col, row] = grid[name] || grid['store'] || [0, 0];
    const c = G.iconCols || 13, r = G.iconRows || 13;
    const px = c > 1 ? (col * 100 / (c - 1)) : 0;
    const py = r > 1 ? (row * 100 / (r - 1)) : 0;
    return `width:${size}px;height:${size}px;` +
           `background-image:url(/assets/img/icons/sprite.webp?v42);` +
           `background-size:${c * 100}% ${r * 100}%;` +
           `background-position:${px}% ${py}%`;
  };
  $$('[data-icon-select]').forEach(sel => {
    const prev = sel.closest('.field')?.querySelector('[data-icon-preview]');
    const sync = () => {
      if (!prev) return;
      prev.innerHTML = '';
      const span = document.createElement('span');
      span.className = 'ic';
      span.setAttribute('style', bg(sel.value, 64));
      prev.appendChild(span);
    };
    sel.addEventListener('change', sync);
    sync();
  });
}

/* -------------------------------------------------------------------------
   20. LIVE COLOR PREVIEW (owner appearance page)
   ---------------------------------------------------------------------- */
function initColorSync() {
  const map = {
    color_primary: '--color-primary',
    color_accent: '--color-accent',
    color_background: '--color-background',
    color_foreground: '--color-foreground',
  };
  $$('[data-color-sync]').forEach(inp => {
    inp.addEventListener('input', () => {
      const v = map[inp.name];
      if (v) document.documentElement.style.setProperty(v, inp.value);
      const code = inp.closest('.color-row')?.querySelector('code');
      if (code) code.textContent = inp.value;
    });
  });
}

/* -------------------------------------------------------------------------
   21. PWA service worker
   ---------------------------------------------------------------------- */
function initPWA() {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(location.hostname)) return;
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(reg => {
      // A stale worker used to keep serving an old shell after an update,
      // which looked like "the site won't open". Take over immediately.
      if (reg.waiting) reg.waiting.postMessage('skipWaiting');
      reg.addEventListener('updatefound', () => {
        const sw = reg.installing;
        sw && sw.addEventListener('statechange', () => {
          if (sw.state === 'installed' && navigator.serviceWorker.controller) {
            sw.postMessage('skipWaiting');
          }
        });
      });
    }).catch(() => {});
    let reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (reloaded) return;
      reloaded = true;
      location.reload();
    });
  });
}

/* -------------------------------------------------------------------------
   22. ANALYTICS  (fire-and-forget intent tracking)
   Counts what the owner actually cares about: calls, WhatsApp, directions.
   ---------------------------------------------------------------------- */
function track(slug, kind) {
  if (!slug || !kind) return;
  const url = `/t/${encodeURIComponent(slug)}/${encodeURIComponent(kind)}`;
  try {
    if (navigator.sendBeacon) navigator.sendBeacon(url);
    else fetch(url, { method: 'POST', keepalive: true }).catch(() => {});
  } catch (e) {}
}

function initTracking() {
  const slug = document.body.dataset.bizSlug;
  if (!slug) return;
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a, button');
    if (!a) return;
    const href = a.getAttribute('href') || '';
    if (a.dataset.track) return track(slug, a.dataset.track);
    if (href.startsWith('tel:')) return track(slug, 'phone');
    if (href.includes('wa.me') || href.includes('whatsapp')) return track(slug, 'whatsapp');
    if (href.includes('google.com/maps/dir')) return track(slug, 'route');
    if (a.dataset.share !== undefined) return track(slug, 'share');
    if (a.dataset.fav !== undefined) return track(slug, 'save');
    if (href.includes('instagram.com')) return track(slug, 'instagram');
    if (href.includes('t.me/') || href.includes('telegram')) return track(slug, 'telegram');
  }, { passive: true });
}

/* -------------------------------------------------------------------------
   23. OTP INPUT  (auto-advance + paste)
   ---------------------------------------------------------------------- */
function initOtp() {
  $$('.otp-input').forEach(inp => {
    inp.addEventListener('input', () => {
      inp.value = inp.value.replace(/[^\d]/g, '').slice(0, 5);
      if (inp.value.length === 5) inp.form?.requestSubmit?.();
    });
  });
}

/* -------------------------------------------------------------------------
   24. BOOT
   ---------------------------------------------------------------------- */
function boot() {
  initTheme();
  initHeader();
  initTilt();
  initReveal();
  initParallax();
  initCountUp();
  initTabs();
  initAccordion();
  initModals();
  initForms();
  initDirectory();
  initGallery();
  initRating();
  initCopy();
  initFavorites();
  initShare();
  initConfirm();
  initIconPicker();
  initColorSync();
  paintOpenBadges();
  startOpenTicker();
  initCopyPhone();
  initDirFilters();
  initTracking();
  initChipOverflow();
  initGeoFill();
  initCatGroups();
  initSupport();
  initOtp();
  initPWA();
  initScenes();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

window.Bazarche = { toast, toFa, faGroup };

/* -------------------------------------------------------------------------
   23. CATEGORY CHIP OVERFLOW
   22 top-level categories do not fit on one row. Collapse to two rows and
   reveal the rest on demand — but only when there is actually something
   hidden, so the button never lies about there being more.
   ---------------------------------------------------------------------- */
/* -------------------------------------------------------------------------
   GEO FILL  ·  "use my current location" on the registration form
   -------------------------------------------------------------------------
   The shopkeeper is standing IN the shop while filling this in, so the phone
   already knows the answer. Typing coordinates by hand is the single most
   error-prone field on the form, and a wrong pin puts his shop on the wrong
   street. Failure is reported in words, never silently.
   ---------------------------------------------------------------------- */
function initGeoFill() {
  const btn = document.querySelector('[data-geo-fill]');
  if (!btn) return;
  const lat = document.querySelector('[name="lat"]');
  const lng = document.querySelector('[name="lng"]');
  const msg = document.querySelector('[data-geo-msg]');
  if (!lat || !lng) return;

  const say = (text, bad) => {
    if (!msg) return;
    msg.hidden = false;
    msg.textContent = text;
    msg.style.color = bad ? 'var(--color-danger, #b42318)' : 'var(--color-primary)';
  };

  btn.addEventListener('click', () => {
    if (!navigator.geolocation) {
      say('مرورگر شما موقعیت‌یابی را پشتیبانی نمی‌کند. مختصات را دستی بنویسید یا روی نقشه نشان بزنید.', true);
      return;
    }
    // The phone reports WHERE YOU ARE, not where the shop is. Remind the
    // shopkeeper to be on the premises, or the pin lands on the wrong street.
    say('موقعیت همین گوشی گرفته می‌شود — لطفاً در محل کسب‌وکار خود باشید، وگرنه پین جای اشتباه می‌افتد.');
    const label = btn.querySelector('span');
    const original = label ? label.textContent : '';
    if (label) label.textContent = 'در حال گرفتن موقعیت…';
    btn.disabled = true;
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const la = pos.coords.latitude.toFixed(6);
        const ln = pos.coords.longitude.toFixed(6);
        lat.value = la; lng.value = ln;
        btn.disabled = false;
        if (label) label.textContent = original;
        // tell the map (if this form has one) to drop a marker there too
        window.dispatchEvent(new CustomEvent('bz:geo', { detail: { lat: +la, lng: +ln } }));
        say('موقعیت ثبت شد و روی نقشه نشان زده شد. اگر دقیق نیست، روی نقشه بکشید یا عدد را اصلاح کنید.');
      },
      (err) => {
        btn.disabled = false;
        if (label) label.textContent = original;
        say(err.code === 1
          ? 'اجازهٔ دسترسی به موقعیت داده نشد. از تنظیمات مرورگر اجازه بدهید، یا مستقیم روی نقشه نشان بزنید.'
          : 'موقعیت پیدا نشد. می‌توانید مستقیم روی نقشه نشان بزنید یا دستی بنویسید.', true);
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
    );
  });
}

function initChipOverflow() {
  const box = document.querySelector('[data-chips]');
  const btn = document.querySelector('[data-chips-more]');
  if (!box || !btn) return;

  const overflowing = () => box.scrollHeight > box.clientHeight + 4;

  const sync = () => {
    if (box.classList.contains('is-expanded')) return;
    btn.hidden = !overflowing();
  };

  btn.addEventListener('click', () => {
    const open = box.classList.toggle('is-expanded');
    btn.setAttribute('aria-expanded', String(open));
    const label = btn.querySelector('span');
    if (label) label.textContent = open ? 'نمایش کمتر' : 'همهٔ دسته‌ها';
    if (!open) sync();
  });

  sync();
  window.addEventListener('resize', sync, { passive: true });

  // keep the active chip visible even while collapsed
  const active = box.querySelector('.chip.is-active');
  if (active && !box.classList.contains('is-expanded')) {
    const top = active.offsetTop - box.offsetTop;
    if (top > box.clientHeight - 10) btn.click();
  }
}

/* -------------------------------------------------------------------------
   24. CATEGORY ACCORDION
   22 parent tiles, each opening its own trades. Only one stays open at a
   time so the grid never reflows into a wall of pills.
   ---------------------------------------------------------------------- */
function initCatGroups() {
  const groups = $$('[data-cat-group]');
  if (!groups.length) return;

  groups.forEach(group => {
    const btn = $('.cat-tile-head', group);
    const subs = $('.cat-subs', group);
    if (!btn || !subs) return;

    btn.addEventListener('click', () => {
      const open = btn.getAttribute('aria-expanded') === 'true';

      // close the others: an accordion, not a set of independent toggles
      groups.forEach(g => {
        const b = $('.cat-tile-head', g);
        const s = $('.cat-subs', g);
        if (b && s && b !== btn) { b.setAttribute('aria-expanded', 'false'); s.hidden = true; }
      });

      btn.setAttribute('aria-expanded', String(!open));
      subs.hidden = open;

      // a tile near the bottom would otherwise open off-screen
      if (!open && !prefersReduced()) {
        requestAnimationFrame(() => {
          const r = group.getBoundingClientRect();
          if (r.bottom > window.innerHeight) {
            group.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          }
        });
      }
    });
  });
}

/* -------------------------------------------------------------------------
   25. SUPPORT WIDGET
   Appears after a delay so it reads as help rather than an ad, and only
   once per session — a visitor who dismissed it should not be nagged again.
   ---------------------------------------------------------------------- */
function initSupport() {
  const fab = $('[data-sup-open]');
  const panel = $('#support-panel');
  if (!fab || !panel) return;

  const DISMISS = 'bazarche.v2.support.dismissed';
  let dismissed = false;
  try { dismissed = sessionStorage.getItem(DISMISS) === '1'; } catch (e) {}

  const delay = Math.max(0, parseInt(panel.dataset.supDelay || '60', 10)) * 1000;

  const show = () => { fab.hidden = false; };
  const open = () => {
    panel.hidden = false;
    fab.setAttribute('aria-expanded', 'true');
    const first = $('summary', panel);
    if (first) first.focus();
  };
  const close = () => {
    panel.hidden = true;
    fab.setAttribute('aria-expanded', 'false');
    try { sessionStorage.setItem(DISMISS, '1'); } catch (e) {}
  };

  // Reveal the button on a timer, or immediately if the visitor looks stuck:
  // scrolling to the bottom without clicking anything is a help signal.
  if (!dismissed) {
    setTimeout(show, delay);
    const onScroll = () => {
      const past = window.scrollY + window.innerHeight;
      if (past > document.body.scrollHeight * 0.9) {
        show();
        window.removeEventListener('scroll', onScroll);
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
  } else {
    show();   // they know it exists; keep it available but never auto-open
  }

  fab.addEventListener('click', () => (panel.hidden ? open() : close()));
  $$('[data-sup-close]', panel).forEach(b => b.addEventListener('click', close));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !panel.hidden) { close(); fab.focus(); }
  });
  document.addEventListener('click', (e) => {
    if (panel.hidden) return;
    if (!panel.contains(e.target) && !fab.contains(e.target)) close();
  });
}

/* ==========================================================================
   QUICK ACTIONS  ·  copy a phone number
   Research on directory behaviour: people copy a number as often as they
   tap it, because they want to save it, paste it into a message, or dial
   from a different SIM. Selecting a phone number by hand on a touch screen
   is genuinely awkward -- "text is too small or fingers are too fat" -- so
   one tap replaces the whole fiddly gesture.
   ========================================================================== */
/* The directory filters fold away on a phone to get results above the fold,
   but a desktop has the room and folding there would just add a click.
   CSS can hide the summary; only JS can set the `open` property. */
function initDirFilters() {
  const d = $('[data-dir-filters]');
  if (!d) return;
  const sync = () => { if (window.matchMedia('(min-width: 861px)').matches) d.open = true; };
  sync();
  window.addEventListener('resize', sync, { passive: true });
}

function initCopyPhone() {
  $$('[data-copy-phone]').forEach(btn => {
    btn.addEventListener('click', async () => {
      const num = btn.dataset.copyPhone || '';
      if (!num) return;
      let ok = false;
      try {
        await navigator.clipboard.writeText(num);
        ok = true;
      } catch (e) {
        // Clipboard API needs a secure context; on plain http (which is how
        // this runs on a local network) it throws, so fall back to the old
        // execCommand path rather than leaving the button dead.
        const ta = document.createElement('textarea');
        ta.value = num;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:-1000px;opacity:0';
        document.body.appendChild(ta);
        ta.select();
        try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
        document.body.removeChild(ta);
      }

      if (ok) {
        const label = $('span', btn);
        const was = label ? label.textContent : '';
        btn.classList.add('is-done');
        if (label) label.textContent = 'کپی شد';
        toast('شمارهٔ تلفن کپی شد: ' + num, 'ok');
        setTimeout(() => {
          btn.classList.remove('is-done');
          if (label) label.textContent = was;
        }, 2000);
      } else {
        toast('کپی نشد — شماره را دستی بردارید: ' + num, 'err');
      }
    });
  });
}
