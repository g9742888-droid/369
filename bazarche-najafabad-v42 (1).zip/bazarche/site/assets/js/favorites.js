/* Favorites page: rebuild saved cards from the API. */
const KEY = 'bazarche.favs';
const read = () => { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } };

const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = (n) => String(n).replace(/\d/g, d => FA[+d]);

const ICON_HEART = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20s-7.5-4.7-7.5-9.6A4.4 4.4 0 0 1 12 7.4a4.4 4.4 0 0 1 7.5 3c0 4.9-7.5 9.6-7.5 9.6Z"/></svg>';
const ICON_PIN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 10.5c0 5.5-8 11.5-8 11.5s-8-6-8-11.5a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10.5" r="3"/></svg>';

async function boot() {
  const list = document.getElementById('fav-list');
  const empty = document.getElementById('fav-empty');
  if (!list) return;

  const favs = read();
  if (!favs.length) { list.hidden = true; return; }

  // skeleton while the API answers — perceived speed, no blank flash
  list.innerHTML = favs.map(() => '<div class="sk sk-card"></div>').join('');

  let all = [];
  try {
    const res = await fetch('/api/businesses');
    all = await res.json();
  } catch (e) { return; }

  const cats = {};
  const rows = all.filter(b => favs.includes(b.slug));
  if (!rows.length) { list.hidden = true; return; }

  empty.hidden = true;
  list.innerHTML = rows.map(b => `
    <article class="card card-hover glass">
      <div class="card-body">
        <div class="between" style="align-items:flex-start;gap:8px">
          <h3 class="card-title"><a href="/b/${b.slug}">${b.name}</a></h3>
          <button class="btn-icon" type="button" data-remove="${b.slug}"
                  aria-label="حذف ${b.name} از علاقه‌مندی‌ها">${ICON_HEART}</button>
        </div>
        <div class="card-meta">${ICON_PIN}<span>${b.address || ''}</span></div>
        <a class="btn btn-glass btn-sm btn-block mt-md" href="/b/${b.slug}">مشاهدهٔ صفحه</a>
      </div>
    </article>`).join('');

  list.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-remove]');
    if (!btn) return;
    const next = read().filter(s => s !== btn.dataset.remove);
    localStorage.setItem(KEY, JSON.stringify(next));
    btn.closest('article').remove();
    if (!next.length) { list.hidden = true; empty.hidden = false; }
    window.Bazarche?.toast('از علاقه‌مندی‌ها حذف شد.');
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else { boot(); }
