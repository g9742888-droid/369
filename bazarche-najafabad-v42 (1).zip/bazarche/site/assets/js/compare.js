/* ==========================================================================
   Compare tray — pick up to 4 businesses anywhere on the site and
   open them side by side. State lives in localStorage so it survives
   navigation between the directory, a detail page and /compare.
   ========================================================================== */
const KEY = 'bazarche.compare';
const MAX = 4;

const read = () => {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]'); }
  catch (e) { return []; }
};
const write = (v) => {
  try { localStorage.setItem(KEY, JSON.stringify(v.slice(0, MAX))); } catch (e) {}
};

const X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg>';

function names() {
  const map = {};
  document.querySelectorAll('[data-cmp]').forEach(b => {
    map[b.dataset.cmp] = b.dataset.cmpName || b.dataset.cmp;
  });
  try {
    const saved = JSON.parse(localStorage.getItem(KEY + '.names') || '{}');
    Object.keys(saved).forEach(k => { if (!map[k]) map[k] = saved[k]; });
  } catch (e) {}
  return map;
}

function rememberNames() {
  const map = names();
  try { localStorage.setItem(KEY + '.names', JSON.stringify(map)); } catch (e) {}
}

function paint() {
  const list = read();
  const nm = names();

  document.querySelectorAll('[data-cmp]').forEach(btn => {
    const on = list.includes(btn.dataset.cmp);
    btn.setAttribute('aria-pressed', String(on));
    const label = btn.querySelector('span');
    if (label && !btn.closest('thead')) label.textContent = on ? 'در مقایسه' : 'مقایسه';
  });

  const tray = document.querySelector('[data-cmp-tray]');
  if (!tray) return;
  const chips = tray.querySelector('[data-cmp-chips]');
  tray.hidden = list.length === 0;
  requestAnimationFrame(() => tray.classList.toggle('is-open', list.length > 0));
  if (chips) {
    chips.innerHTML = list.map(s => `<span class="cmp-chip">${nm[s] || s}
      <button type="button" data-cmp-remove="${s}" aria-label="حذف ${nm[s] || s} از مقایسه">${X}</button></span>`).join('');
  }
  const go = tray.querySelector('[data-cmp-go]');
  if (go) {
    go.href = '/compare?b=' + list.map(encodeURIComponent).join('&b=');
    go.classList.toggle('is-disabled', list.length < 2);
    const t = go.querySelector('span');
    if (t) t.textContent = list.length < 2 ? 'یکی دیگر انتخاب کنید' : `مقایسهٔ ${list.length} مورد`;
  }
}

function toggle(slug, name) {
  let list = read();
  if (list.includes(slug)) {
    list = list.filter(s => s !== slug);
  } else {
    if (list.length >= MAX) {
      window.Bazarche?.toast(`حداکثر ${MAX} کسب‌وکار قابل مقایسه است.`, 'warn');
      return;
    }
    list.push(slug);
    window.Bazarche?.toast(`«${name}» به مقایسه اضافه شد.`, 'ok');
  }
  write(list);
  rememberNames();
  paint();
}

function boot() {
  rememberNames();

  document.addEventListener('click', (e) => {
    const add = e.target.closest('[data-cmp]');
    if (add) {
      e.preventDefault();
      toggle(add.dataset.cmp, add.dataset.cmpName || add.dataset.cmp);
      // on /compare, removing should reload the comparison
      if (location.pathname === '/compare') {
        const list = read();
        location.href = list.length
          ? '/compare?b=' + list.map(encodeURIComponent).join('&b=')
          : '/compare';
      }
      return;
    }
    const rm = e.target.closest('[data-cmp-remove]');
    if (rm) {
      write(read().filter(s => s !== rm.dataset.cmpRemove));
      paint();
      if (location.pathname === '/compare') {
        const list = read();
        location.href = list.length
          ? '/compare?b=' + list.map(encodeURIComponent).join('&b=')
          : '/compare';
      }
      return;
    }
    if (e.target.closest('[data-cmp-clear]')) {
      write([]);
      paint();
      if (location.pathname === '/compare') location.href = '/compare';
    }
  });

  // /compare loaded with query params -> sync the tray to what is shown
  if (location.pathname === '/compare') {
    const qs = new URLSearchParams(location.search).getAll('b');
    if (qs.length) { write(qs); rememberNames(); }
  }

  paint();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot);
} else {
  boot();
}

export { read as compareList };
