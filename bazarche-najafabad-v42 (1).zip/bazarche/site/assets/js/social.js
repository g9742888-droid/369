/* Bazarche — Instagram-style social actions: follow + review helpful (v32) */
const FA = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const fa = n => String(n).replace(/\d/g, d => FA[+d]);

// ---- follow button on the business page
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-follow]');
  if (!btn) return;
  const biz = btn.dataset.biz;
  const label = btn.querySelector('span');
  const count = btn.querySelector('[data-follow-count]');
  try {
    const r = await fetch('/api/follow', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'biz_id=' + encodeURIComponent(biz),
    });
    const j = await r.json();
    if (!j.ok) {
      if (j.error === 'login') { location.href = '/me/login?next=' + encodeURIComponent(location.pathname); }
      return;
    }
    btn.setAttribute('aria-pressed', String(j.on));
    btn.classList.toggle('is-on', j.on);
    if (label) label.textContent = j.on ? 'دنبال می‌کنید' : 'دنبال کردن';
    if (count) count.textContent = '(' + fa(j.count) + ')';
    window.Bazarche?.toast?.(j.on ? 'دنبال شد ✓' : 'لغو دنبال شد', 'ok');
  } catch (err) { /* offline */ }
});

// ---- helpful vote on a review
document.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-helpful]');
  if (!btn) return;
  const id = btn.dataset.id;
  try {
    const r = await fetch('/api/review-helpful', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'id=' + encodeURIComponent(id),
    });
    const j = await r.json();
    if (!j.ok) { window.Bazarche?.toast?.('فقط یک بار می‌توانید رأی دهید.', 'err'); return; }
    btn.classList.add('is-on');
    btn.setAttribute('aria-pressed', 'true');
    const n = btn.querySelector('.nums');
    if (n) n.textContent = fa(j.helpful);
    btn.disabled = true;
  } catch (err) { /* offline */ }
});
