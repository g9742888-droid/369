/* ==========================================================================
   Bazarche Najafabad — WebGL Hero Scene (Three.js)
   A stylised, floating 3D "bazaar district": glass domes, minarets, market
   stalls and drifting light motes over a reflective plaza.

   Guardrails applied (ui-ux-pro-max threejs stack rules):
   - antialias set at CONSTRUCTION time only
   - selective shadow casting (key light + hero meshes + ground only)
   - tiered geometry segment budget (hero 32-48, background 8-16, motes 6)
   - pauses when offscreen / tab hidden
   - honours prefers-reduced-motion (renders one static frame, no loop)
   - graceful non-WebGL fallback (poster gradient stays visible)
   ========================================================================== */

import * as THREE from '../vendor/three.module.min.js';

const PALETTE = {
  brandDark:  0x047857,
  brand:      0x10b981,
  brandLight: 0x6ee7b7,
  accent:     0xf97316,
  accentDeep: 0xea580c,
  sky:        0x38bdf8,
  clay:       0xd9a066,
  clayDeep:   0xb87a45,
  ivory:      0xf4f8f7,
  night:      0x070d14
};

export function initHeroScene(canvas, opts = {}) {
  if (!canvas) return null;

  // ---- capability gate ------------------------------------------------
  let gl = null;
  try {
    gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
  } catch (e) { gl = null; }
  if (!gl) {
    canvas.closest('[data-scene-wrap]')?.setAttribute('data-webgl', 'unsupported');
    return null;
  }

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isCoarse = window.matchMedia('(pointer: coarse)').matches;
  const lowPower = isCoarse || (navigator.hardwareConcurrency || 4) <= 4;

  const variant = opts.variant || 'city';   // 'city' | 'orbit' | 'compact'

  // ---- renderer (antialias MUST be in the constructor) ----------------
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: !lowPower,
    alpha: true,
    powerPreference: lowPower ? 'low-power' : 'high-performance'
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, lowPower ? 1.5 : 2));
  renderer.shadowMap.enabled = !lowPower;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 140);
  camera.position.set(0, 5.4, 20.5);
  camera.lookAt(0, 1.0, 0);

  const root = new THREE.Group();
  scene.add(root);

  /* Composition: in this RTL layout the copy occupies the RIGHT half, so the
     3D district is pushed to the LEFT and scaled down. `layout()` recomputes
     the offset per viewport so the scene never sits under the headline. */
  const composition = { offsetX: 0, scale: 1, baseY: 1.15 };
  function layout() {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    const wide = w >= 1024;
    // world units to shift left; scales with aspect so it tracks the copy column
    composition.offsetX = wide ? -w / h * 1.55 : 0;
    // On narrow screens the copy stacks on top of the canvas, so the district
    // retreats into a small, low backdrop instead of competing with the CTAs.
    composition.scale = wide ? 0.68 : (w < 640 ? 0.34 : 0.48);
    composition.baseY = wide ? 1.85 : -1.4;
    root.position.x = composition.offsetX;
    root.scale.setScalar(composition.scale);
    root.position.z = wide ? 0 : -5.5;

    // dolly the camera back on small viewports so nothing crowds the frame
    const z = wide ? 20.5 : 26.0;
    if (camera.position.z !== z) { camera.position.z = z; }
    camera.fov = wide ? 38 : 34;
    camera.updateProjectionMatrix();
  }

  // ======================================================================
  // LIGHTING — one key light casts shadows, everything else is fill
  // ======================================================================
  const hemi = new THREE.HemisphereLight(0xdff5ee, 0x0a2a24, 0.85);
  scene.add(hemi);

  const key = new THREE.DirectionalLight(0xffffff, 2.1);
  key.position.set(6, 11, 7);
  key.castShadow = !lowPower;
  if (key.castShadow) {
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.near = 1;
    key.shadow.camera.far = 40;
    key.shadow.camera.left = -14;
    key.shadow.camera.right = 14;
    key.shadow.camera.top = 14;
    key.shadow.camera.bottom = -14;
    key.shadow.bias = -0.0012;
    key.shadow.normalBias = 0.02;
  }
  scene.add(key);

  const rimA = new THREE.PointLight(PALETTE.brandLight, 26, 26, 2);
  rimA.position.set(-7, 3.4, -4);
  scene.add(rimA);

  const rimB = new THREE.PointLight(PALETTE.accent, 22, 24, 2);
  rimB.position.set(7.5, 2.2, 3.5);
  scene.add(rimB);

  // ======================================================================
  // MATERIALS
  // ======================================================================
  const matGlass = new THREE.MeshPhysicalMaterial({
    color: 0xffffff, metalness: 0, roughness: 0.08,
    transmission: lowPower ? 0 : 0.92, thickness: 1.4,
    transparent: true, opacity: lowPower ? 0.42 : 1,
    ior: 1.35, clearcoat: 1, clearcoatRoughness: 0.06,
    envMapIntensity: 1.4
  });
  const matGlassMint = matGlass.clone();
  matGlassMint.color = new THREE.Color(PALETTE.brandLight);
  matGlassMint.attenuationColor = new THREE.Color(PALETTE.brand);
  matGlassMint.attenuationDistance = 3;

  const matBrand = new THREE.MeshStandardMaterial({ color: PALETTE.brand, metalness: 0.35, roughness: 0.32 });
  const matBrandDark = new THREE.MeshStandardMaterial({ color: PALETTE.brandDark, metalness: 0.4, roughness: 0.38 });
  const matAccent = new THREE.MeshStandardMaterial({ color: PALETTE.accent, metalness: 0.3, roughness: 0.3, emissive: PALETTE.accentDeep, emissiveIntensity: 0.22 });
  const matClay = new THREE.MeshStandardMaterial({ color: PALETTE.clay, metalness: 0.08, roughness: 0.72 });
  const matClayDeep = new THREE.MeshStandardMaterial({ color: PALETTE.clayDeep, metalness: 0.08, roughness: 0.78 });
  const matIvory = new THREE.MeshStandardMaterial({ color: PALETTE.ivory, metalness: 0.12, roughness: 0.5 });
  const matGold = new THREE.MeshStandardMaterial({ color: 0xffd58a, metalness: 0.95, roughness: 0.22 });

  const disposables = [matGlass, matGlassMint, matBrand, matBrandDark, matAccent, matClay, matClayDeep, matIvory, matGold];

  // ======================================================================
  // GROUND — the floating plaza disc
  // ======================================================================
  const plaza = new THREE.Group();
  root.add(plaza);

  const discGeo = new THREE.CylinderGeometry(7.6, 7.2, 0.55, 64, 1);
  const discMat = new THREE.MeshStandardMaterial({
    color: 0xeaf4f1, metalness: 0.22, roughness: 0.42
  });
  const disc = new THREE.Mesh(discGeo, discMat);
  disc.position.y = -0.3;
  disc.receiveShadow = !lowPower;
  plaza.add(disc);
  disposables.push(discGeo, discMat);

  // inlaid ring — Persian-tile suggestion
  const ringGeo = new THREE.TorusGeometry(6.6, 0.085, 12, 96);
  const ringMesh = new THREE.Mesh(ringGeo, matGold);
  ringMesh.rotation.x = -Math.PI / 2;
  ringMesh.position.y = 0.0;
  plaza.add(ringMesh);
  disposables.push(ringGeo);

  const ring2Geo = new THREE.TorusGeometry(5.4, 0.05, 10, 80);
  const ring2 = new THREE.Mesh(ring2Geo, matBrand);
  ring2.rotation.x = -Math.PI / 2;
  ring2.position.y = 0.005;
  plaza.add(ring2);
  disposables.push(ring2Geo);

  // underside crystal — makes the disc read as floating, not sitting
  const keelGeo = new THREE.ConeGeometry(5.2, 2.3, 6, 1);
  const keelMat = new THREE.MeshStandardMaterial({
    color: 0x0f766e, metalness: 0.55, roughness: 0.35,
    transparent: true, opacity: 0.75, flatShading: true
  });
  const keel = new THREE.Mesh(keelGeo, keelMat);
  keel.position.y = -1.55;
  keel.rotation.y = Math.PI / 6;
  plaza.add(keel);
  disposables.push(keelMat);
  disposables.push(keelGeo);

  // ======================================================================
  // ARCHITECTURE — domes, minarets, stalls
  // ======================================================================
  // Hero dome: 48 segments (hero budget)
  function makeDome(radius, mat, capMat) {
    const g = new THREE.Group();
    const domeGeo = new THREE.SphereGeometry(radius, 40, 24, 0, Math.PI * 2, 0, Math.PI * 0.52);
    const dome = new THREE.Mesh(domeGeo, mat);
    dome.castShadow = !lowPower;
    g.add(dome);
    disposables.push(domeGeo);

    const drumGeo = new THREE.CylinderGeometry(radius * 0.92, radius * 0.98, radius * 0.75, 24, 1);
    const drum = new THREE.Mesh(drumGeo, capMat);
    drum.position.y = -radius * 0.38;
    drum.castShadow = !lowPower;
    g.add(drum);
    disposables.push(drumGeo);

    const finialGeo = new THREE.SphereGeometry(radius * 0.13, 12, 10);
    const finial = new THREE.Mesh(finialGeo, matGold);
    finial.position.y = radius * 1.02;
    g.add(finial);
    disposables.push(finialGeo);

    const spikeGeo = new THREE.ConeGeometry(radius * 0.045, radius * 0.42, 8);
    const spike = new THREE.Mesh(spikeGeo, matGold);
    spike.position.y = radius * 1.3;
    g.add(spike);
    disposables.push(spikeGeo);
    return g;
  }

  const heroDome = makeDome(1.85, matGlassMint, matIvory);
  heroDome.position.set(0, 1.5, -0.4);
  root.add(heroDome);

  const domeB = makeDome(1.05, matGlass, matClay);
  domeB.position.set(-3.5, 1.0, 1.4);
  root.add(domeB);

  const domeC = makeDome(0.82, matGlass, matClayDeep);
  domeC.position.set(3.6, 0.85, 1.9);
  root.add(domeC);

  // Minarets — background budget (12 segments)
  function makeMinaret(h) {
    const g = new THREE.Group();
    const shaftGeo = new THREE.CylinderGeometry(0.17, 0.24, h, 12, 1);
    const shaft = new THREE.Mesh(shaftGeo, matIvory);
    shaft.position.y = h / 2;
    shaft.castShadow = !lowPower;
    g.add(shaft);
    disposables.push(shaftGeo);

    const balcGeo = new THREE.CylinderGeometry(0.32, 0.32, 0.14, 12, 1);
    const balc = new THREE.Mesh(balcGeo, matBrand);
    balc.position.y = h * 0.78;
    g.add(balc);
    disposables.push(balcGeo);

    const capGeo = new THREE.ConeGeometry(0.26, 0.62, 12);
    const cap = new THREE.Mesh(capGeo, matBrandDark);
    cap.position.y = h + 0.28;
    g.add(cap);
    disposables.push(capGeo);

    const tipGeo = new THREE.SphereGeometry(0.075, 8, 8);
    const tip = new THREE.Mesh(tipGeo, matGold);
    tip.position.y = h + 0.66;
    g.add(tip);
    disposables.push(tipGeo);
    return g;
  }

  [[-2.2, -2.6, 4.3], [2.3, -2.5, 4.0], [-4.9, 0.2, 3.2], [4.9, 0.4, 3.0]].forEach(([x, z, h]) => {
    const m = makeMinaret(h);
    m.position.set(x, 0, z);
    root.add(m);
  });

  // Market stalls — low-poly awnings around the rim
  const stallGroup = new THREE.Group();
  root.add(stallGroup);
  const stallCount = lowPower ? 7 : 11;
  const awningGeo = new THREE.ConeGeometry(0.62, 0.46, 4, 1);
  const boxGeo = new THREE.BoxGeometry(0.72, 0.5, 0.72);
  disposables.push(awningGeo, boxGeo);

  for (let i = 0; i < stallCount; i++) {
    const a = (i / stallCount) * Math.PI * 2 + 0.28;
    const r = 5.15;
    const s = new THREE.Group();
    const body = new THREE.Mesh(boxGeo, i % 2 ? matClay : matIvory);
    body.position.y = 0.25;
    body.castShadow = !lowPower;
    s.add(body);

    const awn = new THREE.Mesh(awningGeo, i % 3 === 0 ? matAccent : (i % 3 === 1 ? matBrand : matBrandDark));
    awn.position.y = 0.68;
    awn.rotation.y = Math.PI / 4;
    s.add(awn);

    s.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
    s.rotation.y = -a + Math.PI / 2;
    s.userData.baseY = 0;
    s.userData.phase = i * 0.7;
    stallGroup.add(s);
  }

  // Floating glass "listing cards" — the product metaphor, orbiting the plaza
  const cardGroup = new THREE.Group();
  root.add(cardGroup);
  const cardGeo = new THREE.BoxGeometry(1.5, 1.0, 0.075);
  disposables.push(cardGeo);
  const cardMats = [matGlass, matGlassMint];
  const cardCount = lowPower ? 4 : 6;
  for (let i = 0; i < cardCount; i++) {
    const a = (i / cardCount) * Math.PI * 2;
    const c = new THREE.Mesh(cardGeo, cardMats[i % 2]);
    const r = 4.6 + (i % 2) * 0.7;
    c.position.set(Math.cos(a) * r, 2.5 + Math.sin(i * 1.7) * 0.9, Math.sin(a) * r);
    c.rotation.set(0, -a + Math.PI / 2, (i % 2 ? 1 : -1) * 0.14);
    c.userData = { a, r, baseY: c.position.y, spin: (i % 2 ? 1 : -1) * 0.00022 };
    cardGroup.add(c);

    // accent tag on each card
    const tagGeo = new THREE.BoxGeometry(0.46, 0.15, 0.09);
    const tag = new THREE.Mesh(tagGeo, i % 3 === 0 ? matAccent : matBrand);
    tag.position.set(0.44, 0.36, 0.02);
    c.add(tag);
    disposables.push(tagGeo);
  }

  // ======================================================================
  // LIGHT MOTES — particle stand-ins, 6-segment budget via Points
  // ======================================================================
  const moteCount = lowPower ? 220 : 520;
  const motePos = new Float32Array(moteCount * 3);
  const moteSeed = new Float32Array(moteCount);
  for (let i = 0; i < moteCount; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 2 + Math.random() * 9;
    motePos[i * 3]     = Math.cos(a) * r;
    motePos[i * 3 + 1] = -1 + Math.random() * 9;
    motePos[i * 3 + 2] = Math.sin(a) * r;
    moteSeed[i] = Math.random() * Math.PI * 2;
  }
  const moteGeo = new THREE.BufferGeometry();
  moteGeo.setAttribute('position', new THREE.BufferAttribute(motePos, 3));
  const moteMat = new THREE.PointsMaterial({
    size: 0.075, color: PALETTE.brandLight,
    transparent: true, opacity: 0.75,
    depthWrite: false, blending: THREE.AdditiveBlending,
    sizeAttenuation: true
  });
  const motes = new THREE.Points(moteGeo, moteMat);
  scene.add(motes);
  disposables.push(moteGeo, moteMat);

  // Warm counter-motes
  const warmCount = lowPower ? 90 : 200;
  const warmPos = new Float32Array(warmCount * 3);
  for (let i = 0; i < warmCount; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 3 + Math.random() * 8;
    warmPos[i * 3] = Math.cos(a) * r;
    warmPos[i * 3 + 1] = -0.5 + Math.random() * 7;
    warmPos[i * 3 + 2] = Math.sin(a) * r;
  }
  const warmGeo = new THREE.BufferGeometry();
  warmGeo.setAttribute('position', new THREE.BufferAttribute(warmPos, 3));
  const warmMat = new THREE.PointsMaterial({
    size: 0.06, color: PALETTE.accent, transparent: true, opacity: 0.6,
    depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true
  });
  const warmMotes = new THREE.Points(warmGeo, warmMat);
  scene.add(warmMotes);
  disposables.push(warmGeo, warmMat);

  // ======================================================================
  // VARIANT TWEAKS
  // ======================================================================
  if (variant === 'compact') {
    camera.position.set(0, 4.6, 17.5);
    camera.fov = 42;
    camera.updateProjectionMatrix();
  }
  if (variant === 'orbit') {
    camera.position.set(0, 7.4, 19.0);
  }

  // ======================================================================
  // INTERACTION — pointer parallax (damped, clamped)
  // ======================================================================
  const pointer = { x: 0, y: 0 };
  const target = { x: 0, y: 0 };
  let scrollNorm = 0;

  function onPointerMove(e) {
    const r = canvas.getBoundingClientRect();
    target.x = ((e.clientX - r.left) / r.width - 0.5) * 2;
    target.y = ((e.clientY - r.top) / r.height - 0.5) * 2;
  }
  function onPointerLeave() { target.x = 0; target.y = 0; }

  if (!isCoarse && !reduced) {
    window.addEventListener('pointermove', onPointerMove, { passive: true });
    canvas.addEventListener('pointerleave', onPointerLeave, { passive: true });
  }

  function onScroll() {
    const r = canvas.getBoundingClientRect();
    scrollNorm = THREE.MathUtils.clamp(-r.top / Math.max(r.height, 1), 0, 1.4);
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // ======================================================================
  // RESIZE
  // ======================================================================
  function resize() {
    const w = canvas.clientWidth || canvas.parentElement.clientWidth;
    const h = canvas.clientHeight || canvas.parentElement.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    layout();
    if (reduced) renderer.render(scene, camera);
  }
  const ro = new ResizeObserver(resize);
  ro.observe(canvas.parentElement || canvas);
  resize();

  // ======================================================================
  // LOOP — paused when offscreen or tab hidden
  // ======================================================================
  let raf = 0;
  let running = false;
  let t0 = performance.now();
  const clock = { t: 0 };

  function frame(now) {
    raf = requestAnimationFrame(frame);
    const dt = Math.min((now - t0) / 1000, 0.05);
    t0 = now;
    clock.t += dt;
    const t = clock.t;

    // damped pointer
    pointer.x += (target.x - pointer.x) * 0.045;
    pointer.y += (target.y - pointer.y) * 0.045;

    // whole-scene gentle rotation + pointer parallax + scroll dive
    root.rotation.y = t * 0.055 + pointer.x * 0.20;
    root.rotation.x = pointer.y * 0.045 + scrollNorm * 0.09;
    root.position.y = composition.baseY + Math.sin(t * 0.55) * 0.10 - scrollNorm * 1.4;
    root.position.x = composition.offsetX + pointer.x * 0.35;

    camera.position.y = 5.4 + pointer.y * -0.42 + scrollNorm * 1.0;
    camera.position.x = pointer.x * 0.30;
    camera.lookAt(composition.offsetX * 0.55, 1.0 - scrollNorm * 0.45, 0);

    // domes breathe
    heroDome.position.y = 1.5 + Math.sin(t * 0.8) * 0.075;
    heroDome.rotation.y = t * 0.12;
    domeB.position.y = 1.0 + Math.sin(t * 0.8 + 1.4) * 0.06;
    domeC.position.y = 0.85 + Math.sin(t * 0.8 + 2.7) * 0.06;

    // orbiting cards
    cardGroup.children.forEach((c, i) => {
      const a = c.userData.a + t * 0.14 * (i % 2 ? 1 : -1) * 0.6;
      c.position.x = Math.cos(a) * c.userData.r;
      c.position.z = Math.sin(a) * c.userData.r;
      c.position.y = c.userData.baseY + Math.sin(t * 0.9 + i) * 0.22;
      c.rotation.y = -a + Math.PI / 2;
      c.rotation.z = Math.sin(t * 0.6 + i) * 0.10;
    });

    // stalls bob
    stallGroup.children.forEach((s, i) => {
      s.position.y = Math.sin(t * 1.1 + s.userData.phase) * 0.045;
    });

    // motes drift upward and recycle
    const mp = moteGeo.attributes.position.array;
    for (let i = 0; i < moteCount; i++) {
      mp[i * 3 + 1] += dt * (0.25 + (i % 7) * 0.035);
      mp[i * 3] += Math.sin(t * 0.5 + moteSeed[i]) * dt * 0.09;
      if (mp[i * 3 + 1] > 8.5) mp[i * 3 + 1] = -1.2;
    }
    moteGeo.attributes.position.needsUpdate = true;
    motes.rotation.y = t * 0.02;

    const wp = warmGeo.attributes.position.array;
    for (let i = 0; i < warmCount; i++) {
      wp[i * 3 + 1] += dt * (0.16 + (i % 5) * 0.03);
      if (wp[i * 3 + 1] > 7.5) wp[i * 3 + 1] = -0.8;
    }
    warmGeo.attributes.position.needsUpdate = true;
    warmMotes.rotation.y = -t * 0.015;

    // light pulse
    rimA.intensity = 26 + Math.sin(t * 1.3) * 5;
    rimB.intensity = 22 + Math.cos(t * 1.1) * 4.5;

    renderer.render(scene, camera);
  }

  function start() {
    if (running || reduced) return;
    running = true;
    t0 = performance.now();
    raf = requestAnimationFrame(frame);
  }
  function stop() {
    running = false;
    cancelAnimationFrame(raf);
  }

  // reduced motion → single static frame, no loop
  if (reduced) {
    renderer.render(scene, camera);
  } else {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => e.isIntersecting ? start() : stop());
    }, { threshold: 0.01 });
    io.observe(canvas);

    document.addEventListener('visibilitychange', () => {
      document.hidden ? stop() : start();
    });
  }

  canvas.closest('[data-scene-wrap]')?.setAttribute('data-webgl', 'ready');

  return {
    start, stop,
    dispose() {
      stop();
      ro.disconnect();
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('scroll', onScroll);
      disposables.forEach(d => d.dispose && d.dispose());
      renderer.dispose();
    }
  };
}

/* ==========================================================================
   Secondary scene: a slowly rotating 3D marker cluster for the map page
   ========================================================================== */
export function initMarkerScene(canvas) {
  if (!canvas) return null;
  let gl;
  try { gl = canvas.getContext('webgl2') || canvas.getContext('webgl'); } catch (e) { gl = null; }
  if (!gl) {
    canvas.closest('[data-scene-wrap]')?.setAttribute('data-webgl', 'unsupported');
    return null;
  }
  canvas.closest('[data-scene-wrap]')?.setAttribute('data-webgl', 'ready');

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 60);
  camera.position.set(0, 2.4, 7.5);
  camera.lookAt(0, 0.3, 0);

  scene.add(new THREE.HemisphereLight(0xdff5ee, 0x0a2a24, 1.0));
  const key = new THREE.DirectionalLight(0xffffff, 2.0);
  key.position.set(4, 8, 5);
  scene.add(key);
  const rim = new THREE.PointLight(0xf97316, 18, 20, 2);
  rim.position.set(-4, 2, 2);
  scene.add(rim);

  const g = new THREE.Group();
  scene.add(g);

  const pinBody = new THREE.SphereGeometry(0.42, 24, 18);
  const pinTip = new THREE.ConeGeometry(0.3, 0.72, 20);
  const matA = new THREE.MeshStandardMaterial({ color: 0x10b981, metalness: 0.4, roughness: 0.25, emissive: 0x065f46, emissiveIntensity: 0.3 });
  const matB = new THREE.MeshStandardMaterial({ color: 0xf97316, metalness: 0.4, roughness: 0.25, emissive: 0xc2410c, emissiveIntensity: 0.3 });

  const pins = [];
  for (let i = 0; i < 7; i++) {
    const a = (i / 7) * Math.PI * 2;
    const r = 2.3;
    const p = new THREE.Group();
    const b = new THREE.Mesh(pinBody, i % 3 === 0 ? matB : matA);
    b.position.y = 0.62;
    const tp = new THREE.Mesh(pinTip, i % 3 === 0 ? matB : matA);
    tp.rotation.x = Math.PI;
    p.add(b, tp);
    p.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
    p.userData.phase = i * 0.9;
    g.add(p);
    pins.push(p);
  }

  const gridGeo = new THREE.TorusGeometry(3.1, 0.03, 8, 72);
  const gridMat = new THREE.MeshStandardMaterial({ color: 0x34d399, metalness: 0.6, roughness: 0.3 });
  const grid = new THREE.Mesh(gridGeo, gridMat);
  grid.rotation.x = -Math.PI / 2;
  g.add(grid);

  function resize() {
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(resize);
  ro.observe(canvas.parentElement || canvas);
  resize();

  let raf, t = 0, running = false;
  function frame() {
    raf = requestAnimationFrame(frame);
    t += 0.016;
    g.rotation.y = t * 0.22;
    pins.forEach((p, i) => { p.position.y = Math.sin(t * 1.6 + p.userData.phase) * 0.16; });
    renderer.render(scene, camera);
  }
  if (reduced) { renderer.render(scene, camera); }
  else {
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting && !running) { running = true; raf = requestAnimationFrame(frame); }
      else if (!e.isIntersecting && running) { running = false; cancelAnimationFrame(raf); }
    }), { threshold: 0.01 });
    io.observe(canvas);
  }

  return { dispose() { cancelAnimationFrame(raf); ro.disconnect(); renderer.dispose(); } };
}
