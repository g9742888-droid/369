# -*- coding: utf-8 -*-
"""
Four fixes reported from a real phone, each pinned here.

  1. the map card covered 60% of the map, anchored to the TOP — it sat over
     the very pin it described, and the street name under it was unreadable
  2. the category filter clipped 21 of 23 chips at 84px and sliced the second
     row through the middle of the pills, so it read as breakage
  3. registration only asked for 7 fields; the shopkeeper had to submit, then
     go find an edit screen to add hours, socials and a map pin. He wants to
     finish the whole profile while he is standing in the shop.
  4. the hero picture was removed

The important one is 3: every field the form renders must actually PERSIST.
A field that shows but does not save is worse than no field.

Run:  python3 tools/test_onboarding.py
"""

import json
import os
import re
import sqlite3
import sys
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "server"))

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
DB = os.path.join(ROOT, "data", "bazarche.db")
G, R, B, X = "\033[32m", "\033[31m", "\033[1m", "\033[0m"

passed = failed = 0
fails = []


def ok(label, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  {G}✓{X} {label}")
    else:
        failed += 1
        fails.append(label)
        print(f"  {R}✗{X} {label}   {detail}")


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def post(path, data):
    body = urllib.parse.urlencode(data).encode()
    try:
        r = urllib.request.urlopen(BASE + path, body, timeout=25)
        return r.getcode(), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get("Location", "")


def cleanup(names):
    con = sqlite3.connect(DB)
    for n in names:
        con.execute("DELETE FROM businesses WHERE name=?", (n,))
    con.commit()
    con.close()


def main():
    from playwright.sync_api import sync_playwright

    print(f"\n{B}══ آزمون ثبت‌نام کامل و چیدمان موبایل ══{X}\n")

    # ================================================ 3. the whole profile
    print(f"{B}۱) فرم ثبت همهٔ فیلدها را ذخیره می‌کند{X}")
    NAME = "ززآزمون ثبت کامل"
    cleanup([NAME])
    payload = {
        "name": NAME, "cat_slug": "breadshop", "phone": "09139998801",
        "descr": "نانوایی سنگکی با تنور سنتی و آرد درجه یک",
        "address": "نجف‌آباد، خیابان آزمون، پلاک ۱۲",
        "whatsapp": "989139998801", "tags": "سنگک، بربری، تافتون",
        "instagram": "testbakery", "telegram": "testbakerytg",
        "website": "https://test-bakery.ir",
        "lat": "32.6340", "lng": "51.3660",
        "h_sat_open": "07:00", "h_sat_close": "22:00",
        "h_sun_open": "08:00", "h_sun_close": "20:00",
        "h_fri_open": "09:00", "h_fri_close": "21:00", "h_fri_closed": "on",
    }
    code, where = post("/submit", payload)
    ok("فرم پذیرفته شد", code in (200, 302, 303), f"HTTP {code}")

    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    row = con.execute("SELECT * FROM businesses WHERE name=?", (NAME,)).fetchone()
    ok("کسب‌وکار ذخیره شد", row is not None)
    if row:
        for field, want in [("descr", "نانوایی سنگکی"), ("address", "خیابان آزمون"),
                            ("whatsapp", "989139998801"), ("tags", "سنگک"),
                            ("instagram", "testbakery"),
                            ("telegram", "testbakerytg"),
                            ("website", "test-bakery.ir")]:
            got = str(row[field] or "")
            ok(f"«{field}» ذخیره شد", want in got, repr(got))
        ok("عرض جغرافیایی ذخیره شد", row["lat"] and abs(row["lat"] - 32.634) < 0.01,
           str(row["lat"]))
        ok("طول جغرافیایی ذخیره شد", row["lng"] and abs(row["lng"] - 51.366) < 0.01,
           str(row["lng"]))
        hours = json.loads(row["hours"] or "{}")
        ok("ساعت شنبه ذخیره شد", hours.get("sat") == [["07:00", "22:00"]], str(hours))
        ok("ساعت یک‌شنبه ذخیره شد", hours.get("sun") == [["08:00", "20:00"]], str(hours))
        ok("جمعهٔ تعطیل ذخیره نشد", "fri" not in hours, str(hours))
    con.close()

    # the three-field fast path must still work untouched
    print(f"\n{B}۲) مسیر سریع سه‌فیلدی نشکسته{X}")
    FAST = "ززآزمون سه فیلد"
    cleanup([FAST])
    code, _ = post("/submit", {"name": FAST, "cat_slug": "breadshop",
                               "phone": "09139998802"})
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    r2 = con.execute("SELECT * FROM businesses WHERE name=?", (FAST,)).fetchone()
    ok("ثبت با سه فیلد کار می‌کند", r2 is not None, f"HTTP {code}")
    if r2:
        ok("فیلدهای خالی چیز بی‌ربطی نگرفتند",
           not (r2["instagram"] or r2["website"] or r2["lat"]),
           f"ig={r2['instagram']} web={r2['website']} lat={r2['lat']}")
        # A POST with no h_* keys at all (an API client, or JS off) must not
        # invent hours. The browser default — six days open, Friday shut — is
        # only applied because the FORM carries those values.
        ok("ثبت بدون فیلد ساعت، ساعت نمی‌سازد",
           not (r2["hours"] or "").strip("{} \n"), repr(r2["hours"]))
    con.close()
    cleanup([NAME, FAST])

    print(f"\n{B}۲٫۵) پیش‌فرض ساعت، هفتهٔ کاری ایرانی است{X}")
    vp = read("server/views_public.py")
    ok("جمعه پیش‌فرض تعطیل است", '_k == "fri"' in vp)
    ok("بقیهٔ روزها پیش‌فرض باز", '"09:00"' in vp and '"21:00"' in vp)

    # ---------------------------------------------------------- live layout
    with sync_playwright() as p:
        br = p.chromium.launch()

        print(f"\n{B}۳) فرم روی موبایل{X}")
        ctx = br.new_context(viewport={"width": 412, "height": 915})
        pg = ctx.new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(BASE + "/submit", wait_until="networkidle")
        pg.wait_for_timeout(600)
        pg.click(".more-fields > summary")
        pg.wait_for_timeout(500)
        d = pg.evaluate("""() => {
          const de = document.documentElement;
          return {
            fields: document.querySelectorAll('.more-fields input,.more-fields textarea').length,
            hours: document.querySelectorAll('.hours-row').length,
            groups: [...document.querySelectorAll('.sub-fields legend')].map(e => e.textContent.trim()),
            geo: !!document.querySelector('[data-geo-fill]'),
            over: de.scrollWidth - de.clientWidth,
          };
        }""")
        ok("همهٔ فیلدها روی صفحه‌اند", d["fields"] >= 12, f"{d['fields']} فیلد")
        ok("هر هفت روز هفته هست", d["hours"] == 7, str(d["hours"]))
        ok("سه گروه اطلاعات هست", len(d["groups"]) == 3, str(d["groups"]))
        ok("دکمهٔ موقعیت فعلی هست", d["geo"])
        ok("فرم سرریز افقی ندارد", d["over"] == 0, str(d["over"]))
        ok("بدون خطای جاوااسکریپت", not errs, str(errs[:2]))
        # the geo button must be wired, not decorative
        ok("دکمهٔ موقعیت به کد وصل است",
           "initGeoFill" in read("site/assets/js/app.js")
           and "getCurrentPosition" in read("site/assets/js/app.js"))
        # every rendered field name must be one the server saves
        html = pg.content()
        rendered = set(re.findall(r'name="(h_[a-z]+_[a-z]+|instagram|telegram|'
                                  r'website|lat|lng|descr|address|whatsapp|tags)"', html))
        app = read("server/app.py")
        sub = app[app.index('if path == "/submit":'):]
        sub = sub[:sub.index("# ---- live duplicate check")]
        unsaved = [f for f in rendered
                   if not f.startswith("h_") and f'"{f}"' not in sub]
        ok("هیچ فیلد نمایشی بدون ذخیره نیست", not unsaved, str(unsaved))
        ctx.close()

        print(f"\n{B}۴) کارت نقشه، نقشه را نمی‌پوشاند{X}")
        ctx = br.new_context(viewport={"width": 412, "height": 915})
        pg = ctx.new_page()
        pg.goto(BASE + "/map", wait_until="networkidle")
        pg.wait_for_timeout(2200)
        item = pg.query_selector(".map-item")
        if item:
            item.click()
            pg.wait_for_timeout(1000)
        m = pg.evaluate("""() => {
          const sel = document.querySelector('[data-map-selected]');
          const wrap = document.querySelector('[data-map-canvas]');
          if (!sel || !wrap || sel.hidden) return null;
          const s = sel.getBoundingClientRect(), w = wrap.getBoundingClientRect();
          return {pct: Math.round(s.height / w.height * 100),
                  docked: Math.abs(s.bottom - w.bottom) < 24,
                  above: Math.round(s.top - w.top),
                  close: !!sel.querySelector('.ms-close'),
                  pos: getComputedStyle(sel).position};
        }""")
        # An empty database has no pins, so there is nothing to click and
        # nothing to assert — that is a clean skip, not a failure.
        if item is None:
            print("  — نقشه خالی است، این بخش رد شد")
        else:
            ok("کارت روی نقشه ظاهر شد", m is not None)
        if m:
            ok("کارت بیش از نیمی از نقشه را نمی‌گیرد", m["pct"] <= 50, f"{m['pct']}%")
            ok("کارت به پایین چسبیده", m["docked"], str(m))
            ok("بالای کارت نقشه دیده می‌شود", m["above"] > 150, f"{m['above']}px")
            ok("دکمهٔ بستن دارد", m["close"])
            # closing must actually clear it
            if m["close"]:
                pg.click(".ms-close")
                pg.wait_for_timeout(400)
                ok("دکمهٔ بستن واقعاً می‌بندد",
                   pg.evaluate("document.querySelector('[data-map-selected]').hidden"))
        # on a desktop it stays a corner card, not a sheet
        ctx.close()
        ctx = br.new_context(viewport={"width": 1280, "height": 900})
        pg = ctx.new_page()
        pg.goto(BASE + "/map", wait_until="networkidle")
        pg.wait_for_timeout(2000)
        it = pg.query_selector(".map-item")
        if it:
            it.click()
            pg.wait_for_timeout(800)
        w = pg.evaluate("""() => {
          const sel = document.querySelector('[data-map-selected]');
          const wrap = document.querySelector('[data-map-canvas]');
          if (!sel || sel.hidden) return null;
          const s = sel.getBoundingClientRect(), r = wrap.getBoundingClientRect();
          return {topAnchored: (s.top - r.top) < 40, w: Math.round(s.width)};
        }""")
        ok("روی دسکتاپ همان کارت گوشهٔ بالا می‌ماند",
           w is None or w["topAnchored"], str(w))
        ctx.close()

        print(f"\n{B}۵) فیلتر دسته‌بندی{X}")
        ctx = br.new_context(viewport={"width": 412, "height": 915})
        pg = ctx.new_page()
        pg.goto(BASE + "/businesses", wait_until="networkidle")
        pg.wait_for_timeout(800)
        pg.click("summary")
        pg.wait_for_timeout(600)
        c = pg.evaluate("""() => {
          const box = document.querySelector('[data-chips]');
          const btn = document.querySelector('[data-chips-more]');
          const r = box.getBoundingClientRect();
          const chips = [...box.querySelectorAll('.chip')];
          const half = chips.filter(x => {
            const cr = x.getBoundingClientRect();
            return cr.top < r.bottom - 2 && cr.bottom > r.bottom + 2;
          }).length;
          const br_ = btn ? btn.getBoundingClientRect() : null;
          return {half, btnH: br_ ? Math.round(br_.height) : 0,
                  btnHidden: btn ? btn.hidden : true,
                  boxH: Math.round(r.height), total: chips.length};
        }""")
        ok("هیچ دسته‌ای وسط بریده نشده", c["half"] == 0, f"{c['half']} مورد")
        ok("دکمهٔ «همهٔ دسته‌ها» دیده می‌شود", not c["btnHidden"])
        ok("دکمه هدف لمس ۴۴ پیکسل دارد", c["btnH"] >= 44, f"{c['btnH']}px")
        pg.click("[data-chips-more]")
        pg.wait_for_timeout(700)
        c2 = pg.evaluate("""() => {
          const box = document.querySelector('[data-chips]');
          const r = box.getBoundingClientRect();
          return {expanded: box.classList.contains('is-expanded'),
                  scrollable: getComputedStyle(box).overflowY === 'auto',
                  grew: Math.round(r.height),
                  reachable: box.scrollHeight <= r.height + box.scrollHeight};
        }""")
        ok("با کلیک باز می‌شود", c2["expanded"], str(c2))
        ok("باز شده قابل اسکرول است", c2["scrollable"], str(c2))
        ok("ارتفاعش واقعاً بیشتر شد", c2["grew"] > c["boxH"], str(c2))
        ctx.close()
        br.close()

    print(f"\n{B}{'=' * 58}{X}")
    if failed:
        print(f"{B}{R}  {passed} موفق، {failed} ناموفق{X}")
        for f in fails:
            print(f"    ✗ {f}")
    else:
        print(f"{B}{G}  همه موفق — {passed} آزمون، ۰ ناموفق{X}")
    print(f"{B}{'=' * 58}{X}\n")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
