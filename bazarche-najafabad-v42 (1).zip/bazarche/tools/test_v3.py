# -*- coding: utf-8 -*-
"""
Proof that every v3 feature is real, not decorative.

For each feature we: hit the page, perform the action over HTTP, then
RE-READ the database and assert the value actually changed.

    python3 run.py
    cd tools && BZ=http://127.0.0.1:8080 python3 test_v3.py
"""

import os
import re
import sys
import json
import urllib.parse
import urllib.request
import http.cookiejar

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
KEY = db.owner_token()

jar = http.cookiejar.CookieJar()
OPENER = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def get(path, expect=200):
    url = BASE + path
    try:
        r = OPENER.open(url, timeout=25)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def post(path, data, follow=True):
    body = urllib.parse.urlencode(data, doseq=True).encode()
    req = urllib.request.Request(BASE + path, data=body, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        r = OPENER.open(req, timeout=25)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def apost(path, data):
    d = dict(data)
    d["key"] = KEY
    return post(path, d)


# ==========================================================================
print(f"\n\033[1m\033[36mآزمون قابلیت‌های نسخهٔ ۳ — {BASE}\033[0m")

# ---- fixture: one business we can act on
head("آماده‌سازی داده آزمایشی")
cat = db.categories()[0]["slug"]
BID = db.save_business({"name": "کسب‌وکار آزمون نسخه سه", "cat_slug": cat,
                        "descr": "این رکورد فقط برای آزمون است و پاک می‌شود.",
                        "phone": "09131110099", "address": "نجف‌آباد، خیابان آزمون",
                        "lat": 32.6340, "lng": 51.3670, "status": "published"})
BIZ = db.business(bid=BID)
SLUG = BIZ["slug"]
check("کسب‌وکار آزمایشی ساخته شد", bool(BID), f"id={BID}")

# ==========================================================================
head("۱) صفحه‌های عمومی تازه باز می‌شوند")
for path, name in [("/compare", "مقایسه"), ("/nearby", "نزدیک من"),
                   ("/events", "رویدادهای شهر")]:
    code, html = get(path)
    check(f"{name} ({path})", code == 200, f"code={code}")

# ==========================================================================
head("۲) پرسش و پاسخ — واقعاً ذخیره می‌شود")
before = len(db.questions(biz_id=BID))
code, _ = post(f"/b/{SLUG}/ask-question",
               {"asker": "مشتری آزمون", "body": "آیا پارکینگ اختصاصی دارید؟"})
after = db.questions(biz_id=BID)
check("ثبت پرسش از صفحهٔ کسب‌وکار", len(after) == before + 1,
      f"{before} -> {len(after)}")
QID = after[0]["id"] if after else None
check("پرسش در وضعیت «در انتظار» می‌نشیند",
      bool(after) and after[0]["status"] == "pending",
      after[0]["status"] if after else "—")

code, html = get(f"/panel/qa?key={urllib.parse.quote(KEY)}")
check("پرسش در پنل مدیریت دیده می‌شود",
      code == 200 and "پارکینگ اختصاصی" in html, f"code={code}")

apost(f"/panel/question/{QID}", {"action": "answer",
                                 "answer": "بله، پارکینگ رایگان داریم."})
q = db.question(QID)
check("پاسخ مدیر در پایگاه داده ثبت شد",
      q and q["answer"] == "بله، پارکینگ رایگان داریم.", str(q and q["answer"]))
check("پرسش پس از پاسخ منتشر شد", q and q["status"] == "published",
      str(q and q["status"]))

code, html = get(f"/b/{SLUG}")
check("پرسش و پاسخ روی صفحهٔ عمومی دیده می‌شود",
      "پارکینگ رایگان داریم" in html, "")

h0 = db.question(QID)["helpful"]
post("/api/question-helpful", {"id": str(QID)})
h1 = db.question(QID)["helpful"]
check("شمارندهٔ «مفید بود» بالا رفت", h1 == h0 + 1, f"{h0} -> {h1}")

apost(f"/panel/question/{QID}", {"action": "reject"})
check("رد کردن پرسش کار می‌کند", db.question(QID)["status"] == "rejected",
      db.question(QID)["status"])

# ==========================================================================
head("۳) گزارش تخلف")
n0 = len(db.reports())
post(f"/b/{SLUG}/report", {"reason": "wrong", "body": "شمارهٔ تلفن عوض شده",
                           "reporter": "09131112222"})
rs = db.reports()
check("گزارش ثبت شد", len(rs) == n0 + 1, f"{n0} -> {len(rs)}")
RID = rs[0]["id"] if rs else None
check("دلیل درست ذخیره شد", rs and rs[0]["reason"] == "wrong",
      rs[0]["reason"] if rs else "—")

code, html = get(f"/panel/reports?key={urllib.parse.quote(KEY)}")
check("گزارش در پنل نمایش داده می‌شود",
      code == 200 and "شمارهٔ تلفن عوض شده" in html, f"code={code}")

apost(f"/panel/report/{RID}", {"action": "resolve"})
r = [x for x in db.reports() if x["id"] == RID]
check("رسیدگی به گزارش وضعیت را عوض کرد",
      r and r[0]["status"] == "resolved", r[0]["status"] if r else "—")

apost(f"/panel/report/{RID}", {"action": "dismiss"})
r = [x for x in db.reports() if x["id"] == RID]
check("رد کردن گزارش کار می‌کند", r and r[0]["status"] == "dismissed",
      r[0]["status"] if r else "—")

# ==========================================================================
head("۴) نشان‌ها")
code, html = get(f"/panel/badges?key={urllib.parse.quote(KEY)}")
check("صفحهٔ نشان‌ها باز می‌شود", code == 200, f"code={code}")

n0 = len(db.badges(only_active=False))
apost("/panel/badge/new", {"name": "آزمون نشان", "descr": "برای آزمون",
                           "icon": "star", "color": "#123456", "active": "1"})
bl = db.badges(only_active=False)
check("نشان تازه ساخته شد", len(bl) == n0 + 1, f"{n0} -> {len(bl)}")
NBID = next((b["id"] for b in bl if b["name"] == "آزمون نشان"), None)

apost("/panel/badges/grant", {"biz_id": str(BID), "badge_ids": [str(NBID)]})
got = db.biz_badges(BID)
check("نشان به کسب‌وکار داده شد",
      any(b["id"] == NBID for b in got), f"{[b['name'] for b in got]}")

code, html = get(f"/b/{SLUG}")
check("نشان روی صفحهٔ کسب‌وکار دیده می‌شود", "آزمون نشان" in html, "")

apost("/panel/badges/grant", {"biz_id": str(BID), "badge_ids": []})
check("پس گرفتن نشان کار می‌کند", len(db.biz_badges(BID)) == 0,
      str(len(db.biz_badges(BID))))

apost(f"/panel/badge/{NBID}", {"action": "toggle"})
check("خاموش/روشن کردن نشان کار می‌کند",
      db.badge(bid=NBID)["active"] == 0, str(db.badge(bid=NBID)["active"]))

code, _ = apost("/panel/badges/auto", {})
check("محاسبهٔ خودکار نشان بدون خطا اجرا شد", code in (200, 303), f"code={code}")

apost(f"/panel/badge/{NBID}", {"action": "delete"})
check("حذف نشان کار می‌کند", db.badge(bid=NBID) is None, "")

# ==========================================================================
head("۵) امتیازدهی چندمعیاره")
n0 = len(db.reviews(biz_id=BID))
post(f"/b/{SLUG}/review", {"author": "مشتری معیار", "rating": "5",
                           "body": "خیلی راضی بودم از این مجموعه، کارشان تمیز است.",
                           "crit_quality": "5", "crit_price": "4",
                           "crit_speed": "5", "crit_behaviour": "4"})
revs = db.reviews(biz_id=BID)
check("نظر ثبت شد", len(revs) == n0 + 1, f"{n0} -> {len(revs)}")
RVID = revs[0]["id"] if revs else None
sc = db.review_scores(RVID) if RVID else {}
check("امتیاز تفکیکی ذخیره شد", len(sc) == 4, str(sc))
check("مقدار «قیمت» درست ذخیره شد", sc.get("price") == 4, str(sc.get("price")))

apost(f"/panel/review/{RVID}", {"action": "approve"})
avgs = db.criteria_averages(BID)
check("میانگین معیارها محاسبه می‌شود", len(avgs) == 4, str(len(avgs)))
code, html = get(f"/b/{SLUG}")
check("نوارهای معیار روی صفحه دیده می‌شود", "crit-fill" in html, "")

# ==========================================================================
head("۶) جست‌وجوی شعاعی «نزدیک من»")
code, raw = get(f"/api/nearby?lat=32.6340&lng=51.3670&r=3")
try:
    data = json.loads(raw)
except Exception:
    data = {}
check("API نزدیک من پاسخ JSON می‌دهد", code == 200 and "results" in data,
      f"code={code}")
found = [x for x in data.get("results", []) if x["slug"] == SLUG]
check("کسب‌وکار آزمایشی در شعاع پیدا شد", bool(found), "")
check("فاصله محاسبه شده است",
      bool(found) and found[0]["distance_km"] < 0.5,
      str(found[0]["distance_km"]) if found else "—")

code, raw = get("/api/nearby?lat=35.7&lng=51.4&r=1")
data = json.loads(raw) if raw.startswith("{") else {}
check("خارج از شعاع نتیجه‌ای برنمی‌گرداند",
      len(data.get("results", [])) == 0, str(len(data.get("results", []))))

near = db.nearby(32.6340, 51.3670, 3)
check("تابع haversine در پایتون هم درست است", any(b["slug"] == SLUG for b in near), "")

# ==========================================================================
head("۷) مقایسهٔ کنار هم")
B2 = db.save_business({"name": "کسب‌وکار آزمون دوم", "cat_slug": cat,
                       "descr": "رکورد دوم آزمون.", "phone": "09131110088",
                       "status": "published"})
S2 = db.business(bid=B2)["slug"]
code, html = get(f"/compare?b={SLUG}&b={S2}")
check("صفحهٔ مقایسه با دو مورد باز می‌شود", code == 200, f"code={code}")
check("نام هر دو کسب‌وکار در جدول هست",
      "کسب‌وکار آزمون نسخه سه" in html and "کسب‌وکار آزمون دوم" in html, "")
check("سطر ساعت کاری موجود است", "ساعت کاری" in html, "")
check("سطر نشان‌ها موجود است", "نشان‌ها" in html, "")
code, html = get("/compare")
check("مقایسهٔ خالی پیام راهنما می‌دهد", "انتخاب نشده" in html, "")

# ==========================================================================
head("۸) پلن‌ها و اشتراک واقعی")
code, html = get(f"/panel/plans?key={urllib.parse.quote(KEY)}")
check("صفحهٔ پلن‌ها باز می‌شود", code == 200, f"code={code}")

n0 = len(db.plans(only_active=False))
apost("/panel/plan/new", {"name": "پلن آزمون", "price": "500000",
                          "months": "6", "perks": "یک\nدو", "active": "1"})
pl = db.plans(only_active=False)
check("پلن ساخته شد", len(pl) == n0 + 1, f"{n0} -> {len(pl)}")
NPID = next((p["id"] for p in pl if p["name"] == "پلن آزمون"), None)
NPSLUG = next((p["slug"] for p in pl if p["name"] == "پلن آزمون"), None)

apost(f"/panel/plan/{NPID}", {"action": "save", "name": "پلن آزمون ویرایش‌شده",
                              "price": "700000", "months": "6",
                              "featured_slots": "1", "max_items": "50",
                              "max_photos": "15", "perks": "یک\nدو\nسه",
                              "badge_slug": "verified-shop", "active": "1"})
p2 = db.plan(pid=NPID)
check("ویرایش پلن ذخیره شد", p2["price"] == 700000, str(p2["price"]))
check("امکانات پلن به‌روزرسانی شد", len(p2["perk_list"]) == 3,
      str(len(p2["perk_list"])))

n0 = len(db.subscriptions())
apost("/panel/subscription/new", {"biz_id": str(BID), "plan_slug": NPSLUG,
                                  "ref": "TEST-REF-1", "activate": "1"})
subs = db.subscriptions(biz_id=BID)
check("اشتراک ثبت شد", len(subs) >= 1, str(len(subs)))
SID = subs[0]["id"] if subs else None
check("اشتراک فعال شد", subs and subs[0]["status"] == "active",
      subs[0]["status"] if subs else "—")
check("تاریخ انقضا محاسبه شد", subs and bool(subs[0]["expires"]),
      subs[0]["expires"] if subs else "—")

fresh = db.business(bid=BID)
check("پلن دارای «جایگاه ویژه» کسب‌وکار را ویژه کرد",
      fresh["featured"] == 1, str(fresh["featured"]))
check("نشان همراه پلن اعطا شد",
      any(b["slug"] == "verified-shop" for b in db.biz_badges(BID)),
      str([b["slug"] for b in db.biz_badges(BID)]))

lim = db.plan_limits(BID)
check("سقف‌های پلن روی کسب‌وکار اعمال شد", lim["max_items"] == 50, str(lim))

apost(f"/panel/subscription/{SID}", {"action": "cancel"})
fresh = db.business(bid=BID)
check("لغو اشتراک وضعیت را عوض کرد",
      [x for x in db.subscriptions(biz_id=BID) if x["id"] == SID][0]["status"] == "cancelled", "")
check("لغو اشتراک نشان ویژه را پس گرفت", fresh["featured"] == 0,
      str(fresh["featured"]))
check("لغو اشتراک نشان پلن را پس گرفت",
      not any(b["slug"] == "verified-shop" for b in db.biz_badges(BID)), "")

# expiry logic
import datetime
past = (datetime.date.today() - datetime.timedelta(days=2)).isoformat()
db._run("UPDATE subscriptions SET status='active', expires=? WHERE id=?", (past, SID))
n_exp = db.expire_subscriptions()
check("اشتراک منقضی خودکار بسته شد", n_exp >= 1, str(n_exp))
check("وضعیت پس از انقضا «expired» است",
      [x for x in db.subscriptions(biz_id=BID) if x["id"] == SID][0]["status"] == "expired", "")

apost(f"/panel/subscription/{SID}", {"action": "delete"})
check("حذف ردیف اشتراک کار می‌کند",
      not [x for x in db.subscriptions(biz_id=BID) if x["id"] == SID], "")

apost("/panel/plans/payment", {"pay_method": "manual", "pay_card": "6037991234567890",
                               "pay_card_name": "آزمون", "zarinpal_merchant": ""})
check("روش پرداخت ذخیره شد",
      db.get_settings().get("pay_card") == "6037991234567890",
      db.get_settings().get("pay_card"))

ok_, msg = db.delete_plan(NPID)
check("حذف پلن آزمایشی", ok_, msg)

# ==========================================================================
head("۹) تبلیغات با شمارش واقعی")
code, html = get(f"/panel/ads?key={urllib.parse.quote(KEY)}")
check("صفحهٔ تبلیغات باز می‌شود", code == 200, f"code={code}")

# park every other banner on this slot so the weighted picker is deterministic
PARKED = [a["id"] for a in db.ads(slot="business") if a["active"]]
for pid in PARKED:
    db.save_ad(dict(db.ad(pid), active=0), pid)

AID = db.save_ad({"title": "بنر آزمون", "body": "متن بنر", "url": "/businesses",
                  "slot": "business", "weight": "1", "active": "1"})
check("بنر ساخته شد", bool(AID), str(AID))

v0 = db.ad(AID)["views"]
get(f"/b/{SLUG}")
v1 = db.ad(AID)["views"]
check("نمایش بنر شمرده شد", v1 > v0, f"{v0} -> {v1}")

c0 = db.ad(AID)["clicks"]
code, _ = get(f"/ad/{AID}")
c1 = db.ad(AID)["clicks"]
check("کلیک بنر شمرده شد", c1 == c0 + 1, f"{c0} -> {c1}")
check("کلیک به مقصد هدایت می‌کند", code == 200, f"code={code}")

apost(f"/panel/ad/{AID}", {"action": "reset"})
check("صفر کردن آمار کار می‌کند",
      db.ad(AID)["views"] == 0 and db.ad(AID)["clicks"] == 0, "")
apost(f"/panel/ad/{AID}", {"action": "toggle"})
check("خاموش کردن بنر کار می‌کند", db.ad(AID)["active"] == 0, "")
apost(f"/panel/ad/{AID}", {"action": "delete"})
check("حذف بنر کار می‌کند", db.ad(AID) is None, "")
for pid in PARKED:          # restore what we parked
    db.save_ad(dict(db.ad(pid), active=1), pid)
check("بنرهای موجود دست‌نخورده برگشتند",
      all(db.ad(pid)["active"] == 1 for pid in PARKED), str(PARKED))

# ==========================================================================
head("۱۰) رویدادهای شهر")
n0 = len(db.cityevents(status=None))
apost("/panel/event/new", {"title": "رویداد آزمون", "descr": "توضیح آزمون",
                           "place": "بازارچهٔ مرکزی", "date": "2026-12-01",
                           "time": "18:00", "biz_id": str(BID)})
evs = db.cityevents(status=None)
check("رویداد ثبت شد", len(evs) == n0 + 1, f"{n0} -> {len(evs)}")
EV = next((e for e in evs if e["title"] == "رویداد آزمون"), None)
code, html = get("/events")
check("رویداد در صفحهٔ عمومی دیده می‌شود",
      code == 200 and "رویداد آزمون" in html, f"code={code}")
code, html = get(f"/events/{EV['slug']}")
check("صفحهٔ اختصاصی رویداد باز می‌شود",
      code == 200 and "بازارچهٔ مرکزی" in html, f"code={code}")
check("داده ساخت‌یافتهٔ رویداد تولید شد", '"@type": "Event"' in html, "")
apost(f"/panel/event/{EV['id']}", {"action": "delete"})
check("حذف رویداد کار می‌کند", db.cityevent(eid=EV["id"]) is None, "")

# ==========================================================================
head("۱۱) تأیید تغییرات پروفایل")
db.set_setting("edit_approval", "1")
n0 = len(db.pending_edits())
EID = db.queue_edit(BID, None, {"phone": "09139998877", "address": "نشانی تازه"})
check("درخواست ویرایش صف شد", len(db.pending_edits()) == n0 + 1,
      f"{n0} -> {len(db.pending_edits())}")
code, html = get(f"/panel/edits?key={urllib.parse.quote(KEY)}")
check("درخواست در پنل دیده می‌شود",
      code == 200 and "نشانی تازه" in html, f"code={code}")
apost(f"/panel/edit/{EID}", {"action": "approve"})
fresh = db.business(bid=BID)
check("تأیید ویرایش داده را واقعاً عوض کرد",
      fresh["phone"] == "09139998877", fresh["phone"])
check("وضعیت درخواست approved شد",
      db.pending_edits(status="approved") and
      db.pending_edits(status="approved")[0]["id"] == EID, "")

EID2 = db.queue_edit(BID, None, {"name": "نام رد شده"})
apost(f"/panel/edit/{EID2}", {"action": "reject"})
check("رد ویرایش داده را دست‌نخورده می‌گذارد",
      db.business(bid=BID)["name"] != "نام رد شده", "")

code, _ = apost("/panel/edits/toggle", {})
check("کلید تأیید تغییرات از پنل عوض می‌شود",
      db.get_settings().get("edit_approval") == "0",
      db.get_settings().get("edit_approval"))
db.set_setting("edit_approval", "0")

# ==========================================================================
head("۱۲) هشدار جست‌وجو")
n0 = len(db.alerts())
code, raw = post("/api/alert", {"phone": "09131234567", "term": "قنادی",
                                "cat": ""})
check("هشدار از API ثبت شد", len(db.alerts()) == n0 + 1,
      f"{n0} -> {len(db.alerts())}")
ALID = db.alerts()[0]["id"]
code, html = get(f"/panel/alerts?key={urllib.parse.quote(KEY)}")
check("هشدار در پنل دیده می‌شود",
      code == 200 and "09131234567" in html, f"code={code}")

fake = {"name": "قنادی شیرین", "descr": "", "tags": "", "address": "",
        "cat_slug": cat}
check("تطبیق هشدار با کسب‌وکار مطابق کار می‌کند",
      any(a["id"] == ALID for a in db.matching_alerts(fake)), "")
check("کسب‌وکار نامرتبط هشدار را فعال نمی‌کند",
      not db.matching_alerts({"name": "تعمیرگاه", "descr": "", "tags": "",
                              "address": "", "cat_slug": cat}), "")

apost(f"/panel/alert/{ALID}", {"action": "toggle"})
check("خاموش کردن هشدار کار می‌کند",
      [a for a in db.alerts() if a["id"] == ALID][0]["active"] == 0, "")
apost(f"/panel/alert/{ALID}", {"action": "delete"})
check("حذف هشدار کار می‌کند",
      not [a for a in db.alerts() if a["id"] == ALID], "")

# ==========================================================================
head("۱۳) داده ساخت‌یافته (Schema.org)")
code, html = get(f"/b/{SLUG}")
check("JSON-LD روی صفحهٔ کسب‌وکار هست", 'application/ld+json' in html, "")
check("نوع LocalBusiness درست است", '"LocalBusiness"' in html, "")
check("مسیر راهنما (BreadcrumbList) هست", '"BreadcrumbList"' in html, "")
blocks = re.findall(r'<script type="application/ld\+json">(.*?)</script>', html, re.S)
valid = True
for b in blocks:
    try:
        json.loads(b)
    except Exception:
        valid = False
check(f"هر {len(blocks)} بلوک JSON-LD معتبر است", valid and len(blocks) >= 2,
      str(len(blocks)))
ld = db.jsonld_business(db.business(bid=BID))
check("مختصات جغرافیایی در JSON-LD هست", "geo" in ld, str(ld.get("geo")))
check("امتیاز تجمیعی در JSON-LD هست", "aggregateRating" in ld, "")

# ==========================================================================
head("۱۴) بینش و آمار کل سایت")
code, html = get(f"/panel/insights?key={urllib.parse.quote(KEY)}")
check("صفحهٔ بینش باز می‌شود", code == 200, f"code={code}")
check("نمودار روزانه رندر شد", "ins-chart" in html, "")
check("جدول پربازدیدها هست", "پربازدیدترین" in html, "")
for d in (7, 90, 365):
    code, _ = get(f"/panel/insights?key={urllib.parse.quote(KEY)}&days={d}")
    check(f"بازهٔ {d} روزه کار می‌کند", code == 200, f"code={code}")

db.track(BID, "phone")
ins = db.site_insights(30)
check("رویداد کلیک تماس در آمار ظاهر شد", ins["totals"]["phone"] >= 1,
      str(ins["totals"]))
check("سری روزانه طول درست دارد", len(ins["daily"]) == 30, str(len(ins["daily"])))

# ==========================================================================
head("۱۵) محدودسازی نرخ درخواست")
db.rate_clear()
db.set_settings({"ratelimit_on": "1", "ratelimit_n": "3", "ratelimit_win": "600"})
res = [db.rate_ok("test:bucket") for _ in range(5)]
check("سه درخواست اول مجاز است", res[:3] == [True, True, True], str(res))
check("درخواست چهارم مسدود می‌شود", res[3] is False, str(res))
db.set_settings({"ratelimit_on": "0"})
check("با خاموش بودن کلید، محدودیت اعمال نمی‌شود",
      db.rate_ok("test:bucket") is True, "")
db.set_settings({"ratelimit_on": "1", "ratelimit_n": "8", "ratelimit_win": "600"})
db.rate_clear()

# ==========================================================================
head("۱۶) ناوبری و شمارنده‌های پنل")
code, html = get(f"/panel?key={urllib.parse.quote(KEY)}")
check("داشبورد باز می‌شود", code == 200, f"code={code}")
for path, label in [("/panel/qa", "پرسش و پاسخ"), ("/panel/reports", "گزارش تخلف"),
                    ("/panel/badges", "نشان‌ها"), ("/panel/plans", "پلن‌ها و تعرفه"),
                    ("/panel/subscriptions", "اشتراک‌ها"), ("/panel/ads", "تبلیغات"),
                    ("/panel/events", "رویدادهای شهر"), ("/panel/edits", "تأیید تغییرات"),
                    ("/panel/alerts", "هشدار جست‌وجو"), ("/panel/insights", "بینش و آمار")]:
    check(f"لینک «{label}» در منوی پنل هست", f'href="{path}?key=' in html, "")

for path in ["/panel/qa", "/panel/reports", "/panel/badges", "/panel/plans",
             "/panel/subscriptions", "/panel/ads", "/panel/events",
             "/panel/edits", "/panel/alerts", "/panel/insights"]:
    code, _ = get(f"{path}?key={urllib.parse.quote(KEY)}")
    check(f"{path} با کلید باز می‌شود", code == 200, f"code={code}")
    code, _ = get(path)
    check(f"{path} بدون کلید ۴۰۳ می‌دهد", code == 403, f"code={code}")

# ==========================================================================
head("۱۷) کلیدهای فعال/غیرفعال واقعاً اثر دارند")
db.set_setting("qa_enabled", "0")
code, html = get(f"/b/{SLUG}")
check("خاموش کردن پرسش‌وپاسخ بخش را حذف می‌کند",
      'id="qa"' not in html, "")
db.set_setting("qa_enabled", "1")

db.set_setting("reports_enabled", "0")
code, html = get(f"/b/{SLUG}")
check("خاموش کردن گزارش تخلف بخش را حذف می‌کند",
      "گزارش مشکل در این صفحه" not in html, "")
db.set_setting("reports_enabled", "1")

db.set_setting("nearby_enabled", "0")
code, _ = get("/nearby")
check("خاموش کردن «نزدیک من» صفحه را ۴۰۴ می‌کند", code == 404, f"code={code}")
db.set_setting("nearby_enabled", "1")

db.set_setting("events_enabled", "0")
code, _ = get("/events")
check("خاموش کردن رویدادها صفحه را ۴۰۴ می‌کند", code == 404, f"code={code}")
db.set_setting("events_enabled", "1")

db.set_setting("seo_schema", "0")
code, html = get(f"/b/{SLUG}")
check("خاموش کردن Schema داده ساخت‌یافته را حذف می‌کند",
      "application/ld+json" not in html, "")
db.set_setting("seo_schema", "1")

# ==========================================================================
head("۱۸) پشتیبان‌گیری شامل جدول‌های جدید است")
data = db.export_all()
for t in ("badges", "plans", "subscriptions", "ads", "cityevents",
          "questions", "reports", "review_scores", "edits", "alerts",
          "biz_badges"):
    check(f"جدول «{t}» در پشتیبان هست", t in data, "")

code, raw = get(f"/panel/backup/export?key={urllib.parse.quote(KEY)}")
try:
    payload = json.loads(raw)
    okj = "questions" in payload and "plans" in payload
except Exception:
    okj = False
check("خروجی پشتیبان از پنل معتبر است", okj, f"code={code}")

# round-trip restore
before_q = len(db.questions())
db.import_all(payload)
check("بازیابی پشتیبان بدون خطا انجام شد",
      len(db.questions()) == before_q, f"{before_q} -> {len(db.questions())}")

# ==========================================================================
head("۱۹) پاک‌سازی دادهٔ آزمایشی")
db.delete_business(BID)
db.delete_business(B2)
check("کسب‌وکارهای آزمایشی حذف شدند",
      db.business(bid=BID) is None and db.business(bid=B2) is None, "")
check("پرسش‌های وابسته آبشاری حذف شدند", len(db.questions(biz_id=BID)) == 0, "")
check("گزارش‌های وابسته حذف شدند",
      not [r for r in db.reports() if r.get("biz_id") == BID], "")
db.rate_clear()

# ==========================================================================
print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
