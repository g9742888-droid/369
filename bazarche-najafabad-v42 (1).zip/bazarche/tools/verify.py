#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Headless verification: console errors, WebGL init, a11y basics, screenshots."""
import sys, os, json
from playwright.sync_api import sync_playwright

BASE = "http://localhost:8080"
SHOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'shots')
os.makedirs(SHOT, exist_ok=True)

PAGES = ["index.html", "businesses.html", "businesses-cat.html", "business.html",
         "map.html", "pricing.html", "order-site.html", "contact.html", "about.html",
         "rules.html", "login.html", "register.html", "panel.html",
         "panel-business-edit.html", "panel-reviews.html", "panel-subscription.html",
         "admin.html", "admin-businesses.html", "admin-users.html",
         "admin-categories.html", "admin-reports.html", "admin-settings.html",
         "admin-backup.html", "admin-messages.html", "admin-orders.html",
         "admin-payments.html"]

FULL_SHOTS = {"index.html", "businesses.html", "business.html", "map.html",
              "pricing.html", "admin.html", "panel.html", "login.html"}

A11Y = """() => {
  const out = {imgNoAlt: 0, btnNoName: 0, inputNoLabel: 0, hOrder: [], smallTap: 0};
  document.querySelectorAll('img').forEach(i => { if (!i.hasAttribute('alt')) out.imgNoAlt++; });
  document.querySelectorAll('button, a[href]').forEach(b => {
    const t = (b.innerText || '').trim();
    if (!t && !b.getAttribute('aria-label') && !b.getAttribute('title')) out.btnNoName++;
  });
  document.querySelectorAll('input, select, textarea').forEach(i => {
    if (i.type === 'hidden') return;
    const id = i.id;
    const lab = id && document.querySelector(`label[for="${id}"]`);
    if (!lab && !i.getAttribute('aria-label') && !i.closest('label')) out.inputNoLabel++;
  });
  document.querySelectorAll('h1,h2,h3,h4').forEach(h => out.hOrder.push(+h.tagName[1]));
  // WCAG 2.5.8: links inline within a sentence are exempt from target size.
  const inlineLink = (el) => {
    if (el.tagName !== 'A') return false;
    const p = el.parentElement;
    if (!p) return false;
    return /^(P|SPAN|LI|LABEL|SMALL|TD)$/.test(p.tagName) && p.innerText.trim() !== el.innerText.trim();
  };
  document.querySelectorAll('button, a[href], input[type=checkbox]').forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return;
    if (inlineLink(el)) return;
    // a control wrapped in a >=44px label already has an adequate hit area
    const lab = el.closest('label');
    if (lab && lab.getBoundingClientRect().height >= 40) return;
    if (r.height < 24 || r.width < 24) out.smallTap++;
  });
  return out;
}"""


def main():
    fails = 0
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--enable-unsafe-swiftshader", "--use-gl=swiftshader"])
        for name in PAGES:
            ctx = browser.new_context(viewport={"width": 1440, "height": 950},
                                      device_scale_factor=1, locale="fa-IR")
            page = ctx.new_page()
            errors, warns = [], []
            # SwiftShader (headless software GL) emits benign shader-validate noise
            IGNORE = ("VALIDATE_STATUS", "Shader Error", "GroupMarkerNotSet",
                      "Automatic fallback to software WebGL")
            page.on("console", lambda m: (
                errors.append(m.text)
                if m.type == "error" and not any(k in m.text for k in IGNORE) else None))
            page.on("pageerror", lambda e: errors.append(f"PAGEERROR {e}"))
            page.on("requestfailed", lambda r: errors.append(f"REQFAIL {r.url}"))

            page.goto(f"{BASE}/{name}", wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(2200)

            a = page.evaluate(A11Y)
            webgl = page.evaluate("""() => {
              const w = document.querySelector('[data-scene-wrap]');
              return w ? (w.getAttribute('data-webgl') || 'no-attr') : 'n/a';
            }""") or 'n/a'
            hscroll = page.evaluate(
                "() => document.documentElement.scrollWidth > window.innerWidth + 2")

            issues = []
            if errors: issues.append(f"console: {errors[:2]}")
            if a["imgNoAlt"]: issues.append(f"{a['imgNoAlt']} img w/o alt")
            if a["btnNoName"]: issues.append(f"{a['btnNoName']} unnamed control")
            if a["inputNoLabel"]: issues.append(f"{a['inputNoLabel']} unlabelled input")
            if a["smallTap"]: issues.append(f"{a['smallTap']} tiny tap target")
            if hscroll: issues.append("horizontal scroll")
            if webgl == "unsupported": issues.append("WebGL failed")

            if name in FULL_SHOTS:
                page.screenshot(path=os.path.join(SHOT, name.replace('.html', '.png')),
                                full_page=False)

            flag = "  ok  " if not issues else "  !!  "
            print(f"{flag}{name:<28} webgl={webgl:<12} " + ("; ".join(issues) if issues else ""))
            if issues: fails += 1
            ctx.close()

        # mobile pass
        print("\n--- mobile 390px ---")
        for name in ["index.html", "businesses.html", "business.html", "admin.html"]:
            ctx = browser.new_context(viewport={"width": 390, "height": 844},
                                      device_scale_factor=2, is_mobile=True,
                                      has_touch=True, locale="fa-IR")
            page = ctx.new_page()
            errs = []
            page.on("pageerror", lambda e: errs.append(str(e)))
            page.goto(f"{BASE}/{name}", wait_until="networkidle", timeout=30000)
            page.wait_for_timeout(1500)
            hs = page.evaluate("() => document.documentElement.scrollWidth > window.innerWidth + 2")
            page.screenshot(path=os.path.join(SHOT, 'm-' + name.replace('.html', '.png')))
            issues = (["horizontal scroll"] if hs else []) + (errs[:1] if errs else [])
            print(("  ok  " if not issues else "  !!  ") + f"{name:<28} " + "; ".join(issues))
            if issues: fails += 1
            ctx.close()

        # dark mode pass
        print("\n--- dark theme ---")
        ctx = browser.new_context(viewport={"width": 1440, "height": 950}, locale="fa-IR")
        page = ctx.new_page()
        page.goto(f"{BASE}/index.html", wait_until="networkidle")
        page.evaluate("document.documentElement.setAttribute('data-theme','dark')")
        page.wait_for_timeout(1800)
        page.screenshot(path=os.path.join(SHOT, 'dark-index.png'))
        print("  ok  dark screenshot captured")
        ctx.close()

        browser.close()
    print(f"\n{fails} pages with issues")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
