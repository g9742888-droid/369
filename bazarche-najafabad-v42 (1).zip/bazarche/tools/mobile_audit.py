# -*- coding: utf-8 -*-
"""
Mobile audit — measure the site on the phones Najafabad shopkeepers hold.

This exists because the site was built on a 1440px screen and everyone who
uses it is on a phone. Guessing "it looks fine" is how that happens, so this
prints numbers instead:

  · touch targets under 44px (Apple HIG) / 48px (Material)
  · any text rendered below 12px
  · horizontal overflow and the element causing it
  · how much of the viewport fixed chrome eats
  · whether inputs are >=16px (below that iOS silently zooms the page)

    python3 -u run.py
    BZ=http://127.0.0.1:8080 python3 tools/mobile_audit.py
"""

import os
import sys

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    print("playwright لازم است:  pip install playwright && "
          "python3 -m playwright install chromium")
    sys.exit(2)

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

# real devices, weighted to what is common in Iran
PHONES = [
    ("Galaxy A / Redmi", 360, 800, 3.0),
    ("iPhone SE / 8",    375, 667, 2.0),
    ("iPhone 13/14",     390, 844, 3.0),
    ("Galaxy S Ultra",   412, 915, 3.5),
]

PAGES = ["/", "/businesses", "/prices", "/map", "/catalog", "/pricing",
         "/login", "/submit"]

AUDIT = r"""() => {
  const de = document.documentElement;
  const out = {overflow: de.scrollWidth - de.clientWidth,
               taps: [], small: [], wide: [], fixed: [],
               tapTotal: 0, tapBad: 0, minFont: 99,
               inputsSmall: 0, inputsTotal: 0, docH: de.scrollHeight};

  // ---- horizontal overflow culprits
  document.querySelectorAll('*').forEach(el => {
    const r = el.getBoundingClientRect();
    if (r.width > de.clientWidth + 2 && r.height > 0 && out.wide.length < 6)
      out.wide.push({t: el.tagName + '.' + String(el.className || '').slice(0, 26),
                     w: Math.round(r.width)});
  });

  // ---- touch targets
  const SEL = 'a,button,input,select,textarea,[role=button],summary,label.check';
  document.querySelectorAll(SEL).forEach(el => {
    let r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none') return;

    // .stretch-link uses ::after{inset:0} to make the WHOLE card tappable,
    // so its own text box badly understates the real hit area.
    if (el.classList.contains('stretch-link')) {
      const card = el.closest('.card, article, .item-card');
      if (card) r = card.getBoundingClientRect();
    }
    // Elements that grow their hit area with a transparent ::after inset.
    // The drawn box stays small on purpose (a 44px map pin would be bad
    // cartography); the tappable area is what matters. Verified by a real
    // off-centre click in the map test.
    const grown = el.matches('.bz-pin, .leaflet-marker-icon');
    if (grown) {
      const ins = 11;   // matches the ::after inset in main.css
      r = {width: r.width + ins * 2, height: r.height + ins * 2};
    }
    // Leaflet's own attribution link is third-party chrome we do not own
    if (el.closest('.leaflet-control-attribution')) return;
    // A checkbox wrapped in a <label> is tapped via the label, which is the
    // recommended pattern: keep the box visually small, make the whole row
    // the target. Measure the label, not the 26px box inside it.
    if (el.matches('input[type=checkbox], input[type=radio]')) {
      const lab = el.closest('label');
      if (lab) r = lab.getBoundingClientRect();
    }
    out.tapTotal++;
    if (Math.min(r.width, r.height) < 44) {
      out.tapBad++;
      if (out.taps.length < 12)
        out.taps.push({t: (el.tagName + '.' + String(el.className || '').split(' ')[0]).slice(0, 32),
                       txt: (el.textContent || '').trim().slice(0, 20),
                       w: Math.round(r.width), h: Math.round(r.height)});
    }
  });

  // ---- rendered text size
  document.querySelectorAll('p,span,a,li,td,small,label,div,strong,time').forEach(el => {
    if (el.children.length) return;
    const txt = (el.textContent || '').trim();
    if (!txt) return;
    const fs = parseFloat(getComputedStyle(el).fontSize);
    if (!fs) return;
    if (el.closest('.bottom-nav')) return;
    if (fs < out.minFont) out.minFont = fs;
    // bottom-nav labels are a documented 11px exception: a 22px icon
    // carries the meaning and the whole 72x60 cell is the target
    if (el.closest('.bottom-nav')) return;
    if (fs < 12 && out.small.length < 8)
      out.small.push({txt: txt.slice(0, 22), fs: Math.round(fs * 10) / 10,
                      cls: String(el.className || el.tagName).slice(0, 22)});
  });

  // ---- iOS zoom trap
  document.querySelectorAll('input,select,textarea').forEach(el => {
    out.inputsTotal++;
    if (parseFloat(getComputedStyle(el).fontSize) < 16) out.inputsSmall++;
  });

  // ---- fixed chrome (ignore full-screen decorative layers)
  document.querySelectorAll('*').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.position !== 'fixed' && cs.position !== 'sticky') return;
    const r = el.getBoundingClientRect();
    if (r.height <= 0 || r.width < 60) return;
    if (r.height >= window.innerHeight) return;      // background layers
    out.fixed.push({t: (el.tagName + '.' + String(el.className || '').split(' ')[0]).slice(0, 24),
                    h: Math.round(r.height), pos: cs.position});
  });
  return out;
}"""

fails = 0
with sync_playwright() as p:
    br = p.chromium.launch()
    for name, w, h, dpr in PHONES:
        ctx = br.new_context(viewport={"width": w, "height": h},
                             device_scale_factor=dpr, is_mobile=True,
                             has_touch=True)
        pg = ctx.new_page()
        print(f"\n\033[1m═══ {name}  {w}×{h} @{dpr}x ═══\033[0m")
        for u in PAGES:
            try:
                pg.goto(BASE + u, timeout=25000)
                pg.wait_for_load_state("networkidle")
                pg.wait_for_timeout(500)
                r = pg.evaluate(AUDIT)
            except Exception as e:
                print(f"  {u:22s} \033[31mERR\033[0m {str(e)[:44]}")
                fails += 1
                continue

            bad = (r["overflow"] > 1 or r["tapBad"] > 0
                   or r["minFont"] < 12 or r["inputsSmall"] > 0)
            if bad:
                fails += 1
            mark = "\033[31m✗\033[0m" if bad else "\033[32m✓\033[0m"
            print(f"  {mark} {u:22s} overflow={r['overflow']:>3}  "
                  f"tap<44:{r['tapBad']:>3}/{r['tapTotal']:<3} "
                  f"minFont={r['minFont']:.0f}px  "
                  f"input<16:{r['inputsSmall']}  h={r['docH']}")

            if bad and name.startswith("Galaxy A"):
                for t in r["taps"][:6]:
                    print(f"        tap {t['w']:>3}×{t['h']:<3} {t['t']:32s} {t['txt']}")
                for t in r["small"][:5]:
                    print(f"        {t['fs']}px  {t['cls']:22s} {t['txt']}")
                for t in r["wide"][:3]:
                    print(f"        wide {t['w']}px  {t['t']}")
        if name.startswith("Galaxy A"):
            chrome = sum(f["h"] for f in r["fixed"])
            print(f"      fixed chrome: {chrome}px of {h}px "
                  f"({round(chrome / h * 100)}% of screen)")
            for f in r["fixed"]:
                print(f"        {f['h']:>3}px {f['pos']:7s} {f['t']}")
        ctx.close()
    br.close()

print(f"\n\033[1m{'=' * 58}\033[0m")
if fails:
    print(f"\033[1m\033[31m  {fails} صفحه/دستگاه ایراد دارد\033[0m")
else:
    print("\033[1m\033[32m  همهٔ صفحه‌ها روی موبایل سالم‌اند\033[0m")
print(f"\033[1m{'=' * 58}\033[0m\n")
sys.exit(1 if fails else 0)
