# -*- coding: utf-8 -*-
"""Measure whether the header nav actually fits, at every width that matters.

Guessing a breakpoint is how the header ended up overflowing silently. This
prints the real numbers so a decision about adding a nav link is made against
measurements rather than intuition.

    python3 tools/navfit.py            (needs a server on :8003, or set BZ)
"""
import os, sys
from playwright.sync_api import sync_playwright

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")
WIDTHS = [1920, 1680, 1600, 1560, 1500, 1440, 1400, 1366, 1280,
          1024, 900, 760, 640, 420, 360]

bad = 0
with sync_playwright() as p:
    br = p.chromium.launch()
    pg = br.new_page(viewport={"width": 1920, "height": 900})
    pg.goto(BASE + "/"); pg.wait_for_load_state("networkidle")
    d = pg.evaluate("""() => {
      const hdr=document.querySelector('header');
      const inner=hdr.querySelector('.container-wide')||hdr.firstElementChild;
      const nav=hdr.querySelector('nav');
      const kids=[...inner.children].map(c=>({cls:(c.className||'').split(' ')[0],
                                              w:Math.round(c.scrollWidth)}));
      return {kids, navW:Math.round(nav.scrollWidth),
              links:[...nav.querySelectorAll('a')].map(a=>
                ({t:a.textContent.trim(), w:Math.round(a.getBoundingClientRect().width)}))};
    }""")
    print("\n\033[1mسهم هر بخش از هدر\033[0m")
    for k in d["kids"]:
        print(f"  {k['cls']:18s} {k['w']:5d}px")
    print(f"\n\033[1m{len(d['links'])} لینک ناوبری\033[0m")
    for l in d["links"]:
        print(f"  {l['t']:20s} {l['w']:4d}px")
    print(f"\n  مجموع نیاز ناوبری: {d['navW']}px")
    pg.close()

    print("\n\033[1mسرریز در عرض‌های مختلف\033[0m")
    for w in WIDTHS:
        pg = br.new_page(viewport={"width": w, "height": 900})
        pg.goto(BASE + "/"); pg.wait_for_load_state("networkidle")
        pg.wait_for_timeout(250)
        r = pg.evaluate("""() => {
          const de=document.documentElement;
          const hdr=document.querySelector('header');
          const inner=hdr.querySelector('.container-wide')||hdr.firstElementChild;
          const nav=hdr.querySelector('nav');
          return {page:de.scrollWidth-de.clientWidth,
                  header:inner.scrollWidth-inner.clientWidth,
                  nav: nav ? getComputedStyle(nav).display!=='none' : false};
        }""")
        over = r["page"] > 1 or r["header"] > 1
        if over: bad += 1
        mark = "\033[31m ✗ سرریز\033[0m" if over else "\033[32m ✓\033[0m"
        print(f"  {w:5d}px  صفحه {r['page']:3d}  هدر {r['header']:3d}  "
              f"منو={'باز' if r['nav'] else 'همبرگری'}{mark}")
        pg.close()
    br.close()

ok_msg = '\033[32m  همه‌چیز جا می‌شود\033[0m'
bad_msg = f'\033[31m  {bad} عرض سرریز دارد\033[0m'
print(f"\n{ok_msg if not bad else bad_msg}\n")
sys.exit(1 if bad else 0)
