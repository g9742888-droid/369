# -*- coding: utf-8 -*-
"""
"الان باز است" — the live trading-status feature.

Two things are being proved here:

  1. db.open_state() is correct at the edges, not just the easy middle of a
     working day: the minute a shop opens, the minute it shuts, ranges that
     wrap past midnight, a day that is closed, and a shop with no hours at
     all (which must be reported as unknown, never guessed).

  2. The answer the SERVER renders is the answer the PAGE shows, and the
     "فقط باز" filter really filters instead of being decorative.

Run the site first, then:
    BZ=http://127.0.0.1:8080 python3 tools/test_open.py
"""

import os
import sys
import json
import datetime
import urllib.parse
import urllib.request
import urllib.error

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "server"))
import db  # noqa: E402

BASE = os.environ.get("BZ", "http://127.0.0.1:8080").rstrip("/")

ok_n = bad_n = 0
FAILS = []


def check(label, cond, detail=""):
    global ok_n, bad_n
    if cond:
        ok_n += 1
        print(f"  \033[32m✓\033[0m {label}")
    else:
        bad_n += 1
        FAILS.append(f"{label} — {detail}")
        print(f"  \033[31m✗\033[0m {label}  {detail}")


def head(t):
    print(f"\n\033[1m── {t}\033[0m")


def get(path):
    try:
        r = urllib.request.urlopen(BASE + path, timeout=25)
        return r.getcode(), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:
        return 0, str(e)


def at(day_key, hhmm):
    """Build a datetime whose weekday matches day_key and whose clock is hhmm."""
    want = db.DAY_KEYS.index(day_key)
    base = db.iran_now().replace(second=0, microsecond=0)
    base += datetime.timedelta(days=(want - base.weekday()) % 7)
    h, m = map(int, hhmm.split(":"))
    return base.replace(hour=h, minute=m)


print(f"\n\033[1m\033[36mآزمون «الان باز است» — {BASE}\033[0m")

# ------------------------------------------------------------------ unit
head("۱) ساعت ساده ۹ تا ۲۱")
SHOP = {"hours_map": {d: [["09:00", "21:00"]] for d in db.DAY_KEYS}}
cases = [
    ("09:00", "open",    "دقیقهٔ باز شدن، باز است"),
    ("08:59", "closed",  "یک دقیقه قبل از باز شدن، بسته است"),
    ("14:00", "open",    "وسط روز باز است"),
    ("20:00", "closing", "یک ساعت مانده، «در حال بستن»"),
    ("20:59", "closing", "یک دقیقه مانده، هنوز باز ولی هشدار"),
    ("21:00", "closed",  "دقیقهٔ بسته شدن، بسته است"),
    ("23:30", "closed",  "شب بسته است"),
]
for t, want, label in cases:
    got = db.open_state(SHOP, at("sat", t))["state"]
    check(f"{label} ({t})", got == want, f"انتظار {want}، دریافت {got}")

head("۲) ساعتی که از نیمه‌شب رد می‌شود (۲۰:۰۰ تا ۰۲:۰۰)")
LATE = {"hours_map": {d: [["20:00", "02:00"]] for d in db.DAY_KEYS}}
for t, want, label in [("21:00", "open",    "شب باز است"),
                       ("23:59", "open",    "لحظهٔ قبل از نیمه‌شب باز است"),
                       ("00:30", "open",    "بعد از نیمه‌شب هنوز باز است"),
                       ("01:30", "closing", "نیم‌ساعت مانده، هشدار بستن"),
                       ("02:00", "closed",  "ساعت ۲ بسته می‌شود"),
                       ("12:00", "closed",  "ظهر بسته است")]:
    got = db.open_state(LATE, at("sat", t))["state"]
    check(f"{label} ({t})", got == want, f"انتظار {want}، دریافت {got}")

head("۳) دو شیفت با تعطیلی ظهر")
SPLIT = {"hours_map": {d: [["08:30", "13:00"], ["17:00", "20:00"]]
                       for d in db.DAY_KEYS}}
for t, want, label in [("09:00", "open",   "شیفت صبح باز"),
                       ("14:30", "closed", "تعطیلی ظهر بسته"),
                       ("18:00", "open",   "شیفت عصر باز")]:
    got = db.open_state(SPLIT, at("sat", t))["state"]
    check(f"{label} ({t})", got == want, f"انتظار {want}، دریافت {got}")

st = db.open_state(SPLIT, at("sat", "14:30"))
check("در تعطیلی ظهر، ساعت بازگشایی را می‌گوید",
      "۱۷:۰۰" in st["detail"], st["detail"])

head("۴) جمعه تعطیل")
FRI_OFF = {"hours_map": {d: [["09:00", "18:00"]]
                         for d in db.DAY_KEYS if d != "fri"}}
st = db.open_state(FRI_OFF, at("fri", "12:00"))
check("جمعه بسته است", st["state"] == "closed", st["state"])
# Friday is the last day of the Iranian week, so the next opening is
# Saturday — which the UI phrases as "فردا" because that is what a person
# would say out loud.
check("و می‌گوید فردا (شنبه) باز می‌شود",
      "فردا" in st["detail"] or "شنبه" in st["detail"], st["detail"])

head("۵) صداقت وقتی ساعت ثبت نشده")
for empty in ({"hours_map": {}}, {"hours_map": {"sat": []}}, {}):
    st = db.open_state(empty)
    check("بدون ساعت کاری، «نامشخص» است — نه باز، نه بسته",
          st["state"] == "unknown", st["state"])

head("۶) ورودی خراب باعث خطا نمی‌شود")
for bad in ({"hours_map": {"sat": [["پنج", "شش"]]}},
            {"hours_map": {"sat": [["25:99", "40:00"]]}},
            {"hours_map": {"sat": [["09:00"]]}},
            {"hours_map": {"sat": "not-a-list"}}):
    try:
        st = db.open_state(bad)
        # unreadable hours must read as "unknown", never as a confident
        # "closed" — the shop is not shut, the data is simply unusable
        check(f"ورودی نامعتبر → «نامشخص» (نه «بسته») ", st["state"] == "unknown",
              f"دریافت {st['state']}")
    except Exception as e:
        check("ورودی نامعتبر نباید خطا بدهد", False, f"{type(e).__name__}: {e}")

head("۷) ارقام فارسی در متن")
st = db.open_state(SHOP, at("sat", "20:30"))
check("شمارش معکوس با رقم فارسی است",
      any(c in st["label"] for c in "۰۱۲۳۴۵۶۷۸۹") and
      not any(c.isdigit() and c.isascii() for c in st["label"]),
      st["label"])

head("۸) is_open_now با open_state هم‌خوان است")
for t in ("09:00", "14:00", "20:30", "21:00", "03:00"):
    s2 = db.open_state(SHOP, at("sat", t))
    check(f"هم‌خوانی در {t}",
          db.is_open_now(SHOP, at("sat", t)) ==
          (s2["state"] in ("open", "closing")), s2["state"])

# ------------------------------------------------------------- integration
head("۹) صفحه همان چیزی را نشان می‌دهد که سرور می‌داند")
code, html = get("/businesses")
check("فهرست کسب‌وکارها باز می‌شود", code == 200, f"code={code}")

rows = db.annotate_open(db.businesses(status="published", limit=60))
if rows:
    counts = {}
    for b in rows:
        counts[b["open_state"]["state"]] = counts.get(b["open_state"]["state"], 0) + 1
    print(f"     وضعیت واقعی داده‌ها: {counts}")
    for state, n in counts.items():
        check(f"نشان «{state}» روی صفحه هست ({n} مورد)",
              f'data-open="{state}"' in html, "")

    b0 = rows[0]
    code, bhtml = get(f"/b/{b0['slug']}")
    check("صفحهٔ کسب‌وکار باز می‌شود", code == 200, f"code={code}")
    if b0["open_state"]["state"] != "unknown":
        check("نوار وضعیت روی صفحهٔ کسب‌وکار هست",
              "data-open-line" in bhtml, "")
        check("متن وضعیت با محاسبهٔ سرور یکی است",
              b0["open_state"]["label"] in bhtml, b0["open_state"]["label"])

head("۱۰) فیلتر «فقط باز» واقعاً فیلتر می‌کند")
code, all_html = get("/businesses")
code, open_html = get("/businesses?open=1")
n_all = all_html.count('data-open="')
n_open = open_html.count('data-open="')
n_closed_all = all_html.count('data-open="closed"')
check("صفحهٔ فیلترشده باز می‌شود", code == 200, f"code={code}")
_n_closed_open = open_html.count('data-open="closed"')
check("هیچ کسب‌وکار بسته‌ای در نتیجهٔ فیلتر نیست",
      _n_closed_open == 0,
      f"{_n_closed_open} مورد بسته")
if n_closed_all:
    check("فیلتر واقعاً چیزی را حذف کرده",
          n_open < n_all, f"{n_all} -> {n_open}")
else:
    print("     (همهٔ کسب‌وکارها الان بازند؛ حذفی قابل سنجش نیست)")
check("تیک فیلتر پس از ارسال باقی می‌ماند",
      "data-dir-open checked" in open_html, "")

head("۱۱) فیلتر، کسب‌وکار بدون ساعت را حذف نمی‌کند")
# a blank hours field is a missing field, not a closed shop — punishing it
# would hide a real business for a clerical omission
saved = {}
target = None
for b in db.businesses(status="published", limit=5):
    target = b
    break
if target:
    saved = db.business(bid=target["id"])
    db._run("UPDATE businesses SET hours='' WHERE id=?", (target["id"],))
    code, h = get("/businesses?open=1")
    fresh = db.business(bid=target["id"])
    check("کسب‌وکار بدون ساعت کاری در فیلتر «فقط باز» می‌ماند",
          db.open_state(fresh)["state"] == "unknown" and target["slug"] in h,
          "حذف شد")
    db._run("UPDATE businesses SET hours=? WHERE id=?",
            (saved.get("hours") or "", target["id"]))

head("۱۲) پارامتر open_now در search() دیگر بی‌اثر نیست")
a = db.search()
b = db.search(open_now=True)
check("search(open_now=True) نتیجهٔ متفاوت یا مساوی می‌دهد، نه خطا",
      isinstance(b, list) and len(b) <= len(a), f"{len(a)} vs {len(b)}")
check("و هیچ بسته‌ای در آن نیست",
      all(db.open_state(x)["state"] != "closed" for x in b), "")

print(f"\n\033[1m{'='*58}\033[0m")
if bad_n == 0:
    print(f"\033[1m\033[32m  همه موفق — {ok_n} آزمون، ۰ ناموفق\033[0m")
else:
    print(f"\033[1m\033[31m  {ok_n} موفق، {bad_n} ناموفق\033[0m")
    for f in FAILS:
        print(f"    • {f}")
print(f"\033[1m{'='*58}\033[0m\n")
sys.exit(1 if bad_n else 0)
